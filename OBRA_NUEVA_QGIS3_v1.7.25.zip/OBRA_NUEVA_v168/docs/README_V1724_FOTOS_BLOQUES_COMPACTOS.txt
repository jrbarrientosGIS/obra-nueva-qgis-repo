OBRA_NUEVA 1.7.24 - Fotos: bloques 1 y 2 compactos
==================================================

- Los bloques 1 y 2 de la pestaña Fotos miden solo lo que necesitan.
- La cola de fotos del bloque 2 se ajusta a sus filas (entre 3 y 6; con mas, aparece la barra de desplazamiento).
- El bloque 3 aprovecha todo el espacio restante.
- Deja de forzarse el mismo alto en los tres bloques (V1.7.17).
- La 1.7.23 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.23.zip y OBRA_NUEVA_QGIS4_v1.7.23.zip.

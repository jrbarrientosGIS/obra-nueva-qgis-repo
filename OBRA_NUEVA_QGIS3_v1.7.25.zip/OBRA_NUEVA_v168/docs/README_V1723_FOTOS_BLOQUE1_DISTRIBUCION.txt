OBRA_NUEVA 1.7.23 - Fotos, bloque 1: distribucion
=================================================

- La lista de GeoPackage se ajusta a sus filas (entre 3 y 8; con mas, aparece
  la barra de desplazamiento) y ya no deja un hueco vacio debajo.
- El boton «1) Georref fotos ambitos» se coloca a la izquierda, justo debajo de
  la lista.
- La 1.7.22 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.22.zip y
  OBRA_NUEVA_QGIS4_v1.7.22.zip.

OBRA_NUEVA 1.7.25 - Fotos: listas de al menos tres filas
==================================================

- Todas las listas de Fotos (GeoPackage del bloque 1, cola del bloque 2 y lista del bloque 3) muestran al menos tres filas completas, tambien con hojas de estilo de relleno grande.
- Las alturas se recalculan al mostrarse la pestana.
- Bloque 2: el boton «2) Iniciar / continuar colocacion» esta en la misma fila que los demas botones.
- La 1.7.24 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.24.zip y OBRA_NUEVA_QGIS4_v1.7.24.zip.

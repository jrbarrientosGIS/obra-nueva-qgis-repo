OBRA_NUEVA 1.7.22 - Fotos, bloque 1: coordenadas en la foto original
====================================================================

- Desaparecen «Solo entidades seleccionadas» e «Intentar escribir
  coordenadas GPS EXIF en JPG».
- El botón «1) Georref fotos ámbitos» ya no exporta: escribe (EXIF GPS) en
  cada foto original las coordenadas del centroide de su entidad (WGS84).
- Se procesan todas las entidades de las capas operativas de los GeoPackages
  marcados. Antes se pide confirmación, porque se modifican originales.
- Las fotos que ya están en su sitio (a menos de ~0,2 m) se omiten. La fecha de
  modificación del fichero no cambia.
- Las fotos que no son JPG no se tocan: se cuentan y se indican en el resumen.
- Si una foto pertenece a varias entidades, vale la primera.
- El bloque 1 se reorganiza: el árbol de GeoPackages ocupa todo el espacio.
- Bloque 3, «Exportar a carpeta»: ahora siempre graba el GPS en las copias.
- La 1.7.21 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.21.zip y
  OBRA_NUEVA_QGIS4_v1.7.21.zip.

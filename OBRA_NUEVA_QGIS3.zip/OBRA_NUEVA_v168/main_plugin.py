# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from .ui.main_dialog import ObraNuevaMainDialog


class ObraNuevaPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.action = QAction(QIcon(icon_path), 'OBRA_NUEVA', self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu('OBRA_NUEVA', self.action)

    def unload(self):
        # V1.7.16: al descargar el plugin se cancela la herramienta de colocar
        # fotos (si estaba activa en el lienzo) y se cierra el diálogo.
        if self.dialog is not None:
            try:
                from .ui.tab_fotos import FotosTab
                for tab in self.dialog.findChildren(FotosTab):
                    tab.cancel_placement(silent=True)
            except Exception:
                pass
            try:
                self.dialog.close()
                self.dialog.deleteLater()
            except Exception:
                pass
            self.dialog = None
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu('OBRA_NUEVA', self.action)
            self.action = None

    def run(self):
        if self.dialog is None:
            self.dialog = ObraNuevaMainDialog(self.iface)
            self.dialog.setWindowModality(Qt.NonModal)
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()

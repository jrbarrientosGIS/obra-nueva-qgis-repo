# -*- coding: utf-8 -*-
BASE_LAYER_PATTERNS = {
    'Estaciones': ['estaciones'],
    'PK': ['pk'],
    'Lineas_FFCC': ['lineas_ffcc', 'líneas_ffcc', 'lineas ferrocarril', 'lineas_ffcc'],
}

OPERATIVE_LAYER_PATTERNS = {
    'Puntos': ['puntos'],
    'Lineas': ['lineas', 'líneas'],
    'Poligonos': ['poligonos', 'polígonos', 'poligonos'],
}


def classify_layer_name(name):
    lower_name = name.lower()
    for canonical, patterns in BASE_LAYER_PATTERNS.items():
        if any(pattern in lower_name for pattern in patterns):
            return 'Base', canonical
    for canonical, patterns in OPERATIVE_LAYER_PATTERNS.items():
        if any(pattern in lower_name for pattern in patterns):
            return 'Operativas', canonical
    return 'Auxiliares', name

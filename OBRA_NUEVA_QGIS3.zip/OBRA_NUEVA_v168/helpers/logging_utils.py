# -*- coding: utf-8 -*-
from qgis.core import QgsMessageLog, Qgis


PLUGIN_TAG = 'OBRA_NUEVA'


def log_info(message):
    QgsMessageLog.logMessage(str(message), PLUGIN_TAG, Qgis.Info)


def log_warning(message):
    QgsMessageLog.logMessage(str(message), PLUGIN_TAG, Qgis.Warning)


def log_error(message):
    QgsMessageLog.logMessage(str(message), PLUGIN_TAG, Qgis.Critical)

# -*- coding: utf-8 -*-
import os


def normalize_base_name(path):
    return os.path.splitext(os.path.basename(path))[0]


def ensure_directory(path):
    os.makedirs(path, exist_ok=True)
    return path


def safe_join(*parts):
    return os.path.normpath(os.path.join(*parts))

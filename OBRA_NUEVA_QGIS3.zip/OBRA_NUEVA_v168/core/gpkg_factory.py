# -*- coding: utf-8 -*-
import os
import shutil

from ..helpers.logging_utils import log_info


class GpkgFactory:
    def create_from_template(self, source_gpkg, output_dir, output_name, overwrite=False):
        if not os.path.exists(source_gpkg):
            raise FileNotFoundError(f'No existe el GeoPackage origen: {source_gpkg}')
        os.makedirs(output_dir, exist_ok=True)
        if not output_name.lower().endswith('.gpkg'):
            output_name = f'{output_name}.gpkg'
        target_path = os.path.join(output_dir, output_name)
        if os.path.exists(target_path):
            if not overwrite:
                raise FileExistsError(f'El archivo de salida ya existe: {target_path}')
            os.remove(target_path)
        shutil.copy2(source_gpkg, target_path)
        log_info(f'GeoPackage creado: {target_path}')
        return target_path

    def load_created_gpkg(self, gpkg_path, load_mode='all', no_duplicates=True, skip_empty=False):
        from .gpkg_loader import GpkgLoader
        return GpkgLoader().load_grouped_gpkg(gpkg_path, load_mode=load_mode, no_duplicates=no_duplicates, skip_empty=skip_empty)

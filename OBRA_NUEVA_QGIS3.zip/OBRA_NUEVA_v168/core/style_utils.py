# -*- coding: utf-8 -*-


class StyleUtils:
    """
    Utilidades de estilo para KML. Esta versión prioriza estabilidad y una salida limpia.
    La traducción exacta renderer->KML sigue siendo un punto de validación fina en QGIS.
    """

    @staticmethod
    def geometry_style(geometry_type):
        if geometry_type == 0:  # point
            return {
                'icon_href': 'http://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png',
                'icon_scale': '1.1',
                'line_color': 'ff00ffff',
                'poly_color': '7f00ffff',
                'line_width': '2',
            }
        if geometry_type == 1:  # line
            return {
                'line_color': 'ff0000ff',
                'line_width': '2.5',
                'poly_color': '00000000',
            }
        return {
            'line_color': 'ff0000ff',
            'line_width': '1.5',
            'poly_color': '7f0000ff',
        }

# -*- coding: utf-8 -*-
"""
OBRA_NUEVA - Actualizador de estructura de GeoPackage.

Sincroniza la estructura (campos y, opcionalmente, tablas) de un GeoPackage
"antiguo" con la de un GeoPackage "modelo" más reciente, sin tocar ni perder
en ningún momento las entidades gráficas ni los datos ya existentes:

  * Los campos que existan en el modelo y falten en el antiguo se añaden
    (ALTER TABLE ... ADD COLUMN), siempre como opcionales (nullable), para no
    invalidar registros ya cargados.
  * Los campos que existan en el antiguo y no en el modelo NUNCA se tocan ni
    se eliminan: se conservan tal cual (se informa de ellos como "extra").
  * Las tablas del modelo que no tengan equivalente en el antiguo pueden
    crearse vacías (misma estructura de campos, geometría y CRS) si el
    usuario lo solicita.
  * La correspondencia entre tablas operativas (Puntos/Líneas/Polígonos) se
    hace por rol, no por nombre exacto, ya que cada obra nombra sus tablas
    con un prefijo distinto (p.ej. "SDON_78_Puntos" frente a
    "SDONO120_Puntos"): así nunca se renombra ni se toca la tabla original.
"""
import os
import re
import shutil
import sqlite3
from datetime import datetime

from qgis.core import (
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
    QgsCoordinateTransformContext,
)

from .gpkg_utils import GpkgIntrospector, normalize_text
from ..helpers.logging_utils import log_info, log_warning

ROLES = ('Puntos', 'Lineas', 'Poligonos')
IGNORED_COLUMN_KEYS = ('fid', 'geom', 'geometry')
NON_STYLED_TABLES = ('clave', 'layer_styles')

# Sufijo que _make_backup() añade a las copias de seguridad, p.ej.
# "..._backup_20260901_101638.gpkg". Se usa para no volver a tratar una
# copia de seguridad como si fuera un GeoPackage de obra más al buscar en
# una carpeta de forma recursiva.
_BACKUP_SUFFIX_RE = re.compile(r'_backup_\d{8}_\d{6}$')


def scan_gpkg_files_recursive(folder_path, exclude_paths=None, progress_cb=None):
    """Busca de forma recursiva (incluidas todas las subcarpetas) todos los
    archivos .gpkg dentro de folder_path.

    Excluye:
      * las rutas indicadas en exclude_paths (comparación por ruta absoluta
        normalizada; se usa típicamente para no incluir el propio GPKG
        modelo si está dentro de la misma carpeta),
      * las copias de seguridad que crea este mismo módulo
        (sufijo "_backup_AAAAMMDD_HHMMSS"), para que una ejecución posterior
        no las trate como obras a actualizar.

    Si se pasa `progress_cb`, se llama tras revisar cada subcarpeta como
    `progress_cb(current_dir, dirs_visited, found_count)` -- para que un
    llamador con interfaz gráfica pueda mostrar avance real (p. ej. una
    barra de progreso) mientras dura el recorrido de una carpeta grande,
    en vez de quedarse congelado hasta que termina. Cualquier excepción
    del callback se ignora (nunca debe interrumpir la búsqueda).

    Devuelve una lista de rutas absolutas, ordenada alfabéticamente.
    """
    exclude_norm = {
        os.path.normcase(os.path.abspath(p)) for p in (exclude_paths or []) if p
    }
    found = []
    dirs_visited = 0
    for root, _dirs, files in os.walk(folder_path):
        dirs_visited += 1
        for name in files:
            if not name.lower().endswith('.gpkg'):
                continue
            full_path = os.path.join(root, name)
            if os.path.normcase(os.path.abspath(full_path)) in exclude_norm:
                continue
            stem = os.path.splitext(name)[0]
            if _BACKUP_SUFFIX_RE.search(stem):
                continue
            found.append(full_path)
        if progress_cb is not None:
            try:
                progress_cb(root, dirs_visited, len(found))
            except Exception:
                pass
    found.sort(key=lambda p: os.path.normcase(p))
    return found


def _type_base(type_str):
    """'TEXT(254)' -> 'TEXT' — compara solo la afinidad de tipo, no la anchura."""
    t = (type_str or '').strip().upper()
    idx = t.find('(')
    if idx >= 0:
        t = t[:idx]
    return t.strip() or 'TEXT'


class TableDiff:
    """Diferencias de estructura entre una tabla del GPKG antiguo y su
    equivalente en el GPKG modelo."""

    def __init__(self, role, old_table, model_table):
        self.role = role                # 'Puntos' / 'Lineas' / 'Poligonos' / None
        self.old_table = old_table
        self.model_table = model_table
        self.add_columns = []           # [{'name','type','notnull',...}, ...] a añadir al antiguo
        self.extra_in_old = []          # nombres de columnas del antiguo que no están en el modelo
        self.type_mismatch = []         # [(nombre, tipo_antiguo, tipo_modelo), ...]
        self.geom_mismatch = None       # (tipo_antiguo, tipo_modelo) si difiere el tipo de geometría
        self.style_status = 'skip'      # 'match' | 'missing' | 'different' | 'skip'

    @property
    def has_changes(self):
        return bool(self.add_columns)

    @property
    def needs_style_sync(self):
        return self.style_status in ('missing', 'different')


class GpkgUpdatePlan:
    def __init__(self, model_path, old_path):
        self.model_path = model_path
        self.old_path = old_path
        self.pairs = []           # [TableDiff, ...]
        self.new_tables = []      # tablas del modelo sin equivalente en el antiguo
        self.unmatched_old_roles = []  # roles presentes en el antiguo que el modelo no define

    def has_changes(self):
        return bool(self.new_tables) or any(p.has_changes for p in self.pairs)

    def total_new_fields(self):
        return sum(len(p.add_columns) for p in self.pairs)

    def total_style_updates(self):
        return sum(1 for p in self.pairs if p.needs_style_sync)


class GpkgStructureUpdater:

    # ── Análisis ─────────────────────────────────────────────────────────
    def analyze(self, model_path, old_path):
        plan = GpkgUpdatePlan(model_path, old_path)

        model_intro = GpkgIntrospector(model_path)
        old_intro = GpkgIntrospector(old_path)

        model_roles = model_intro.detect_operational_tables()
        old_roles = old_intro.detect_operational_tables()

        matched_model_tables = set()

        for role in ROLES:
            model_table = model_roles.get(role)
            old_table = old_roles.get(role)
            if model_table:
                matched_model_tables.add(model_table)
            if old_table and model_table:
                plan.pairs.append(
                    self._diff_tables(role, old_table, old_intro, model_table, model_intro)
                )
            elif old_table and not model_table:
                plan.unmatched_old_roles.append(role)
                log_warning(
                    f'El GPKG modelo no define capa de rol "{role}"; '
                    f'se conserva "{old_table}" sin cambios.'
                )

        # Tablas "con nombre propio" (no operativas): CLAVE, layer_styles,
        # y cualquier otra capa base/de referencia del modelo (Estaciones,
        # Lineas_FFCC, pk, ...).
        model_named = [t for t in model_intro.list_feature_tables() if t not in matched_model_tables]
        old_role_tables = {v for v in old_roles.values() if v}
        old_named = [t for t in old_intro.list_feature_tables() if t not in old_role_tables]

        old_named_by_norm = {normalize_text(t): t for t in old_named}
        for model_table in model_named:
            old_table = old_named_by_norm.get(normalize_text(model_table))
            if old_table:
                plan.pairs.append(
                    self._diff_tables(None, old_table, old_intro, model_table, model_intro)
                )
            else:
                plan.new_tables.append(model_table)

        return plan

    def _diff_tables(self, role, old_table, old_intro, model_table, model_intro):
        diff = TableDiff(role, old_table, model_table)

        old_cols = old_intro.table_columns_full(old_table)
        model_cols = model_intro.table_columns_full(model_table)

        old_by_norm = {normalize_text(c['name']): c for c in old_cols if normalize_text(c['name']) not in IGNORED_COLUMN_KEYS}
        model_by_norm = {normalize_text(c['name']): c for c in model_cols if normalize_text(c['name']) not in IGNORED_COLUMN_KEYS}

        for key, col in model_by_norm.items():
            if key not in old_by_norm:
                diff.add_columns.append(col)
            else:
                old_col = old_by_norm[key]
                if _type_base(old_col['type']) != _type_base(col['type']):
                    diff.type_mismatch.append((col['name'], old_col['type'], col['type']))

        for key, col in old_by_norm.items():
            if key not in model_by_norm:
                diff.extra_in_old.append(col['name'])

        try:
            old_geom = old_intro.geometry_type_by_table().get(old_table)
            model_geom = model_intro.geometry_type_by_table().get(model_table)
            if old_geom and model_geom and old_geom.upper() != model_geom.upper():
                diff.geom_mismatch = (old_geom, model_geom)
        except Exception:
            pass

        diff.style_status = self._compare_styles(old_table, old_intro, model_table, model_intro)

        return diff

    def _compare_styles(self, old_table, old_intro, model_table, model_intro):
        """Compara la leyenda/simbología (tabla layer_styles) de old_table
        frente a model_table. Solo mira metadatos de estilo, nunca datos ni
        geometrías. Devuelve 'skip' si la tabla no es susceptible de tener
        estilo propio (CLAVE, layer_styles, o si el modelo no define uno)."""
        if normalize_text(model_table) in NON_STYLED_TABLES or normalize_text(old_table) in NON_STYLED_TABLES:
            return 'skip'
        try:
            model_qml = model_intro.default_style_qml(model_table)
        except Exception:
            model_qml = None
        if not model_qml:
            return 'skip'
        try:
            old_qml = old_intro.default_style_qml(old_table)
        except Exception:
            old_qml = None
        if not old_qml:
            return 'missing'
        if old_qml == model_qml:
            return 'match'
        return 'different'

    # ── Aplicación ───────────────────────────────────────────────────────
    def apply(self, plan, backup=True, create_missing_tables=True, sync_styles=True, progress_cb=None):
        def log(msg):
            if progress_cb:
                progress_cb(msg)
            log_info(msg)

        result = {'backup_path': None, 'fields_added': 0, 'tables_created': [], 'styles_synced': 0}

        if backup:
            backup_path = self._make_backup(plan.old_path)
            result['backup_path'] = backup_path
            log(f'🗄  Copia de seguridad creada: {backup_path}')

        conn = sqlite3.connect(plan.old_path)
        try:
            cur = conn.cursor()
            for diff in plan.pairs:
                for col in diff.add_columns:
                    col_type = col.get('type') or 'TEXT'
                    col_name = col['name']
                    sql = f'ALTER TABLE "{diff.old_table}" ADD COLUMN "{col_name}" {col_type}'
                    cur.execute(sql)
                    result['fields_added'] += 1
                    log(f'＋ {diff.old_table}: campo "{col_name}" ({col_type}) añadido.')
                    if col.get('notnull'):
                        log(
                            f'   ⚠ "{col_name}" es obligatorio en el modelo; '
                            f'se crea como opcional para no afectar registros existentes.'
                        )
            conn.commit()
        except Exception:
            conn.rollback()
            conn.close()
            raise
        conn.close()

        if sync_styles:
            for diff in plan.pairs:
                if not diff.needs_style_sync:
                    continue
                try:
                    n = self._copy_layer_styles(plan.model_path, plan.old_path, diff.model_table, diff.old_table)
                    if n:
                        result['styles_synced'] += 1
                        log(f'🎨 {diff.old_table}: leyenda y simbología actualizada desde el modelo.')
                except Exception as e:
                    log(f'✖ No se pudo sincronizar la leyenda de "{diff.old_table}": {e}')

        if create_missing_tables:
            for table_name in plan.new_tables:
                try:
                    self._create_empty_table_from_model(plan.model_path, plan.old_path, table_name)
                    result['tables_created'].append(table_name)
                    log(f'✚ Tabla nueva "{table_name}" creada (vacía) a partir del modelo.')
                    if sync_styles:
                        try:
                            n = self._copy_layer_styles(plan.model_path, plan.old_path, table_name, table_name)
                            if n:
                                result['styles_synced'] += 1
                                log(f'🎨 {table_name}: leyenda y simbología copiada desde el modelo.')
                        except Exception as e:
                            log(f'✖ No se pudo copiar la leyenda de "{table_name}": {e}')
                except Exception as e:
                    log(f'✖ No se pudo crear la tabla "{table_name}": {e}')

        return result

    def _make_backup(self, path):
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        base, ext = os.path.splitext(path)
        backup_path = f'{base}_backup_{stamp}{ext}'
        shutil.copy2(path, backup_path)
        return backup_path

    def _create_empty_table_from_model(self, model_path, target_path, table_name):
        src_layer = QgsVectorLayer(f'{model_path}|layername={table_name}', table_name, 'ogr')
        if not src_layer.isValid():
            raise RuntimeError(f'No se pudo leer la tabla "{table_name}" del GPKG modelo.')

        wkb_type = src_layer.wkbType()
        if wkb_type in (QgsWkbTypes.NoGeometry, QgsWkbTypes.Unknown):
            uri = 'None'
        else:
            uri = f'{QgsWkbTypes.displayString(wkb_type)}?crs={src_layer.crs().authid()}'

        mem = QgsVectorLayer(uri, table_name, 'memory')
        if not mem.isValid():
            raise RuntimeError(f'No se pudo preparar la estructura en memoria para "{table_name}".')

        prov = mem.dataProvider()
        prov.addAttributes(src_layer.fields())
        mem.updateFields()

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = 'GPKG'
        options.layerName = table_name
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

        write_result = QgsVectorFileWriter.writeAsVectorFormatV3(
            mem, target_path, QgsCoordinateTransformContext(), options,
        )
        err_code, err_msg = write_result[0], write_result[1]
        if err_code != QgsVectorFileWriter.NoError:
            raise RuntimeError(err_msg or f'Error desconocido creando "{table_name}".')

    def _copy_layer_styles(self, model_path, target_path, model_table, target_table):
        """Copia (sustituyendo) las filas de layer_styles del modelo para
        model_table al GeoPackage de destino bajo target_table. Solo toca
        metadatos de leyenda/simbología (tabla layer_styles); nunca modifica
        datos ni geometrías de las capas. Devuelve el número de filas de
        estilo copiadas."""
        try:
            mconn = sqlite3.connect(model_path)
            try:
                mcur = mconn.cursor()
                mcur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='layer_styles'")
                if not mcur.fetchone():
                    return 0
                cur_cols = [r[1] for r in mcur.execute("PRAGMA table_info('layer_styles')").fetchall()]
                cols = [c for c in cur_cols if c != 'id']
                col_list_sql = ', '.join('"' + c + '"' for c in cols)
                rows = mcur.execute(
                    'SELECT {} FROM layer_styles WHERE f_table_name=?'.format(col_list_sql),
                    (model_table,),
                ).fetchall()
            finally:
                mconn.close()
        except Exception as e:
            log_warning(f'No se pudo leer el estilo del modelo para "{model_table}": {e}')
            return 0
        if not rows:
            return 0
        name_idx = cols.index('f_table_name')
        tconn = sqlite3.connect(target_path)
        try:
            tcur = tconn.cursor()
            tcur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='layer_styles'")
            if not tcur.fetchone():
                return 0
            tcur.execute('DELETE FROM layer_styles WHERE f_table_name=?', (target_table,))
            placeholders = ', '.join('?' for _ in cols)
            insert_sql = 'INSERT INTO layer_styles ({}) VALUES ({})'.format(col_list_sql, placeholders)
            count = 0
            for row in rows:
                row = list(row)
                row[name_idx] = target_table
                tcur.execute(insert_sql, row)
                count += 1
            tconn.commit()
            return count
        finally:
            tconn.close()

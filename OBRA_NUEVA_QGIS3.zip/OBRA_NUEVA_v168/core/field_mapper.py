# -*- coding: utf-8 -*-
from .gpkg_utils import normalize_text


class FieldMapper:
    AMBITO_CANDIDATES = ['AMBITO', 'ÁMBITO', 'ambito', 'ámbito', 'N_AMB']
    TIPO_CANDIDATES = ['TIPO', 'tipo', 'N_TIPO']
    CODIGO_CANDIDATES = ['codigo', 'código', 'CODIGO', 'CÓDIGO', 'obra']
    DESC_CANDIDATES = ['descripcion', 'descripción', 'desc', 'texto', 'nombre']

    @staticmethod
    def find_existing_field(fields, candidates):
        names = [f.name() if hasattr(f, 'name') else str(f) for f in fields]
        norm_map = {normalize_text(name): name for name in names}
        for candidate in candidates:
            nc = normalize_text(candidate)
            if nc in norm_map:
                return norm_map[nc]
        for name in names:
            nn = normalize_text(name)
            for candidate in candidates:
                if normalize_text(candidate) in nn:
                    return name
        return None

    @classmethod
    def detect_standard_fields(cls, fields):
        return {
            'ambito': cls.find_existing_field(fields, cls.AMBITO_CANDIDATES),
            'tipo': cls.find_existing_field(fields, cls.TIPO_CANDIDATES),
            'codigo': cls.find_existing_field(fields, cls.CODIGO_CANDIDATES),
            'descripcion': cls.find_existing_field(fields, cls.DESC_CANDIDATES),
        }

    @staticmethod
    def build_lookup_dict(layer, key_field_candidates=None, value_field_candidates=None):
        if layer is None:
            return {}
        key_field_candidates = key_field_candidates or ['CLAVE', 'clave', 'KEY', 'key', 'codigo', 'CODIGO', 'N_AMB', 'N_TIPO']
        value_field_candidates = value_field_candidates or ['DESCRIPCION', 'descripcion', 'Descripción', 'texto', 'nombre', 'DESC']
        fields = layer.fields()
        key_field = FieldMapper.find_existing_field(fields, key_field_candidates)
        value_field = FieldMapper.find_existing_field(fields, value_field_candidates)
        if not key_field or not value_field:
            return {}
        result = {}
        for feat in layer.getFeatures():
            key = feat[key_field]
            val = feat[value_field]
            if key not in (None, '') and val not in (None, ''):
                result[str(key)] = str(val)
        return result

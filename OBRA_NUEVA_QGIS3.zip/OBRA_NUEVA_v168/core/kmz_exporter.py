# -*- coding: utf-8 -*-
from dataclasses import dataclass
import os
import shutil
import sqlite3
import tempfile
import zipfile

from qgis.core import Qgis, QgsFeatureRequest, QgsMessageLog, QgsVectorLayer, QgsWkbTypes

from .legend_pruner import LegendPruner
from .style_utils import StyleUtils
from .gpkg_utils import normalize_text


@dataclass
class KMZExportConfig:
    gpkg_path: str
    operational_layers: dict
    clave_table_name: str
    output_dir: str
    output_name: str
    ambito_field: str
    tipo_field: str
    export_by_ambito: bool = True
    group_by_geometry: bool = True
    include_legend: bool = True
    exclude_leyenda_layer: bool = True
    use_desc_for_ambito: bool = True
    use_desc_for_tipo: bool = True


class KMZExporter:
    def __init__(self, iface=None):
        self.iface = iface
        self.legend_pruner = LegendPruner()

    def export(self, config: KMZExportConfig) -> str:
        self._validate_config(config)

        layers = self._load_operational_layers(config)
        ambito_lookup = self._build_lookup_dict_from_table(config.gpkg_path, config.clave_table_name)
        tipo_lookup = dict(ambito_lookup)

        tmpdir = tempfile.mkdtemp(prefix='obra_nueva_kmz_')
        try:
            doc_kml = os.path.join(tmpdir, 'doc.kml')
            self._write_kml(config, layers, doc_kml, ambito_lookup, tipo_lookup)
            if config.include_legend:
                self._write_legend(config, layers, tmpdir, tipo_lookup)
            kmz_path = os.path.join(config.output_dir, f'{config.output_name}.kmz')
            self._zip_folder(tmpdir, kmz_path)
            return kmz_path
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def _load_operational_layers(self, config):
        result = {}
        for geom_name in ['Puntos', 'Lineas', 'Poligonos']:
            table_name = config.operational_layers.get(geom_name)
            if not table_name:
                continue
            layer = QgsVectorLayer(f'{config.gpkg_path}|layername={table_name}', table_name, 'ogr')
            if layer.isValid():
                result[geom_name] = layer
        if not result:
            raise ValueError('No se han podido abrir capas operativas válidas para el KMZ.')
        return result

    def _write_kml(self, config, layers, output_path, ambito_lookup, tipo_lookup):
        styles = self._build_style_blocks()
        folder_chunks = []

        if config.export_by_ambito:
            grouped = self._group_features_by_ambito(config, layers, ambito_lookup, tipo_lookup)
            for ambito_name in sorted(grouped.keys(), key=lambda x: normalize_text(x)):
                geom_sections = []
                for geom_name in ['Puntos', 'Lineas', 'Poligonos']:
                    placemarks = grouped[ambito_name].get(geom_name, [])
                    if not placemarks:
                        continue
                    if config.group_by_geometry:
                        geom_sections.append(
                            f'<Folder><name>{self._xml(geom_name)}</name>{"".join(placemarks)}</Folder>'
                        )
                    else:
                        geom_sections.extend(placemarks)
                if geom_sections:
                    folder_chunks.append(
                        f'<Folder><name>{self._xml(ambito_name)}</name>{"".join(geom_sections)}</Folder>'
                    )
        else:
            geom_sections = []
            for geom_name in ['Puntos', 'Lineas', 'Poligonos']:
                layer = layers.get(geom_name)
                if not layer:
                    continue
                placemarks = self._build_geom_placemarks(
                    layer=layer,
                    geom_name=geom_name,
                    config=config,
                    current_ambito_name='',
                    tipo_lookup=tipo_lookup
                )
                if not placemarks:
                    continue
                if config.group_by_geometry:
                    geom_sections.append(
                        f'<Folder><name>{self._xml(geom_name)}</name>{"".join(placemarks)}</Folder>'
                    )
                else:
                    geom_sections.extend(placemarks)
            folder_chunks.append(f'<Folder><name>{self._xml(config.output_name)}</name>{"".join(geom_sections)}</Folder>')

        kml = f'''<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>{self._xml(config.output_name)}</name>
    {styles}
    {''.join(folder_chunks)}
  </Document>
</kml>
'''
        with open(output_path, 'w', encoding='utf-8') as fh:
            fh.write(kml)

    def _group_features_by_ambito(self, config, layers, ambito_lookup, tipo_lookup):
        grouped = {}
        for geom_name, layer in layers.items():
            for feat in self._iter_features(layer):
                ambito_raw = feat[config.ambito_field]
                ambito_key = '' if ambito_raw is None else str(ambito_raw)
                ambito_name = ambito_lookup.get(ambito_key, ambito_key) if config.use_desc_for_ambito else ambito_key
                ambito_name = ambito_name or 'Sin ámbito'
                grouped.setdefault(ambito_name, {'Puntos': [], 'Lineas': [], 'Poligonos': []})
                placemark = self._build_placemark(
                    feat=feat,
                    geom_name=geom_name,
                    config=config,
                    ambito_label=ambito_name,
                    tipo_lookup=tipo_lookup,
                )
                if placemark:
                    grouped[ambito_name][geom_name].append(placemark)
        return grouped

    def _build_geom_placemarks(self, layer, geom_name, config, current_ambito_name, tipo_lookup):
        placemarks = []
        for feat in self._iter_features(layer):
            placemark = self._build_placemark(
                feat=feat,
                geom_name=geom_name,
                config=config,
                ambito_label=current_ambito_name,
                tipo_lookup=tipo_lookup,
            )
            if placemark:
                placemarks.append(placemark)
        return placemarks

    def _build_placemark(self, feat, geom_name, config, ambito_label, tipo_lookup):
        tipo_raw = feat[config.tipo_field]
        tipo_key = '' if tipo_raw is None else str(tipo_raw)
        tipo_label = tipo_lookup.get(tipo_key, tipo_key) if config.use_desc_for_tipo else tipo_key
        name = tipo_label or ambito_label or geom_name
        description = self._build_description(feat)
        geom = feat.geometry()
        kml_geom = self._geometry_to_kml(geom)
        if not kml_geom:
            self._log(f'Geometría no soportada o vacía para feature {feat.id()}.', Qgis.Warning)
            return ''
        style_id = {'Puntos': 'pointStyle', 'Lineas': 'lineStyle', 'Poligonos': 'polyStyle'}.get(geom_name, 'lineStyle')
        return (
            f'<Placemark>'
            f'<name>{self._xml(name)}</name>'
            f'<styleUrl>#{style_id}</styleUrl>'
            f'<description><![CDATA[{description}]]></description>'
            f'{kml_geom}'
            f'</Placemark>'
        )


    def _geometry_to_kml(self, geom):
        if geom is None or geom.isEmpty():
            return ''

        try:
            if geom.isMultipart():
                if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.PointGeometry:
                    parts = geom.asMultiPoint()
                    return '<MultiGeometry>' + ''.join(self._point_kml(p) for p in parts) + '</MultiGeometry>'
                if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.LineGeometry:
                    parts = geom.asMultiPolyline()
                    return '<MultiGeometry>' + ''.join(self._line_kml(line) for line in parts) + '</MultiGeometry>'
                if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.PolygonGeometry:
                    parts = geom.asMultiPolygon()
                    return '<MultiGeometry>' + ''.join(self._polygon_kml(poly) for poly in parts) + '</MultiGeometry>'
            else:
                if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.PointGeometry:
                    return self._point_kml(geom.asPoint())
                if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.LineGeometry:
                    return self._line_kml(geom.asPolyline())
                if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.PolygonGeometry:
                    return self._polygon_kml(geom.asPolygon())
        except Exception as e:
            self._log(f'Error convirtiendo geometría a KML: {e}', Qgis.Warning)
            return ''

        return ''

    def _coord(self, pt):
        try:
            return f'{pt.x()},{pt.y()}'
        except Exception:
            return ''

    def _point_kml(self, pt):
        coord = self._coord(pt)
        return f'<Point><coordinates>{coord}</coordinates></Point>' if coord else ''

    def _line_kml(self, line):
        if not line:
            return ''
        coords = ' '.join(self._coord(pt) for pt in line if self._coord(pt))
        return f'<LineString><tessellate>1</tessellate><coordinates>{coords}</coordinates></LineString>' if coords else ''

    def _polygon_kml(self, poly):
        if not poly or not poly[0]:
            return ''
        outer = ' '.join(self._coord(pt) for pt in poly[0] if self._coord(pt))
        if not outer:
            return ''
        inners = []
        for ring in poly[1:]:
            coords = ' '.join(self._coord(pt) for pt in ring if self._coord(pt))
            if coords:
                inners.append(f'<innerBoundaryIs><LinearRing><coordinates>{coords}</coordinates></LinearRing></innerBoundaryIs>')
        return ('<Polygon><outerBoundaryIs><LinearRing><coordinates>' + outer + '</coordinates></LinearRing></outerBoundaryIs>' + ''.join(inners) + '</Polygon>')

    def _log(self, text, level=Qgis.Info):
        QgsMessageLog.logMessage(text, 'OBRA_NUEVA', level)

    def _build_description(self, feat):
        lines = []
        for field in feat.fields():
            value = feat[field.name()]
            lines.append(f'<b>{self._xml(field.name())}</b>: {self._xml(value)}')
        return '<br/>'.join(lines)

    def _build_style_blocks(self):
        point_style = StyleUtils.geometry_style(QgsWkbTypes.PointGeometry)
        line_style = StyleUtils.geometry_style(QgsWkbTypes.LineGeometry)
        poly_style = StyleUtils.geometry_style(QgsWkbTypes.PolygonGeometry)
        return (
            '<Style id="pointStyle">'
            f'<IconStyle><scale>{point_style["icon_scale"]}</scale><Icon><href>{point_style["icon_href"]}</href></Icon></IconStyle>'
            '</Style>'
            '<Style id="lineStyle">'
            f'<LineStyle><color>{line_style["line_color"]}</color><width>{line_style["line_width"]}</width></LineStyle>'
            '</Style>'
            '<Style id="polyStyle">'
            f'<LineStyle><color>{poly_style["line_color"]}</color><width>{poly_style["line_width"]}</width></LineStyle>'
            f'<PolyStyle><color>{poly_style["poly_color"]}</color></PolyStyle>'
            '</Style>'
        )

    def _write_legend(self, config, layers, tmpdir, tipo_lookup):
        values = set()
        for layer in layers.values():
            values.update(self.legend_pruner.present_tipo_values(layer, config.tipo_field))
        lines = ['LEYENDA', '']
        for value in sorted(values, key=lambda x: normalize_text(x)):
            lines.append(f'- {tipo_lookup.get(str(value), str(value))}')
        with open(os.path.join(tmpdir, 'legend.txt'), 'w', encoding='utf-8') as fh:
            fh.write('\n'.join(lines))

    def _iter_features(self, layer):
        return layer.getFeatures(QgsFeatureRequest())

    def _zip_folder(self, source_dir, kmz_path):
        with zipfile.ZipFile(kmz_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            for root, _, files in os.walk(source_dir):
                for fname in files:
                    fpath = os.path.join(root, fname)
                    arcname = os.path.relpath(fpath, source_dir)
                    zf.write(fpath, arcname)

    def _build_lookup_dict_from_table(self, gpkg_path, table_name):
        if not table_name:
            return {}
        conn = sqlite3.connect(gpkg_path)
        try:
            cur = conn.cursor()
            table_sql = table_name.replace("'", "''")
            cur.execute(f"PRAGMA table_info('{table_sql}')")
            cols = [row[1] for row in cur.fetchall()]
            if not cols:
                return {}

            key_col = self._pick_column(cols, ['CLAVE', 'clave', 'KEY', 'key', 'codigo', 'CODIGO', 'N_AMB', 'N_TIPO'])
            value_col = self._pick_column(cols, ['DESCRIPCION', 'descripcion', 'Descripción', 'texto', 'nombre', 'DESC'])
            if not key_col or not value_col:
                return {}

            cur.execute(f'SELECT "{key_col}", "{value_col}" FROM "{table_sql}"')
            result = {}
            for key, value in cur.fetchall():
                if key not in (None, '') and value not in (None, ''):
                    result[str(key)] = str(value)
            return result
        finally:
            conn.close()

    def _pick_column(self, columns, candidates):
        norm_map = {normalize_text(c): c for c in columns}
        for candidate in candidates:
            nc = normalize_text(candidate)
            if nc in norm_map:
                return norm_map[nc]
        for col in columns:
            ncol = normalize_text(col)
            for candidate in candidates:
                if normalize_text(candidate) in ncol:
                    return col
        return None

    def _validate_config(self, config):
        if not config.gpkg_path or not os.path.isfile(config.gpkg_path):
            raise ValueError('El GeoPackage de origen no es válido.')
        if not config.operational_layers:
            raise ValueError('No se han detectado capas operativas para exportar.')
        if not os.path.isdir(config.output_dir):
            raise ValueError('El directorio de salida no es válido.')
        if not config.output_name:
            raise ValueError('El nombre de salida no es válido.')
        probe_table = config.operational_layers.get('Puntos') or config.operational_layers.get('Lineas') or config.operational_layers.get('Poligonos')
        probe = QgsVectorLayer(f'{config.gpkg_path}|layername={probe_table}', probe_table, 'ogr')
        if not probe.isValid():
            raise ValueError('No se ha podido abrir la capa operativa de referencia.')
        if probe.fields().indexOf(config.ambito_field) < 0:
            raise ValueError(f'No existe el campo ÁMBITO: {config.ambito_field}')
        if probe.fields().indexOf(config.tipo_field) < 0:
            raise ValueError(f'No existe el campo TIPO: {config.tipo_field}')

    def _xml(self, value):
        if value is None:
            text = ''
        else:
            text = str(value)
            if text.upper() == 'NULL':
                text = ''
        return (
            text
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;')
            .replace("'", '&apos;')
        )

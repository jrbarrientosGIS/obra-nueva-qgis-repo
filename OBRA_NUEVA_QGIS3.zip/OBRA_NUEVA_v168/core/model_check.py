# -*- coding: utf-8 -*-
"""
OBRA_NUEVA - Comprobación al abrir un proyecto (V1.7.27).

Al abrir un proyecto de QGIS, el plugin mira qué GeoPackage de obra tiene
capas cargadas y comprueba si están al día con el GeoPackage modelo
(SDONXXX_MODELO.gpkg) que se usa en "Actualiza GPKG". Si alguno no lo
está, se avisa en la barra de mensajes de QGIS; NUNCA se modifica nada
automáticamente.

CÓMO SE COMPRUEBA
-----------------
El análisis completo es el mismo de "Actualiza GPKG"
(GpkgStructureUpdater.analyze): campos, tablas nuevas, leyenda,
formulario de atributos y códigos de CLAVE/ASPECTOS. Es solo lectura,
pero abre cada capa para revisar el formulario y puede tardar unos
segundos.

Para no repetirlo cada vez, se calcula una "huella" (resumen SHA-1) de lo
que decide el resultado del análisis, tanto en el modelo como en la obra:
  - estructura de las tablas (nombres, campos, tipos, geometría);
  - estilos guardados en layer_styles (leyenda y formulario);
  - contenido de las tablas de apoyo CLAVE y ASPECTOS.
NO entran las entidades de las capas: editar puntos, líneas o polígonos
no cambia la huella.

Cuando el análisis completo dice que una obra está al día, se apunta en la
configuración de QGIS de ESTE equipo (QSettings) la pareja de huellas
(modelo, obra). La próxima vez, si ninguna de las dos ha cambiado, la obra
se da por buena sin volver a analizarla. Se hace en QSettings, y no dentro
del GeoPackage, para que la comprobación al abrir no escriba nunca en el
fichero de la obra.

Las huellas se leen con sqlite3 solo con SELECT/PRAGMA (nunca se escribe),
igual que ya hace GpkgIntrospector.
"""
import hashlib
import os
import sqlite3

from .gpkg_updater import GpkgStructureUpdater
from .gpkg_utils import GpkgIntrospector, detect_loaded_gpkg_paths, normalize_text
from .settings_manager import SettingsManager
from ..helpers.logging_utils import log_info, log_warning

# Ajustes (QSettings, prefijo OBRA_NUEVA/).
CHECK_ON_OPEN_KEY = 'model_check/on_open'
OK_CACHE_PREFIX = 'model_check/ok/'

# Cambiar este valor invalida todas las comprobaciones guardadas (p. ej. si
# una versión futura del plugin revisa cosas nuevas en el análisis).
CHECK_LOGIC_VERSION = '1'

SUPPORT_TABLES = ('clave', 'aspectos')


def plugin_version():
    """Versión de metadata.txt (sin el sufijo -qgis4)."""
    import configparser
    meta = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'metadata.txt')
    try:
        cp = configparser.ConfigParser(interpolation=None)
        cp.read(meta, encoding='utf-8')
        return cp.get('general', 'version').split('-')[0]
    except Exception:
        return '?'


def _norm_path(path):
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(path or '')))
    except Exception:
        return os.path.normcase(path or '')


def _truthy(value, default=True):
    if value is None:
        return default
    return str(value).strip().lower() not in ('false', '0', 'no', '')


# ── Recuento de cambios pendientes (compartido con "Actualiza GPKG") ─────
def pending_counts(plan, create_tables=True, sync_styles=True):
    """(campos, tablas, leyendas, formularios, códigos) pendientes de un
    plan de GpkgStructureUpdater.analyze(), con las mismas reglas que la
    pestaña "Actualiza GPKG"."""
    n_fields = plan.total_new_fields()
    n_tables = (len(plan.new_tables) + len(plan.missing_roles)) if create_tables else 0
    n_styles = plan.total_style_updates() if sync_styles else 0
    n_forms = plan.total_form_fixes()
    n_rows = plan.total_support_rows()
    return n_fields, n_tables, n_styles, n_forms, n_rows


def pending_text(n_fields, n_tables, n_styles, n_forms, n_rows):
    partes = []
    if n_fields:
        partes.append(f"{n_fields} campo(s) nuevo(s)")
    if n_tables:
        partes.append(f"{n_tables} tabla(s) o capa(s) nueva(s)")
    if n_styles:
        partes.append(f"{n_styles} leyenda(s)/simbología(s)")
    if n_forms:
        partes.append(f"{n_forms} formulario(s) de atributos")
    if n_rows:
        partes.append(f"{n_rows} código(s) nuevo(s) de CLAVE/ASPECTOS")
    if not partes:
        return ''
    return partes[0] if len(partes) == 1 else ', '.join(partes[:-1]) + ' y ' + partes[-1]


# ── Huella ───────────────────────────────────────────────────────────────
def _q(name):
    return '"' + str(name).replace('"', '""') + '"'


def structure_fingerprint(gpkg_path):
    """Resumen SHA-1 de la estructura, los estilos guardados y las tablas
    CLAVE/ASPECTOS de un GeoPackage. Independiente de las entidades de las
    capas. Lanza excepción si el fichero no se puede leer."""
    h = hashlib.sha1()

    def feed(*parts):
        for p in parts:
            h.update(repr(p).encode('utf-8'))
        h.update(b'\n')

    conn = sqlite3.connect(gpkg_path)
    try:
        cur = conn.cursor()
        tables = [r[0] for r in cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'rtree_%' "
            "AND name NOT LIKE 'gpkg_%' ORDER BY name"
        ).fetchall()]
        for t in tables:
            cols = cur.execute(f'PRAGMA table_info({_q(t)})').fetchall()
            feed('T', t, [(c[1], (c[2] or '').upper(), c[3]) for c in cols])
        try:
            for row in cur.execute(
                'SELECT table_name, column_name, geometry_type_name, srs_id '
                'FROM gpkg_geometry_columns ORDER BY table_name'
            ).fetchall():
                feed('G', *row)
        except sqlite3.Error:
            pass
        if 'layer_styles' in tables:
            cols = {r[1] for r in cur.execute("PRAGMA table_info('layer_styles')").fetchall()}
            sel = [c for c in ('f_table_name', 'f_geometry_column', 'useAsDefault', 'styleQML') if c in cols]
            if 'f_table_name' in sel:
                order = 'f_table_name' + (', id' if 'id' in cols else '')
                for row in cur.execute(
                    'SELECT {} FROM layer_styles ORDER BY {}'.format(', '.join(sel), order)
                ).fetchall():
                    feed('S', *row)
        for t in tables:
            if normalize_text(t) not in SUPPORT_TABLES:
                continue
            col_names = [c[1] for c in cur.execute(f'PRAGMA table_info({_q(t)})').fetchall()]
            keep = [c for c in col_names if normalize_text(c) != 'fid']
            if not keep:
                continue
            rows = cur.execute(
                'SELECT {} FROM {}'.format(', '.join(_q(c) for c in keep), _q(t))
            ).fetchall()
            feed('R', t, keep, sorted(repr(r) for r in rows))
    finally:
        conn.close()
    return h.hexdigest()


# ── Comprobación ─────────────────────────────────────────────────────────
class ObraCheckResult:
    """Resultado de comprobar una obra contra el modelo.
    status: 'ok' | 'pending' | 'error' | 'skip'."""

    def __init__(self, gpkg_path, status, text='', counts=None, cached=False):
        self.gpkg_path = gpkg_path
        self.status = status
        self.text = text
        self.counts = counts or (0, 0, 0, 0, 0)
        self.cached = cached

    @property
    def name(self):
        return os.path.splitext(os.path.basename(self.gpkg_path or ''))[0]


class ModelChecker:
    def __init__(self, settings=None, updater=None):
        self.settings = settings or SettingsManager()
        self.updater = updater or GpkgStructureUpdater()
        # Una versión nueva del plugin vuelve a analizar cada obra una vez
        # (puede revisar cosas que la anterior no revisaba).
        self.logic_tag = f'{CHECK_LOGIC_VERSION}:{plugin_version()}'

    # Ajustes
    def enabled(self):
        return _truthy(self.settings.get(CHECK_ON_OPEN_KEY, True), True)

    def set_enabled(self, value):
        self.settings.set(CHECK_ON_OPEN_KEY, bool(value))

    def model_path(self):
        """El modelo de "Actualiza GPKG"; si no hay, el de "Nueva Obra"."""
        for key in ('actualiza/model_gpkg', 'new_work/source'):
            path = (self.settings.get(key, '') or '').strip()
            if path:
                return path
        return ''

    def options(self):
        create = _truthy(self.settings.get('actualiza/create_tables', True), True)
        sync = _truthy(self.settings.get('actualiza/sync_styles', True), True)
        return create, sync

    # Caché de "obra al día"
    def _cache_key(self, gpkg_path):
        digest = hashlib.sha1(_norm_path(gpkg_path).encode('utf-8')).hexdigest()[:20]
        return OK_CACHE_PREFIX + digest

    def _cache_value(self, model_fp, obra_fp):
        create, sync = self.options()
        return f'{self.logic_tag}|{int(create)}{int(sync)}|{model_fp}|{obra_fp}'

    def remember_ok(self, model_path, gpkg_path):
        """Apunta que la obra está al día con el modelo (tras un análisis
        completo limpio). Nunca lanza excepción."""
        try:
            value = self._cache_value(structure_fingerprint(model_path), structure_fingerprint(gpkg_path))
            self.settings.set(self._cache_key(gpkg_path), value)
        except Exception as e:
            log_warning(f'No se pudo recordar la comprobación de {gpkg_path}: {e}')

    def forget(self, gpkg_path):
        try:
            self.settings.set(self._cache_key(gpkg_path), '')
        except Exception:
            pass

    # Obras del proyecto
    def project_obra_paths(self, model_path=''):
        """GeoPackage de obra (con capas Puntos/Líneas/Polígonos) que tienen
        alguna capa cargada en el proyecto actual. Excluye el modelo."""
        model_norm = _norm_path(model_path) if model_path else None
        result = []
        seen = set()
        for path in detect_loaded_gpkg_paths():
            norm = _norm_path(path)
            if norm in seen or norm == model_norm:
                continue
            seen.add(norm)
            if not os.path.exists(path):
                continue
            try:
                roles = GpkgIntrospector(path).detect_operational_tables()
            except Exception:
                continue
            if any(roles.values()):
                result.append(path)
        return result

    def check_obra(self, model_path, gpkg_path, model_fp=None):
        try:
            if model_fp is None:
                model_fp = structure_fingerprint(model_path)
            obra_fp = structure_fingerprint(gpkg_path)
        except Exception as e:
            return ObraCheckResult(gpkg_path, 'error', f'no se pudo leer: {e}')

        cached = self.settings.get(self._cache_key(gpkg_path), '') or ''
        if cached and cached == self._cache_value(model_fp, obra_fp):
            return ObraCheckResult(gpkg_path, 'ok', 'al día (sin cambios desde la última comprobación)', cached=True)

        try:
            plan = self.updater.analyze(model_path, gpkg_path)
        except ValueError as e:
            if 'No parece un GeoPackage de obra' in str(e):
                return ObraCheckResult(gpkg_path, 'skip', str(e))
            return ObraCheckResult(gpkg_path, 'error', str(e))
        except Exception as e:
            return ObraCheckResult(gpkg_path, 'error', str(e))

        create, sync = self.options()
        counts = pending_counts(plan, create, sync)
        if any(counts):
            return ObraCheckResult(gpkg_path, 'pending', pending_text(*counts), counts)
        try:
            self.settings.set(self._cache_key(gpkg_path), self._cache_value(model_fp, obra_fp))
        except Exception:
            pass
        return ObraCheckResult(gpkg_path, 'ok', 'al día con el modelo')

    def check_project(self):
        """Comprueba todas las obras cargadas en el proyecto. Devuelve
        (ruta_modelo, [ObraCheckResult, ...]); la lista va vacía si no hay
        modelo configurado o accesible, o si no hay obras cargadas."""
        model_path = self.model_path()
        if not model_path:
            log_info('Comprobación al abrir: no hay GeoPackage modelo configurado en "Actualiza GPKG".')
            return model_path, []
        if not os.path.exists(model_path):
            log_info(f'Comprobación al abrir: el modelo no está accesible ({model_path}); no se comprueba nada.')
            return model_path, []
        obras = self.project_obra_paths(model_path)
        if not obras:
            return model_path, []
        try:
            model_fp = structure_fingerprint(model_path)
        except Exception as e:
            log_warning(f'Comprobación al abrir: no se pudo leer el modelo {model_path}: {e}')
            return model_path, []
        results = []
        for path in obras:
            res = self.check_obra(model_path, path, model_fp)
            results.append(res)
            log_info(f'Comprobación al abrir: {res.name}: {res.status} - {res.text}')
        return model_path, results

# -*- coding: utf-8 -*-
import os
import sqlite3

_NULL_TOKENS = {'', 'null', 'none', 'nan', '<null>', 'sin foto', 's/f'}

# Subcarpetas habituales donde este tipo de obra suele guardar fotografías
# y documentos junto al GeoPackage, cuando la ruta guardada en el campo
# ExternalResource es relativa (sin carpeta propia definida en el widget).
_ATTACHMENT_SUBFOLDERS = (
    'fotos', 'Fotos', 'FOTOS',
    'imagenes', 'Imágenes',
    'documentos', 'Documentos', 'DOCUMENTOS',
    'docs', 'Docs',
    'fichas', 'Fichas',
    'informes', 'Informes',
    'anejo', 'Anejo',
)


def resolve_attachment_path(raw_value, gpkg_path):
    """Resuelve el valor guardado en un campo de documento/foto
    (ExternalResource: "Ficha", "Foto 1"-"Foto 4", "Doc_Apertura",
    "Doc_Cierre"...) a una ruta ABSOLUTA del fichero adjunto, sin dar por
    hecho ningún "DefaultRoot" concreto del widget (que puede faltar, estar
    vacío o apuntar a la carpeta de un ordenador distinto al actual).

    Reutiliza el mismo criterio ya probado en ui/tab_fotos.py
    (`_photo_paths`) -- probar la propia carpeta del GeoPackage y varias
    subcarpetas habituales -- pero generalizado a cualquier tipo de
    documento (no solo imágenes) y como función reutilizable.

    Devuelve (ruta_absoluta, encontrada): `encontrada` es True si esa ruta
    existe de verdad en disco; si no se encuentra en ningún candidato, se
    devuelve igualmente la mejor ruta estimada (absoluta) junto con
    `encontrada=False`, para que el llamador pueda avisar sin dejar de
    guardar un valor útil. Devuelve (None, False) si `raw_value` está
    vacío o es alguno de los valores nulos habituales ("", "NULL", ...),
    tanto si el campo entero es ese valor como si es una ruta completa
    cuyo nombre de fichero (última parte de la ruta) es ese valor -- p.
    ej. "...\\OTROS\\GIS\\NULL" -- que es como algunos orígenes de datos
    marcan "sin foto/documento" en vez de dejar el campo vacío.
    """
    if raw_value is None:
        return None, False
    raw = str(raw_value).strip().strip('"').strip("'")
    if raw.lower() in _NULL_TOKENS:
        return None, False
    basename = os.path.basename(raw.replace('\\', os.sep).replace('/', os.sep)).strip()
    basename_no_ext = os.path.splitext(basename)[0].strip()
    if basename.lower() in _NULL_TOKENS or basename_no_ext.lower() in _NULL_TOKENS:
        return None, False

    base_dir = os.path.dirname(gpkg_path) if gpkg_path else ''

    if os.path.isabs(raw):
        alternatives = [os.path.normpath(raw)]
    else:
        project_dir = base_dir
        try:
            from qgis.core import QgsProject
            project_file = QgsProject.instance().fileName()
            if project_file:
                project_dir = os.path.dirname(project_file)
        except Exception:
            pass

        alternatives = [
            os.path.normpath(os.path.join(base_dir, raw)),
            os.path.normpath(os.path.join(project_dir, raw)),
        ]
        alternatives.extend(
            os.path.normpath(os.path.join(base_dir, sub, raw))
            for sub in _ATTACHMENT_SUBFOLDERS
        )

    for alt in alternatives:
        if os.path.exists(alt):
            return alt, True
    return alternatives[0], False


def detect_loaded_gpkg_paths():
    """Devuelve, en el mismo orden en que aparecen en el proyecto QGIS
    actual, las rutas (sin duplicados) de los GeoPackage (.gpkg) de los que
    provenga alguna capa vectorial cargada en el lienzo. Mismo criterio ya
    probado en ui/tab_fotos.py (`_find_loaded_gpkgs`): mirar `layer.source()`
    y quedarse con la parte antes de "|layername=...". Se usa para proponer
    por defecto, en pestañas como "Actualiza GPKG" o "Archivar GPKG", el
    GeoPackage que el usuario ya tiene abierto en el proyecto, en vez de
    dejar el campo vacío o pedirle que lo busque de nuevo."""
    paths = []
    try:
        from qgis.core import QgsProject, QgsMapLayer
        for layer in QgsProject.instance().mapLayers().values():
            try:
                if layer.type() != QgsMapLayer.VectorLayer or not layer.isValid():
                    continue
                source = layer.source() or ""
                if ".gpkg" not in source.lower():
                    continue
                gpkg_path = source.split("|")[0]
                if not gpkg_path.lower().endswith(".gpkg"):
                    continue
                if gpkg_path not in paths:
                    paths.append(gpkg_path)
            except Exception:
                continue
    except Exception:
        pass
    return paths


def primary_loaded_gpkg_path():
    """El primer GeoPackage detectado como cargado en el proyecto QGIS
    actual (ver `detect_loaded_gpkg_paths`), o None si no hay ninguno."""
    paths = detect_loaded_gpkg_paths()
    return paths[0] if paths else None


def document_field_names(layer):
    """Nombres de los campos de una capa configurados con el widget
    "ExternalResource" (documento/foto adjuntos: "Ficha", "Foto 1"-"Foto 4",
    "Doc_Apertura", "Doc_Cierre"...). Genérico: no depende de una lista fija
    de nombres, así que cubre cualquier campo de documento que el modelo
    defina, presente o futuro. Compartida entre "Consulta" y "Archivar
    GPKG"."""
    names = set()
    fields = layer.fields()
    for i in range(fields.count()):
        try:
            if layer.editorWidgetSetup(i).type() == 'ExternalResource':
                names.add(fields.at(i).name())
        except Exception:
            continue
    return names


def normalize_text(value):
    return (
        str(value or '')
        .lower()
        .replace('á', 'a')
        .replace('é', 'e')
        .replace('í', 'i')
        .replace('ó', 'o')
        .replace('ú', 'u')
        .replace('ñ', 'n')
        .replace(' ', '_')
    )


class GpkgIntrospector:
    def __init__(self, gpkg_path):
        self.gpkg_path = gpkg_path

    def _connect(self):
        return sqlite3.connect(self.gpkg_path)

    def list_feature_tables(self):
        conn = self._connect()
        try:
            cur = conn.cursor()
            cur.execute(
                """
                SELECT table_name
                FROM gpkg_contents
                WHERE data_type IN ('features', 'attributes')
                ORDER BY table_name
                """
            )
            return [row[0] for row in cur.fetchall()]
        finally:
            conn.close()

    def list_geometry_tables(self):
        conn = self._connect()
        try:
            cur = conn.cursor()
            cur.execute(
                """
                SELECT table_name
                FROM gpkg_contents
                WHERE data_type='features'
                ORDER BY table_name
                """
            )
            return [row[0] for row in cur.fetchall()]
        finally:
            conn.close()

    def list_attribute_tables(self):
        conn = self._connect()
        try:
            cur = conn.cursor()
            cur.execute(
                """
                SELECT table_name
                FROM gpkg_contents
                WHERE data_type='attributes'
                ORDER BY table_name
                """
            )
            return [row[0] for row in cur.fetchall()]
        finally:
            conn.close()

    def geometry_type_by_table(self):
        """Devuelve {tabla: geometry_type} desde gpkg_geometry_columns sin abrir capas OGR."""
        conn = self._connect()
        try:
            cur = conn.cursor()
            cur.execute(
                """
                SELECT table_name, geometry_type_name
                FROM gpkg_geometry_columns
                """
            )
            return {row[0]: row[1] for row in cur.fetchall()}
        finally:
            conn.close()

    def table_columns(self, table_name):
        conn = self._connect()
        try:
            cur = conn.cursor()
            table_sql = table_name.replace("'", "''")
            cur.execute(f"PRAGMA table_info('{table_sql}')")
            return [row[1] for row in cur.fetchall()]
        finally:
            conn.close()

    def table_columns_full(self, table_name):
        """Devuelve metadatos completos de columnas: [{name, type, notnull, dflt_value, pk}, ...]."""
        conn = self._connect()
        try:
            cur = conn.cursor()
            table_sql = table_name.replace("'", "''")
            cur.execute(f"PRAGMA table_info('{table_sql}')")
            columns = []
            for row in cur.fetchall():
                columns.append({
                    'cid': row[0],
                    'name': row[1],
                    'type': row[2] or '',
                    'notnull': bool(row[3]),
                    'dflt_value': row[4],
                    'pk': bool(row[5]),
                })
            return columns
        finally:
            conn.close()

    def has_layer_styles_table(self):
        conn = self._connect()
        try:
            cur = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='layer_styles'")
            return cur.fetchone() is not None
        finally:
            conn.close()

    def default_style_qml(self, table_name):
        """Devuelve el styleQML marcado como predeterminado (useAsDefault=1)
        para table_name, o el primero disponible si ninguno está marcado.
        None si la tabla no tiene ningún estilo registrado."""
        if not self.has_layer_styles_table():
            return None
        conn = self._connect()
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT styleQML FROM layer_styles WHERE f_table_name=? "
                "ORDER BY useAsDefault DESC, id ASC LIMIT 1",
                (table_name,),
            )
            row = cur.fetchone()
            return row[0] if row else None
        finally:
            conn.close()

    def geometry_column_name(self, table_name):
        conn = self._connect()
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT column_name FROM gpkg_geometry_columns WHERE table_name=?",
                (table_name,),
            )
            row = cur.fetchone()
            return row[0] if row else None
        finally:
            conn.close()

    def table_exists(self, table_name):
        return table_name in self.list_feature_tables()

    def first_matching_table(self, candidates, geometry_only=False):
        tables = self.list_geometry_tables() if geometry_only else self.list_feature_tables()
        norm_map = {normalize_text(t): t for t in tables}
        for candidate in candidates:
            c = normalize_text(candidate)
            if c in norm_map:
                return norm_map[c]
        for table in tables:
            nt = normalize_text(table)
            for candidate in candidates:
                if normalize_text(candidate) in nt:
                    return table
        return None

    def detect_operational_tables(self):
        tables = self.list_geometry_tables()
        result = {'Puntos': None, 'Lineas': None, 'Poligonos': None}
        for table in tables:
            nt = normalize_text(table)
            if result['Puntos'] is None and ('_puntos' in nt or nt.endswith('puntos') or nt == 'puntos'):
                result['Puntos'] = table
            elif result['Lineas'] is None and ('_lineas' in nt or nt.endswith('lineas') or nt == 'lineas'):
                result['Lineas'] = table
            elif result['Poligonos'] is None and ('_poligonos' in nt or nt.endswith('poligonos') or nt == 'poligonos'):
                result['Poligonos'] = table
        return result

    def detect_base_tables(self):
        return {
            'Lineas_FFCC': self.first_matching_table(['Lineas_FFCC', 'líneas_ffcc', 'lineasffcc'], geometry_only=True),
            'pk': self.first_matching_table(['pk', 'pks'], geometry_only=True),
            'Estaciones': self.first_matching_table(['Estaciones', 'Estacion'], geometry_only=True),
        }

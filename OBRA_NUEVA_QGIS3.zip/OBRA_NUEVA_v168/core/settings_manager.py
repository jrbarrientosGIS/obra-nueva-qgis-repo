# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QSettings


class SettingsManager:
    PREFIX = 'OBRA_NUEVA'

    def get(self, key, default=None):
        return QSettings().value(f'{self.PREFIX}/{key}', default)

    def set(self, key, value):
        QSettings().setValue(f'{self.PREFIX}/{key}', value)

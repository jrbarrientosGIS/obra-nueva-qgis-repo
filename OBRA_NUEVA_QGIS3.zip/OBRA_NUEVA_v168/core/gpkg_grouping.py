# -*- coding: utf-8 -*-
from qgis.core import QgsProject


class GroupingService:
    def collapse_group(self, group_name, collapsed=True):
        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(group_name)
        if group:
            group.setExpanded(not collapsed)
            return True
        return False

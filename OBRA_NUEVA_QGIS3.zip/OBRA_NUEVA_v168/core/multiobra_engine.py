# -*- coding: utf-8 -*-
import os
import sqlite3

from qgis.core import (
    QgsFeature,
    QgsFields,
    QgsField,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
    QgsCoordinateTransformContext,
)
from qgis.PyQt.QtCore import QVariant

from .field_mapper import FieldMapper
from .gpkg_utils import GpkgIntrospector, normalize_text
from ..helpers.logging_utils import log_info


class MultiObraEngine:
    def scan_folder(self, folder_path):
        results = []
        for entry in sorted(os.listdir(folder_path)):
            if entry.lower().endswith('.gpkg'):
                results.append(os.path.join(folder_path, entry))
        return results

    def summarize_folder(self, folder_path):
        gpkg_files = self.scan_folder(folder_path)
        items = []
        operational_layers = set()
        for gpkg in gpkg_files:
            intro = GpkgIntrospector(gpkg)
            ops = intro.detect_operational_tables()
            present = {k: v for k, v in ops.items() if v}
            operational_layers.update(present.keys())
            items.append({'path': gpkg, 'operational': present})
        return {
            'count': len(gpkg_files),
            'files': gpkg_files,
            'items': items,
            'operational_layers': sorted(operational_layers),
        }

    def common_filter_values(self, folder_path, layer_role):
        gpkg_files = self.scan_folder(folder_path)
        ambitos = set()
        tipo_keys = set()
        tipo_desc_map = {}
        for gpkg in gpkg_files:
            tipo_desc_map.update(self._read_tipo_lookup_from_gpkg(gpkg))
            layer = self._open_role_layer(gpkg, layer_role)
            if not layer:
                continue
            mapped = FieldMapper.detect_standard_fields(layer.fields())
            af, tf = mapped['ambito'], mapped['tipo']
            if af:
                for feat in layer.getFeatures():
                    val = feat[af]
                    if val not in (None, ''):
                        ambitos.add(str(val))
            if tf:
                for feat in layer.getFeatures():
                    val = feat[tf]
                    if val not in (None, ''):
                        tipo_keys.add(str(val))

        tipo_items = []
        for key in sorted(tipo_keys):
            desc = tipo_desc_map.get(str(key), str(key))
            tipo_items.append((desc, str(key)))
        tipo_items.sort(key=lambda x: (x[0].lower(), x[1]))
        return sorted(ambitos), tipo_items

    def build_virtual_result(self, folder_path, layer_role='Puntos', ambito_value=None, tipo_value=None):
        gpkg_files = self.scan_folder(folder_path)
        if not gpkg_files:
            raise ValueError('No se encontraron GeoPackages en la carpeta seleccionada.')

        first_layer = None
        valid_files = []
        features_buffer = []
        source_fields = None
        source_wkb = None
        source_crs = None

        for gpkg in gpkg_files:
            layer = self._open_role_layer(gpkg, layer_role)
            if not layer or not layer.isValid():
                continue
            mapped = FieldMapper.detect_standard_fields(layer.fields())
            af, tf, cf = mapped['ambito'], mapped['tipo'], mapped['codigo']
            if not af and not tf:
                continue
            if first_layer is None:
                first_layer = layer
                source_fields = layer.fields()
                source_wkb = layer.wkbType()
                source_crs = layer.crs()
            valid_files.append(gpkg)
            for feat in layer.getFeatures():
                if ambito_value not in (None, '', '(Todos)') and af and str(feat[af]) != str(ambito_value):
                    continue
                if tipo_value not in (None, '', '(Todos)') and tf and str(feat[tf]) != str(tipo_value):
                    continue
                features_buffer.append((gpkg, feat))

        if first_layer is None:
            raise ValueError('No se encontraron capas operativas válidas para construir la consulta.')

        mem = QgsVectorLayer(f'{QgsWkbTypes.displayString(source_wkb)}?crs={source_crs.authid()}', 'Consulta_multiobra', 'memory')
        prov = mem.dataProvider()

        fields = QgsFields()
        fields.append(QgsField('obra_gpkg', QVariant.String))
        for field in source_fields:
            if fields.indexOf(field.name()) < 0:
                fields.append(field)
        prov.addAttributes(fields)
        mem.updateFields()

        new_features = []
        for gpkg, feat in features_buffer:
            new_feat = QgsFeature(mem.fields())
            new_feat.setGeometry(feat.geometry())
            attrs = [os.path.splitext(os.path.basename(gpkg))[0]]
            for field in source_fields:
                attrs.append(feat[field.name()])
            new_feat.setAttributes(attrs)
            new_features.append(new_feat)

        if new_features:
            prov.addFeatures(new_features)
            mem.updateExtents()

        log_info(f'Consulta multiobra generada con {len(new_features)} entidades procedentes de {len(valid_files)} geopackages.')
        return mem, valid_files, len(new_features)

    def save_result_to_gpkg(self, layer, output_path, layer_name='consulta_resultado', overwrite=True):
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = 'GPKG'
        options.layerName = layer_name
        if overwrite and os.path.exists(output_path):
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        elif overwrite:
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        err_code, err_msg, *_ = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer,
            output_path,
            QgsCoordinateTransformContext(),
            options,
        )
        if err_code != QgsVectorFileWriter.NoError:
            raise RuntimeError(f'No se pudo guardar el resultado: {err_msg}')
        return output_path

    def _open_role_layer(self, gpkg_path, layer_role):
        intro = GpkgIntrospector(gpkg_path)
        ops = intro.detect_operational_tables()
        table_name = ops.get(layer_role)
        if not table_name:
            return None
        return QgsVectorLayer(f'{gpkg_path}|layername={table_name}', table_name, 'ogr')

    def _read_tipo_lookup_from_gpkg(self, gpkg_path):
        """Lee la tabla CLAVE del GeoPackage y devuelve un mapa key -> descripción de TIPO."""
        intro = GpkgIntrospector(gpkg_path)
        table_name = intro.first_matching_table(['CLAVE', 'clave'], geometry_only=False)
        if not table_name:
            return {}
        conn = sqlite3.connect(gpkg_path)
        try:
            cur = conn.cursor()
            table_sql = table_name.replace("'", "''")
            cur.execute(f"PRAGMA table_info('{table_sql}')")
            cols = [row[1] for row in cur.fetchall()]
            if not cols:
                return {}
            key_col = self._pick_column(cols, ['key', 'KEY', 'CLAVE', 'clave', 'N_TIPO', 'tipo_key'])
            value_col = self._pick_column(cols, ['TIPO', 'tipo', 'DESCRIPCION', 'descripcion', 'Descripción', 'DESC', 'nombre'])
            if not key_col or not value_col:
                return {}
            cur.execute(f'SELECT "{key_col}", "{value_col}" FROM "{table_sql}"')
            result = {}
            for key, value in cur.fetchall():
                if key not in (None, '') and value not in (None, ''):
                    result[str(key)] = str(value)
                    if str(key).endswith('.0'):
                        result[str(key)[:-2]] = str(value)
            return result
        finally:
            conn.close()

    def _pick_column(self, columns, candidates):
        norm_map = {normalize_text(c): c for c in columns}
        for candidate in candidates:
            nc = normalize_text(candidate)
            if nc in norm_map:
                return norm_map[nc]
        for col in columns:
            ncol = normalize_text(col)
            for candidate in candidates:
                if normalize_text(candidate) in ncol:
                    return col
        return None

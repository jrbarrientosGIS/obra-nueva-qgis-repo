# -*- coding: utf-8 -*-
"""Núcleo de la pestaña "Archivar GPKG": copia un GeoPackage ya terminado a
una carpeta de destino (p. ej. una carpeta de "GPKG listos para consulta")
dejando sus documentos y fotos adjuntos (Ficha, Foto 1-4, Doc_Apertura,
Doc_Cierre...) perfectamente accesibles desde esa copia, sin mover ni
duplicar los ficheros originales: sus rutas se reescriben como ABSOLUTAS
apuntando a la ubicación donde ya están (la carpeta del GeoPackage
original), y el widget de cada campo se reconfigura a RelativeStorage =
Absoluto para que QGIS los interprete tal cual."""
import os
import shutil

from qgis.core import QgsVectorLayer, QgsEditorWidgetSetup

from .gpkg_utils import GpkgIntrospector, resolve_attachment_path, document_field_names


class GpkgArchiveError(Exception):
    pass


def _copy_sidecars(source_path, dest_path):
    """Copia también los ficheros auxiliares de SQLite (-wal/-shm) si el
    GeoPackage de origen los tiene (modo WAL), para no dejar la copia en un
    estado inconsistente."""
    for suffix in ('-wal', '-shm'):
        src_side = source_path + suffix
        if os.path.exists(src_side):
            shutil.copy2(src_side, dest_path + suffix)


def archive_gpkg(source_path, dest_folder, overwrite=False, progress_cb=None):
    """Copia `source_path` a `dest_folder` dejando accesibles sus
    documentos/fotos adjuntos desde la copia.

    Devuelve un dict:
      {
        'dest_path': ruta del .gpkg copiado,
        'tables_processed': nº de tablas con campos de documento,
        'fields_updated': nº de campos reconfigurados a ruta absoluta,
        'values_rewritten': nº de valores de campo reescritos,
        'missing': [(tabla, campo, fid, ruta_estimada), ...] -- adjuntos no
                    encontrados en disco (se guarda igualmente la mejor
                    ruta estimada, no se deja el campo vacío).
      }
    Lanza GpkgArchiveError con un mensaje claro ante cualquier problema
    (origen inválido, destino inválido, archivo ya existente sin
    `overwrite`, fallo al guardar cambios...).
    """

    def _progress(msg):
        if progress_cb:
            try:
                progress_cb(msg)
            except Exception:
                pass

    if not source_path or not os.path.isfile(source_path):
        raise GpkgArchiveError(f'No se encuentra el GeoPackage de origen: {source_path}')
    if not dest_folder:
        raise GpkgArchiveError('Selecciona una carpeta de destino.')

    os.makedirs(dest_folder, exist_ok=True)

    dest_path = os.path.join(dest_folder, os.path.basename(source_path))
    if os.path.normcase(os.path.abspath(dest_path)) == os.path.normcase(os.path.abspath(source_path)):
        raise GpkgArchiveError(
            'La carpeta de destino no puede ser la misma carpeta donde ya está el GeoPackage de origen.'
        )
    if os.path.exists(dest_path) and not overwrite:
        raise GpkgArchiveError(f'Ya existe un archivo con ese nombre en el destino:\n{dest_path}')

    _progress(f'Copiando "{os.path.basename(source_path)}" a "{dest_folder}"...')
    shutil.copy2(source_path, dest_path)
    _copy_sidecars(source_path, dest_path)

    introspector = GpkgIntrospector(dest_path)
    tables = introspector.list_feature_tables()

    tables_processed = 0
    fields_updated = 0
    values_rewritten = 0
    missing = []

    for table_name in tables:
        uri = f'{dest_path}|layername={table_name}'
        layer = QgsVectorLayer(uri, table_name, 'ogr')
        if not layer.isValid():
            _progress(f'⚠ No se pudo abrir la tabla "{table_name}" en la copia; se omite.')
            continue

        try:
            layer.loadDefaultStyle()
        except Exception:
            pass

        doc_fields = document_field_names(layer)
        if not doc_fields:
            continue

        fields = layer.fields()
        field_indexes = {name: fields.indexOf(name) for name in doc_fields}
        field_indexes = {name: idx for name, idx in field_indexes.items() if idx >= 0}
        if not field_indexes:
            continue

        tables_processed += 1
        _progress(f'Procesando documentos en "{table_name}" ({len(field_indexes)} campo(s))...')

        if not layer.startEditing():
            _progress(f'⚠ No se pudo editar la tabla "{table_name}"; sus documentos no se han podido reescribir.')
            continue

        try:
            for feat in layer.getFeatures():
                for name, idx in field_indexes.items():
                    raw_value = feat[name]
                    if raw_value in (None, ''):
                        continue
                    resolved, found = resolve_attachment_path(raw_value, source_path)
                    if not resolved:
                        continue
                    if str(resolved) != str(raw_value):
                        layer.changeAttributeValue(feat.id(), idx, resolved)
                        values_rewritten += 1
                    if not found:
                        missing.append((table_name, name, feat.id(), resolved))

            for name, idx in field_indexes.items():
                try:
                    config = dict(layer.editorWidgetSetup(idx).config() or {})
                except Exception:
                    config = {}
                config['RelativeStorage'] = 0  # Absoluto.
                config['DefaultRoot'] = ''
                layer.setEditorWidgetSetup(idx, QgsEditorWidgetSetup('ExternalResource', config))
                fields_updated += 1

            if not layer.commitChanges():
                errors = layer.commitErrors()
                raise GpkgArchiveError(
                    f'No se pudieron guardar los cambios en "{table_name}": {"; ".join(errors)}'
                )
        except GpkgArchiveError:
            layer.rollBack()
            raise
        except Exception as e:
            layer.rollBack()
            raise GpkgArchiveError(f'Error procesando "{table_name}": {e}')

        # Persiste la nueva configuración de widgets (RelativeStorage =
        # Absoluto) en la tabla layer_styles de la copia, para que quede
        # guardada de verdad al reabrir el GeoPackage más adelante (igual
        # que hace QGIS al guardar un estilo "por defecto").
        try:
            msg = layer.saveStyleToDatabase(
                'default', 'Documentos con ruta absoluta (Archivar GPKG)', True, ''
            )
            if msg:
                _progress(f'⚠ Aviso al guardar el estilo de "{table_name}": {msg}')
        except Exception as e:
            _progress(f'⚠ No se pudo guardar el estilo de "{table_name}": {e}')

    _progress(f'✔ Archivado completado: {dest_path}')

    return {
        'dest_path': dest_path,
        'tables_processed': tables_processed,
        'fields_updated': fields_updated,
        'values_rewritten': values_rewritten,
        'missing': missing,
    }

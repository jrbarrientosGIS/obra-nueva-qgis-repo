# -*- coding: utf-8 -*-
from qgis.core import (
    QgsCategorizedSymbolRenderer,
    QgsExpression,
    QgsExpressionContext,
    QgsExpressionContextUtils,
    QgsRendererCategory,
    QgsRuleBasedRenderer,
)


class LegendPruner:
    def present_tipo_values(self, layer, tipo_field):
        values = set()
        if not layer or not tipo_field:
            return values
        for feat in layer.getFeatures():
            value = feat[tipo_field]
            if value not in (None, ''):
                values.add(str(value))
        return values

    def build_legend_lines(self, layer, tipo_field, tipo_lookup=None):
        tipo_lookup = tipo_lookup or {}
        values = sorted(self.present_tipo_values(layer, tipo_field), key=lambda x: str(x))
        lines = []
        for value in values:
            label = tipo_lookup.get(str(value), str(value))
            lines.append(f'- {label}')
        return lines

    def prune_layer_legend(self, layer):
        """Ajusta la leyenda del layer a las clases/reglas realmente presentes."""
        try:
            if not layer or not layer.isValid() or layer.featureCount() == 0:
                return False

            renderer = layer.renderer()
            if renderer is None:
                return False

            if renderer.type() == 'categorizedSymbol':
                return self._prune_categorized_renderer(layer, renderer)

            if renderer.type() == 'RuleRenderer':
                root = renderer.rootRule().clone()
                self._prune_rule_children(root, layer)
                layer.setRenderer(QgsRuleBasedRenderer(root))
                layer.triggerRepaint()
                return True

            return False
        except Exception:
            return False

    def _prune_categorized_renderer(self, layer, renderer):
        class_attr = renderer.classAttribute()
        present_values = self._renderer_values_present(layer, class_attr)
        if not present_values:
            return False

        kept = []
        for cat in renderer.categories():
            try:
                cat_val = cat.value()
                if cat_val is None:
                    continue
                if str(cat_val) in present_values:
                    kept.append(
                        QgsRendererCategory(
                            cat.value(),
                            cat.symbol().clone(),
                            cat.label(),
                            cat.renderState(),
                        )
                    )
            except Exception:
                continue

        if not kept:
            return False

        new_renderer = QgsCategorizedSymbolRenderer(class_attr, kept)
        try:
            new_renderer.setSourceSymbol(renderer.sourceSymbol().clone())
        except Exception:
            pass
        try:
            new_renderer.setSourceColorRamp(renderer.sourceColorRamp().clone())
        except Exception:
            pass
        try:
            new_renderer.setUsingSymbolLevels(renderer.usingSymbolLevels())
        except Exception:
            pass

        layer.setRenderer(new_renderer)
        layer.triggerRepaint()
        return True

    def _renderer_values_present(self, layer, class_attr):
        present_values = set()
        if not class_attr:
            return present_values

        field_idx = layer.fields().indexOf(class_attr)
        if field_idx != -1:
            for feat in layer.getFeatures():
                val = feat[field_idx]
                if val not in (None, ''):
                    present_values.add(str(val))
            return present_values

        expr = QgsExpression(class_attr)
        ctx = QgsExpressionContext()
        ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))

        for feat in layer.getFeatures():
            ctx.setFeature(feat)
            val = expr.evaluate(ctx)
            if val not in (None, ''):
                present_values.add(str(val))
        return present_values

    def _prune_rule_children(self, rule, layer):
        children = list(rule.children())
        for child in children:
            self._prune_rule_children(child, layer)

        for child in list(rule.children()):
            if not self._rule_has_matches(child, layer):
                rule.removeChild(child)

    def _rule_has_matches(self, rule, layer):
        try:
            if rule.isElse():
                return True
            expr_text = rule.filterExpression()
            if not expr_text:
                return True

            expr = QgsExpression(expr_text)
            ctx = QgsExpressionContext()
            ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))

            for feat in layer.getFeatures():
                ctx.setFeature(feat)
                val = expr.evaluate(ctx)
                if bool(val):
                    return True
            return False
        except Exception:
            return True

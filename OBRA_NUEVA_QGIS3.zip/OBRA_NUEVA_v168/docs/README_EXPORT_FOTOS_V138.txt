OBRA_NUEVA - EXPORT_FOTOS V138

Cambio principal:
- La Sección 2 permite marcar fotografías sin fecha visible para estampar fecha al exportar.
- Si no se detecta fecha en EXIF ni en el nombre de archivo, el plugin propone estampar fecha y pide al usuario la fecha de la fotografía.
- Formato obligatorio: DD/MM/AAAA HH:MM. Ejemplo: 10/12/2025 11:10.
- La fecha se guarda en el campo fecha_foto.
- El campo estampar_fecha controla si se escribe la fecha sobre la imagen exportada.
- La exportación mantiene el nombre corto: FR_nombre_original.jpg o IF_nombre_original.jpg.
- Las imágenes marcadas para informe final siguen usando IF_; el resto FR_.

Campos nuevos:
- fecha_foto: texto, formato DD/MM/AAAA HH:MM.
- estampar_fecha: entero, 1 = estampar fecha al exportar; 0 = no estampar.

Notas:
- La fecha se estampa en la esquina inferior derecha con texto blanco y contorno/sombra para legibilidad.
- Si Pillow no está disponible en el entorno de QGIS, la exportación continúa pero se registra aviso y la fecha no se estampa.

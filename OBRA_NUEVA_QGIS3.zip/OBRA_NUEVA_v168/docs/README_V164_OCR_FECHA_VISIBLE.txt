OBRA_NUEVA v1.6.4 - Detección opcional de fecha visible estampada

Cambios:
- La detección de fecha en fotografías ya no se limita a EXIF/nombre de archivo.
- Se añade un tercer intento de lectura: OCR sobre fecha estampada visualmente en la imagen.
- Se analizan primero franjas inferiores y esquinas inferiores de la fotografía, que son las zonas habituales donde aparece la fecha impresa.
- Se prueban varias preparaciones de imagen: escala, autocontraste, inversión y umbrales para mejorar lectura de texto claro/oscuro.
- Se reconocen formatos habituales: DD/MM/AAAA HH:MM, DD-MM-AAAA HH.MM, DD.MM.AAAA HHhMM, AAAA/MM/DD HH:MM y variantes sin separadores.
- La fecha normalizada se conserva siempre como DD/MM/AAAA HH:MM.

Notas de uso:
- La lectura visual requiere Tesseract disponible en el entorno de QGIS, bien como ejecutable del sistema o mediante el módulo pytesseract.
- Si Tesseract no está disponible o no consigue leer la fecha, el plugin mantiene el comportamiento seguro: pide la fecha manualmente y permite estamparla al exportar.
- No se rompe el flujo de importación aunque no exista OCR instalado.

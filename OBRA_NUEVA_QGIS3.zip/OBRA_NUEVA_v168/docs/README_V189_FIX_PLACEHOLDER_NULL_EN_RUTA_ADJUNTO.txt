V189 - FIX: RUTAS DE ADJUNTO QUE TERMINAN EN "NULL" YA NO SE MARCAN COMO "NO ENCONTRADAS"
============================================================================================

PROBLEMA
--------
Al archivar un GeoPackage real (SDON135.gpkg), el registro mostraba varios
avisos "No encontrado" para campos de foto cuya ruta terminaba literalmente
en "...\OTROS\GIS\NULL", por ejemplo:

  Fotos.foto_path (id 1): C:\...\SDON135_Estacion de Urnieta\OTROS\GIS\NULL

CAUSA
-----
El campo no estaba realmente vacío: contenía una ruta ABSOLUTA completa cuyo
nombre de fichero era literalmente "NULL". Es la convención que usa el
origen de estos datos para marcar "sin foto/documento" en vez de dejar el
campo vacío.

El filtro de valores nulos de `resolve_attachment_path` (core/gpkg_utils.py)
solo comparaba el VALOR COMPLETO del campo contra tokens como "", "null",
"none"... Como aquí el valor completo es una ruta larga (no solo la palabra
"NULL"), no coincidía con ningún token y el código intentaba resolverlo como
un adjunto real -- y, como no existe ningún fichero llamado "NULL", lo
marcaba (correctamente, dado el dato) como "no encontrado".

CORRECCIÓN
----------
core/gpkg_utils.py (`resolve_attachment_path`):
  Además de comparar el valor completo del campo contra los tokens nulos
  habituales, ahora también se compara el NOMBRE DE FICHERO (última parte
  de la ruta, con y sin extensión) contra esos mismos tokens. Si el nombre
  de fichero es "NULL" (con cualquier combinación de mayúsculas/minúsculas),
  el valor se trata igual que un campo vacío: no se resuelve como adjunto y
  no se avisa de "no encontrado". Un fichero real cuyo nombre solo CONTENGA
  la palabra "null" en otra posición (p. ej. "anular_null_2026.jpg") sigue
  resolviéndose con normalidad -- el criterio exige que sea el nombre
  completo (sin extensión), no una subcadena.

Este cambio afecta a la vez a "Archivar GPKG" y a "Consulta" (ambas usan
`resolve_attachment_path`), ya que comparten el mismo núcleo.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless) y con el GeoPackage real del usuario
(SDON135.gpkg) que generó los avisos originales:
  - Se confirmó en sqlite3 que los 5 registros afectados de "Fotos"
    contenían efectivamente una ruta completa terminada en "\NULL".
  - Tras la corrección, se repitió `archive_gpkg` sobre ese mismo
    GeoPackage real: los 4 casos de "\NULL" en la tabla "Fotos" ya no
    aparecen en la lista de adjuntos "no encontrados"; las fotos reales que
    sí tienen nombre de fichero genuino se siguen evaluando con
    normalidad (avisan solo si de verdad no se encuentran en disco).
  - Prueba nueva (`test_null_placeholder_attachment.py`, 9 comprobaciones):
    valores "NULL"/"" a secas, rutas absolutas terminadas en "\NULL" (con
    mayúsculas, minúsculas y barras "/"), un nombre real que solo CONTIENE
    "null" como subcadena (debe seguir resolviéndose), y un flujo completo
    de archivado con una foto real existente, una foto real inexistente y
    un placeholder "NULL" mezclados en la misma tabla.
  - Se repitió toda la batería de pruebas anteriores (21 pruebas en total)
    para confirmar que este cambio no rompe nada, incluida la resolución de
    rutas de documentos en "Consulta" (V182).

CÓMO COMPROBARLO EN TU QGIS
-----------------------------
1. Archiva de nuevo el mismo GeoPackage que mostraba los avisos "No
   encontrado: ...\NULL".
2. En el registro, esos avisos concretos ya no deben aparecer -- solo
   seguirán avisando los adjuntos que de verdad falten en disco (fotos con
   nombre de fichero real que no se encuentre en la carpeta esperada).

COMPATIBILIDAD
---------------
Cambio interno, solo en `core/gpkg_utils.py` (función
`resolve_attachment_path`, compartida por "Archivar GPKG" y "Consulta"). No
cambia ningún otro comportamiento: un adjunto realmente ausente sigue
avisando igual que antes. Ambas variantes QGIS3/QGIS4 comparten el mismo
comportamiento (archivo sin dependencias de Qt).

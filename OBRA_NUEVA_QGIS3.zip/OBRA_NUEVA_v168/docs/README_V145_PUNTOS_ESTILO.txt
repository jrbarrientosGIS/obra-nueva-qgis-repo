OBRA_NUEVA v145 - Estilo oficial puntos_informe

Cambios:
- Sustituido el QML empaquetado por el archivo puntos.qml aportado por el usuario.
- La capa puntos_informe carga automáticamente styles/puntos.qml al crearse.
- Si puntos_informe ya existe al abrir la pestaña Fotos, se reaplica el estilo oficial.
- Se evita sobrescribir por código el etiquetado/simbología del QML después de cargarlo.
- El mismo QML se deja también como styles/anejo.qml por compatibilidad con versiones anteriores.

Nota:
- Si una capa puntos_informe ya estaba creada con otro estilo en el proyecto, abrir la pestaña Fotos o seleccionar nuevas fotos debe reactivar el estilo oficial.

OBRA_NUEVA 1.7.30 - Fotos, bloque 3 (anejo fotografico): un informe por capa y planos a escala
==============================================================================================

INFORMES
- Cada informe tiene su propia capa de fotos: puntos_informe_IS-01, puntos_informe_IS-02, ...
  (informes semestrales) y puntos_informe_IF (informe final). Cada una se guarda en su
  GeoPackage junto a la obra (puntos_informe_IS-01.gpkg, ...).
- Nuevo selector «Informe:» y boton «Nuevo informe…» (propone el siguiente IS-NN y el IF).
  Todo el bloque trabaja sobre el informe elegido: seleccionar fotos, agrupar y renumerar,
  exportar a carpeta y DOCX.
- La capa antigua «puntos_informe» (sin codigo) se sigue viendo en el selector y se puede exportar.
- Al elegir carpeta se toman las fotos cuyo nombre empieza por el codigo del informe (IF…,
  IS-01 / IS01 / IS_01…); si no hay ninguna, se ofrece usar todas.
- Exportar a carpeta: las copias llevan el codigo del informe como prefijo (IF_, IS-01_…).
- Los planos generales solo muestran las fotos del informe que se exporta.

SELECCION DE FOTOS
- Carpeta y fichero: vista previa de cada foto con «Pinchar en lienzo», «Usar el GPS de la foto»,
  «Saltar esta foto» y «Detener», descripcion opcional y la casilla «Colocar las siguientes
  fotos con su GPS sin preguntar».
- Las fotos que ya estan en el informe se omiten (tambien al importar desde el lienzo). Si se
  detiene la cola, al volver a elegir la carpeta se sigue por donde se dejo.
- Fotos sin fecha: en la vista previa se propone la ultima fecha escrita; al importar desde el
  lienzo se puede marcar «usar esta fecha para las demas fotos sin fecha de esta tanda».

DOCX
- Una sola ventana de opciones: disposicion, escala del plano general y resumen.
- Escala del plano general: automatica o la que se elija (1:500 … 1:1.000.000, o escrita).
  Es la escala real del plano impreso (16,2 x 10,8 cm). Si las fotos no caben en un plano se
  hacen varios, sin separar nunca las dos fotos de una pareja. Automatica: un solo plano entre
  1:1.000 y 1:50.000; si no cabe, varios a 1:50.000.
- Cada plano lleva escala grafica (con «Escala 1:N») y norte, y el pie indica la escala.
- Titulo con el informe: «ANEJO FOTOGRAFICO · INFORME SEMESTRAL IS-01» / «· INFORME FINAL».
  Fichero: anejo_fotografico_<codigo>.docx.
- Las parejas se forman por Nº (1-2, 3-4…). Si falta una foto en su ruta queda su hueco y las
  demas parejas no se desplazan; se avisa antes. Con Nº repetidos o vacios no se genera y se
  indica cuales son.
- Las fotos van reducidas (lado mayor 2000 px) y giradas segun su EXIF: el DOCX pesa mucho menos
  y las fotos verticales de movil salen derechas.
- El resumen por parejas ya no deja «Fotos 1 y 2, .» cuando no hay descripcion.

- Cambios en ui/tab_fotos.py.
- La 1.7.29 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.29.zip y OBRA_NUEVA_QGIS4_v1.7.29.zip.

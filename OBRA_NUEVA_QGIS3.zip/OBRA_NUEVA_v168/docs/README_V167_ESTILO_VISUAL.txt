OBRA_NUEVA v167 - Estilo visual profesional + Agrupación IF por ubicación

== Estilo visual ==
- Añadido ui/styles.py: hoja de estilos QSS global con paleta azul/gris oscuro.
  Cubre: QDialog, QTabBar, QGroupBox, QLineEdit, QTextEdit, QPushButton,
  QCheckBox, QComboBox, QListWidget, QTreeWidget, QScrollBar, QHeaderView,
  QToolTip, QMessageBox y QSplitter.
- main_dialog.py: aplica get_stylesheet() en __init__; cabecera rediseñada con
  punto de color, título, subtítulo y barra de versión inferior.
- Consola de estado con objectName="status_console": estilo terminal.
- Pestañas con iconos Unicode: 🗂 Nueva Obra · 📂 Carga · 🗺 KMZ · 🔍 Consulta · 📷 Fotos.
- Botones de acción principal con objectName="run_btn": color acento azul #4A90D9.

== Agrupación IF por ubicación y renumeración ==
Nuevo botón "⇄ Agrupar IF por ubicación y renumerar" en el bloque 3 (Anejo fotográfico).

Comportamiento:
- Recoge todos los puntos de puntos_informe con informe_final=1.
- Los empareja por proximidad geográfica usando clustering greedy:
    · Ancla inicial: foto más al noroeste (mayor latitud, menor longitud).
    · Compañera: foto IF más cercana aún no emparejada (distancia euclidiana).
    · Se repite hasta agotar las fotos IF.
- Dentro de cada pareja, el número IMPAR se asigna a la foto más antigua
  (según campo fecha_foto) y el número PAR a la más reciente.
- Si una foto no tiene fecha_foto, se trata como la más reciente de la pareja.
- Si el número de fotos IF es impar se advierte y permite continuar; la foto
  sobrante recibe el número impar correspondiente.
- Las fotos NO marcadas como IF se renumeran al final conservando su orden original.
- Los cambios se aplican directamente sobre la capa puntos_informe cargada en QGIS
  (startEditing / commitChanges). Si falla el commit, se hace rollBack.
- Al finalizar se muestra un resumen con el número de parejas completas/incompletas.

Sin dependencias externas nuevas. Solo stdlib (math, datetime) y API QGIS/PyQt5.

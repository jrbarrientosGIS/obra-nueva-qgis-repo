OBRA_NUEVA v156 - DOCX: tablas y alineación inferior de fotografías

Cambios:
- Las fotografías del informe se insertan dentro de tablas para estabilizar la maquetación en Word.
- En disposición de dos fotos en paralelo, las celdas usan alineación vertical inferior.
- Si dos fotografías de la misma pareja tienen alturas distintas, quedan apoyadas visualmente por abajo y no alineadas por arriba.
- En disposición vertical, las dos fotografías de la pareja también se insertan en tabla centrada.
- Se mantiene el límite funcional de dos fotografías por página.

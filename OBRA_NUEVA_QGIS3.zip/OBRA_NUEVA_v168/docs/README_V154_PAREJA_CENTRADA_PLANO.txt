OBRA_NUEVA v154 - Pareja única centrada en plano general

Cambio aplicado:
- Cuando el Plano general de ubicación de fotografías contiene una única pareja de fotos, el encuadre se centra expresamente en esa pareja.
- Se evita que una pareja aislada aparezca desplazada hacia un borde del plano cuando la extensión de puntos_informe es muy pequeña o degenerada.
- El ajuste mantiene la relación de aspecto del PNG del plano y conserva un margen cartográfico razonable alrededor de los puntos.

Se mantienen los cambios previos:
- Exportación DOCX a carpeta seleccionada.
- Dos fotos por página.
- Texto bajo plano: Localización de las fotos de los emplazamientos n/N.
- Etiquetas Foto: Nº visibles independientemente de escala.
- Respeto de capas visibles en el lienzo.
- Estilo oficial puntos_informe desde puntos.qml.

V180 - "CONSULTA": BÚSQUEDA RECURSIVA EN SUBCARPETAS + VENTANA DE SELECCIÓN
============================================================================

PETICIÓN
--------
"Esta vez vamos a repensar la pestaña consulta. En principio al
seleccionar carpeta se ha de permitir la búsqueda recursiva en todas las
subcarpetas, en segundo lugar, una vez finalizada la búsqueda se nos
abrirá una ventana emergente que nos permitirá seleccionar los GPKG
sobre los que realizaremos la búsqueda."

SITUACIÓN ANTERIOR
-------------------
"Escanear carpeta" (`ConsultaTab.scan_folder`) solo miraba los archivos
.gpkg directamente dentro de la carpeta elegida (`os.listdir`, sin
recursividad) y a continuación escaneaba TODOS los que encontraba, capa
a capa y valor a valor, sin dar opción a excluir ninguno antes de ese
análisis (el más costoso de la operación).

CORRECCIÓN
----------
ui/tab_consulta.py:
  1. La búsqueda ahora es RECURSIVA: se reutiliza la misma función que ya
     usa "Actualiza GPKG" para su actualización masiva de carpeta
     (`core.gpkg_updater.scan_gpkg_files_recursive`), que recorre la
     carpeta elegida y TODAS sus subcarpetas (`os.walk`), excluyendo
     automáticamente las copias de seguridad que crea el propio plugin
     (sufijo "_backup_AAAAMMDD_HHMMSS").
  2. En cuanto termina esa búsqueda (antes de analizar ninguna capa), se
     abre una ventana emergente nueva (`GpkgSelectionDialog`) con la
     lista completa de GeoPackage encontrados -- mostrando la ruta
     relativa a la carpeta elegida, para distinguir de un vistazo los
     que están en subcarpetas -- cada uno con su casilla de verificación
     (todos marcados por defecto), más los botones "Seleccionar
     todo"/"Ninguno". Solo tras pulsar "Aceptar" se procede; solo los
     GeoPackage que queden marcados se abren y analizan (capas, campos,
     valores de Ámbito/Tipo/Periodo) -- los demás se descartan sin
     tocarlos, ahorrando tiempo cuando la carpeta contiene muchos
     GeoPackage de los que no interesan. Si se pulsa "Cancelar", el
     escaneo se aborta sin cambiar nada de lo que ya hubiera en la
     pestaña.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless) y un GeoPackage real del usuario
(SDON_78.gpkg), copiado tres veces en una estructura de carpetas
anidadas (carpeta raíz, subcarpeta y sub-subcarpeta) más una copia con
sufijo "_backup_...": se ejecutó `ConsultaTab.scan_folder()` de verdad
simulando la ventana emergente (sin bloquear el bucle de eventos, igual
que en las pruebas de diálogos anteriores).
  - Se confirmó que la búsqueda recursiva encuentra los 3 GeoPackage
    (raíz + subcarpeta + sub-subcarpeta) y excluye correctamente la
    copia de seguridad.
  - Se confirmó que, al cancelar la ventana emergente, no se modifica el
    estado de la pestaña (sin datos de escaneo).
  - Se confirmó que, al aceptar la ventana emergente con uno de los tres
    GeoPackage desmarcado, SOLO los dos marcados se escanean y
    aparecen en los resultados (`scan_info`, `gpkg_files`) -- el
    desmarcado no se toca en absoluto.
  - Se repitió el flujo completo (escaneo con todos marcados por
    defecto + "Ejecutar consulta" real) para confirmar que el resto de
    la pestaña sigue funcionando exactamente igual que antes.
Se repitió también toda la batería de pruebas anteriores (V174-V179)
para confirmar que este cambio, al no tocar ningún otro módulo, no
rompe nada.

CÓMO COMPROBARLO EN TU QGIS
-----------------------------
1. En la pestaña "Consulta", elige una carpeta que tenga GeoPackage
   tanto en la raíz como en alguna subcarpeta.
2. Pulsa "Escanear carpeta": debe aparecer una ventana con la lista de
   TODOS los GeoPackage encontrados (incluidos los de las subcarpetas),
   cada uno con su ruta relativa y su casilla marcada.
3. Desmarca alguno y pulsa "Aceptar": el registro y los filtros
   (Obra/Ámbito/Tipo/Periodo) solo deben reflejar los GeoPackage que
   quedaron marcados.

COMPATIBILIDAD
---------------
Afecta solo a ui/tab_consulta.py (y a un nuevo import de la función ya
existente `scan_gpkg_files_recursive` de core/gpkg_updater.py, sin
modificar esa función). No afecta a ninguna otra pestaña ni a la
estructura de datos de ningún GeoPackage. Ambas variantes QGIS3/QGIS4
comparten el mismo comportamiento (solo difieren, como siempre, en los
enums planos/con ámbito de Qt: `Qt.Checked`/`Qt.CheckState.Checked`,
`exec_()`/`exec()`, etc.).

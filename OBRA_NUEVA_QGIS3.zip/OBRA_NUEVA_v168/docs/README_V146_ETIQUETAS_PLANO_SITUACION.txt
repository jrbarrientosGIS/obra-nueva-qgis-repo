OBRA_NUEVA v146 - Etiquetas robustas en planos de situación

Cambio principal:
- En los planos de situación del anejo fotográfico, las etiquetas Foto: Nº de puntos_informe se dibujan manualmente sobre el PNG exportado.
- Esto evita que el motor de etiquetado de QGIS oculte etiquetas por conflicto a cualquier escala.
- Las etiquetas mantienen tamaño visual constante, independiente de la escala del plano: 1:300, 1:20.000 o escalas intermedias.
- Si dos o más puntos/fotos están próximos, las llamadas se recolocan automáticamente alrededor del punto con línea guía.
- La capa real puntos_informe no se modifica: conserva su simbología QML oficial y sus atributos.

Regla funcional:
- En el anejo: una foto = una ficha.
- En el plano de situación: una foto = una etiqueta visible. No se fusionan ni se ocultan etiquetas por escala.

OBRA_NUEVA v162 - Corrección DOCX vertical no legible

Corrección aplicada sobre v161.

Motivo:
- Word podía mostrar el aviso "contenido no legible" al abrir el DOCX generado en disposición vertical.
- La causa probable era la implementación de v161, que usaba una tabla anidada dentro de una celda para intentar mantener la pareja en la misma página.

Cambios:
- Se elimina la tabla anidada en disposición vertical.
- El bloque fotográfico vertical vuelve a generarse como una única tabla global plana.
- Cada pareja se estructura como filas consecutivas: foto, pie, foto, pie.
- Se aplican keepNext y cantSplit para intentar mantener cada pareja en la misma página sin producir XML conflictivo para Word.
- Se mantiene el ajuste automático de tamaño en vertical para aprovechar el espacio y evitar separar parejas cuando sea posible.

Se mantiene:
- Fotos horizontales a 8 cm.
- Tabla global del bloque fotográfico.
- Planos generales sin título, solo con pie.
- Etiquetas grandes en planos generales.
- Previsualización escalable.

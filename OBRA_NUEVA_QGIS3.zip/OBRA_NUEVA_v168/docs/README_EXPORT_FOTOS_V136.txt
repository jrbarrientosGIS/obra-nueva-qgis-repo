OBRA_NUEVA - EXPORT_FOTOS V136

Hotfix de persistencia para Sección 2.

Cambios:
- La previsualización de foto individual/carpeta ya no intenta crear ni guardar la capa en GeoPackage.
- La herramienta de clic en canvas trabaja primero con capa en memoria.
- La capa fotos_georref/fotos_informe se persiste en GeoPackage después de insertar el punto.
- Corregida la opción de escritura GPKG: CreateOrOverwriteFile si el archivo no existe, CreateOrOverwriteLayer si existe.
- Si OGR bloquea la escritura, el flujo no se rompe: mantiene la capa en memoria y avisa en la barra de mensajes.

V183 - "CONSULTA": LA BARRA DE ESCANEO SE ANIMA TAMBIÉN DURANTE LA BÚSQUEDA DE CARPETAS
==========================================================================================

PETICIÓN
--------
"LA BARRA DE PROGRESO DE ESCANEAR CARPETA TAMBIEN SE DEBE LLENAR CUANDO ESTA
ESCANEANDO LOS DIRECTORIOS."

CAUSA
-----
La V181 añadió una barra de progreso al escaneo, pero solo avanzaba durante
la segunda fase (analizar capa por capa cada GeoPackage ya localizado). La
PRIMERA fase -- recorrer recursivamente la carpeta elegida y todas sus
subcarpetas en busca de ficheros .gpkg, mediante `scan_gpkg_files_recursive`
mediante `os.walk` -- se ejecutaba de un tirón, sin ceder el control a la
interfaz. La barra se quedaba con el texto fijo "Buscando GeoPackage..." sin
moverse en ningún momento durante toda esa búsqueda, que en árboles de
carpetas grandes (muchas subcarpetas de obra) puede tardar bastante --
dando la sensación de que el programa se había quedado colgado.

CORRECCIÓN
----------
core/gpkg_updater.py:
  `scan_gpkg_files_recursive(folder_path, exclude_paths=None,
  progress_cb=None)` admite ahora un parámetro opcional `progress_cb`. Tras
  procesar cada subcarpeta del recorrido `os.walk`, si se ha pasado
  `progress_cb`, se le llama como `progress_cb(current_dir, dirs_visited,
  found_count)` -- con la carpeta que se acaba de revisar, cuántas
  subcarpetas se llevan revisadas y cuántos .gpkg se llevan encontrados
  hasta el momento. Cualquier excepción del callback se ignora, para que un
  fallo ahí nunca pueda interrumpir la búsqueda. Al no pasar `progress_cb`
  (como sigue haciendo "Actualiza GPKG" al analizar una carpeta completa) el
  comportamiento es exactamente el mismo que antes.

ui/tab_consulta.py:
  `ConsultaTab.scan_folder()` pone ahora la barra de escaneo en modo
  "ocupado" (mínimo y máximo a 0, el modo estándar de Qt para barras
  indeterminadas que se animan solas) mientras dura la primera fase, y le
  pasa un callback que actualiza el TEXTO de la barra en cada subcarpeta
  revisada: "Buscando... N carpeta(s) revisada(s), M GeoPackage
  encontrado(s)", llamando además a `QApplication.processEvents()` para que
  la interfaz se repinte y se note el avance real mientras dura el
  recorrido, en vez de congelarse hasta el final. Al terminar la búsqueda,
  la barra pasa a un mensaje claro con el total encontrado ("N GeoPackage
  encontrados -- elige cuáles escanear") antes de abrir la ventana de
  selección, y a partir de ahí la segunda fase (analizar los GeoPackage
  elegidos) sigue funcionando igual que en la V181, con su barra
  determinada de "Escaneando: %v / %m GeoPackage".

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless): prueba dedicada
(test_consulta_scan_walk_progress.py) que 1) llama directamente a
`scan_gpkg_files_recursive` con un `progress_cb` de prueba sobre un árbol
de 6 subcarpetas y 2 GeoPackage reales, comprobando que el callback se
dispara una vez por subcarpeta, que `dirs_visited` crece de forma
estrictamente creciente y que el recuento final de encontrados es correcto;
y 2) ejecuta `ConsultaTab.scan_folder()` de principio a fin, registrando
cada texto que se llega a poner en la barra de progreso, comprobando que
aparecen los mensajes de avance ("Buscando... N carpeta(s)...") DURANTE el
recorrido y el mensaje final con el total antes de la ventana de selección,
y que la lista de GeoPackage detectados es la correcta. Se repitió también
toda la batería de pruebas anteriores (V174-V182, 14 pruebas en total) para
confirmar que este cambio no rompe nada.

CÓMO COMPROBARLO EN TU QGIS
-----------------------------
1. En la pestaña "Consulta", elige una carpeta con varias obras en
   subcarpetas (a poder ser, un árbol con bastantes niveles) y pulsa
   "Escanear carpeta".
2. Observa que la barra de progreso se anima (modo "ocupado") y que su
   texto va cambiando en tiempo real, mostrando cuántas carpetas se han
   revisado y cuántos GeoPackage se han encontrado hasta ese momento,
   mientras dura la búsqueda.
3. Al terminar, la barra muestra el total de GeoPackage encontrados y se
   abre la ventana de selección, igual que antes.

COMPATIBILIDAD
---------------
Cambio interno en `core/gpkg_updater.py` (parámetro opcional, no rompe
ninguna llamada existente, incluida la de "Actualiza GPKG") y en
`ui/tab_consulta.py`. No afecta a ninguna otra pestaña. Ambas variantes
QGIS3/QGIS4 comparten el mismo comportamiento.

OBRA_NUEVA v160 - Etiquetas ampliadas en planos generales

Cambio aplicado:
- En los planos generales del informe se duplica el tamaño de las etiquetas manuales Foto: Nº.
- Se escalan también separaciones, márgenes, cajas de fondo y líneas guía para mantener la legibilidad.
- El cambio afecta solo al PNG insertado en el DOCX; no modifica la capa puntos_informe ni su QML.

Base: v159-preview-escalable.

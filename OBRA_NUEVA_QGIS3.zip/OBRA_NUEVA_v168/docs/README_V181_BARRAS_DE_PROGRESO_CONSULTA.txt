V181 - "CONSULTA": BARRAS DE PROGRESO PARA EL ESCANEO Y PARA LA CONSULTA
==========================================================================

PETICIÓN
--------
"Añádele una barra de progreso al escaneo." Y, sobre la marcha:
"Añade otra barra de progreso asociada al botón Ejecutar consulta."

SITUACIÓN ANTERIOR
-------------------
Tanto "Escanear carpeta" (que abre y analiza, capa a capa, cada
GeoPackage marcado en la ventana emergente de V180) como "Ejecutar
consulta" (que recorre cada GeoPackage y cada capa seleccionada,
entidad a entidad, para aplicar los filtros) podían tardar un rato con
carpetas grandes, sin ningún indicador visual de avance más allá del
registro de texto -- no había forma de saber, de un vistazo, cuánto
quedaba ni si el proceso seguía vivo.

CORRECCIÓN
----------
ui/tab_consulta.py: dos barras de progreso nuevas, independientes entre
sí:
  1. `self.scan_progress`, bajo el grupo "Carpeta de GeoPackage" (justo
     debajo de "Escanear carpeta"): al confirmar la ventana emergente de
     selección de GeoPackage, se fija el máximo al número de
     GeoPackage marcados y avanza uno a uno según se van escaneando
     ("Escaneando: X / Y GeoPackage"), terminando en "Escaneo
     completado: Y / Y GeoPackage". Si el escaneo se cancela o no
     encuentra nada, la barra se reinicia con un texto que explica por
     qué (p. ej. "Selección cancelada").
  2. `self.query_progress`, encima de los botones "Ejecutar
     consulta"/"Cerrar": al pulsar "Ejecutar consulta" se calcula de
     antemano cuántas combinaciones GeoPackage×capa se van a procesar
     de verdad según los filtros de Obra/capas activas, y la barra
     avanza una unidad por cada una ("Consultando: X / Y capas"),
     terminando en "Consulta completada: Y / Y capas". Si se pulsa sin
     haber escaneado antes, o sin ninguna capa marcada, la barra se
     reinicia con el aviso correspondiente en vez de quedarse en un
     estado ambiguo.
Ambas barras llaman a `QApplication.processEvents()` en cada paso para
que la interfaz se repinte y siga respondiendo durante el proceso, en
vez de quedar "congelada" hasta el final. Se añadió también un bloque
de estilo `QProgressBar`/`QProgressBar::chunk` a ui/styles.py (color de
la paleta ya existente, `accent`) para que ambas barras seen visualmente
coherentes con el resto del panel oscuro del plugin.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless) y GeoPackage reales del usuario, copiados
en una estructura de carpetas con subcarpetas:
  - Se comprobó que `scan_progress` arranca en estado "listo" (0 / 1),
    avanza exactamente 1 en 1 según se escanea cada GeoPackage marcado,
    y termina mostrando el texto de "completado" con el valor igual al
    máximo. También que, al cancelar la ventana emergente, la barra se
    reinicia limpiamente en vez de quedar a medias.
  - Se comprobó que `query_progress` arranca en "listo" (0 / 1), que
    pulsar "Ejecutar consulta" sin haber escaneado antes (o sin
    ninguna capa marcada) la reinicia con el aviso correspondiente sin
    tocar nada más, y que, en una consulta real con 2 GeoPackage y las
    3 capas por defecto marcadas, avanza de forma monótona (0→1→...→6)
    hasta el número real de combinaciones procesadas, terminando en el
    texto de "completada".
Se repitió también toda la batería de pruebas anteriores (V174-V180)
para confirmar que este cambio, puramente de interfaz, no rompe nada.

CÓMO COMPROBARLO EN TU QGIS
-----------------------------
1. En "Consulta", escanea una carpeta con varios GeoPackage: debajo de
   "Escanear carpeta" debe verse la barra avanzar mientras se procesan.
2. Pulsa "Ejecutar consulta": encima de ese botón debe verse otra barra
   avanzando según se recorren los GeoPackage y capas seleccionados.

COMPATIBILIDAD
---------------
Afecta solo a ui/tab_consulta.py y ui/styles.py (añade una regla QSS
nueva, no modifica ninguna existente). No afecta a ninguna otra pestaña
ni a la estructura de datos de ningún GeoPackage. Ambas variantes
QGIS3/QGIS4 comparten el mismo comportamiento (solo difieren, como
siempre, en los enums planos/con ámbito de Qt).

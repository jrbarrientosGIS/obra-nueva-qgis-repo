V182 - "CONSULTA": LOS DOCUMENTOS Y FOTOS ADJUNTOS QUEDAN ACCESIBLES EN EL RESULTADO
======================================================================================

PETICIÓN
--------
"Al ejecutar la consulta, se pierden las rutas a los documentos y fotos
insertados en las capas, quiero que esos documentos se incluyan en el
resultado de la consulta, no como ruta sin destino, sino perfectamente
accesibles."

CAUSA
-----
Los campos de documento/foto ("Ficha", "Foto 1"-"Foto 4", "Doc_Apertura",
"Doc_Cierre"...) usan el widget "ExternalResource" de QGIS, y su valor
suele guardarse como una ruta RELATIVA (relativa a la carpeta del propio
GeoPackage, o a una subcarpeta como "fotos/"). Eso funciona bien cuando
se abre la capa original, porque QGIS puede resolver esa ruta relativa
contra la carpeta donde vive ese GeoPackage concreto.

Pero "Consulta" agrega resultados de VARIOS GeoPackage a la vez -- a
veces de carpetas distintas -- en tres capas temporales en memoria
(RESULT_PUNTOS/LINEAS/POLIGONOS) que no tienen ninguna carpeta propia.
Al construir esas capas resultado (`make_result_layer`/
`build_feature_out`), el plugin copiaba el VALOR de esos campos tal
cual (la ruta relativa, sin cambios) pero nunca copiaba la configuración
del widget "ExternalResource" del campo -- así que en el resultado esos
campos aparecían como texto plano, con una ruta relativa que ya no tenía
ninguna carpeta de referencia frente a la que resolverse: "una ruta sin
destino", exactamente como describe el usuario.

CORRECCIÓN
----------
ui/tab_consulta.py + core/gpkg_utils.py:
  1. Nueva función reutilizable `core.gpkg_utils.resolve_attachment_path
     (raw_value, gpkg_path)`: dado el valor guardado en un campo de
     documento y la ruta del GeoPackage de origen, prueba la carpeta del
     propio GeoPackage y varias subcarpetas habituales (fotos/Fotos/
     FOTOS, documentos/Documentos, fichas/Fichas, informes/Informes,
     anejo/Anejo, imagenes/Imágenes...) -- el mismo criterio ya probado
     en la pestaña "Fotos" (`_photo_paths`), generalizado a cualquier
     tipo de documento, no solo imágenes, y expuesto como función
     compartida. Devuelve la ruta ABSOLUTA (encontrada de verdad en
     disco, o la mejor estimación si no) y si se encontró o no.
  2. `ConsultaTab._document_field_names(layer)`: detecta, de forma
     genérica (sin depender de una lista fija de nombres de campo), qué
     campos de una capa origen están configurados como
     "ExternalResource" -- cubre cualquier campo de documento que el
     modelo defina, presente o futuro.
  3. `ConsultaTab._apply_document_widgets(...)`: traslada ese widget
     "ExternalResource" a la capa resultado, pero fuerza
     `RelativeStorage` a Absoluto -- puesto que ahora los valores ya se
     guardan como rutas absolutas reales, el widget del resultado debe
     interpretarlos tal cual, sin intentar resolverlos otra vez contra
     una carpeta relativa que ya no pinta nada en una capa que mezcla
     varios GeoPackage de origen.
  4. `build_feature_out(...)` ahora resuelve el valor de cada campo de
     documento con `resolve_attachment_path` ANTES de copiarlo a la
     entidad resultado, usando la carpeta del GeoPackage del que viene
     ESA entidad en concreto (no una carpeta compartida), así que cada
     documento queda accesible sin importar de qué obra/carpeta procede.
  5. Antes de leer el `editorWidgetSetup` de cada capa origen, se llama
     a `src.loadDefaultStyle()` para CADA GeoPackage consultado (no solo
     el primero) -- necesario para que el widget "ExternalResource"
     esté realmente cargado y se detecte, en una consulta que mezcla
     varias obras.
  6. Si algún documento no se llega a encontrar en ninguna carpeta
     candidata, se guarda igualmente la mejor ruta absoluta estimada
     (para no dejar el campo vacío) y se avisa en el registro de la
     pestaña con la lista de campos/rutas no encontrados, para que el
     usuario sepa qué revisar.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless): se construyó un GeoPackage de prueba con
una capa de Puntos y un campo "Foto 1" (ExternalResource, ruta relativa
a una subcarpeta "fotos/"), con dos entidades -- una cuya foto SÍ existe
en disco y otra cuya foto NO existe -- y se guardó como estilo
persistido del GeoPackage (igual que deja "Actualiza GPKG" en un
GeoPackage real). Se ejecutó el flujo real de "Consulta" (escanear +
ejecutar consulta) y se comprobó que:
  - La entidad con foto real queda con una ruta ABSOLUTA que apunta
    exactamente al fichero real en disco.
  - La entidad con foto inexistente queda con una ruta absoluta
    (mejor estimación) y aparece listada en el aviso de "no
    encontrados" del registro.
  - El campo "Foto 1" de la capa resultado queda con el widget
    "ExternalResource" y `RelativeStorage=Absoluto`.
Se repitió también toda la batería de pruebas anteriores (V174-V181)
para confirmar que este cambio no rompe nada.

CÓMO COMPROBARLO EN TU QGIS
-----------------------------
1. Ejecuta una consulta que incluya obras con fotos/documentos
   adjuntados.
2. Abre la tabla de atributos de RESULT_PUNTOS (o Líneas/Polígonos) y
   comprueba que los campos de foto/documento muestran una ruta
   absoluta y que el botón del widget abre el fichero correctamente.
3. Si el registro muestra el aviso de "no encontrados", revisa esas
   rutas -- indica que el fichero no está donde se esperaba.

COMPATIBILIDAD
---------------
Afecta a ui/tab_consulta.py y añade una función nueva en
core/gpkg_utils.py (no modifica ninguna función existente de ese
fichero). No afecta a ninguna otra pestaña ni a los datos originales de
ningún GeoPackage (los ficheros de fotos/documentos no se mueven ni
copian, solo se referencian con su ruta absoluta). Ambas variantes
QGIS3/QGIS4 comparten el mismo comportamiento.

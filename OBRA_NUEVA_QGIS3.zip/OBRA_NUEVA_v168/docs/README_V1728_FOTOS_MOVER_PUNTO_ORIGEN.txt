OBRA_NUEVA 1.7.28 - Fotos, bloque 2: mover tambien el punto de origen
=====================================================================

- Si la foto se elige con «1. Seleccionar en el Lienzo» y la entidad pinchada es un punto (p. ej. de una capa de «Importar fotos geoetiquetadas»), al colocar la foto ese punto se mueve en su capa al sitio pinchado.
- Se actualizan tambien sus campos de coordenadas si existen: longitude/latitude o lon/lat (WGS84) y x/y (SRC de la capa). Se conserva la altitud (Z) y el tipo de geometria.
- Capa sin editar: el cambio se guarda directamente. Capa ya en edicion: el cambio queda en su edicion, sin guardar ni descartar los demas cambios.
- Con varias fotos en la misma entidad, el punto se mueve con la primera que se coloca.
- Las lineas y los poligonos no se mueven. Las fotos elegidas por fichero o carpeta no mueven nada.
- Cambio en ui/tab_fotos.py (_mover_entidad_origen).
- La 1.7.27 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.27.zip y OBRA_NUEVA_QGIS4_v1.7.27.zip.

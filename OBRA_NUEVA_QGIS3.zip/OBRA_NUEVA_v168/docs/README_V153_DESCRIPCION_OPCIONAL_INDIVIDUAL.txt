OBRA_NUEVA v153 - Descripción opcional en foto individual para informe final

Cambio aplicado sobre v152:

1. En el flujo de "Seleccionar foto individual" del bloque Anejo Fotográfico / puntos_informe,
   la previsualización pregunta expresamente si se quiere añadir descripción.
2. Se añade la casilla "Añadir descripción de la fotografía".
3. El campo de descripción permanece desactivado hasta marcar la casilla.
4. Si no se marca la casilla, la fotografía se inserta con descripción vacía.
5. Si se marca, el texto introducido se guarda en el campo de descripción de puntos_informe
   y se usa después en el anejo DOCX.

Se mantienen los cambios anteriores: dos fotos por página, texto bajo plano general,
carpeta de salida DOCX, parejas, resumen opcional, etiquetas visibles, capas activas
del lienzo y ventana escalable.

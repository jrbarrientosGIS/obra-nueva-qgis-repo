V185 - "ACTUALIZA GPKG" Y "ARCHIVAR GPKG" PROPONEN POR DEFECTO EL GPKG YA CARGADO EN EL PROYECTO
====================================================================================================

PETICIÓN
--------
"Tanto en la pestaña Actualizar, como en la pestaña Archivar, al
seleccionar el GPKG a actualizar como el GPKG a archivar, debe contener
por defecto el GPKG cargado en el proyecto actual de QGIS."

CAUSA
-----
Los campos "GPKG a actualizar (antiguo)" (en "Actualiza GPKG", modo "un
solo GeoPackage") y "GeoPackage a archivar" (en "Archivar GPKG") se
abrían siempre vacíos (o con el último GeoPackage usado, si lo había),
obligando al usuario a volver a buscar con el selector de archivos el
mismo GeoPackage que ya tenía abierto y cargado en el lienzo de QGIS.

CORRECCIÓN
----------
core/gpkg_utils.py:
  Nuevas funciones compartidas:
    - `detect_loaded_gpkg_paths()`: recorre las capas vectoriales cargadas
      en el proyecto QGIS actual y devuelve, sin duplicados y en el mismo
      orden en que aparecen, las rutas de los GeoPackage (.gpkg) de los
      que provienen -- mismo criterio ya probado en ui/tab_fotos.py
      (`_find_loaded_gpkgs`): mirar `layer.source()` y quedarse con la
      parte antes de "|layername=...".
    - `primary_loaded_gpkg_path()`: el primero de esos GeoPackage, o
      `None` si no hay ninguno cargado.

ui/tab_actualiza_gpkg.py:
  Nuevo método `refresh_project_default()`: si el modo es "un solo
  GeoPackage" y el campo "GPKG a actualizar (antiguo)" está vacío, lo
  rellena con el GeoPackage detectado como cargado en el proyecto. Se
  llama al cambiar de modo, al restaurar el estado de la pestaña, y cada
  vez que esta pestaña pasa a ser la pestaña activa del panel principal.
  En modo "carpeta completa" no se toca (ese campo es una carpeta, no un
  GeoPackage individual).

ui/tab_archivar_gpkg.py:
  Mismo método `refresh_project_default()` para el campo "GeoPackage a
  archivar": si está vacío, se rellena con el GeoPackage cargado en el
  proyecto. Se llama al restaurar el estado de la pestaña y cada vez que
  pasa a ser la pestaña activa.

ui/main_dialog.py:
  Al cambiar de pestaña, si la pestaña activa es "Actualiza GPKG" o
  "Archivar GPKG", se llama a su `refresh_project_default()` -- así, si el
  usuario carga un GeoPackage nuevo en el lienzo (p. ej. desde "Carga
  Obra") y luego cambia a alguna de estas dos pestañas sin haber
  seleccionado nada todavía, el campo se rellena solo.

En ningún caso se sobrescribe una ruta que el usuario ya haya elegido a
mano (con el selector de archivos, o escribiéndola directamente): el
relleno automático solo actúa cuando el campo está vacío.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless): se creó un GeoPackage de prueba, se cargó
como capa en `QgsProject.instance()` (igual que hace QGIS al abrir un
proyecto con ese GeoPackage, o tras usar "Carga Obra") y se comprobó que:
  - Sin ningún GeoPackage cargado, no se propone nada.
  - Con el GeoPackage cargado, tanto `ActualizaGpkgTab.old_edit` como
    `ArchivarGpkgTab.src_edit` se autocompletan con su ruta al construir
    la pestaña.
  - Si el usuario ya ha escrito o elegido otra ruta, `refresh_project_default()`
    NO la sobrescribe.
  - En modo "carpeta completa" de "Actualiza GPKG", no se autocompleta
    (correcto, ese campo espera una carpeta).
  - Si el campo se vacía después de construir la pestaña (simulando que
    el proyecto se cargó más tarde) y se llama a `refresh_project_default()`
    de nuevo, se rellena correctamente.
Se repitió también toda la batería de pruebas anteriores (V174-V184, 17
pruebas en total) para confirmar que este cambio no rompe nada.

CÓMO COMPROBARLO EN TU QGIS
-----------------------------
1. Abre un proyecto QGIS que ya tenga cargado un GeoPackage de OBRA_NUEVA
   (o cárgalo con "Carga Obra").
2. Ve a "Actualiza GPKG" (modo "Un solo GeoPackage") o a "Archivar GPKG":
   el campo del GeoPackage a actualizar/archivar debe aparecer ya
   relleno con la ruta de ese GeoPackage.
3. Si cambias esa ruta a mano y vuelves a cambiar de pestaña y regresas,
   tu elección se conserva (no se sobrescribe).

COMPATIBILIDAD
---------------
Cambio aditivo en `core/gpkg_utils.py` (dos funciones nuevas, no modifica
ninguna existente), `ui/tab_actualiza_gpkg.py`, `ui/tab_archivar_gpkg.py`
y `ui/main_dialog.py`. No afecta a ninguna otra pestaña. Ambas variantes
QGIS3/QGIS4 comparten el mismo comportamiento.

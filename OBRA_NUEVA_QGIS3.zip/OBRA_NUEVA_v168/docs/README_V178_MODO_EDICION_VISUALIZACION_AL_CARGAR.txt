V178 - "CARGAR EN EL LIENZO" TRAS ACTUALIZAR AHORA PREGUNTA EL MODO (COMO "CARGA OBRA")
============================================================================================

PETICIÓN
--------
"Ahora cuando carga el gpkg actualizado, pide visualización o edición,
asegúrate que en edición carga la leyenda completa y en visualización la
leyenda recortada a los elementos gráficos contenidos en la capa."

Tras actualizar un GeoPackage con "Actualiza GPKG", el aviso de "¿Quieres
cargar el GeoPackage actualizado en el lienzo?" solo tenía Sí/No, y
siempre cargaba con la leyenda RECORTADA (solo las categorías que ya
tienen entidades en los datos) -- sin la opción de cargar la leyenda
COMPLETA del modelo para poder seguir dando de alta elementos de
cualquier categoría, que es justo lo que la pestaña "Carga Obra" ya
ofrece con sus dos modos "Edición"/"Visualización".

CORRECCIÓN
----------
ui/tab_actualiza_gpkg.py (`_offer_load_in_canvas`): el aviso de "cargar en
el lienzo" ahora ofrece tres botones, igual que el diálogo de modo de
"Carga Obra":
  - "Edición": carga la leyenda COMPLETA del modelo (todas las
    categorías, aunque los datos aún no tengan entidades de todas ellas)
    -- para poder seguir dando de alta elementos de cualquier tipo.
  - "Visualización" (opción por defecto, como antes): carga la leyenda
    RECORTADA a las categorías que ya tienen entidades en cada capa.
  - "No": no carga nada (como antes).
Internamente, se pasa `prune_legend=False` para "Edición" y
`prune_legend=True` para "Visualización" al cargador -- el mismo
parámetro que ya usa "Carga Obra" para lo mismo, así que el
comportamiento es idéntico entre las dos pestañas.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless) y los ficheros reales del usuario
(SDON79.gpkg + su modelo, con la capa de Polígonos con 16 categorías
posibles y solo 1 realmente presente en los datos): se ejecutó la
pestaña "Actualiza GPKG" de verdad (Analizar → Actualizar) simulando el
clic en "Edición" en una prueba y en "Visualización" en otra. Resultado:
con "Edición" la capa de Polígonos queda con las 16 categorías del
modelo; con "Visualización", con solo 1 (la única presente en los
datos) -- igual que ya hace "Carga Obra". Se repitió también toda la
batería de pruebas anteriores (V174-V177) para confirmar que este cambio
no las rompe.

COMPATIBILIDAD
---------------
Afecta solo a ui/tab_actualiza_gpkg.py. No afecta a "Carga Obra" (que ya
tenía este comportamiento), "Nueva Obra", KMZ, Consulta ni Fotos. Ambas
variantes QGIS3/QGIS4 comparten el mismo comportamiento (solo difieren,
como siempre, en los enums planos/con ámbito de Qt).

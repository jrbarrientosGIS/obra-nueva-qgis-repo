V190 - REORDENACION DE TIPOS DE INCIDENCIAS Y CAMPO "ASPECTO AMBIENTAL" + "ZONA"
==================================================================================

PETICION
--------
En el ambito "7-Incidencias" de la tabla CLAVE, reordenar los tipos para que
queden: 7.1 Incidencias Ambientales, 7.2 No Conformidades, 7.3 Denuncias,
7.4 Emergencias. Ademas, al introducir un elemento grafico de Ambito
"7-Incidencias" y Tipo "Incidencias Ambientales", pedir el aspecto ambiental
con el que esta relacionado (codigo del checklist, p. ej. "SUE-01.1") y la
zona (ZIA/Tajo/Tunel/Acceso).

CAMBIOS
-------
1. Tabla CLAVE (SDONXXX_MODELO - IV.gpkg): los 3 tipos existentes de
   "7-Incidencias" se reordenaron y renombraron, y se dio de alta un cuarto:
     7.1 Incidencias Ambientales   (nuevo)
     7.2 No Conformidades          (antes "No conformidades por impacto en el medio")
     7.3 Denuncias                 (antes 7.1)
     7.4 Emergencias               (antes 7.3, "Emergencias (danos a flora o fauna, incendios, otros)")
   Como "Tipo" es un ValueRelation sobre CLAVE filtrado por Ambito y
   ordenado por "key" (ver estilo de Puntos/Lineas/Poligonos), el cambio de
   contenido de la tabla ya reordena y renombra el desplegable sin tocar
   ningun estilo QML.

   OJO -- dato ya guardado en obras reales: el valor que se guarda en cada
   entidad es el numero (7.1, 7.2...), no el texto. Si alguna obra en
   produccion ya tiene incidencias con Tipo=7.1 bajo el esquema ANTIGUO
   (7.1=Denuncias), esos registros pasaran a leerse como "Incidencias
   Ambientales" en cuanto se sincronice este modelo con "Actualiza GPKG".
   Revisar caso por caso antes de propagar el cambio si existen esas obras.

2. Tabla nueva ASPECTOS (SDONXXX_MODELO - IV.gpkg): 93 filas con los
   codigos de aspecto ambiental del checklist (CODIGO, DESCRIPCION,
   CATEGORIA, APARTADO, ORDEN, ETIQUETA), extraidos de la plantilla
   IVVA_Ed.03.docx. Registrada en gpkg_contents igual que CLAVE. (Se
   descarto 1 codigo duplicado del propio checklist: "ATM-01.2" aparecia
   dos veces con el mismo texto.)

3. Campo nuevo "Aspecto Ambiental" (TEXT) en las tablas Puntos/Lineas/
   Poligonos: se anade con ALTER TABLE ADD COLUMN igual que Apertura/
   Doc_Apertura/Cierre/Doc_Cierre (core/form_customizer.py, NEW_FIELDS),
   solo en tablas que ya sigan el esquema estandar de obra.

4. Formulario de edicion (core/form_customizer.py):
   - El campo "Aspecto Ambiental" se configura como ValueRelation contra
     ASPECTOS (Key=CODIGO, Value=ETIQUETA, ordenado por ORDEN) si aun no
     tiene un widget ValueRelation asignado.
   - Nuevo metodo _ensure_aspecto_zona_group(): crea (si no existe todavia)
     un grupo "ASPECTO-ZONA" con los campos "Aspecto Ambiental" y "Zona",
     visible -- y DESPLEGADO, no plegado como los demas grupos -- solo
     cuando Ambito contiene "incidencias" Y el texto representado de Tipo
     contiene "incidencias ambientales". Se ejecuta siempre (formulario
     recien reconstruido o ya diseñado en el modelo) y es idempotente.
   - Como "Zona" ya existia suelto en la raiz del formulario para
     cualquier Ambito/Tipo, _dedupe_root_fields() (V179) retira esa copia
     suelta en cuanto queda tambien dentro de "ASPECTO-ZONA", igual que ya
     hacia con Apertura/Doc_Apertura/Doc_Cierre.

5. core/gpkg_loader.py: _repair_value_relation_layers() generalizado de
   "solo repara CLAVE" a una lista SUPPORT_TABLES = ('CLAVE', 'ASPECTOS'):
   cualquier campo ValueRelation cuyo LayerName coincida con una tabla de
   esa lista se reapunta a la copia de esa tabla en EL GeoPackage que se
   esta cargando (antes solo lo hacia para "CLAVE"). Sin este cambio, el
   desplegable de "Aspecto Ambiental" se veria como un codigo en bruto
   (p. ej. el fid interno) en vez de "SUE-01.1 - Las zonas ocupadas..." en
   cualquier obra abierta en un equipo distinto al que genero el estilo.

DETALLES TECNICOS
------------------
- core/form_customizer.py: NEW_FIELDS, ASPECTO_VALUE_RELATION_CONFIG,
  IncidenciaFormCustomizer._ensure_aspecto_zona_group(), llamada desde
  _apply_form() antes de _dedupe_root_fields().
- core/gpkg_loader.py: GpkgLoader.SUPPORT_TABLES,
  _repair_value_relation_layers() generalizado, _get_hidden_support_layer()
  (sustituye a _get_hidden_clave_layer(), mismo comportamiento para CLAVE).

COMO SE COMPROBO
-----------------
Sin instancia real de QGIS disponible en este entorno: se construyo un
modulo qgis.core de sustitucion (clases QgsAttributeEditorContainer/Field,
QgsEditFormConfig, QgsEditorWidgetSetup, QgsExpression/QgsOptionalExpression,
QgsFields, QgsVectorLayer, QgsProject) que reproduce la API real usada por
este modulo, y se ejecuto IncidenciaFormCustomizer.apply_form() de verdad
(no una aproximacion) contra dos capas simuladas:
  a) sin formulario diseñado (fuerza _rebuild_form_from_scratch): el grupo
     ASPECTO-ZONA aparece con la condicion de visibilidad correcta, el
     campo "Aspecto Ambiental" queda con widget ValueRelation->ASPECTOS
     (Key=CODIGO, Value=ETIQUETA), y "Zona" no queda duplicado.
  b) con formulario ya diseñado (simulando una obra ya sincronizada con
     FICHAS-INFORMES/FOTOS/NC-INCIDENCIAS y "Zona" suelto en la raiz,
     como esta hoy en el modelo real): mismo resultado, sin tocar los
     grupos existentes.
  c) reaplicar apply_form() una segunda vez sobre (b): no duplica el grupo
     ASPECTO-ZONA ni el campo "Zona" (idempotencia).
Tambien se probo _repair_value_relation_layers() con dos campos
ValueRelation (uno LayerName=CLAVE con una ruta antigua, otro
LayerName=ASPECTOS): ambos quedan reapuntados a
"<ruta_del_gpkg>|layername=<TABLA>" sin alterar Key/Value/resto de config.
Aparte, se comprobo con sqlite3 real contra SDONXXX_MODELO - IV.gpkg: la
tabla CLAVE reordenada (integrity_check ok), y la tabla ASPECTOS creada y
poblada con 93 filas (integrity_check ok).

PENDIENTE DE COMPROBAR EN QGIS REAL (no verificable sin QGIS instalado)
-------------------------------------------------------------------------
- Que el desplegable de "Aspecto Ambiental" se ve y filtra bien en el
  formulario real (orden por ORDEN, texto ETIQUETA legible).
- Que el grupo "ASPECTO-ZONA" se despliega/oculta visualmente al cambiar
  Ambito/Tipo en el formulario de QGIS (setVisibilityExpression +
  represent_value() en la version de QGIS instalada).
- Sincronizar este cambio de CLAVE/ASPECTOS a las obras ya existentes via
  "Actualiza GPKG", revisando antes si alguna tiene incidencias con
  Tipo=7.1/7.3 bajo el esquema antiguo (ver aviso en el punto 1).

COMPATIBILIDAD
---------------
Cambios aplicados por igual en las versiones QGIS3 y QGIS4 del plugin
(ambos ficheros de core/ quedan byte-a-byte identicos entre variantes,
igual que antes de este cambio). No afecta a otras pestañas (KMZ, Consulta,
Nueva Obra). No modifica ni elimina ningun campo ni tabla existente.

V179 - CAMPOS QUE SE VEÍAN DUPLICADOS FUERA DE SU GRUPO EN EL FORMULARIO
=========================================================================

PETICIÓN
--------
"Revisa el plugin, como verás en la imagen en algunos casos, al
actualizar el gpkg, dentro del formulario de atributos se duplican los
campos Apertura, Doc_apertura y Doc_cierre fuera de la carpeta
NC-INCIDENCIAS."

(Con capturas reales del diseñador "Formulario de atributos" de QGIS
para una capa "SDONO125_Puntos" recién actualizada, mostrando "Apertura",
"Doc_Apertura" y "Doc_Cierre" sueltos en la raíz del formulario, ADEMÁS
de aparecer correctamente dentro del grupo "NC-INCIDENCIAS".)

CAUSA
-----
Desde V175, "Actualiza GPKG" traslada EXACTAMENTE el formulario que el
propio modelo trae diseñado a mano en QGIS (ver
README_V175_TRASLADO_EXACTO_FORMULARIO.txt) en vez de reconstruirlo en
Python -- ese cambio arregló varios problemas de nombres/agrupación,
pero también significa que cualquier defecto que YA estuviera presente
en el diseño del propio modelo se traslada tal cual a cada obra
actualizada.

Comprobado directamente sobre el styleQML real persistido en el modelo
del usuario: el formulario del modelo tiene, en la raíz de
<attributeEditorForm>, tres campos <attributeEditorField> sueltos
("Apertura", "Doc_Apertura" y "Doc_Cierre" -- pero NO "Cierre", que en
el modelo solo aparece una vez) ADEMÁS de tener esos mismos cuatro
campos correctamente agrupados dentro del contenedor
"NC-INCIDENCIAS". Es decir: el propio diseño del modelo tiene ese
descuido (probablemente arrastrado de una edición manual en el
diseñador de formularios de QGIS), y V175 lo propagaba fielmente a cada
GeoPackage actualizado, tal y como refleja la captura del usuario.

CORRECCIÓN
----------
core/form_customizer.py: nuevo método `_dedupe_root_fields(root)`,
llamado desde `_apply_form()` justo después de decidir si se traslada
el formulario del modelo tal cual o se reconstruye desde cero (se aplica
en ambos casos, aunque la reconstrucción desde cero nunca produce este
tipo de duplicado). El método:
  1. Recorre todos los grupos (QgsAttributeEditorContainer) que cuelgan
     de la raíz del formulario y recopila, recursivamente, los nombres
     de todos los campos que ya están agrupados dentro de alguno de
     ellos.
  2. Localiza los campos que cuelgan SUELTOS de la raíz (sin grupo) cuyo
     nombre coincide con alguno de los ya agrupados.
  3. Elimina esos duplicados sueltos, conservando únicamente la copia
     agrupada -- sin tocar ningún otro campo, grupo, nombre, orden ni
     estado de colapso del formulario.

La corrección es GENÉRICA (no está hardcodeada a "Apertura",
"Doc_Apertura" ni "Doc_Cierre"): limpia cualquier campo que aparezca
duplicado entre la raíz y un grupo, sea cual sea su nombre, así que
también protege frente a otros descuidos similares que pueda tener el
modelo en el futuro.

Nota técnica importante: `QgsAttributeEditorContainer` NO tiene ningún
método para eliminar un único hijo -- solo `clear()`, que los elimina
TODOS de golpe (y además invalida cualquier referencia Python a los
hijos originales, así que no se puede llamar primero y decidir después).
Por eso el patrón usado es: clonar (`clone(root)`) los hijos que SÍ hay
que conservar ANTES de tocar nada, vaciar el contenedor con `clear()`, y
volver a añadir esos clones con `addChildElement()` en su orden
original. (Esto evita repetir el error de V173, en el que se intentó
usar un método `removeChildElement` que nunca existió en PyQGIS.)

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless) y los ficheros reales del usuario
(SDONXXX_MODELO.gpkg + SDON_78.gpkg): se ejecutó la actualización de
estructura completa (GpkgStructureUpdater.analyze + apply con
sync_styles=True, que copia tal cual el styleQML del modelo, incluido su
defecto de diseño) y después la carga real de la capa en un
QgsProject real (GpkgLoader.load_grouped_gpkg). Se inspeccionó
directamente el QgsAttributeEditorContainer raíz del formulario
resultante:
  - ANTES de esta corrección: "Apertura", "Doc_Apertura" y "Doc_Cierre"
    aparecían tanto sueltos en la raíz como dentro de "NC-INCIDENCIAS"
    (reproduce exactamente la captura del usuario).
  - DESPUÉS: esos tres campos ya NO aparecen sueltos en la raíz -- solo
    dentro de "NC-INCIDENCIAS", junto con "Cierre" (que nunca estuvo
    duplicado y sigue apareciendo igual que antes). Los tres grupos
    ("FICHAS-INFORMES", "FOTOS", "NC-INCIDENCIAS") siguen intactos.
Se repitió también toda la batería de pruebas anteriores (V174-V178,
7 scripts) para confirmar que esta corrección no rompe nada: formulario
reconstruido desde cero (obras sin estilo propio), ValueRelation de
"Tipo", recarga de la tabla CLAVE oculta, refresco de capas ya cargadas
al reabrir un proyecto guardado, y el diálogo Edición/Visualización al
cargar en el lienzo. Las 8 pruebas (incluida la nueva de este arreglo)
pasan correctamente.

CÓMO COMPROBARLO EN TU QGIS
-----------------------------
1. Actualiza cualquier GeoPackage de obra con "Actualiza GPKG".
2. Abre el "Formulario de atributos" (diseñador) de una capa de Puntos,
   Líneas o Polígonos.
3. Comprueba que "Apertura", "Doc_Apertura" y "Doc_Cierre" aparecen
   ÚNICAMENTE dentro del grupo "NC-INCIDENCIAS" -- ya no sueltos en la
   raíz del árbol del formulario.

COMPATIBILIDAD
---------------
Afecta solo a core/form_customizer.py. No afecta a la estructura de
datos del GeoPackage (no se borra ni modifica ninguna columna, tabla ni
entidad gráfica) ni a ninguna otra pestaña del plugin. Ambas variantes
QGIS3/QGIS4 comparten el mismo comportamiento (solo difieren, como
siempre, en los enums planos/con ámbito de Qt).

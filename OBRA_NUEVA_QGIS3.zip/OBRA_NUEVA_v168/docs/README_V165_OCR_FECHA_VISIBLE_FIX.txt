OBRA_NUEVA v1.6.5 - OCR fecha visible y estabilidad

Cambios principales:
- Mejora de detección OCR de fecha visible estampada en fotografías: prueba pytesseract y Tesseract instalado en rutas habituales de Windows, además del PATH.
- OCR con varios modos PSM (7, 6 y 11) para fechas en una sola línea o texto disperso.
- Se mantiene la normalización final al formato DD/MM/AAAA HH:MM.
- Corrección de numeración de fotografías: _add_photo_feature_to_layer devuelve el Nº asignado y evita recalcularlo tras insertar.
- Añadido contador de capa en memoria para evitar duplicados o lecturas frágiles del proveedor antes de refrescar.
- Corrección de PRAGMA table_info en gpkg_utils para compatibilidad con Python embebido en QGIS anterior a 3.12.
- Corrección de guardado de resultados de consulta a GeoPackage nuevo en MultiObraEngine.

Nota:
La detección automática de fecha visible necesita que QGIS pueda ejecutar Tesseract OCR o que esté disponible pytesseract. Si no existe motor OCR instalado, el plugin no puede leer texto ya impreso en la imagen y seguirá pidiendo la fecha manualmente.

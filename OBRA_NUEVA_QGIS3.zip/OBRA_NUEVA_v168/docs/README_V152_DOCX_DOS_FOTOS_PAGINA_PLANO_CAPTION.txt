OBRA_NUEVA v152 - DOCX: dos fotos por página y texto bajo plano general

Cambios aplicados sobre v151:

1. En la exportación del anejo a DOCX, las fotografías se maquetan siempre en bloques de dos por página.
   - Formato paralelo: una pareja por página, dos fotos en la misma fila, ancho 8 cm.
   - Formato vertical: una pareja por página, dos fotos una debajo de otra, ancho 12 cm.

2. En los planos generales de ubicación se elimina el texto:
   "Extensión ceñida a la capa puntos_informe..."

3. Bajo cada plano general se inserta el texto:
   "Localización de las fotos de los emplazamientos X/N"
   donde X es el número de hoja del plano y N el total de planos generales.

Se mantienen las mejoras anteriores: carpeta de salida DOCX, resumen opcional, orden por número de foto, etiquetas visibles, capas activas del lienzo y ventana escalable.

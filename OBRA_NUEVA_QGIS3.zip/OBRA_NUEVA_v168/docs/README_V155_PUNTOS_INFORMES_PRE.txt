OBRA_NUEVA v155 - puntos_informes_pre desde georreferenciación avanzada

Cambios:
- En la pestaña 2 · Georreferenciación manual avanzada, cuando una fotografía se marca como informe final, además de añadirse al flujo normal de fotos_georref se crea un punto equivalente en la capa puntos_informes_pre.
- La capa puntos_informes_pre se crea automáticamente si no existe.
- Conserva la misma estructura de campos de las capas fotográficas: Nº, Descripción, foto_path, informe_final, fecha_foto, estampar_fecha, x, y, lon y lat.
- El punto de puntos_informes_pre se inserta en la misma ubicación que la fotografía colocada en el lienzo.
- La simbología toma como base puntos.qml, pero fuerza el fondo amarillo de la etiqueta para distinguir la preselección del informe final.
- Se añade estado visible de la capa puntos_informes_pre en el bloque de georreferenciación manual avanzada.

Se mantienen los cambios anteriores: pareja centrada en plano general, dos fotos por página, carpeta de salida DOCX, texto bajo plano, etiquetas visibles a cualquier escala, resumen opcional, fecha y descripción opcionales, cola de descartes y ventana escalable.

V187 - FIX: "ACTUALIZA GPKG" PRIORIZA EL GPKG DEL PROYECTO SOBRE EL RECORDADO
================================================================================

PROBLEMA
--------
"La pestaña Actualizar, hay que corregir la opción GPKG a actualizar
(Antiguo) para que muestre por defecto el GPKG cargado en el proyecto de
QGIS."

CAUSA
-----
La V185 ya rellenaba el campo "GPKG a actualizar (antiguo)" con el
GeoPackage cargado en el proyecto QGIS actual, pero SOLO cuando ese campo
estaba vacío. En la práctica, tras usar la pestaña alguna vez, QGIS ya
tenía guardado en sus ajustes (QSettings) el último GeoPackage usado --
así que el campo NUNCA estaba realmente vacío, y ese valor recordado
ganaba siempre sobre el GeoPackage que el usuario tenía cargado en el
lienzo en ese momento. Por eso el usuario seguía sin ver, por defecto, el
GeoPackage correcto.

CORRECCIÓN
----------
ui/tab_actualiza_gpkg.py:
  Se cambia la prioridad: el GeoPackage cargado en el proyecto QGIS actual
  ahora GANA siempre al último recordado, mientras el usuario no haya
  elegido nada a mano en esta sesión de la pestaña. Para distinguir "valor
  puesto automáticamente" de "el usuario ya eligió algo", se añade un
  indicador `_old_gpkg_user_chosen`:
    - Se pone a `True` en cuanto el usuario selecciona un GeoPackage con
      el selector de archivos ("…"), o escribe/edita el campo a mano
      (señal `textEdited`, que solo salta con la interacción real del
      usuario, no con los rellenos automáticos que hace el propio código).
    - Se pone a `False` de nuevo al pulsar "Limpiar formulario", momento
      en el que se vuelve a proponer el GeoPackage del proyecto si lo hay.
  Mientras el indicador esté a `False`, `refresh_project_default()`
  sobrescribe el campo con el GeoPackage del proyecto en cuanto haya uno
  disponible -- al abrir la pestaña, al cambiar de modo, y cada vez que
  esta pestaña pasa a ser la activa (p. ej. tras cargar una obra distinta
  con "Carga Obra" y volver a "Actualiza GPKG"). Si no hay ningún
  GeoPackage cargado en el proyecto, se mantiene el comportamiento
  anterior: se usa el último recordado.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless): se simuló una "sesión anterior" dejando en
QSettings un GeoPackage recordado distinto al que se carga ahora en el
proyecto, y se comprobó que:
  - Al construir la pestaña, el campo muestra el GeoPackage del PROYECTO,
    no el recordado.
  - Tras una edición real del usuario (señal `textEdited`, simulando
    teclear o pegar una ruta), refrescos posteriores ya no la sobrescriben.
  - Elegir un archivo con el selector también fija la elección del
    usuario.
  - "Limpiar formulario" reactiva el relleno automático con el proyecto.
  - Sin ningún GeoPackage cargado en el proyecto, se sigue usando el
    último recordado (comportamiento anterior, sin cambios).
  - En modo "carpeta completa" sigue sin autocompletarse (ese campo es
    una carpeta, no un GeoPackage individual).
Se repitió también toda la batería de pruebas anteriores (V174-V186, 19
pruebas en total) para confirmar que este cambio no rompe nada.

CÓMO COMPROBARLO EN TU QGIS
-----------------------------
1. Actualiza al menos un GeoPackage alguna vez con "Actualiza GPKG" (para
   que quede un valor recordado).
2. Carga en el lienzo un GeoPackage DISTINTO (con "Carga Obra", o abriendo
   un proyecto que ya lo traiga).
3. Ve a "Actualiza GPKG" (modo "Un solo GeoPackage"): el campo debe
   mostrar el GeoPackage que acabas de cargar, no el que usaste la vez
   anterior.

COMPATIBILIDAD
---------------
Cambio interno, solo en `ui/tab_actualiza_gpkg.py`. No afecta a "Archivar
GPKG" (que ya se comportaba correctamente, sin este problema, porque hasta
ahora no tenía ningún valor recordado con el que competir) ni a ninguna
otra pestaña. Ambas variantes QGIS3/QGIS4 comparten el mismo
comportamiento.

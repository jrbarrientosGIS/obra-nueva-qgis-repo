V176 - EL DESPLEGABLE "TIPO" SE VEÍA ROTO ("(8.1)" EN VEZ DE LA DESCRIPCIÓN)
================================================================================

PROBLEMA
--------
El usuario reportó que "Analizar diferencias" no encontraba ninguna
diferencia entre el modelo y SDON79.gpkg (correcto: la estructura y el
estilo ya coincidían exactamente) pero que el resultado cargado en el
lienzo "está fatal". Con una captura del formulario de una entidad real
se vio el problema: el campo "Tipo" mostraba literalmente "(8.1)" en vez
de una descripción legible como "Residuos generados en la obra".

CAUSA
-----
"Tipo" es un desplegable ValueRelation que busca su descripción en la
tabla "CLAVE" (filtrada por el campo "Ámbito"). Su configuración, tal y
como la guarda el modelo, incluye dos referencias a la capa CLAVE que
solo tienen sentido en el ORDENADOR Y EL PROYECTO DE QGIS DEL AUTOR DEL
MODELO:
  - 'LayerSource': una ruta absoluta fija, p. ej.
    "E:/1_GPK/SDON_KKK.gpkg|layername=CLAVE" -- que no existe en otro
    ordenador (ni tendría por qué).
  - 'Layer': el id interno que esa capa CLAVE tenía cargada en el
    proyecto de QGIS del autor en el momento de guardar el estilo -- un
    id que no coincide con nada cargado en el proyecto de quien abre
    otra obra.

Como el estilo se traslada ahora tal cual desde el modelo (V175, para no
perder nada de su diseño), esa referencia rota se copiaba igual a
CUALQUIER GeoPackage actualizado. QGIS no podía resolver la descripción
del código seleccionado y mostraba el valor crudo entre paréntesis
("(8.1)") en vez de su descripción. Este problema NO tiene nada que ver
con "Analizar diferencias" (que sigue siendo correcto: no hay diferencia
de estructura ni de estilo que reportar) -- está en cómo se CARGA la capa
después.

Cabe destacar que la pestaña "Nueva Obra" ya tenía, desde antes, su
propia solución a este mismo problema (reescribe la ruta al crear la
obra y repara el campo "Tipo" en tiempo real) -- pero "Carga Obra" y
"Actualiza GPKG" comparten un cargador distinto (GpkgLoader) que nunca
tuvo esa reparación.

CORRECCIÓN
----------
core/gpkg_loader.py: se añadió `_repair_value_relation_layers()`, que se
ejecuta justo después de cargar el estilo persistido de cada capa
(Puntos/Líneas/Polígonos), tanto para "Carga Obra" como para "Actualiza
GPKG" → "cargar en el lienzo":
  - Detecta cualquier campo ValueRelation cuyo 'LayerName' sea "CLAVE"
    (no solo "Tipo": cualquier campo presente o futuro con ese diseño).
  - Carga (o reutiliza, si ya estaba cargada) la tabla "CLAVE" del PROPIO
    GeoPackage que se está abriendo, como capa oculta de apoyo (no
    aparece en el panel de capas).
  - Reapunta 'Layer' (al id de esa capa oculta) y 'LayerSource' (a la
    ruta real de ese GeoPackage) -- conservando intacto el resto de la
    configuración del campo (columnas clave/valor, filtro por Ámbito,
    descripción...) tal y como la dejó el modelo.
No se toca ninguna otra cosa del estilo ni del formulario.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless) y los ficheros reales del usuario
(SDON79.gpkg + su modelo actual): antes de la corrección,
represent_value("Tipo") sobre la entidad real de Polígonos devolvía vacío
(de ahí el "(8.1)" que se veía en el formulario); después de la
corrección, devuelve "Residuos generados en la obra" -- la descripción
correcta para el código "8.1" con Ámbito "8-Residuos". También se
comprobó que recargar el mismo GeoPackage dos veces no duplica la capa
oculta de apoyo "CLAVE", y se repitió toda la batería de pruebas
anteriores (V174/V175: nombres de grupo, colapso, traslado exacto del
formulario) para confirmar que este cambio no las rompe.

CÓMO COMPROBARLO EN TU QGIS
------------------------------
Abre una obra (por "Carga Obra" o tras "Actualiza GPKG" → cargar en el
lienzo) y edita una entidad cuyo campo "Tipo" tenga un valor: debe verse
la descripción completa (p. ej. "Residuos generados en la obra"), no el
código entre paréntesis.

COMPATIBILIDAD
---------------
Afecta solo a core/gpkg_loader.py (usado por "Carga Obra" y "Actualiza
GPKG"). No afecta a "Nueva Obra" (que ya tenía su propia reparación) ni a
KMZ, Consulta o Fotos. Ambas variantes QGIS3/QGIS4 comparten el mismo
código en este módulo.

OBRA_NUEVA - Pestaña Fotos / Anejo fotográfico v139

Cambios aplicados:
- Se sustituye la simbología de puntos_informe por la aportada en puntos.qml.
- Anejo fotográfico: el botón "Seleccionar fotos desde carpeta" busca únicamente imágenes cuyo nombre empiece por IF.
- La búsqueda desde carpeta es recursiva e incluye subcarpetas.
- Se añade el botón "Seleccionar foto individual".
- En foto individual se pregunta si se desea pinchar en el lienzo; si se responde No, se intenta insertar en sus coordenadas GPS EXIF.
- Desaparece el botón "Iniciar colocación"; al seleccionar carpeta IF se inicia directamente la colocación en lienzo.
- El DOCX genera plano(s) general(es) ceñidos a la extensión de puntos_informe.
- Si la escala global estimada supera 1:300000, la extensión se divide en tantos planos como sea necesario, insertados al inicio del informe antes de las fotos individuales.

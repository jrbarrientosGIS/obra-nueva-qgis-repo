V174 - LOS GRUPOS DEL FORMULARIO NO USABAN LOS NOMBRES NI EL COLAPSO DEL MODELO
================================================================================

PROBLEMA
--------
La corrección V173 dejó de lanzar excepción y volvió a reorganizar el
formulario, pero con nombres de "group box" inventados por el plugin en
vez de los nombres reales que el propio modelo trae diseñados a mano en
QGIS, y sin plegar ("colapsar") los grupos por defecto como sí hace el
modelo. Además, el campo "Poyecto" (así, tal cual está escrito en el
esquema real del GeoPackage) se quedaba suelto fuera de cualquier grupo.

Comparando directamente el QML del modelo (SDONXXX_MODELO, capa de
Puntos) con lo que generaba el plugin:

  Modelo (real)                          Plugin (antes de esta corrección)
  --------------------------------       ---------------------------------
  "FICHAS-INFORMES" (Ficha + Poyecto)    Ficha suelto sin nombre de grupo;
                                          Poyecto fuera de cualquier grupo
  "FOTOS" (Foto 1-4)                     "Fotos"
  "NC-INCIDENCIAS" (Apertura/Cierre/     "Incidencia · No conformidad"
   Doc_Apertura/Doc_Cierre)
  Los tres colapsados (collapsed="1")    Ninguno colapsado

CORRECCIÓN
----------
core/form_customizer.py (IncidenciaFormCustomizer._apply_form):
  - Los tres grupos ahora usan el nombre EXACTO del modelo:
    "FICHAS-INFORMES", "FOTOS" y "NC-INCIDENCIAS" (comprobado carácter a
    carácter contra el QML real del modelo).
  - Los tres grupos se crean con `setCollapsed(True)`, igual que el
    modelo (collapsed="1"), de forma que aparecen plegados al abrir el
    formulario y el usuario los despliega solo si los necesita.
  - Se añade el campo "Poyecto" (nombre real del campo en el esquema,
    con la errata incluida tal cual está en el GeoPackage) dentro del
    grupo "FICHAS-INFORMES", junto a "Ficha". "Ficha" se sigue ocultando
    condicionalmente cuando Ámbito="Incidencias" y Tipo="No conformidad"
    (comportamiento documentado en README_V170/171); "Poyecto" se
    muestra siempre dentro de ese mismo grupo.
  - El grupo "NC-INCIDENCIAS" conserva la visibilidad condicional (solo
    aparece en incidencias de "no conformidad"): en el modelo este grupo
    es estático porque su formulario no tiene esa lógica, pero ocultarlo
    el resto del tiempo es un comportamiento deliberado del plugin, no
    un error, y el usuario no ha pedido eliminarlo -- solo corregir el
    nombre y el colapso, que es lo que se ha hecho.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless), extendiendo las mismas pruebas de V173
para además comprobar el nombre EXACTO de cada grupo, su estado
`collapsed()` y que "Poyecto" quede agrupado dentro de "FICHAS-INFORMES":

  'FICHAS-INFORMES': groupBox=True collapsed=True -> OK
  'FOTOS':            groupBox=True collapsed=True -> OK
  'NC-INCIDENCIAS':   groupBox=True collapsed=True -> OK
  Poyecto está en el contenedor: FICHAS-INFORMES -> OK

Se repitió también la prueba de extremo a extremo sobre la pestaña
"Actualiza GPKG" de verdad (clic en "Analizar diferencias" → "Actualizar
GPKG" → "Sí" a cargar en el lienzo), confirmando los mismos tres grupos
con los nombres y el colapso correctos sobre la capa realmente cargada
en el lienzo.

CÓMO COMPROBARLO EN QGIS DE VERDAD
------------------------------------
1. Actualiza un GeoPackage (individual o por carpeta) y cárgalo en el
   lienzo (o ábrelo con "Carga Obra").
2. Abre el formulario de una entidad de Puntos/Líneas/Polígonos: deben
   verse tres grupos plegados llamados exactamente "FICHAS-INFORMES",
   "FOTOS" y "NC-INCIDENCIAS" (este último solo cuando Ámbito=Incidencias
   y Tipo=No conformidad). Al desplegar "FICHAS-INFORMES" deben verse
   "Ficha" (o su hueco oculto, en no conformidad) y "Poyecto" juntos.

COMPATIBILIDAD
---------------
Afecta solo a core/form_customizer.py. Sin cambios en gpkg_loader.py ni
gpkg_updater.py respecto a V173. Ambas variantes QGIS3/QGIS4 comparten el
mismo código en este módulo.

V172 - PESTAÑA "ACTUALIZA GPKG": ACTUALIZACIÓN MASIVA Y CARGA EN EL LIENZO
============================================================================

Dos añadidos a la pestaña "Actualiza GPKG" (V169), sin tocar el resto de
pestañas ni el motor de comparación/actualización que ya existía.

1. ACTUALIZACIÓN MASIVA (CARPETA COMPLETA, RECURSIVA)
-------------------------------------------------------
Nuevo selector "Actualizar: ⦿ Un solo GeoPackage / ⦿ Carpeta completa
(busca .gpkg también en subcarpetas)" encima del campo "GPKG a actualizar".

Al marcar "Carpeta completa", ese campo pasa a pedir una carpeta (en vez de
un archivo) y el flujo de siempre se aplica sobre TODOS los .gpkg que se
encuentren dentro de ella y de todas sus subcarpetas:

  · "Analizar diferencias" busca de forma recursiva, analiza cada GeoPackage
    encontrado contra el mismo modelo y muestra un informe con una línea-
    resumen por archivo (campos/tablas/leyendas pendientes, "ya actualizado"
    o el error de análisis si el archivo no se ha podido leer) más un
    resumen global.
  · "Actualizar GPKG" pide confirmación una sola vez (con los totales
    agregados) y aplica los cambios a todos los archivos con algo pendiente,
    uno a uno, con las mismas opciones (copia de seguridad, crear tablas
    nuevas, sincronizar leyenda) para todos. Un fallo en un archivo no
    detiene el resto del lote: se registra como error y se continúa.
  · Al terminar, vuelve a analizar toda la carpeta y muestra un resumen
    final (archivos actualizados, totales, errores).

La búsqueda recursiva excluye automáticamente:
  · el propio GPKG modelo, si está dentro de la misma carpeta;
  · las copias de seguridad que crea este mismo proceso (sufijo
    "_backup_AAAAMMDD_HHMMSS.gpkg"), para que una segunda pasada no las
    trate como si fueran obras a actualizar.

Como en el modo de un solo archivo, nunca se modifica ni se elimina una
entidad gráfica, geometría o dato ya existente en ninguno de los GeoPackage
del lote.

DETALLES TÉCNICOS
  · core/gpkg_updater.py: nueva función scan_gpkg_files_recursive(folder_path,
    exclude_paths=None) — recorre la carpeta con os.walk, sin dependencias
    de QGIS (solo os/re), reutilizable fuera de la UI.
  · ui/tab_actualiza_gpkg.py: el modo se resuelve con un QRadioButton; los
    métodos _do_analyze/_do_update reparten a _do_analyze_single/
    _do_analyze_batch y _do_update_single/_do_update_batch según el modo.
    El estado de "un solo archivo" (self._plan) y el de "carpeta"
    (self._batch_items, lista de {'path','plan','error'}) son independientes.

2. OFERTA DE CARGAR EN EL LIENZO TRAS ACTUALIZAR (MODO UN SOLO ARCHIVO)
-------------------------------------------------------------------------
Al terminar una actualización individual con éxito (tras el aviso de
"Actualización completada"), la pestaña pregunta:

  "¿Quieres cargar el GeoPackage actualizado en el lienzo?"

Si se responde que sí, se cargan sus capas operativas (Puntos/Líneas/
Polígonos) en un grupo con el nombre del archivo, reutilizando
GpkgLoader.load_grouped_gpkg() — el mismo motor que usa la pestaña "Carga
Obra" — con leyenda filtrada (modo visualización). Si ya había una capa de
ese mismo GeoPackage cargada en el proyecto, se reutiliza y se refresca
(sus campos y formulario), igual que hace "Carga Obra".

Esta pregunta solo aparece en el modo "un solo GeoPackage": en una
actualización masiva no tendría sentido (podrían ser decenas de archivos).

CÓMO COMPROBARLO
------------------
1. Pestaña "Actualiza GPKG": selecciona el GPKG modelo, marca "Un solo
   GeoPackage", selecciona un GPKG antiguo y pulsa "Actualizar GPKG". Al
   terminar debe aparecer la pregunta de cargar en el lienzo; si aceptas,
   deben aparecer las capas en el panel de capas.
2. Marca "Carpeta completa", selecciona una carpeta con varias obras (puede
   tener subcarpetas) y pulsa "Analizar diferencias": debe listar todos los
   .gpkg encontrados (excluyendo el modelo y cualquier backup previo) con su
   resumen individual. Pulsa "Actualizar GPKG": deben quedar todos
   actualizados y, al reanalizar, el informe debe mostrar "ya actualizado"
   en cada uno.

COMPATIBILIDAD
---------------
No afecta a otras pestañas (KMZ, Consulta, Nueva Obra, Carga Obra, Fotos)
ni al análisis/aplicación de un solo GeoPackage, que se comporta igual que
en V169-V171. core/gpkg_updater.py y core/gpkg_utils.py son idénticos entre
las variantes QGIS3 y QGIS4 del plugin (solo cambia la sintaxis de enums de
Qt en ui/tab_actualiza_gpkg.py, como en el resto del proyecto).

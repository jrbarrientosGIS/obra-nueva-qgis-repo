V173 - CORRECCIÓN: EL FORMULARIO DE ATRIBUTOS NO SE REORGANIZABA AL CARGAR
============================================================================

PROBLEMA
--------
El botón "cargar en el lienzo" añadido en V172 (y, en realidad, también la
pestaña "Carga Obra" desde siempre) cargaba las capas, pero el formulario
de edición NO quedaba reorganizado como espera README_V170/V171: nunca se
ocultaba "Ficha" en incidencias de "no conformidad", nunca aparecía el
grupo con Apertura/Cierre, y el grupo "Fotos" solo agrupaba Foto 1/Foto 2
(nunca Foto 3/Foto 4, aunque "Actualiza GPKG" ya las añade). El fallo era
totalmente silencioso: no aparecía ningún aviso en la interfaz, solo un
registro de advertencia en el panel de mensajes de QGIS que nadie mira.

Se ha reproducido y verificado con QGIS real (3.34, headless) instanciando
la pestaña de verdad y simulando los clics: "Analizar diferencias" →
"Actualizar GPKG" → "cargar en el lienzo".

CAUSA
-----
core/form_customizer.py (IncidenciaFormCustomizer._apply_form) usaba dos
llamadas que NO EXISTEN en la API real de PyQGIS comprobada:

  1. `root.removeChildElement(child)` -- QgsAttributeEditorContainer no
     tiene ningún método con ese nombre (el método real para vaciar un
     contenedor es `clear()`). Esto lanzaba AttributeError en la primera
     línea de la reconstrucción del formulario.
  2. `elem.setVisibilityExpression(...)` sobre un QgsAttributeEditorField
     -- ese método solo existe en QgsAttributeEditorContainer, no en
     QgsAttributeEditorField. Para ocultar un único campo (Ficha) según una
     condición hay que envolverlo en un contenedor sin caja de grupo, no
     ponerle la expresión directamente.

Como apply_form() envuelve toda la reconstrucción en un try/except amplio
(para no tumbar la carga de la capa si algo falla), cualquiera de las dos
excepciones se capturaba en silencio y la función devolvía sin haber
aplicado ninguno de los cambios -- la capa se quedaba con el formulario que
ya traía cargado (el guardado en el modelo, si "Actualiza GPKG" lo había
sincronizado, o el que QGIS asigna por defecto si no).

CORRECCIÓN
----------
- `root.clear()` en lugar de iterar y llamar a un método inexistente.
- El campo "Ficha" se envuelve en un QgsAttributeEditorContainer sin caja
  de grupo (`setIsGroupBox(False)`) y la expresión de visibilidad se pone
  sobre ESE contenedor, no sobre el campo.
- El grupo "Fotos" ahora también agrupa Foto 3 y Foto 4 si existen en la
  capa (antes solo conocía Foto 1/Foto 2).
- El widget de Doc_Apertura/Doc_Cierre (ExternalResource) YA NO se
  sobrescribe si el campo ya tiene un ExternalResource configurado (por
  ejemplo, cargado desde el estilo persistido que sincroniza "Actualiza
  GPKG", con su propia carpeta por defecto): solo se aplica la
  configuración genérica de repuesto en obras antiguas sin estilo guardado,
  para no perder la carpeta configurada en el modelo.
- core/gpkg_loader.py: se añadió `_load_persisted_style()` (antes de
  aplicar el formulario, igual que ya hacían "Nueva Obra" y "Consulta") con
  la firma correcta de `loadDefaultStyle()` (sin argumentos, devuelve
  `(mensaje, ok)`; la firma con un parámetro de salida que usaban esas dos
  pestañas también es incorrecta en las versiones de PyQGIS comprobadas y
  fallaba en silencio, aunque sin mayor efecto porque QgsVectorLayer ya
  carga el estilo por defecto automáticamente al construirse).

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, modo headless, sin simuladores): se actualizó un
GeoPackage de obra con un modelo que tiene el formulario ya diseñado
(listas desplegables ValueMap/ValueRelation, formato de fecha, carpeta de
documento) y grupos "FICHAS-INFORMES"/"FOTOS"/"NC-INCIDENCIAS", se cargó en
un QgsProject real pulsando los botones reales de la pestaña, y se
inspeccionó la capa resultante:
  - Zona/Periodo/Ámbito: ValueMap. Tipo: ValueRelation.
  - Apertura/Cierre: DateTime.
  - Doc_Apertura/Doc_Cierre: ExternalResource, con la carpeta por defecto
    del modelo conservada.
  - Grupos del formulario tras cargar: "" (Ficha, oculto condicionalmente),
    "Incidencia · No conformidad" (Apertura/Cierre/Doc_Apertura/Doc_Cierre,
    visible solo si Ámbito=Incidencias y Tipo=No conformidad) y "Fotos"
    (Foto 1/2/3/4).
  - La expresión de visibilidad se validó como expresión QGIS correcta y
    se evaluó contra entidades reales sin error.

CÓMO COMPROBARLO EN QGIS DE VERDAD
------------------------------------
1. Pestaña "Actualiza GPKG": actualiza un GPKG antiguo con un modelo que
   tenga el formulario bien diseñado (o, aunque no lo tenga, esta
   corrección sigue aplicando la reorganización automática de
   Ficha/Apertura-Cierre/Fotos como en V170-171).
2. Acepta la pregunta de cargar en el lienzo (o usa "Carga Obra").
3. Abre el formulario de una entidad de Puntos/Líneas/Polígonos: Foto 1-4
   deben verse agrupadas en dos columnas; con Ámbito=Incidencias y
   Tipo=alguna variante de "No conformidad", debe desaparecer "Ficha" y
   aparecer el grupo con Apertura/Cierre y sus documentos.

COMPATIBILIDAD
---------------
Afecta a core/form_customizer.py y core/gpkg_loader.py, usados por "Carga
Obra", "Nueva Obra" y la pestaña "Actualiza GPKG" (botón de cargar en el
lienzo). No afecta a KMZ, Consulta ni Fotos. Ambas variantes QGIS3/QGIS4
comparten el mismo código en estos dos módulos (sin diferencias de enums
de Qt).

V169 - PESTAÑA "ACTUALIZA GPKG"
================================

PROBLEMA RESUELTO
------------------
El GeoPackage modelo (plantilla) evoluciona con el tiempo: se le añaden campos
nuevos o tablas nuevas a las capas operativas. Los GeoPackage de obras ya
creados con versiones anteriores de la plantilla se quedan con una estructura
desactualizada, y hasta ahora no había forma de ponerlos al día sin rehacerlos
a mano ni arriesgarse a perder las entidades gráficas ya digitalizadas.

SOLUCIÓN
--------
Nueva pestaña "Actualiza GPKG" que permite seleccionar:

  · GPKG modelo (nuevo)      -> la plantilla actualizada
  · GPKG a actualizar (antiguo) -> la obra ya existente

Y compara ambas estructuras:

  1. Empareja las capas operativas (Puntos / Líneas / Polígonos) por ROL, no
     por nombre exacto, ya que cada obra nombra sus tablas con un prefijo
     propio (p.ej. "SDON_78_Puntos" frente a "SDONO120_Puntos" en el modelo).
     Así el nombre de la tabla del GPKG antiguo NUNCA se toca ni se renombra.
  2. Empareja el resto de tablas (CLAVE, layer_styles, capas base como
     Estaciones/Lineas_FFCC/pk, etc.) por nombre normalizado.
  3. Para cada pareja de tablas, detecta los campos que existen en el modelo
     y faltan en el antiguo, y los añade con ALTER TABLE ... ADD COLUMN,
     siempre como opcionales (aunque el modelo los marque obligatorios), para
     no invalidar los registros ya cargados.
  4. Los campos que solo existen en el antiguo NUNCA se eliminan ni se tocan:
     se listan en el informe como "campos propios, se conservan".
  5. Opcionalmente (casilla activada por defecto), crea vacías las tablas que
     existan en el modelo y no tengan equivalente en el antiguo (p.ej. nuevas
     capas base incorporadas en versiones recientes de la plantilla).
  6. Antes de tocar el archivo, y si la casilla correspondiente está activada
     (por defecto sí), crea una copia de seguridad con marca de fecha/hora
     junto al GeoPackage original.

El botón "Analizar diferencias" genera un informe legible con todos los
cambios detectados antes de aplicar nada. El botón "Actualizar GPKG" solo se
activa si hay cambios pendientes, pide confirmación explícita y, al terminar,
vuelve a analizar el archivo para confirmar que ya coincide con el modelo.

En ningún momento se modifica ni se elimina una entidad gráfica, una
geometría o un valor de atributo ya existente en el GeoPackage antiguo.

DETALLES TÉCNICOS
------------------
- core/gpkg_updater.py (nuevo):
    - GpkgStructureUpdater.analyze(model_path, old_path) -> GpkgUpdatePlan
      con el detalle de campos a añadir, tablas nuevas, campos "extra" del
      antiguo y discrepancias de tipo/geometría (informativas, no se actúa
      sobre ellas).
    - GpkgStructureUpdater.apply(plan, backup, create_missing_tables,
      progress_cb) ejecuta los ALTER TABLE y, si procede, crea las tablas
      nuevas vacías a partir del modelo (mismos campos, tipo de geometría y
      CRS) usando QgsVectorFileWriter, igual que el resto del plugin.
    - Reutiliza GpkgIntrospector.detect_operational_tables() (ya existente en
      core/gpkg_utils.py) para el emparejamiento por rol.
- core/gpkg_utils.py:
    - Nuevo método GpkgIntrospector.table_columns_full(): metadatos completos
      de columnas (nombre, tipo, notnull, valor por defecto, clave primaria).
    - Nuevo método GpkgIntrospector.geometry_column_name().
- ui/tab_actualiza_gpkg.py (nuevo): interfaz de la pestaña.
- ui/main_dialog.py: registro de la nueva pestaña "🔄 Actualiza GPKG".

COMPATIBILIDAD
---------------
No afecta a otras pestañas (KMZ, Consulta, Nueva Obra, Carga Obra, Fotos).
Validado contra GeoPackage de ejemplo reales de distintas obras con distinta
versión de plantilla, comprobando que ninguna entidad gráfica se pierde tras
la actualización.

OBRA_NUEVA v151 - Exportación DOCX con carpeta de descarga

Cambios:
- En la exportación del anejo fotográfico a DOCX, el plugin solicita ahora una carpeta de descarga/salida en lugar de pedir directamente un archivo.
- El DOCX se guarda automáticamente como anejo_fotografico.docx dentro de la carpeta elegida.
- Si ya existe un archivo con ese nombre, se genera un nombre correlativo: anejo_fotografico_2.docx, anejo_fotografico_3.docx, etc.
- Se mantienen todas las mejoras de v150: previsualización, descripción, fecha opcional, planos ordenados, resumen por parejas, maquetación paralelo/vertical y ventana escalable.

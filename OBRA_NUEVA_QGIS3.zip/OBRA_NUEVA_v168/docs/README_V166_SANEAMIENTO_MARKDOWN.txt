OBRA_NUEVA v166 - saneamiento de incidencias del markdown

Cambios principales:
- Eliminado el método huérfano _configure_anejo_labels de tab_fotos.py.
- Eliminado _photo_cell_content, compatibilidad interna no usada.
- Consolidado el contrato de _ensure_anejo_photo_date: devuelve (fecha_foto, estampar_fecha) o None si se cancela.
- Normalizada defensivamente la captura opcional de segundos en _photo_date_from_filename.
- Añadido guard interno en _ocr_prepared_images para evitar ImportError no controlado si se llama fuera del flujo habitual.
- KMZExporter._xml ya convierte None y QVariant NULL/texto NULL a cadena vacía antes de escapar XML.
- DOCX: Content_Types registra .tif y .tiff como image/tiff.
- GpkgLoader deja de abrir una QgsVectorLayer por cada tabla solo para comprobar geometría: usa gpkg_geometry_columns vía SQLite.
- GpkgLoader reutiliza normalize_text de gpkg_utils para evitar duplicación de lógica.
- metadata.txt actualizado a 1.6.6-saneamiento-markdown y about acortado.

Notas:
- La detección de fecha visible estampada sigue dependiendo de Tesseract/pytesseract disponible en el entorno de QGIS.
- El OCR continúa ejecutándose en el hilo principal; queda como mejora futura migrarlo a QgsTask/QThread para evitar congelaciones en fotos pesadas.

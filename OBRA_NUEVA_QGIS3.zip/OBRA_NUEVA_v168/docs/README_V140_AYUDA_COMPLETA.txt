OBRA_NUEVA - v140 AYUDA COMPLETA
==================================

Actualización aplicada sobre v139_anejo_fotografico.

Cambios incluidos:
- Redactada y sustituida la ayuda integrada del plugin en docs/help/index.html.
- La ayuda cubre instalación, conceptos generales, Nueva Obra, Carga Obra, KMZ, Consulta, Fotos, Anejo Fotográfico, campos, salidas e incidencias frecuentes.
- Se documenta expresamente el nuevo flujo de Anejo Fotográfico:
  * puntos_informe con simbología de puntos.qml.
  * Selección desde carpeta solo de archivos que empiezan por IF.
  * Búsqueda recursiva en subcarpetas.
  * Selección de foto individual con decisión entre pinchar en lienzo o usar coordenadas GPS EXIF.
  * Eliminación del botón Iniciar colocación.
  * Plano(s) general(es) ajustados a la extensión de puntos_informe.
  * División en varios planos si la escala resultante supera 1:300000.
- Se mantienen intactos los cambios funcionales de v139.

Instalación:
1. Cerrar QGIS.
2. Sustituir la carpeta OBRA_NUEVA del perfil de QGIS por la incluida en este ZIP.
3. Abrir QGIS y activar/recargar el complemento.
4. Abrir OBRA_NUEVA y pulsar Ayuda.

OBRA_NUEVA v142 - Simbología puntos_informe

Cambios:
- La capa objetivo del bloque Anejo Fotográfico pasa a denominarse puntos_informe.
- El estilo corporativo se carga desde styles/puntos.qml sobre la capa puntos_informe.
- Se actualiza la ayuda integrada para referirse a puntos_informe.
- Se mantiene copia legacy styles/anejo.qml con el mismo contenido para compatibilidad interna si existiera alguna referencia residual.

Nota:
- El plano general y el DOCX del anejo se generan con la extensión de puntos_informe.

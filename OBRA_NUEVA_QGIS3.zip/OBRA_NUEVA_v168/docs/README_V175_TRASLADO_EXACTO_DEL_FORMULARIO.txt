V175 - TRASLADAR EXACTAMENTE EL FORMULARIO DEL MODELO (EN VEZ DE APROXIMARLO)
================================================================================

PROBLEMA DE FONDO
------------------
Las correcciones V173/V174 seguían reconstruyendo el formulario de
atributos DESDE CERO en Python cada vez que se cargaba una capa, con
nombres de grupo, columnas y colapso escritos a mano en el plugin. Aunque
V174 ya acertaba los nombres ("FICHAS-INFORMES"/"FOTOS"/"NC-INCIDENCIAS")
y el plegado, seguía siendo una APROXIMACIÓN: cualquier detalle del
formulario que el usuario diseñe en el modelo y el plugin no conozca
explícitamente (una expresión de plegado, un campo reordenado, un grupo
nuevo, un ancho de columna distinto...) se perdía, porque el plugin
tiraba el formulario real y ponía el suyo encima.

Sin embargo, la pestaña "Actualiza GPKG" YA COPIA el formulario del modelo
tal cual, byte a byte: cuando "Sincronizar leyenda y simbología" está
activado, copia la fila COMPLETA de la tabla layer_styles del modelo
(styleQML incluida) sobre el GeoPackage que se actualiza, y esa styleQML
contiene el diseño íntegro del formulario (grupos, nombres, colapso,
expresiones...). Al cargar la capa, `QgsVectorLayer` (y el
`loadDefaultStyle()` que ejecuta GpkgLoader) ya restauran ese formulario
completo automáticamente. Se ha comprobado con QGIS real, SIN que
form_customizer.py interviniese en nada, que el formulario que trae la
capa recién actualizada y cargada ya es idéntico al del modelo -- grupos
"FICHAS-INFORMES"/"FOTOS"/"NC-INCIDENCIAS" con sus nombres y su colapso
exactos. El problema nunca fue que ese traslado fallase: era que
form_customizer.py lo tiraba y ponía su propia reconstrucción encima.

CORRECCIÓN
----------
core/form_customizer.py (IncidenciaFormCustomizer._apply_form):
  - Si la capa YA trae un formulario con grupos (porque "Actualiza GPKG"
    sincronizó el estilo del modelo y QGIS lo cargó), NO SE TOCA. Se deja
    exactamente como está: es el formulario real que el usuario diseñó a
    mano en el modelo, trasladado tal cual.
  - Solo se reconstruye un formulario desde cero (con los mismos tres
    grupos, como red de seguridad) cuando la capa NO trae ningún grupo
    propio -- por ejemplo, una obra muy antigua sin estilo guardado, o
    "Actualiza GPKG" ejecutado con "Sincronizar leyenda y simbología"
    desactivado.
  - En los dos casos, se aplica un último ajuste de colapso a los tres
    grupos conocidos, replicando la configuración que se nos indicó en
    capturas de "Formulario de atributos" de QGIS: plegados por defecto
    y, cuando la versión de QGIS lo soporta (3.44+, el mínimo que ya
    declara este plugin), con despliegue automático en cuanto ya hay
    datos que mostrar:
      · "FICHAS-INFORMES" se despliega solo cuando "Ficha" no está vacío.
      · "FOTOS" se despliega solo cuando "Foto 1" no está vacío.
      · "NC-INCIDENCIAS" se despliega solo cuando "Apertura" no está vacío.
    Si la versión de QGIS no tiene esa API (más antigua que 3.44), el
    grupo se queda simplemente plegado por defecto, sin desplegarse solo.

IMPORTANTE -- por qué esto es "trasladar exactamente"
--------------------------------------------------------
Con este cambio, cualquier ajuste futuro que el usuario haga al
formulario EN EL MODELO (renombrar un grupo, añadir un campo, cambiar el
orden, añadir una expresión de visibilidad...) se trasladará él solo al
actualizar un GeoPackage, sin necesitar ningún cambio de código en el
plugin -- siempre que el modelo guarde ese diseño como estilo
predeterminado del GeoPackage (botón "Guardar como" > "Valores
predeterminados de la capa" > "Todos los estilos de esta capa", o
equivalente, con la casilla de formulario incluida) y "Actualiza GPKG" se
ejecute con la sincronización de estilos activada (opción por defecto).

LIMITACIÓN DE PRUEBA CONOCIDA
-------------------------------
El plegado automático por expresión ("Control Collapsed by Expression")
es una API de QGIS 3.44+; el entorno de pruebas headless con QGIS real
disponible aquí es la versión 3.34 (empaquetada en Ubuntu), que NO expone
ese método en Python. Se ha comprobado con QGIS real que el código
detecta correctamente su ausencia y no rompe nada (el grupo se queda
plegado por defecto, sin desplegado automático); pero el desplegado
automático en sí mismo -- con QGIS 3.44 de verdad -- no se ha podido
verificar en este entorno y conviene confirmarlo en tu QGIS.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless), dos escenarios:
  1. Formulario ya diseñado (el camino normal: "Actualiza GPKG" con
     sincronización de estilos activada): se comprobó que el formulario
     cargado es exactamente el del modelo (mismos grupos, nombres,
     colapso, incluidos detalles del propio modelo que el plugin nunca
     tuvo codificados, como el campo "Poyecto" y la duplicación de
     Apertura/Doc_Apertura/Doc_Cierre en la raíz del formulario).
  2. Sin formulario diseñado (sincronización de estilos desactivada): se
     comprobó que la reconstrucción de emergencia sigue generando los
     mismos tres grupos con los nombres y el colapso correctos.
Además, se repitió la prueba de extremo a extremo sobre la pestaña
"Actualiza GPKG" de verdad (clic en "Analizar diferencias" → "Actualizar
GPKG" → "Sí" a cargar en el lienzo), confirmando el mismo resultado sobre
la capa realmente cargada en el lienzo.

CÓMO COMPROBARLO EN TU QGIS
------------------------------
1. Diseña el formulario en el modelo (Propiedades de capa > Formulario de
   atributos) como quieras que quede -- grupos, nombres, colapso,
   expresiones -- y guárdalo como estilo predeterminado del GeoPackage.
2. Actualiza un GeoPackage de obra con ese modelo desde "Actualiza GPKG"
   (con "Sincronizar leyenda y simbología" activado) y cárgalo en el
   lienzo.
3. Abre el formulario de una entidad: debe verse EXACTAMENTE el diseño
   del modelo, incluido el despliegue automático de los grupos al
   rellenar Ficha/Foto 1/Apertura (si tu QGIS es 3.44 o posterior).

COMPATIBILIDAD
---------------
Afecta solo a core/form_customizer.py. Sin cambios en gpkg_loader.py ni
gpkg_updater.py respecto a V174. Ambas variantes QGIS3/QGIS4 comparten el
mismo código en este módulo.

V177 - SI LA CAPA YA ESTABA CARGADA (proyecto guardado reabierto), NO SE ACTUALIZABA
========================================================================================

PROBLEMA
--------
El usuario reportó: "cuando abres un proyecto guardado de QGIS que
contiene el gpkg antiguo ya cargado, no se actualiza". La actualización
del propio fichero (campos, estilo) funcionaba bien, pero la capa que ya
estaba en el lienzo se quedaba tal cual estaba antes -- sin los campos
nuevos, sin el desplegable de "Tipo" reparado (V176), sin el formulario
correcto (V174/V175).

CAUSA
-----
`GpkgLoader.load_selected_layers()` YA tenía, desde antes, una rama
pensada exactamente para este caso: si una capa con el mismo origen de
datos ya está cargada en el proyecto, en vez de crear una copia nueva,
refresca ESA MISMA capa (nuevos campos, estilo, formulario...). Pero esa
rama solo se activa cuando se le llama con `no_duplicates=True` -- y los
DOS sitios que realmente la usan en la interfaz (el botón "¿Cargar el
GeoPackage actualizado en el lienzo?" de "Actualiza GPKG", y "Carga
Obra") llamaban a `load_grouped_gpkg()` / `load_selected_layers()` con
`no_duplicates=False`. Con ese valor, la condición que decide si
reutilizar la capa ya cargada (`if no_duplicates and
self._is_layer_loaded(uri)`) es siempre falsa, así que el código NUNCA
reconoce que la capa ya estaba en el proyecto: crea una capa nueva,
correctamente actualizada, y la dejaba en el grupo que gestiona el
plugin -- pero la capa ORIGINAL, la que el usuario ya tenía abierta
(por ejemplo, en la raíz del panel de capas o en un grupo distinto,
como pasa al reabrir un proyecto guardado hace tiempo), se queda
exactamente como estaba, sin tocar. El usuario ve la capa vieja (que es
la que tenía abierta) y, aunque en algún otro sitio del panel se haya
añadido una copia nueva correcta, para él "no se ha actualizado".

CORRECCIÓN
----------
- ui/tab_actualiza_gpkg.py y ui/tab_carga_obra.py: se cambia
  `no_duplicates=False` → `no_duplicates=True` en las dos llamadas al
  cargador. Así, si el GeoPackage ya tiene estas capas cargadas en el
  proyecto (con el mismo origen de datos), se refresca esa misma capa en
  vez de crear una copia.
- core/gpkg_loader.py:
    · El refresco de una capa ya cargada ahora usa `setDataSource()`
      (cierra y reabre el origen de datos por completo) en vez de solo
      `reloadData()` + `updateFields()`: es una forma más fiable de
      forzar que el proveedor relea de verdad la estructura actual del
      fichero, por si su conexión interna tuviera la anterior en caché.
    · Tras refrescarla, si la capa ya tenía un nodo en el árbol de capas
      en cualquier otro sitio (p. ej. la raíz, o un grupo distinto), se
      quita de ahí antes de añadirla al grupo de la obra que gestiona el
      plugin, para que no quede duplicada visualmente en el panel.
    · Esa misma rama ya incluye, de V176, la reparación del desplegable
      "Tipo"/CLAVE, así que una capa que ya estaba abierta con el
      desplegable roto también se repara al refrescarla.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless), reproduciendo el escenario exacto: se
carga una capa "a mano" (fuera de cualquier grupo del plugin, como
quedaría en un proyecto guardado hace tiempo), se GUARDA el proyecto, se
REABRE en un proceso nuevo (mismo id de capa, campos antiguos), y
entonces se usa la pestaña "Actualiza GPKG" de verdad (clic en "Analizar
diferencias" → "Actualizar GPKG" → "Sí" a cargar en el lienzo). Resultado:
sigue habiendo una única capa de Puntos en el proyecto, con el MISMO id
que la reabierta (no una copia), ya con los campos nuevos
(Apertura/Doc_Apertura/Cierre/Doc_Cierre/Foto 3/Foto 4), el formulario
correcto (FICHAS-INFORMES/FOTOS/NC-INCIDENCIAS) y, además, ahora colocada
dentro del grupo de la obra en el panel de capas. Se repitió también toda
la batería de pruebas anteriores (V174-V176) para confirmar que este
cambio no las rompe.

COMPATIBILIDAD
---------------
Afecta a core/gpkg_loader.py, ui/tab_actualiza_gpkg.py y
ui/tab_carga_obra.py. No afecta a "Nueva Obra", KMZ, Consulta ni Fotos.
Ambas variantes QGIS3/QGIS4 comparten el mismo comportamiento (solo
difieren, como siempre, en los enums planos/con ámbito de Qt).

OBRA_NUEVA v144 - Cola revisable en Georreferenciación manual

Cambios incorporados:

1. Sección 2 · Georreferenciación manual avanzada
   - Al seleccionar una carpeta ya no se inicia directamente la vista previa de la primera foto.
   - Primero se carga el listado completo de imágenes detectadas en la cola de trabajo.
   - El usuario puede seleccionar una o varias fotografías del listado y pulsar "Eliminar seleccionadas de la cola".
   - Las fotografías eliminadas de la cola no se georreferencian y, por tanto, no entran en la exportación de fotos_georref.

2. Nuevo botón de control
   - Se añade "Iniciar / continuar colocación" para comenzar o reanudar el recorrido de imágenes tras revisar la carpeta.
   - Se conserva el flujo de vista previa, marcado para informe final, descripción solo si se marca para informe final, fecha DD/MM/AAAA HH:MM y clic en lienzo.

3. Protección de fotos ya colocadas
   - La eliminación desde la cola solo afecta a fotografías pendientes.
   - Si una fotografía ya fue colocada en la capa fotos_georref, debe eliminarse desde la propia capa si no debe exportarse.

V184 - NUEVA PESTAÑA "ARCHIVAR GPKG": COPIAR UN GPKG TERMINADO SIN PERDER SUS ADJUNTOS
==========================================================================================

PETICIÓN
--------
"Voy a crearme en el servidor una carpeta de GPKG acabados y listos para
la consulta, pero para no perder las rutas de los adjuntos, vamos a
agregar una pestaña que se va a llamar Archivar GPKG, que incluirá una
función que nos permitirá elegir un GPKG y la carpeta de destino, y lo
exportará de tal forma que las rutas a archivos sigan siendo funcionales
desde esa nueva carpeta."

Contexto: la carpeta de trabajo tiene cientos de obras y muchos GeoPackage
que no interesan para "Consulta", lo que hace tediosa la selección de
GPKG. El usuario quiere ir moviendo a una carpeta aparte, ya ordenada,
solo los GeoPackage terminados y listos para consultar. Se aclaró con el
usuario que las FOTOS/DOCUMENTOS no debían copiarse -- se quedan donde
están, en la carpeta original -- y que si al archivar no se encuentra
algún adjunto en disco, el proceso debe continuar igualmente y avisar en
el registro qué falta.

CAUSA
-----
Los campos de documento/foto ("Ficha", "Foto 1"-"Foto 4", "Doc_Apertura",
"Doc_Cierre"...) guardan casi siempre una ruta RELATIVA a la carpeta del
propio GeoPackage (o a una subcarpeta como "fotos/"). Si el usuario
simplemente copiara el fichero .gpkg a otra carpeta con el explorador de
Windows, esa ruta relativa dejaría de tener sentido -- la copia buscaría
"fotos/imagen.jpg" dentro de SU PROPIA carpeta (la nueva, donde no hay
ninguna foto) en vez de en la carpeta original donde sí existe.

CORRECCIÓN
----------
core/gpkg_utils.py:
  Nueva función compartida `document_field_names(layer)`, que detecta de
  forma genérica qué campos de una capa están configurados con el widget
  "ExternalResource" (ya usada por "Consulta" desde la V182, ahora también
  por "Archivar GPKG").

core/gpkg_archiver.py (nuevo):
  `archive_gpkg(source_path, dest_folder, overwrite=False, progress_cb=None)`:
    1. Copia el fichero .gpkg (y sus posibles ficheros auxiliares -wal/-shm)
       a la carpeta de destino, sin tocar el original.
    2. Para cada tabla de la copia que tenga campos de documento/foto,
       recorre sus entidades y reescribe el VALOR de esos campos a una
       ruta ABSOLUTA que sigue apuntando al fichero real, usando la misma
       función `resolve_attachment_path` ya usada en "Consulta" (V182) --
       mismo criterio: probar la carpeta del GeoPackage ORIGINAL y varias
       subcarpetas habituales (fotos/Fotos, documentos/Documentos,
       fichas/Fichas...). Los ficheros de foto/documento NO se mueven ni
       se copian: se quedan donde ya estaban.
    3. Reconfigura el widget de cada campo de documento a
       `RelativeStorage = Absoluto` y lo guarda como estilo persistido del
       GeoPackage (`saveStyleToDatabase`), para que la copia interprete
       esas rutas absolutas tal cual, sin intentar resolverlas otra vez
       contra su propia carpeta.
    4. Si algún adjunto no se encuentra en ninguna carpeta candidata, se
       guarda igualmente la mejor ruta absoluta estimada (para no dejar el
       campo vacío) y se añade a una lista de "no encontrados" que se
       devuelve al llamador -- el proceso NO se detiene por esto.
    5. Si ya existe un archivo con ese nombre en el destino, se exige
       `overwrite=True` explícito (la pestaña pregunta al usuario antes).

ui/tab_archivar_gpkg.py (nuevo) + ui/main_dialog.py:
  Nueva pestaña "🗄 Archivar GPKG": selector de GeoPackage de origen,
  selector de carpeta de destino, barra de progreso, registro propio y
  botón "Archivar GPKG". Al terminar, muestra un resumen (tablas con
  documentos, campos reconfigurados, rutas reescritas) y, si procede, la
  lista de adjuntos no encontrados. Si el archivo ya existe en el destino,
  pregunta antes de sobrescribirlo. Un GeoPackage sin ningún campo de
  documento se copia igualmente, sin advertencias.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless): se construyó un GeoPackage de prueba con
una capa de Puntos y un campo "Foto 1" (ExternalResource, ruta relativa a
una subcarpeta "fotos/"), con una entidad cuya foto SÍ existe en disco y
otra cuya foto NO existe, y se guardó como estilo persistido (igual que
deja "Actualiza GPKG" en un GeoPackage real). Se ejecutó `archive_gpkg()`
a una carpeta de destino distinta y se comprobó que:
  - Se crea la copia en el destino y el GeoPackage original queda intacto.
  - La carpeta "fotos/" NO se copia a destino (los adjuntos se quedan en
    origen).
  - En la copia, el campo "Foto 1" queda con una ruta ABSOLUTA que apunta
    exactamente al fichero real en la carpeta ORIGINAL.
  - La entidad con foto inexistente queda con una ruta absoluta (mejor
    estimación) y se registra en la lista de "no encontrados".
  - El widget del campo queda como "ExternalResource" con
    `RelativeStorage=Absoluto`.
  - Volver a archivar sin `overwrite` lanza un error claro; con
    `overwrite=True` sobrescribe correctamente.
  - Un GeoPackage sin ningún campo de documento se archiva igualmente
    (copia simple).
Se repitió también el mismo flujo completo desde la pestaña
(ArchivarGpkgTab.run_archive) simulando la interacción del usuario, y toda
la batería de pruebas anteriores (V174-V183, 16 pruebas en total) para
confirmar que este cambio no rompe nada.

CÓMO COMPROBARLO EN TU QGIS
-----------------------------
1. Abre la nueva pestaña "🗄 Archivar GPKG".
2. Elige un GeoPackage terminado (con fotos/documentos adjuntados) y una
   carpeta de destino distinta a la de origen.
3. Pulsa "Archivar GPKG" y revisa el resumen y el registro.
4. Abre la copia en QGIS desde la nueva carpeta y comprueba que los
   campos de foto/documento siguen abriendo el fichero correcto (aunque
   la copia esté en una carpeta distinta a la original).

COMPATIBILIDAD
---------------
Pestaña nueva, no modifica el comportamiento de ninguna otra pestaña.
Añade `core/gpkg_archiver.py` y una función nueva en `core/gpkg_utils.py`
(no modifica ninguna función existente de ese fichero). Ambas variantes
QGIS3/QGIS4 comparten el mismo comportamiento.

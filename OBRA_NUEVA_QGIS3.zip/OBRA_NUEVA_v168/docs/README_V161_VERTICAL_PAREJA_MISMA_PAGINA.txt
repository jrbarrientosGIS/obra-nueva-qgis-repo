OBRA_NUEVA v161 - DOCX vertical con pareja indivisible

Cambios:
- En la disposición vertical del anejo fotográfico, cada pareja de fotos se mantiene siempre en la misma página cuando sea físicamente posible.
- La pareja se encapsula como bloque indivisible dentro de la tabla global del documento.
- Word recibe la instrucción de no dividir las filas de la pareja entre páginas.
- El ancho vertical parte de 12 cm y se reduce automáticamente por pareja si hace falta para que ambas fotos y sus pies quepan en la misma página.
- Se conserva el máximo tamaño posible para aprovechar el espacio disponible.

Se mantienen los cambios previos: tabla global, disposición horizontal a 8 cm, hasta tres parejas por página en horizontal, planos generales sin título y etiquetas de plano duplicadas.

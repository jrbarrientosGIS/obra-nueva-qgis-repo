OBRA_NUEVA v141 - Ayuda con captura de pestaña Fotos

Actualización sobre v140-ayuda-completa.

Cambios realizados:
- Añadida captura de referencia de la pestaña Fotos en la ayuda integrada HTML.
- La captura se guarda en docs/help/img/fotos.png.
- La sección 07 · Fotografías del manual muestra ahora la imagen antes de describir los tres bloques funcionales.
- Actualizado metadata.txt a version=1.4.1-ayuda-fotos.

No se modifica la lógica funcional de la pestaña Fotos/Anejo Fotográfico.

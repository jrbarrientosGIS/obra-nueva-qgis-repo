V168 - MODO DE CARGA (EDICIÓN / VISUALIZACIÓN)
================================================

PROBLEMA RESUELTO
------------------
En la pestaña "Cargar Obra", la leyenda de cada capa se recortaba automáticamente
a los elementos (valores de "tipo") realmente presentes en el GeoPackage. Esto
era correcto para visualizar la obra, pero impedía editar las capas y añadir
elementos nuevos, ya que sus categorías no aparecían en la leyenda ni, por tanto,
podían seleccionarse al digitalizar.

SOLUCIÓN
--------
Al seleccionar un GeoPackage (.gpkg) en la pestaña "Cargar Obra" —ya sea con el
botón "Examinar..." o escribiendo/pegando la ruta manualmente— aparece un
cuadro de diálogo que pregunta cómo se quiere cargar:

  · EDICIÓN
    Se carga con la leyenda COMPLETA (todas las categorías definidas en el
    estilo .qml), aunque no tengan elementos presentes todavía. Permite añadir
    nuevos elementos de cualquier tipo a las capas.

  · VISUALIZACIÓN
    Se carga con la leyenda RECORTADA a los elementos realmente presentes en
    cada capa (comportamiento clásico, pensado solo para consulta).

El modo elegido se refleja en la pestaña (etiqueta y radio buttons) y puede
cambiarse en cualquier momento antes de pulsar "Cargar" con el botón
"Cambiar modo...". El último modo usado se recuerda entre sesiones de QGIS.

DETALLES TÉCNICOS
------------------
- ui/tab_carga_obra.py:
    - Nuevo método _ask_load_mode(): muestra un QMessageBox con las opciones
      "Edición" / "Visualización" y actualiza los radio buttons existentes.
    - Se invoca automáticamente desde _select_gpkg() (botón Examinar) y desde
      _on_gpkg_path_edited() (edición manual de la ruta), solo cuando la ruta
      apunta a un GeoPackage válido y distinto del último preguntado.
    - Botón "Cambiar modo..." para relanzar la pregunta manualmente.
    - self.mode_status_label muestra el modo activo para el GeoPackage actual.
- core/gpkg_loader.py:
    - Sin cambios de comportamiento: ya admitía el parámetro prune_legend.
      En modo Edición se llama con prune_legend=False (leyenda completa);
      en modo Visualización con prune_legend=True (leyenda recortada,
      core/legend_pruner.py).

COMPATIBILIDAD
---------------
No afecta a otras pestañas (KMZ, Consulta, Nueva Obra, Fotos), que no dependen
de este flujo de carga con interfaz.

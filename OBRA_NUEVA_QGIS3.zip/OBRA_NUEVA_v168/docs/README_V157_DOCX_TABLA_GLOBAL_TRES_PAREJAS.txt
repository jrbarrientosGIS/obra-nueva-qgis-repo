OBRA_NUEVA v157 - DOCX tabla global y tres parejas por página

Cambios principales:

1. El bloque de fotografías del DOCX se genera como una única tabla global.
2. En disposición horizontal, cada pareja ocupa dos filas:
   - fila de imágenes: Foto impar / Foto par
   - fila de pies: pie de foto independiente bajo cada imagen
3. La fila de pies de foto tiene altura automática y se adapta al tamaño de fuente y longitud del texto.
4. Las imágenes quedan centradas horizontalmente y alineadas verticalmente abajo cuando tienen distinta altura.
5. En disposición horizontal se intenta colocar tres parejas por página.
6. El ancho horizontal se ajusta a 7,7 cm para ayudar a encajar tres parejas por página, respetando el mínimo indicado.
7. La disposición vertical también usa una única tabla global, con imagen y pie en filas independientes.

Base: v156.

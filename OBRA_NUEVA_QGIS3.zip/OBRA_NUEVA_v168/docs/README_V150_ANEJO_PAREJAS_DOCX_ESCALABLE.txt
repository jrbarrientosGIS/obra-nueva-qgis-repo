OBRA_NUEVA v150 - Ajustes finales de anejo fotográfico por parejas

Cambios aplicados sobre v149:

1. Foto individual en puntos_informe
   - La previsualización de foto individual para informe final incluye ahora campo de descripción.
   - La descripción se guarda en el campo Descripción de la capa puntos_informe.
   - Se mantiene el control de fecha/hora y la casilla opcional de estampar fecha.

2. Planos generales de ubicación
   - Si el plano general se divide en varias hojas, las hojas se ordenan por el número mínimo de foto contenido en cada plano.
   - Se mantiene el respeto a las capas visibles del lienzo antes de exportar.
   - Se mantienen las etiquetas Foto: Nº visibles, sin ocultarse por escala o solape.

3. Exportación DOCX
   - Al exportar se pregunta la disposición de las fotografías:
     a) Dos fotos en paralelo, ancho 8 cm.
     b) Disposición vertical, ancho 12 cm.
   - La maquetación respeta la lógica de parejas consecutivas: 1-2, 3-4, 5-6...
   - Si el número de fotos es impar, se muestra aviso y permite cancelar.
   - Se pregunta si se desea insertar un resumen de fotografías bajo el último plano general.
   - El resumen se genera por parejas y se puede revisar/editar antes de insertar.

4. Ventana del plugin
   - La ventana principal es redimensionable.
   - La pestaña Fotos se aloja en un área con scroll redimensionable para evitar controles cortados en pantallas pequeñas o con escalado de Windows.


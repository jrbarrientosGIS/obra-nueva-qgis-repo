OBRA_NUEVA v159 - Previsualización escalable de fotos individuales

Cambios:
- Las ventanas de previsualización de foto individual son redimensionables.
- Al cambiar el tamaño de la ventana, la imagen de vista previa se reescala automáticamente manteniendo proporciones.
- Se aplica tanto al flujo de Georreferenciación manual avanzada como al flujo de foto individual de puntos_informe.
- Se mantiene el resto de funcionalidad de v158: DOCX con tabla global, planos sin título superior y hasta dos planos por página.

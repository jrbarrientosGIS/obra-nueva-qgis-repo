OBRA_NUEVA v148 - Previsualización y fecha opcional en foto individual de anejo

Cambios:
- Al seleccionar una foto individual para puntos_informe/informe final se muestra siempre una previsualización antes de insertarla.
- En esa previsualización se permite elegir si se estampa o no la fecha en la fotografía exportada.
- Si la fotografía no tiene fecha detectada, se puede introducir manualmente en formato DD/MM/AAAA HH:MM solo cuando se activa la estampación.
- Si no se marca la estampación, la foto se inserta normalmente y no se imprime fecha sobre la imagen exportada.
- Desde la misma previsualización se puede elegir entre pinchar en el lienzo o insertar usando coordenadas GPS EXIF.
- Se mantienen las mejoras anteriores: estilo oficial de puntos_informe, cola de descartes y etiquetas visibles en planos de situación.

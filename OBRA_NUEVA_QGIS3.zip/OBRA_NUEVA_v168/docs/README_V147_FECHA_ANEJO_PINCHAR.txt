OBRA_NUEVA v147 - Fecha en fotos de informe insertadas por lienzo

Cambios:
- En la pestaña Fotos, apartado 3 Anejo fotográfico / puntos_informe, la opción "Seleccionar foto individual" + "Pinchar en lienzo" ahora controla la fecha de la fotografía.
- Si la imagen no tiene fecha legible, el plugin solicita la fecha antes de insertar el punto en puntos_informe.
- La fecha se valida y guarda en formato DD/MM/AAAA HH:MM.
- Si se introduce una fecha manual, queda marcada para estamparse visualmente al exportar la foto.
- La misma regla se aplica cuando se inserta una foto individual del anejo usando coordenadas GPS EXIF: si no hay fecha detectada, se solicita.
- Se mantiene el comportamiento de v146: todas las etiquetas Foto: Nº se dibujan en los planos de situación sin descarte por escala ni solape.
- Se mantiene el estilo oficial puntos_informe desde styles/puntos.qml.

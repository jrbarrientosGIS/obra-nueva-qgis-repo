OBRA_NUEVA v163 - saneamiento de código Fotos/Anejo

Cambios principales:
- _add_photo_feature_to_layer ya no hace commitChanges()/rollBack() si la capa ya estaba en edición. Evita cerrar o descartar ediciones previas del usuario.
- Exportación de fotos: puntos_informe y puntos_informes_pre exportan siempre con prefijo IF_.
- _prefixed_original_name elimina prefijos FR_/IF_ heredados y aplica siempre el prefijo correcto del flujo actual.
- Generador DOCX: wp:docPr y pic:cNvPr usan IDs únicos por imagen para reducir riesgo de reparación por Word.
- Se conserva compatibilidad de llamadas antiguas a export_layer_photos(layer, prefix), aunque el prefijo real se decide internamente por capa/campo.

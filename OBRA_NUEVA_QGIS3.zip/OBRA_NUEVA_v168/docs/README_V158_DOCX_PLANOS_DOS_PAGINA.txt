OBRA_NUEVA v158 - Ajustes DOCX: fotos a 8 cm y planos generales compactos

Cambios:
- En disposición horizontal por parejas se mantiene el ancho de foto en 8 cm.
- El bloque fotográfico conserva una única tabla global, pies en fila independiente y alineación inferior.
- Los planos generales del anejo ya no llevan título superior.
- Bajo cada plano se mantiene únicamente el pie: Localización de las fotos de los emplazamientos i/n.
- Se intenta colocar dos planos generales por página cuando el tamaño de los planos lo permite.

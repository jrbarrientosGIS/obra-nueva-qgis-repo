OBRA_NUEVA 1.7.27 - Comprobacion al abrir un proyecto
=====================================================

- Al abrir un proyecto de QGIS, el plugin comprueba si las obras con capas cargadas estan al dia con el GeoPackage modelo de «Actualiza GPKG» (si no hay, el de «Nueva Obra»).
- Si alguna no lo esta, se avisa en la barra de mensajes de QGIS con lo que falta (campos, tablas, leyendas, formularios, codigos de CLAVE/ASPECTOS).
- Boton «Abrir Actualiza GPKG»: abre la herramienta con esa obra y el modelo y lanza el analisis. No se modifica nada hasta pulsar «Actualizar GPKG». Al quedar al dia, el aviso se quita.
- Boton «No comprobar al abrir» y nueva casilla en «Actualiza GPKG» para activarla o desactivarla.
- La comprobacion solo lee. Nunca escribe en la obra.
- Para que sea rapida, se calcula una huella de la estructura, los estilos y las tablas CLAVE/ASPECTOS del modelo y de la obra. Si un analisis completo dice que la obra esta al dia, se recuerda en la configuracion de QGIS del equipo y no se vuelve a analizar mientras ninguna de las dos huellas cambie. Editar entidades no cambia la huella. Una version nueva del plugin vuelve a analizar cada obra una vez.
- Si el modelo no esta accesible (unidad de red o USB desconectados), no se comprueba nada; solo queda anotado en el registro de QGIS (pestaña OBRA_NUEVA).
- Codigo nuevo: core/model_check.py. Cambios en main_plugin.py y ui/tab_actualiza_gpkg.py (el recuento de cambios pendientes pasa a core/model_check.py, compartido).
- La 1.7.26 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.26.zip y OBRA_NUEVA_QGIS4_v1.7.26.zip.

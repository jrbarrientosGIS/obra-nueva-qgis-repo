OBRA_NUEVA
================

Instalación
-----------
1. Copiar la carpeta OBRA_NUEVA dentro de:
   %APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\
2. Reiniciar QGIS.
3. Activar el complemento desde el administrador de plugins.

Módulos incluidos
-----------------
- Nueva Obra: clona un GeoPackage base y carga el resultado agrupado.
- Carga Obra: carga un GeoPackage existente con árbol Base / Operativas / Auxiliares.
- KMZ: exporta una capa cargada a KMZ, con organización por ÁMBITO y leyenda textual filtrada.
- Consulta: escanea una carpeta de GPKG, consulta por capa operativa y filtros ÁMBITO / TIPO, y genera una capa temporal o la guarda a GPKG.

Notas técnicas
--------------
- La exportación KMZ de esta versión es funcional y estable, pero la equivalencia exacta de simbología QGIS -> KML debe validarse en tu entorno QGIS con tus renderers reales.
- La resolución CLAVE -> descripción está preparada para tablas sencillas con campos tipo clave/descripcion.
- El módulo Consulta asume esquemas homogéneos entre GeoPackages.

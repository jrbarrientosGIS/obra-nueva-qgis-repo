V186 - FIX: LA BARRA DE PROGRESO DE "ARCHIVAR GPKG" YA NO SE ANIMA EN REPOSO
================================================================================

PROBLEMA
--------
"En la pestaña Archivar la barra de progreso está en continuo movimiento,
corrige para que eso no suceda y solo se mueva cuando está archivando."

CAUSA
-----
La barra de progreso de "Archivar GPKG" se inicializaba (al construir la
pestaña) con `_reset_progress()`, un método que ponía la barra en el modo
"ocupado" de Qt (mínimo y máximo a 0) -- el mismo modo que se usa
correctamente en "Consulta" (V183) para animarse DURANTE una búsqueda.
El problema es que en "Archivar GPKG" ese modo "ocupado" se dejaba puesto
también en reposo, desde el mismo momento de abrir la pestaña y sin haber
pulsado nunca "Archivar GPKG" -- por eso se veía animándose todo el rato,
incluso sin estar haciendo nada.

CORRECCIÓN
----------
ui/tab_archivar_gpkg.py:
  Se separan los tres estados de la barra en métodos distintos:
    - `_set_progress_idle(text)`: barra ESTÁTICA y vacía (no se anima).
      Se usa al construir la pestaña ("Sin archivar") y si el archivado
      falla con un error ("Error") -- antes, un error dejaba la barra al
      100% con el texto "Error", lo cual además era confuso.
    - `_set_progress_busy(text)`: el modo "ocupado" de Qt que se anima
      solo -- se usa ÚNICAMENTE mientras `archive_gpkg()` está realmente
      en marcha, entre pulsar "Archivar GPKG" y que termine.
    - `_set_progress_done(text)`: barra estática al 100%, para cuando el
      archivado termina correctamente ("Archivado completado").

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless): se comprobó que, al construir la pestaña
(sin haber archivado nada todavía), la barra tiene `minimum() != maximum()`
(no está en modo ocupado); que tras un intento con un GeoPackage de
origen inválido tampoco queda animándose; que durante un archivado real
la barra SÍ pasa por el modo ocupado en algún momento (registrado dentro
del propio callback de progreso); y que, al terminar con éxito, vuelve a
quedar estática (no animándose). Se repitió también toda la batería de
pruebas anteriores (V174-V185, 18 pruebas en total) para confirmar que
este cambio no rompe nada.

CÓMO COMPROBARLO EN TU QGIS
-----------------------------
1. Abre la pestaña "Archivar GPKG": la barra debe verse estática y vacía
   ("Sin archivar"), sin moverse.
2. Pulsa "Archivar GPKG": la barra se anima mientras dura el proceso.
3. Al terminar (con éxito o con error), la barra deja de animarse.

COMPATIBILIDAD
---------------
Cambio interno, solo en `ui/tab_archivar_gpkg.py`. No afecta a ninguna
otra pestaña ni a la lógica de `core/gpkg_archiver.py`. Ambas variantes
QGIS3/QGIS4 comparten el mismo comportamiento.

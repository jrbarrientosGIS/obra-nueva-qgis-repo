OBRA_NUEVA - EXPORT_FOTOS v135

Hotfix aplicado sobre v134.

Corrección:
- Reescrita la creación de campos en _ensure_photo_fields para evitar línea frágil con ternario y argumento len.
- Los campos de texto se crean con QgsField(name, QVariant.String, "", length).
- Mantiene Sección 1 intacta.
- Mantiene Sección 2 avanzada: foto individual, carpeta, previsualización, informe_final, descripción solo si se marca informe final, prefijo IF al exportar.

OBRA_NUEVA v143 - Ajustes finales de Anejo Fotográfico

Cambios incorporados:

1. Simbología de puntos_informe
   - Se mantiene puntos_informe como capa de puntos del anejo.
   - Se incorpora puntos.qml como estilo definitivo.
   - Se fuerza etiquetado tipo llamada: caja negra, texto blanco y expresión Foto: Nº.

2. Planos de ubicación del DOCX
   - La extensión se calcula sobre puntos_informe.
   - Si la escala global excede 1:300000, se divide en varios planos.
   - Solo se exportan e insertan en el informe los planos que contienen fotografías/puntos dentro del encuadre.
   - Los planos vacíos se descartan.

3. Interfaz
   - Desaparece el botón Crear/activar puntos_informe.
   - La capa puntos_informe se crea automáticamente al seleccionar fotos desde carpeta o foto individual.

4. Ayuda
   - Actualizada la ayuda integrada para reflejar el nuevo flujo sin botón de creación manual.
   - Actualizada la explicación de planos de ubicación y simbología.

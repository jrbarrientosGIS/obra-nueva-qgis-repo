EXPORT_FOTOS v137
=================

Hotfix de nomenclatura de exportación de fotografías.

Regla nueva:
- Foto normal / georreferenciada: FR_nombre_original.jpg
- Foto seleccionada para informe final: IF_nombre_original.jpg

Se elimina del nombre exportado:
- numeración 001/002/003
- nombre del GPKG
- nombre de capa
- FID o códigos internos

Nota: si ya existe un archivo con el mismo nombre en la carpeta destino, se añade un sufijo mínimo _2, _3, etc. para no sobrescribir fotografías.

Se mantiene:
- escritura de coordenadas GPS EXIF si está activada/disponible
- manifest_fotos.csv
- lógica de informe_final / descripción

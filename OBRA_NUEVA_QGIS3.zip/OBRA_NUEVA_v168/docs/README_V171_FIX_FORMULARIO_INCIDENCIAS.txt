V171 - CORRECCIÓN: EL FORMULARIO DE INCIDENCIAS NO SE APLICABA
==================================================================

Tras la V170, al abrir el formulario de una entidad con Ámbito=Incidencias
y Tipo=No conformidad, los campos "Apertura" y "Cierre" no aparecían. Se han
corregido dos causas, ambas en core/form_customizer.py y core/gpkg_loader.py:

1. ENUM INCORRECTO AL FIJAR EL DISEÑO DEL FORMULARIO
-------------------------------------------------------
core/form_customizer.py usaba `QgsEditFormConfig.TabLayout` para activar el
diseño de "arrastrar y soltar" (necesario para que se respete la
reorganización en grupos/columnas). Esa forma "plana" del enum no está
garantizada en todas las versiones de PyQGIS: en las ramas más recientes
(QGIS4/master) el valor vive en `Qgis.AttributeFormLayout`, expuesto en
`QgsEditFormConfig.EditorLayout` como alias. Si esa línea lanzaba una
excepción, el bloque try/except de apply_form() la capturaba en silencio y
se descartaba TODA la personalización del formulario, sin aviso visible más
allá del registro de log.

Corrección: se usa `QgsEditFormConfig.EditorLayout.TabLayout`, forma
compatible con QGIS3 y QGIS4 según la documentación oficial de PyQGIS.

2. LA CAPA YA CARGADA NO SE REFRESCABA
-------------------------------------------
core/gpkg_loader.py evita cargar dos veces la misma capa: si el GeoPackage
ya estaba abierto en el proyecto, reutilizaba el objeto de capa existente
sin volver a aplicar el formulario ni refrescar sus campos. Si esa capa se
había cargado en una sesión anterior (antes de tener los campos
Apertura/Cierre, o antes de esta funcionalidad), reabrir el proyecto o
volver a pulsar "Cargar" no actualizaba nada visible.

Corrección: cuando se reutiliza una capa ya cargada, ahora se refresca su
proveedor de datos (dataProvider().reloadData() + updateFields()) para que
"vea" los campos añadidos al archivo, y se vuelve a aplicar el formulario
(apply_form) y la limpieza de leyenda sobre ella.

3. "NUEVA OBRA" NO APLICABA EL FORMULARIO A LAS CAPAS RECIÉN CREADAS
------------------------------------------------------------------------
La pestaña "Nueva Obra" no reutiliza GpkgLoader: crea el GeoPackage nuevo
copiando capas del GeoPackage de entrada (normalmente el modelo) y las carga
con su propio código (NuevaObraTab._load_result_layers_to_qgis), que nunca
pasaba por IncidenciaFormCustomizer. Resultado: una obra creada desde cero
heredaba los campos Apertura/Cierre solo si el GeoPackage de entrada ya los
tenía, y en ningún caso se le aplicaba la reorganización del formulario.

Corrección: NuevaObraTab también llama ahora a
ensure_fields_for_gpkg(...) (por si el GeoPackage de entrada no tuviera aún
los campos) y a apply_form(...) sobre cada capa operativa recién creada,
igual que hace GpkgLoader en "Carga Obra".

Adicionalmente, la expresión de visibilidad condicional (Ámbito=Incidencias
y Tipo=No conformidad) ahora se construye con los nombres reales de los
campos "Ámbito"/"Tipo" de cada capa en vez de tenerlos fijos en el código,
por si algún GeoPackage los nombrase con una variante de acentuación
distinta.

CÓMO COMPROBARLO
------------------
1. Cierra QGIS por completo (para partir de un proyecto limpio, sin capas
   de sesiones anteriores) y ábrelo de nuevo.
2. Instala este plugin (sustituye la versión anterior).
3. Pestaña "Carga Obra": carga el GeoPackage de la obra.
4. Abre el formulario de una entidad de Puntos/Líneas/Polígonos, pon
   Ámbito = Incidencias y Tipo = alguna opción "No conformidad...".
   Debe desaparecer "Ficha" y aparecer el grupo con "Apertura" y "Cierre"
   (una fila, dos columnas) y, debajo de cada uno, su campo de documento.
5. Comprueba también que "Foto 1" y "Foto 2" aparecen siempre en una fila
   de dos columnas, sea cual sea el Ámbito/Tipo.

Si el GeoPackage ya estaba cargado en un proyecto de QGIS abierto (de antes
de actualizar el plugin), cierra y vuelve a abrir ese proyecto, o usa
"Cargar" de nuevo desde la pestaña Carga Obra, para que la capa se refresque
con el nuevo formulario.

OBRA_NUEVA 1.7.29 - Fotos, bloque 2: la entidad de origen apunta siempre al JPG
==============================================================================

- Si una foto elegida con «1. Seleccionar en el Lienzo» no es JPG (p. ej. PNG), se sigue creando su JPG en la misma carpeta (el original no se toca) y, ademas, la entidad de origen pasa a apuntar a ese JPG.
- Se cambia el nombre de la foto en cada campo de texto cuyo valor termina en el (ruta completa, relativa o solo nombre). En las capas de «Importar fotos geoetiquetadas»: photo y filename. La carpeta no cambia.
- Vale para puntos, lineas y poligonos, y para todas las fotos de la entidad.
- Mismo criterio de guardado que al mover el punto: capa sin editar, se guarda; capa en edicion, el cambio queda en su edicion.
- Cambio en ui/tab_fotos.py (_actualizar_ruta_origen, _aplicar_cambios_origen).
- La 1.7.28 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.28.zip y OBRA_NUEVA_QGIS4_v1.7.28.zip.

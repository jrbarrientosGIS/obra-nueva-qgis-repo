V191 - ANEJO FOTOGRAFICO: IMPORTAR FOTOS DESDE ENTIDADES SELECCIONADAS EN EL LIENZO
====================================================================================

PETICION
--------
En el bloque "3 . Anejo fotografico / puntos_informe" de la pestana Fotos,
anadir una forma de incorporar a puntos_informe fotografias que ya estan
cargadas como atributo en una capa vectorial del proyecto (por ejemplo un
shapefile con un campo de tipo "foto"/"imagen"), sin tener que exportarlas
antes a una carpeta ni pincharlas manualmente en el lienzo. El usuario
selecciona las entidades directamente en el lienzo (con las herramientas
nativas de seleccion de QGIS) y el plugin importa sus fotos.

CAMBIOS
-------
ui/tab_fotos.py:
  Nuevo boton "Importar fotos desde seleccion en el lienzo" en el bloque 3,
  junto a "Seleccionar fotos desde carpeta" / "Seleccionar foto individual".

  Nuevo metodo import_anejo_photos_from_selection():
    1. Toma como capa origen la CAPA ACTIVA del lienzo (iface.activeLayer()).
       Se avisa si no hay capa activa valida o si la activa es una de las
       capas del propio anejo (puntos_informe / puntos_informes_pre /
       fotos_georref).
    2. Toma las entidades SELECCIONADAS de esa capa
       (layer.getSelectedFeatures()); si no hay ninguna, se avisa y no
       hace nada.
    3. Para cada entidad, reutiliza el detector de campos de foto ya
       existente _photo_paths() (el mismo que usa el bloque 1 de "Fotos
       asociadas a ambitos del GeoPackage cargado") para encontrar una o
       varias rutas de imagen validas en sus atributos, resolviendo rutas
       relativas contra la carpeta de la propia capa.
    4. Cada foto encontrada se anade a la capa puntos_informe (creandola si
       no existe) en el CENTROIDE de la entidad de origen, reproyectado a
       la CRS de puntos_informe si hace falta -- no se pincha en el lienzo,
       la ubicacion ya viene dada por la geometria de origen.
    5. Fecha: se aplica el mismo contrato que el resto del anejo
       (_ensure_anejo_photo_date): si la foto tiene fecha detectable
       (EXIF/nombre/OCR) se conserva como metadato sin preguntar; si no,
       se pide la fecha para esa foto y se marca para estamparla al
       exportar. Se puede cancelar la fecha de una foto concreta sin
       abortar el resto del lote.
    6. Descripcion: se deja vacia (igual que al importar desde carpeta) --
       se rellena luego a mano en la tabla de atributos de puntos_informe;
       no se copia de ningun campo del shapefile origen.
    7. Al terminar, muestra un resumen (fotos importadas, entidades sin
       foto detectada, rutas de imagen no encontradas en disco).

No se ha tocado el flujo existente de "Seleccionar fotos desde carpeta" /
"Seleccionar foto individual"; esta es una tercera via de entrada a
puntos_informe, pensada especificamente para fotos que ya viven como
atributo en una capa (shapefile, GeoPackage, etc.) cargada en el proyecto.

PENDIENTE
---------
No se ha podido probar contra QGIS real en este entorno (sin QGIS
instalado); revisar en tu instalacion:
  - Que "capa activa" + seleccion en el lienzo es el flujo esperado (frente
    a, por ejemplo, elegir la capa desde un desplegable propio del plugin).
  - El caso de shapefiles con varias fotos por entidad (campos foto_1,
    foto_2...) y rutas relativas a subcarpetas ("fotos/", "Fotos/"...).
  - Si conviene en el futuro evitar duplicados al reimportar la misma
    seleccion dos veces (hoy no se deduplica, igual que en la importacion
    desde carpeta).

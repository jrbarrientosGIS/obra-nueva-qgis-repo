V188 - FIX: "ARCHIVAR GPKG" TAMBIÉN PRIORIZA EL GPKG DEL PROYECTO SOBRE EL RECORDADO
========================================================================================

PROBLEMA
--------
"Haz lo mismo para la pestaña Archivar ya que mantiene el último y no se
actualiza al proyecto actual." (mismo problema que la V187 corrigió en
"Actualiza GPKG", ahora también en "Archivar GPKG".)

CAUSA
-----
Igual que le pasaba a "Actualiza GPKG" antes de la V187: el campo
"GeoPackage a archivar" solo se rellenaba con el GeoPackage del proyecto
cuando estaba VACÍO. En cuanto el usuario archivaba un GeoPackage una vez,
QGIS ya guardaba esa ruta en sus ajustes (QSettings) como "último
usado" -- así que, en las siguientes aperturas, el campo nunca estaba
realmente vacío y ese valor recordado ganaba siempre al GeoPackage que el
usuario tenía cargado en el lienzo en ese momento.

CORRECCIÓN
----------
ui/tab_archivar_gpkg.py:
  Mismo cambio de prioridad que la V187 en "Actualiza GPKG": el
  GeoPackage cargado en el proyecto QGIS actual ahora gana siempre al
  último recordado, mientras el usuario no haya elegido nada a mano.
    - Nuevo indicador `_src_gpkg_user_chosen`, a `True` en cuanto el
      usuario selecciona un GeoPackage con el selector de archivos ("…"),
      o escribe/edita el campo a mano (señal `textEdited`).
    - A diferencia de "Actualiza GPKG" (que tiene un botón "Limpiar
      formulario" para reactivar el relleno automático), "Archivar GPKG"
      no tiene ese botón -- así que, en su lugar, si el usuario vuelve a
      VACIAR el campo a mano, el indicador se pone de nuevo a `False` y el
      relleno automático con el proyecto se reactiva.
  Mientras el indicador esté a `False`, `refresh_project_default()`
  sobrescribe el campo con el GeoPackage del proyecto en cuanto haya uno
  disponible -- al abrir la pestaña y cada vez que pasa a ser la pestaña
  activa. Si no hay ningún GeoPackage cargado en el proyecto, se mantiene
  el comportamiento anterior: se usa el último recordado.

CÓMO SE COMPROBÓ
-----------------
Con QGIS real (3.34, headless): se simuló una "sesión anterior" dejando en
QSettings un GeoPackage recordado distinto al que se carga ahora en el
proyecto, y se comprobó que:
  - Al construir la pestaña, el campo muestra el GeoPackage del PROYECTO,
    no el recordado.
  - Tras una edición real del usuario (señal `textEdited`), refrescos
    posteriores ya no la sobrescriben.
  - Elegir un archivo con el selector también fija la elección del
    usuario.
  - Volver a vaciar el campo a mano reactiva el relleno automático con el
    proyecto.
  - Sin ningún GeoPackage cargado en el proyecto, se sigue usando el
    último recordado (comportamiento anterior, sin cambios).
Se repitió también toda la batería de pruebas anteriores (V174-V187, 20
pruebas en total) para confirmar que este cambio no rompe nada, incluidas
las pruebas de la barra de progreso (V186) y de los documentos accesibles
(V182/V184).

CÓMO COMPROBARLO EN TU QGIS
-----------------------------
1. Archiva al menos un GeoPackage alguna vez con "Archivar GPKG" (para que
   quede un valor recordado).
2. Carga en el lienzo un GeoPackage DISTINTO (con "Carga Obra", o abriendo
   un proyecto que ya lo traiga).
3. Ve a "Archivar GPKG": el campo "GeoPackage a archivar" debe mostrar el
   GeoPackage que acabas de cargar, no el que archivaste la vez anterior.

COMPATIBILIDAD
---------------
Cambio interno, solo en `ui/tab_archivar_gpkg.py`. No afecta a
"Actualiza GPKG" ni a ninguna otra pestaña. Ambas variantes QGIS3/QGIS4
comparten el mismo comportamiento.

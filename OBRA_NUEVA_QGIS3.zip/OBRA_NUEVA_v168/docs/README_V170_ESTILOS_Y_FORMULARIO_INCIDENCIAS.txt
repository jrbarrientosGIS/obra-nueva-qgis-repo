V170 - SINCRONIZACIÓN DE ESTILOS Y FORMULARIO DE INCIDENCIAS
===============================================================

Esta versión añade dos mejoras solicitadas sobre la pestaña "Actualiza GPKG"
y sobre el formulario de introducción de datos de las capas operativas.

1. "ACTUALIZA GPKG" TAMBIÉN COMPRUEBA LEYENDA Y SIMBOLOGÍA
-------------------------------------------------------------
Hasta ahora la pestaña "Actualiza GPKG" solo comparaba la estructura de
campos y tablas. Ahora compara también la leyenda y simbología (tabla
"layer_styles" del GeoPackage, que guarda el QML completo de cada capa) de
cada tabla operativa (Puntos/Líneas/Polígonos) del GPKG antiguo frente al
modelo:

  · Si el antiguo no tiene ningún estilo propio para una tabla -> "leyenda
    ausente, se copiará la del modelo".
  · Si el antiguo tiene un estilo distinto al del modelo (comparado por
    contenido, no solo por existencia) -> "leyenda distinta, se actualizará".
  · Si coincide -> no se toca.

Se ha añadido la casilla "Sincronizar leyenda y simbología con el modelo"
(activada por defecto). El informe de diferencias y el resumen final
muestran cuántas leyendas están pendientes de aplicar, y el resultado de la
actualización indica cuántas se sincronizaron. La sincronización de estilo
es una operación exclusivamente sobre metadatos de leyenda: nunca toca datos
ni geometrías de las capas.

2. FORMULARIO ESPECIAL PARA INCIDENCIAS · NO CONFORMIDADES
---------------------------------------------------------------
Al cargar cualquier capa operativa (Puntos, Líneas o Polígonos) que siga el
esquema estándar de obra (campos Ámbito, Tipo, Ficha, Foto 1, Foto 2), el
plugin prepara automáticamente el formulario de edición:

  · Se añaden (si faltan, sin tocar ningún dato existente) cuatro campos
    nuevos a la tabla: "Apertura", "Doc_Apertura", "Cierre" y "Doc_Cierre".
  · Cuando el Ámbito de la entidad es "Incidencias" y el Tipo es "No
    conformidad..." (comparación tolerante a mayúsculas y acentos), el campo
    "Ficha" se oculta automáticamente y en su lugar aparece un grupo con
    "Apertura" y "Cierre" en una fila de dos columnas; debajo de cada uno,
    su campo de documento correspondiente ("Doc_Apertura" / "Doc_Cierre",
    con visor de documento enlazable) también en fila de dos columnas.
  · En cualquier otro caso (ámbito o tipo distintos), el formulario se
    comporta como siempre: se ve "Ficha" y el grupo de Apertura/Cierre
    permanece oculto.
  · "Foto 1" y "Foto 2" se muestran siempre en una fila de dos columnas,
    independientemente del Ámbito/Tipo.

Esta reorganización se aplica en memoria sobre la capa ya cargada en QGIS
(igual que la limpieza de leyenda existente en el plugin), por lo que
funciona tanto con obras antiguas como con el GeoPackage modelo, sin
necesidad de editar a mano el estilo QML de cada capa.

DETALLES TÉCNICOS
------------------
- core/gpkg_updater.py:
    - GpkgStructureUpdater._copy_layer_styles(): copia (sustituyendo) las
      filas de "layer_styles" del modelo para una tabla al GeoPackage de
      destino. No modifica gpkg_contents ni ninguna tabla de datos.
    - TableDiff incorpora style_status ('match' | 'missing' | 'different' |
      'skip') y la propiedad needs_style_sync.
    - GpkgUpdatePlan.total_style_updates() y apply(..., sync_styles=True)
      para activar/desactivar la sincronización.
- core/gpkg_utils.py: GpkgIntrospector.has_layer_styles_table() y
  default_style_qml(table_name).
- core/form_customizer.py (nuevo): IncidenciaFormCustomizer.
    - ensure_fields_for_gpkg(gpkg_path, table_names): añade con
      ALTER TABLE ADD COLUMN los cuatro campos nuevos si la tabla sigue el
      esquema estándar de obra (Ámbito + Tipo + Ficha). No toca tablas que
      no encajen (CLAVE, Estaciones, Lineas_FFCC, pk, etc.).
    - apply_form(layer): reconstruye el QgsEditFormConfig de la capa cargada
      con QgsAttributeEditorContainer (2 columnas) y visibilidad condicional
      vía QgsOptionalExpression + expresión
      lower("Ámbito") LIKE '%incidencias%' AND
      lower(represent_value("Tipo")) LIKE '%no conformidad%'.
- core/gpkg_loader.py: engancha ensure_fields_for_gpkg() y apply_form() en
  el proceso de carga de capas operativas (GpkgLoader.load_selected_layers),
  cubriendo tanto "Carga Obra" como la agrupación por GPKG.
- ui/tab_actualiza_gpkg.py: casilla "Sincronizar leyenda y simbología con el
  modelo", informe y resumen ampliados con el recuento de leyendas.

COMPATIBILIDAD
---------------
Cambios aplicados por igual en las versiones QGIS3 y QGIS4 del plugin (los
cuatro módulos nuevos/ampliados de core/ no usan sintaxis específica de Qt,
solo API de QGIS y sqlite3). No afecta a otras pestañas (KMZ, Consulta,
Nueva Obra, Fotos). "core/multiobra_engine.py" (consulta multiobra de solo
lectura) no se modifica deliberadamente: la reorganización de formulario
solo tiene sentido en contexto de edición de datos.

Probado (sin instancia real de QGIS disponible) contra copias de los
GeoPackage de ejemplo GPK_OLD.gpkg / GPK_NEW.gpkg: alta de los cuatro campos
nuevos, idempotencia al repetir la operación, sincronización de leyenda
(incluyendo el caso de varias filas de estilo por tabla) y verificación de
que ni el número de filas ni los datos existentes cambian tras aplicar los
cambios.

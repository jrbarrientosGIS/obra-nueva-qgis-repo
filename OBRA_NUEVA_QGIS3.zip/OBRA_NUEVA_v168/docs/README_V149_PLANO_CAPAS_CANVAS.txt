OBRA_NUEVA v149 - Plano general con capas visibles del lienzo

Cambio aplicado:
- El Plano general de ubicación de fotografías del anejo ya no renderiza todas las capas cargadas en el proyecto.
- Ahora toma como base las capas visibles/activadas en el canvas de QGIS en el momento de exportar el informe.
- Se respeta la composición previa del usuario: ortofoto, cartografía base, ejes, pk, ámbitos u otras capas activadas/desactivadas.
- La capa puntos_informe se conserva como referencia del informe fotográfico y mantiene el sistema de etiquetas visibles de versiones anteriores.

Regla funcional:
Antes de exportar el anejo, el usuario deja activadas en el panel de capas las capas que quiere ver en el lienzo; el plano general del DOCX reproduce esa composición.

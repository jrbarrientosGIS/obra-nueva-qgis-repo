OBRA_NUEVA - EXPORT_FOTOS v134

Actualización de la Sección 2 de la pestaña Fotos.

Cambios principales:
1. Dos botones en Sección 2:
   - Seleccionar foto individual.
   - Seleccionar carpeta.
2. Vista previa previa a la colocación, con base aproximada de 10 cm y aspecto conservado.
3. En foto individual: vista previa -> decidir si entra en informe final -> clic en canvas.
4. En carpeta: se muestra la primera imagen -> Pinchar en lienzo o Siguiente imagen. El flujo continúa con las imágenes restantes.
5. Opción "Seleccionar para informe final" en todos los casos.
6. Si se selecciona para informe final, se solicita descripción. Si no, no se pide descripción.
7. Se añade campo informe_final en la capa de fotos, manteniendo Descripción para el informe.
8. Al exportar imágenes georreferenciadas, las fotografías seleccionadas para informe final o con descripción exportan nombre comenzando por IF.

Se mantiene intacta la Sección 1.

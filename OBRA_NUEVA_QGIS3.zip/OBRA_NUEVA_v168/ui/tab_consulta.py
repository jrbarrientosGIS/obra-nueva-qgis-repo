# -*- coding: utf-8 -*-
import os
import csv
import sqlite3
from collections import defaultdict

from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QLineEdit, QPushButton,
    QFileDialog, QComboBox, QCheckBox, QMessageBox, QGroupBox, QTextEdit,
    QDialog, QListWidget, QListWidgetItem, QAbstractItemView, QProgressBar, QApplication
)
from qgis.core import (
    QgsVectorLayer, QgsFeature, QgsField, QgsFields, QgsProject,
    QgsWkbTypes, QgsVectorFileWriter, QgsCoordinateTransformContext,
    QgsMapLayerStyle, QgsCategorizedSymbolRenderer, QgsRendererCategory,
    QgsRuleBasedRenderer, QgsExpression, QgsExpressionContext, QgsExpressionContextUtils,
    QgsEditorWidgetSetup
)

from ..core.gpkg_updater import scan_gpkg_files_recursive
from ..core.gpkg_utils import resolve_attachment_path

TARGET_LAYERS = ["SDON_Puntos", "SDON_Lineas", "SDON_Poligonos"]
CANONICAL_SUFFIXES = {
    "SDON_Puntos": ["_puntos", "puntos"],
    "SDON_Lineas": ["_lineas", "lineas"],
    "SDON_Poligonos": ["_poligonos", "poligonos"],
}
AMBITO_NAMES = ["AMBITO", "Ambito", "Ámbito", "ámbito", "ambito"]
TIPO_NAMES = ["TIPO", "Tipo", "tipo"]
PERIODO_NAMES = ["PERIODO", "Periodo", "periodo"]
ALL_VALUE = "(Todos)"


class GpkgSelectionDialog(QDialog):
    """Ventana emergente que aparece al terminar la búsqueda recursiva de
    GeoPackage en la carpeta elegida (y todas sus subcarpetas): muestra la
    lista completa encontrada, con casilla de verificación, para que el
    usuario decida sobre cuáles quiere realizar la consulta antes de que
    el plugin abra y analice cada uno (ese análisis, capa a capa y valor a
    valor, es lo costoso -- descartar aquí los que no interesan evita
    perder tiempo escaneándolos)."""

    def __init__(self, gpkg_files, base_folder, parent=None):
        super().__init__(parent)
        self.base_folder = base_folder
        self.accepted_selection = False
        self.setWindowTitle("Selecciona los GeoPackage a consultar")
        self.setModal(True)
        self.setMinimumSize(520, 420)

        layout = QVBoxLayout(self)

        info = QLabel(
            f"Se han encontrado {len(gpkg_files)} GeoPackage en esta carpeta "
            "y sus subcarpetas. Marca los que quieras incluir en la consulta:"
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QAbstractItemView.NoSelection)
        for full_path in gpkg_files:
            try:
                display = os.path.relpath(full_path, base_folder)
            except ValueError:
                display = full_path
            item = QListWidgetItem(display)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked)
            item.setData(Qt.UserRole, full_path)
            self.list_widget.addItem(item)
        layout.addWidget(self.list_widget, 1)

        sel_btns = QHBoxLayout()
        self.btn_select_all = QPushButton("Seleccionar todo")
        self.btn_select_none = QPushButton("Ninguno")
        sel_btns.addWidget(self.btn_select_all)
        sel_btns.addWidget(self.btn_select_none)
        sel_btns.addStretch()
        layout.addLayout(sel_btns)
        self.btn_select_all.clicked.connect(self._select_all)
        self.btn_select_none.clicked.connect(self._select_none)

        btns = QHBoxLayout()
        btns.addStretch()
        self.btn_ok = QPushButton("Aceptar")
        self.btn_ok.setObjectName("run_btn")
        self.btn_cancel = QPushButton("Cancelar")
        btns.addWidget(self.btn_ok)
        btns.addWidget(self.btn_cancel)
        layout.addLayout(btns)
        self.btn_ok.clicked.connect(self._on_accept)
        self.btn_cancel.clicked.connect(self.reject)

    def _on_accept(self):
        self.accepted_selection = True
        self.accept()

    def _select_all(self):
        for i in range(self.list_widget.count()):
            self.list_widget.item(i).setCheckState(Qt.Checked)

    def _select_none(self):
        for i in range(self.list_widget.count()):
            self.list_widget.item(i).setCheckState(Qt.Unchecked)

    def selected_files(self):
        result = []
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item.checkState() == Qt.Checked:
                result.append(item.data(Qt.UserRole))
        return result


class ConsultaTab(QWidget):
    def __init__(self, iface, status_callback=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.status_callback = status_callback or (lambda text: None)
        self.folder_path = ""
        self.gpkg_files = []
        self.scan_info = {}
        self.tipo_key_by_display = {}
        self._missing_docs_log = set()
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        folder_group = QGroupBox("Carpeta de GeoPackage")
        fg = QGridLayout()

        self.folder_edit = QLineEdit()
        self.btn_browse = QPushButton("Seleccionar carpeta")
        self.btn_scan = QPushButton("Escanear carpeta")

        fg.addWidget(QLabel("Carpeta:"), 0, 0)
        fg.addWidget(self.folder_edit, 0, 1)
        fg.addWidget(self.btn_browse, 0, 2)
        fg.addWidget(self.btn_scan, 1, 2)

        self.scan_progress = QProgressBar()
        self.scan_progress.setMinimum(0)
        self.scan_progress.setMaximum(1)
        self.scan_progress.setValue(0)
        self.scan_progress.setFormat("Escanear carpeta para empezar")
        fg.addWidget(QLabel("Progreso:"), 2, 0)
        fg.addWidget(self.scan_progress, 2, 1, 1, 2)

        folder_group.setLayout(fg)
        layout.addWidget(folder_group)

        filter_group = QGroupBox("Filtros")
        fl = QGridLayout()

        self.cmb_obra = QComboBox()
        self.cmb_ambito = QComboBox()
        self.cmb_tipo = QComboBox()
        self.cmb_periodo = QComboBox()
        for cmb in (self.cmb_obra, self.cmb_ambito, self.cmb_tipo, self.cmb_periodo):
            cmb.addItem(ALL_VALUE)

        fl.addWidget(QLabel("Obra:"), 0, 0)
        fl.addWidget(self.cmb_obra, 0, 1)
        fl.addWidget(QLabel("Ámbito:"), 1, 0)
        fl.addWidget(self.cmb_ambito, 1, 1)
        fl.addWidget(QLabel("Tipo:"), 2, 0)
        fl.addWidget(self.cmb_tipo, 2, 1)
        fl.addWidget(QLabel("Periodo:"), 3, 0)
        fl.addWidget(self.cmb_periodo, 3, 1)

        self.chk_points = QCheckBox("SDON_Puntos")
        self.chk_lines = QCheckBox("SDON_Lineas")
        self.chk_polygons = QCheckBox("SDON_Poligonos")
        self.chk_points.setChecked(True)
        self.chk_lines.setChecked(True)
        self.chk_polygons.setChecked(True)

        caps = QHBoxLayout()
        caps.addWidget(self.chk_points)
        caps.addWidget(self.chk_lines)
        caps.addWidget(self.chk_polygons)
        caps.addStretch()
        fl.addWidget(QLabel("Capas a consultar:"), 4, 0)
        fl.addLayout(caps, 4, 1)

        self.chk_zoom = QCheckBox("Zoom automático a resultados")
        self.chk_zoom.setChecked(True)
        fl.addWidget(self.chk_zoom, 5, 1)

        filter_group.setLayout(fl)
        layout.addWidget(filter_group)

        export_group = QGroupBox("Exportación")
        el = QGridLayout()
        self.export_folder_edit = QLineEdit()
        self.btn_export_folder = QPushButton("Carpeta de salida")
        self.btn_export_gpkg = QPushButton("Exportar resultados a GeoPackage")
        self.btn_export_gpkg.setObjectName("run_btn")
        self.btn_export_csv = QPushButton("Exportar resumen a CSV")
        el.addWidget(QLabel("Salida:"), 0, 0)
        el.addWidget(self.export_folder_edit, 0, 1)
        el.addWidget(self.btn_export_folder, 0, 2)
        el.addWidget(self.btn_export_gpkg, 1, 1)
        el.addWidget(self.btn_export_csv, 1, 2)
        export_group.setLayout(el)
        layout.addWidget(export_group)

        query_progress_row = QHBoxLayout()
        self.query_progress = QProgressBar()
        self.query_progress.setMinimum(0)
        self.query_progress.setMaximum(1)
        self.query_progress.setValue(0)
        self.query_progress.setFormat("Ejecutar consulta para empezar")
        query_progress_row.addWidget(QLabel("Progreso de consulta:"))
        query_progress_row.addWidget(self.query_progress, 1)
        layout.addLayout(query_progress_row)

        btns = QHBoxLayout()
        self.btn_query = QPushButton("Ejecutar consulta")
        self.btn_query.setObjectName("run_btn")
        self.btn_close = QPushButton("Cerrar")
        btns.addStretch()
        btns.addWidget(self.btn_query)
        btns.addWidget(self.btn_close)
        layout.addLayout(btns)

        layout.addWidget(QLabel("Registro"))
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        layout.addWidget(self.log_box)

        self.btn_browse.clicked.connect(self.choose_folder)
        self.btn_scan.clicked.connect(self.scan_folder)
        self.btn_query.clicked.connect(self.run_query)
        self.btn_close.clicked.connect(self._close_parent_dialog)
        self.btn_export_folder.clicked.connect(self.choose_export_folder)
        self.btn_export_gpkg.clicked.connect(self.export_results_to_gpkg)
        self.btn_export_csv.clicked.connect(self.export_summary_to_csv)

    def _close_parent_dialog(self):
        parent = self.window()
        if parent is not None:
            parent.close()

    def log(self, text):
        self.log_box.append(text)
        try:
            self.status_callback(text)
        except Exception:
            pass

    def choose_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Selecciona la carpeta con los GeoPackage")
        if folder:
            self.folder_path = folder
            self.folder_edit.setText(folder)
            if not self.export_folder_edit.text().strip():
                self.export_folder_edit.setText(folder)

    def choose_export_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Selecciona la carpeta de salida")
        if folder:
            self.export_folder_edit.setText(folder)

    def selected_target_layers(self):
        layers = []
        if self.chk_points.isChecked():
            layers.append("SDON_Puntos")
        if self.chk_lines.isChecked():
            layers.append("SDON_Lineas")
        if self.chk_polygons.isChecked():
            layers.append("SDON_Poligonos")
        return layers

    def normalize_name(self, name):
        return (
            str(name).strip().lower()
            .replace("á", "a").replace("à", "a")
            .replace("é", "e").replace("è", "e")
            .replace("í", "i").replace("ì", "i")
            .replace("ó", "o").replace("ò", "o")
            .replace("ú", "u").replace("ù", "u")
        )

    def find_existing_field(self, fields, candidates):
        names = [f.name() for f in fields]
        for c in candidates:
            if c in names:
                return c
        normalized = {self.normalize_name(n): n for n in names}
        for c in candidates:
            hit = normalized.get(self.normalize_name(c))
            if hit:
                return hit
        return None


    def _list_gpkg_feature_tables(self, gpkg_path):
        tables = []
        try:
            conn = sqlite3.connect(gpkg_path)
            cur = conn.cursor()
            cur.execute("SELECT table_name, data_type FROM gpkg_contents")
            for table_name, data_type in cur.fetchall():
                if str(data_type).lower() == "features":
                    tables.append(str(table_name))
            conn.close()
        except Exception:
            pass
        return tables

    def _canonical_target_for_table(self, table_name):
        normalized = self.normalize_name(table_name)
        for canonical, suffixes in CANONICAL_SUFFIXES.items():
            canonical_norm = self.normalize_name(canonical)
            if normalized == canonical_norm:
                return canonical
            for suffix in suffixes:
                suffix_norm = self.normalize_name(suffix)
                if normalized.endswith(suffix_norm):
                    return canonical
        return None

    def _discover_target_layers(self, gpkg_path):
        discovered = {}
        for table_name in self._list_gpkg_feature_tables(gpkg_path):
            canonical = self._canonical_target_for_table(table_name)
            if canonical and canonical not in discovered:
                discovered[canonical] = table_name
        return discovered

    def _tipo_desc_for_gpkg(self, gpkg_path, key):
        """Devuelve la descripción legible del TIPO desde la tabla CLAVE.
        En este modelo la relación normal es key -> TIPO, con N_AMB como campo auxiliar.
        Si no puede resolverla, devuelve la key original.
        """
        key = '' if key is None else str(key).strip()
        if not key:
            return key

        try:
            conn = sqlite3.connect(gpkg_path)
            cur = conn.cursor()

            cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
            table_names = [r[0] for r in cur.fetchall()]
            clave_table = next((t for t in table_names if self.normalize_name(t) == 'clave'), None)
            if not clave_table:
                conn.close()
                return key

            cur.execute(f'PRAGMA table_info("{clave_table}")')
            columns = [r[1] for r in cur.fetchall()]
            norm_to_real = {self.normalize_name(c): c for c in columns}

            # Prioridad correcta para tu esquema: key -> TIPO
            key_candidates = ['key', 'clave', 'codigo', 'id', 'tipo_key', 'tipoid', 'tipo_id', 'tipo']
            desc_candidates = ['tipo', 'descripcion', 'description', 'desc', 'tipo_desc', 'nombre', 'label']

            key_field = next((norm_to_real[n] for n in key_candidates if n in norm_to_real), None)
            desc_field = next((norm_to_real[n] for n in desc_candidates if n in norm_to_real), None)

            if not key_field or not desc_field:
                conn.close()
                return key

            query = f'SELECT "{desc_field}" FROM "{clave_table}" WHERE CAST("{key_field}" AS TEXT)=? LIMIT 1'
            cur.execute(query, (key,))
            row = cur.fetchone()
            conn.close()

            if row and row[0] not in (None, ''):
                return str(row[0])
            return key
        except Exception:
            return key

    def _reset_scan_progress(self, text="Escanear carpeta para empezar"):
        self.scan_progress.setMinimum(0)
        self.scan_progress.setMaximum(1)
        self.scan_progress.setValue(0)
        self.scan_progress.setFormat(text)

    def scan_folder(self):
        folder = self.folder_edit.text().strip()
        if not folder or not os.path.isdir(folder):
            QMessageBox.warning(self, "Carpeta no válida", "Selecciona una carpeta válida.")
            return

        self.folder_path = folder
        self.log_box.clear()

        # Modo "ocupado": sin un total conocido de antemano (aún no hemos
        # recorrido la carpeta), la barra se anima en vez de mostrar un
        # porcentaje -- pero el texto SÍ se actualiza en cada subcarpeta
        # revisada, para que se note avance real mientras dura la
        # búsqueda en árboles de carpetas grandes.
        self.scan_progress.setMinimum(0)
        self.scan_progress.setMaximum(0)
        self.scan_progress.setValue(0)
        self.scan_progress.setFormat("Buscando GeoPackage...")

        self.log(f"Buscando GeoPackage en \"{folder}\" y todas sus subcarpetas...")

        def _on_walk_progress(current_dir, dirs_visited, found_count):
            self.scan_progress.setFormat(
                f"Buscando... {dirs_visited} carpeta(s) revisada(s), {found_count} GeoPackage encontrado(s)"
            )
            try:
                QApplication.processEvents()
            except Exception:
                pass

        found_files = scan_gpkg_files_recursive(folder, progress_cb=_on_walk_progress)

        if not found_files:
            self._reset_scan_progress("Sin GeoPackage encontrados")
            QMessageBox.information(self, "Sin archivos", "No se encontraron archivos .gpkg en esa carpeta ni en sus subcarpetas.")
            return

        self._reset_scan_progress(f"{len(found_files)} GeoPackage encontrados -- elige cuáles escanear")

        dialog = GpkgSelectionDialog(found_files, folder, self)
        dialog.exec_()
        if not dialog.accepted_selection:
            self._reset_scan_progress("Selección cancelada")
            self.log("Selección de GeoPackage cancelada por el usuario.")
            return

        selected_files = dialog.selected_files()
        if not selected_files:
            self._reset_scan_progress("Sin GeoPackage seleccionados")
            QMessageBox.information(self, "Sin selección", "No se ha marcado ningún GeoPackage para consultar.")
            return

        self.gpkg_files = sorted(selected_files, key=lambda p: os.path.normcase(p))
        self.scan_info = {}
        self.tipo_key_by_display = {}
        obras, ambitos, tipos, periodos = set(), set(), set(), set()

        for cmb in (self.cmb_obra, self.cmb_ambito, self.cmb_periodo):
            cmb.clear()
            cmb.addItem(ALL_VALUE)
        self.cmb_tipo.clear()
        self.cmb_tipo.addItem(ALL_VALUE, ALL_VALUE)

        self.log(f"Encontrados {len(found_files)} GeoPackage; {len(self.gpkg_files)} seleccionado(s) para escanear.")
        self.log(f"Escaneando {len(self.gpkg_files)} GeoPackage...")
        total_layers_found = 0

        total_to_scan = len(self.gpkg_files)
        self.scan_progress.setMinimum(0)
        self.scan_progress.setMaximum(total_to_scan)
        self.scan_progress.setValue(0)
        self.scan_progress.setFormat("Escaneando: %v / %m GeoPackage")

        for scan_index, gpkg in enumerate(self.gpkg_files, start=1):
            obra = os.path.splitext(os.path.basename(gpkg))[0]
            per_file = {}
            discovered_layers = self._discover_target_layers(gpkg)
            for canonical_name in TARGET_LAYERS:
                real_layer_name = discovered_layers.get(canonical_name)
                if not real_layer_name:
                    continue

                uri = f"{gpkg}|layername={real_layer_name}"
                layer = QgsVectorLayer(uri, real_layer_name, "ogr")
                if not layer.isValid():
                    continue

                ambito_field = self.find_existing_field(layer.fields(), AMBITO_NAMES)
                tipo_field = self.find_existing_field(layer.fields(), TIPO_NAMES)
                periodo_field = self.find_existing_field(layer.fields(), PERIODO_NAMES)

                if not any([ambito_field, tipo_field, periodo_field]):
                    continue

                total_layers_found += 1
                per_file[canonical_name] = {
                    "real_layer_name": real_layer_name,
                    "ambito_field": ambito_field,
                    "tipo_field": tipo_field,
                    "periodo_field": periodo_field,
                    "crs_authid": layer.crs().authid() if layer.crs().isValid() else "EPSG:4326",
                    "wkb_type": int(layer.wkbType()),
                }

                obras.add(obra)
                if ambito_field:
                    idx = layer.fields().indexOf(ambito_field)
                    ambitos.update(str(v) for v in layer.uniqueValues(idx) if v not in (None, ""))
                if tipo_field:
                    idx = layer.fields().indexOf(tipo_field)
                    for v in layer.uniqueValues(idx):
                        if v in (None, ""):
                            continue
                        key = str(v)
                        desc = self._tipo_desc_for_gpkg(gpkg, key)
                        tipos.add((desc, key))
                if periodo_field:
                    idx = layer.fields().indexOf(periodo_field)
                    periodos.update(str(v) for v in layer.uniqueValues(idx) if v not in (None, ""))

            if per_file:
                self.scan_info[gpkg] = per_file
                visible = [f"{k}→{v.get('real_layer_name', k)}" for k, v in per_file.items()]
                self.log(f"OK {os.path.basename(gpkg)} -> {', '.join(visible)}")

            self.scan_progress.setValue(scan_index)
            try:
                QApplication.processEvents()
            except Exception:
                pass

        self.scan_progress.setFormat("Escaneo completado: %v / %m GeoPackage")

        for value in sorted(obras):
            self.cmb_obra.addItem(value)
        for value in sorted(ambitos):
            self.cmb_ambito.addItem(value)
        for desc, key in sorted(tipos, key=lambda x: (x[0].lower(), x[1])):
            display = desc
            if display in self.tipo_key_by_display and self.tipo_key_by_display[display] != key:
                display = f"{desc} [{key}]"
            self.tipo_key_by_display[display] = key
            self.cmb_tipo.addItem(display, key)
        for value in sorted(periodos):
            self.cmb_periodo.addItem(value)

        self.log("")
        self.log(f"GeoPackage válidos: {len(self.scan_info)}")
        self.log(f"Capas detectadas: {total_layers_found}")
        self.log(f"Obras: {len(obras)} | Ámbito: {len(ambitos)} | Tipo: {len(tipos)} | Periodo: {len(periodos)}")

        if not self.scan_info:
            QMessageBox.information(self, "Sin capas compatibles", "No se encontraron capas SDON_* con campos compatibles.")


    def _find_tipo_field_name(self, layer):
        return self.find_existing_field(layer.fields(), TIPO_NAMES)

    def _renderer_values_present(self, layer, class_attr):
        """Devuelve los valores realmente presentes para el atributo/expresión del renderer."""
        present_values = set()
        if not class_attr:
            return present_values

        field_idx = layer.fields().indexOf(class_attr)
        if field_idx != -1:
            for feat in layer.getFeatures():
                val = feat[field_idx]
                if val not in (None, ''):
                    present_values.add(str(val))
            return present_values

        expr = QgsExpression(class_attr)
        ctx = QgsExpressionContext()
        ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))

        for feat in layer.getFeatures():
            ctx.setFeature(feat)
            val = expr.evaluate(ctx)
            if val not in (None, ''):
                present_values.add(str(val))
        return present_values

    def _prune_result_legend(self, layer):
        """Ajusta la leyenda del resultado a las categorías realmente presentes."""
        try:
            if not layer or not layer.isValid() or layer.featureCount() == 0:
                return

            renderer = layer.renderer()
            if renderer is None:
                return

            if renderer.type() == 'categorizedSymbol':
                class_attr = renderer.classAttribute()
                present_values = self._renderer_values_present(layer, class_attr)
                if not present_values:
                    return

                kept = []
                for cat in renderer.categories():
                    try:
                        cat_val = cat.value()
                        if cat_val is None:
                            continue
                        if str(cat_val) in present_values:
                            kept.append(QgsRendererCategory(cat.value(), cat.symbol().clone(), cat.label(), cat.renderState()))
                    except Exception:
                        continue

                if kept:
                    new_renderer = QgsCategorizedSymbolRenderer(class_attr, kept)
                    try:
                        new_renderer.setSourceSymbol(renderer.sourceSymbol().clone())
                    except Exception:
                        pass
                    try:
                        new_renderer.setSourceColorRamp(renderer.sourceColorRamp().clone())
                    except Exception:
                        pass
                    try:
                        new_renderer.setUsingSymbolLevels(renderer.usingSymbolLevels())
                    except Exception:
                        pass
                    layer.setRenderer(new_renderer)
                    layer.triggerRepaint()
                return

            if renderer.type() == 'RuleRenderer':
                root = renderer.rootRule().clone()
                self._prune_rule_children(root, layer)
                layer.setRenderer(QgsRuleBasedRenderer(root))
                layer.triggerRepaint()
                return
        except Exception as e:
            self.log(f"Aviso al ajustar leyenda de {layer.name()}: {e}")

    def _prune_rule_children(self, rule, layer):
        children = list(rule.children())
        for child in children:
            self._prune_rule_children(child, layer)

        for child in list(rule.children()):
            if not self._rule_has_matches(child, layer):
                rule.removeChild(child)

    def _rule_has_matches(self, rule, layer):
        try:
            if rule.isElse():
                return True
            expr_text = rule.filterExpression()
            if not expr_text:
                return True

            expr = QgsExpression(expr_text)
            ctx = QgsExpressionContext()
            ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))

            for feat in layer.getFeatures():
                ctx.setFeature(feat)
                val = expr.evaluate(ctx)
                if bool(val):
                    return True
            return False
        except Exception:
            return True

    def make_result_layer(self, result_name, sample_layer):
        fields = QgsFields()
        existing = set()
        for fld in sample_layer.fields():
            fields.append(fld)
            existing.add(fld.name())
        if "obra" not in existing:
            fields.append(QgsField("obra", QVariant.String, len=80))
        if "archivo_gpkg" not in existing:
            fields.append(QgsField("archivo_gpkg", QVariant.String, len=255))

        geometry_str = QgsWkbTypes.displayString(sample_layer.wkbType())
        crs_authid = sample_layer.crs().authid() if sample_layer.crs().isValid() else "EPSG:4326"
        uri = f"{geometry_str}?crs={crs_authid}"
        mem = QgsVectorLayer(uri, result_name, "memory")
        pr = mem.dataProvider()
        pr.addAttributes(fields)
        mem.updateFields()
        return mem

    def apply_source_style(self, source_layer, target_layer):
        try:
            err = ""
            if hasattr(source_layer, "loadDefaultStyle"):
                source_layer.loadDefaultStyle(err)
        except Exception:
            pass

        try:
            if source_layer.renderer():
                target_layer.setRenderer(source_layer.renderer().clone())
        except Exception as e:
            self.log(f"Aviso al clonar renderizador de {source_layer.name()}: {e}")

        try:
            target_layer.setLabelsEnabled(source_layer.labelsEnabled())
            if source_layer.labelsEnabled() and source_layer.labeling():
                target_layer.setLabeling(source_layer.labeling().clone())
        except Exception:
            pass

        try:
            target_layer.setOpacity(source_layer.opacity())
        except Exception:
            pass

        for prop in [
            "legend/label-0",
            "embeddedWidgets/count",
            "embeddedWidgets/0/id",
            "embeddedWidgets/0/config",
            "labeling",
            "labeling/enabled",
            "labeling/fontFamily",
            "labeling/fontSize",
            "labeling/fieldName",
            "MapTip",
        ]:
            try:
                val = source_layer.customProperty(prop, None)
                if val is not None:
                    target_layer.setCustomProperty(prop, val)
            except Exception:
                pass

        try:
            style = QgsMapLayerStyle()
            style.readFromLayer(source_layer)
            style.writeToLayer(target_layer)
        except Exception:
            pass

        try:
            target_layer.triggerRepaint()
        except Exception:
            pass

    def _document_field_names(self, layer):
        """Nombres de los campos de la capa configurados con el widget
        "ExternalResource" (documento/foto adjuntos: "Ficha", "Foto 1"-
        "Foto 4", "Doc_Apertura", "Doc_Cierre"...). Genérico: no depende de
        una lista fija de nombres, así que cubre cualquier campo de
        documento que el modelo defina, presente o futuro."""
        names = set()
        fields = layer.fields()
        for i in range(fields.count()):
            try:
                if layer.editorWidgetSetup(i).type() == 'ExternalResource':
                    names.add(fields.at(i).name())
            except Exception:
                continue
        return names

    def _apply_document_widgets(self, src_layer, target_layer, document_fields):
        """Traslada a la capa resultado el widget "ExternalResource" de
        cada campo de documento/foto detectado en la capa origen, pero
        forzando `RelativeStorage` a Absoluto: como build_feature_out ya
        resuelve cada ruta a una ruta absoluta real (ver
        core.gpkg_utils.resolve_attachment_path), el widget de la capa
        resultado debe interpretar el valor guardado tal cual, sin
        intentar resolverlo de nuevo contra una carpeta relativa que ya no
        tiene sentido en una capa que mezcla varios GeoPackage de origen."""
        if not document_fields:
            return
        target_fields = target_layer.fields()
        for name in document_fields:
            src_idx = src_layer.fields().indexOf(name)
            tgt_idx = target_fields.indexOf(name)
            if src_idx < 0 or tgt_idx < 0:
                continue
            try:
                src_config = dict(src_layer.editorWidgetSetup(src_idx).config() or {})
            except Exception:
                src_config = {}
            src_config['RelativeStorage'] = 0  # Absoluto.
            src_config['DefaultRoot'] = ''
            try:
                target_layer.setEditorWidgetSetup(tgt_idx, QgsEditorWidgetSetup('ExternalResource', src_config))
            except Exception as e:
                self.log(f"Aviso al configurar el campo de documento \"{name}\" en el resultado: {e}")

    def build_feature_out(self, feat_in, result_layer, obra, archivo_gpkg, document_fields=None, gpkg_path=None):
        document_fields = document_fields or set()
        out = QgsFeature(result_layer.fields())
        out.setGeometry(feat_in.geometry())
        result_names = [f.name() for f in result_layer.fields()]
        input_names = feat_in.fields().names()
        attrs = []
        for n in result_names:
            if n == "obra":
                attrs.append(obra if n not in input_names else feat_in[n])
            elif n == "archivo_gpkg":
                attrs.append(archivo_gpkg if n not in input_names else feat_in[n])
            elif n in input_names:
                value = feat_in[n]
                if n in document_fields and value not in (None, "") and gpkg_path:
                    resolved, found = resolve_attachment_path(value, gpkg_path)
                    if resolved:
                        value = resolved
                        if not found:
                            self._missing_docs_log.add((n, resolved))
                attrs.append(value)
            else:
                attrs.append(None)
        out.setAttributes(attrs)
        return out

    def feature_matches(self, feat, info, obra_value, ambito_value, tipo_value, periodo_value):
        ambito_field = info.get("ambito_field")
        tipo_field = info.get("tipo_field")
        periodo_field = info.get("periodo_field")

        if ambito_value != ALL_VALUE:
            if not ambito_field or str(feat[ambito_field]) != ambito_value:
                return False
        if tipo_value != ALL_VALUE:
            if not tipo_field or str(feat[tipo_field]) != tipo_value:
                return False
        if periodo_value != ALL_VALUE:
            if not periodo_field or str(feat[periodo_field]) != periodo_value:
                return False
        return True

    def remove_existing_result_layers(self):
        project = QgsProject.instance()
        for name in ["RESULT_PUNTOS", "RESULT_LINEAS", "RESULT_POLIGONOS"]:
            for lyr in project.mapLayersByName(name):
                project.removeMapLayer(lyr.id())
        group = project.layerTreeRoot().findGroup("RESULTADOS_MULTIObra")
        if group is not None:
            project.layerTreeRoot().removeChildNode(group)

    def _reset_query_progress(self, text="Ejecutar consulta para empezar"):
        self.query_progress.setMinimum(0)
        self.query_progress.setMaximum(1)
        self.query_progress.setValue(0)
        self.query_progress.setFormat(text)

    def run_query(self):
        if not self.scan_info:
            self._reset_query_progress("Primero escanea la carpeta")
            QMessageBox.warning(self, "Primero escanea", "Primero debes escanear la carpeta.")
            return

        selected_layers = self.selected_target_layers()
        if not selected_layers:
            self._reset_query_progress("Selecciona al menos una capa")
            QMessageBox.warning(self, "Sin capas", "Selecciona al menos una capa.")
            return

        obra_value = self.cmb_obra.currentText()
        ambito_value = self.cmb_ambito.currentText()
        tipo_value = self.cmb_tipo.currentData() if self.cmb_tipo.currentIndex() >= 0 else self.cmb_tipo.currentText()
        periodo_value = self.cmb_periodo.currentText()

        self.remove_existing_result_layers()

        self._missing_docs_log = set()
        created_layers = {}
        counts = {"RESULT_PUNTOS": 0, "RESULT_LINEAS": 0, "RESULT_POLIGONOS": 0}
        result_name_map = {
            "SDON_Puntos": "RESULT_PUNTOS",
            "SDON_Lineas": "RESULT_LINEAS",
            "SDON_Poligonos": "RESULT_POLIGONOS",
        }

        self.log("")
        self.log("Ejecutando consulta...")
        self.log(f"Obra={obra_value} | Ámbito={ambito_value} | Tipo={tipo_value} | Periodo={periodo_value}")

        total_units = 0
        for gpkg, per_file in self.scan_info.items():
            obra = os.path.splitext(os.path.basename(gpkg))[0]
            if obra_value != ALL_VALUE and obra != obra_value:
                continue
            for layer_name in selected_layers:
                if layer_name in per_file:
                    total_units += 1

        self.query_progress.setMinimum(0)
        self.query_progress.setMaximum(max(total_units, 1))
        self.query_progress.setValue(0)
        self.query_progress.setFormat("Consultando: %v / %m capas")
        query_progress_counter = 0

        for gpkg, per_file in self.scan_info.items():
            obra = os.path.splitext(os.path.basename(gpkg))[0]
            if obra_value != ALL_VALUE and obra != obra_value:
                continue

            archivo = os.path.basename(gpkg)
            for layer_name in selected_layers:
                if layer_name not in per_file:
                    continue

                query_progress_counter += 1
                self.query_progress.setValue(query_progress_counter)
                try:
                    QApplication.processEvents()
                except Exception:
                    pass

                info = per_file[layer_name]
                real_layer_name = info.get("real_layer_name", layer_name)
                src = QgsVectorLayer(f"{gpkg}|layername={real_layer_name}", real_layer_name, "ogr")
                if not src.isValid():
                    continue

                # Carga el estilo persistido de ESTA capa origen (incluye el
                # formulario/widgets de campo) antes de leer su
                # editorWidgetSetup: sin esto, los campos de documento
                # ("Ficha", "Foto 1"-"Foto 4", "Doc_Apertura", "Doc_Cierre")
                # aparecerían con el widget de texto por defecto en vez de
                # "ExternalResource", y no se detectarían como adjuntos a
                # resolver más abajo. Se hace para CADA GeoPackage de
                # origen, no solo el primero, porque una consulta
                # multiobra mezcla varios.
                try:
                    err = ""
                    src.loadDefaultStyle(err)
                except Exception:
                    pass
                document_fields = self._document_field_names(src)

                result_name = result_name_map[layer_name]
                if result_name not in created_layers:
                    created_layers[result_name] = self.make_result_layer(result_name, src)
                    self.apply_source_style(src, created_layers[result_name])

                self._apply_document_widgets(src, created_layers[result_name], document_fields)

                out_layer = created_layers[result_name]
                feats_to_add = []
                for feat in src.getFeatures():
                    if self.feature_matches(feat, info, obra_value, ambito_value, tipo_value, periodo_value):
                        feats_to_add.append(self.build_feature_out(feat, out_layer, obra, archivo, document_fields, gpkg))

                if feats_to_add:
                    out_layer.dataProvider().addFeatures(feats_to_add)
                    out_layer.updateExtents()
                    counts[result_name] += len(feats_to_add)

        self.query_progress.setFormat("Consulta completada: %v / %m capas")

        if self._missing_docs_log:
            self.log("")
            self.log(f"⚠ {len(self._missing_docs_log)} documento(s)/foto(s) no se encontraron en disco (se guarda la mejor ruta estimada, revisa la carpeta):")
            for field_name, path in sorted(self._missing_docs_log):
                self.log(f"  {field_name}: {path}")

        if not created_layers:
            QMessageBox.information(self, "Sin resultados", "No se generó ninguna capa resultado.")
            return

        project = QgsProject.instance()
        root = project.layerTreeRoot()
        result_group = root.addGroup("RESULTADOS_MULTIObra")

        added = []
        for result_name in ["RESULT_POLIGONOS", "RESULT_LINEAS", "RESULT_PUNTOS"]:
            layer = created_layers.get(result_name)
            if layer and layer.featureCount() > 0:
                self._prune_result_legend(layer)
                project.addMapLayer(layer, False)
                result_group.addLayer(layer)
                added.append(layer)
                self.log(f"{result_name}: {counts[result_name]} entidades")
            elif layer:
                self.log(f"{result_name}: 0 entidades")

        if not added:
            QMessageBox.information(self, "Sin resultados", "No hay entidades que cumplan el filtro.")
            return

        if self.chk_zoom.isChecked():
            extent = None
            for lyr in added:
                if extent is None:
                    extent = lyr.extent()
                else:
                    extent.combineExtentWith(lyr.extent())
            if extent and not extent.isEmpty():
                self.iface.mapCanvas().setExtent(extent)
                self.iface.mapCanvas().refresh()

        try:
            self.iface.messageBar().pushMessage(
                "MultiObra Query Pro",
                "Consulta finalizada. Revisa el grupo RESULTADOS_MULTIObra.",
                level=0,
                duration=5
            )
        except Exception:
            pass
        QMessageBox.information(self, "Consulta finalizada", "Consulta completada correctamente.")

    def current_result_layers(self):
        project = QgsProject.instance()
        result = []
        for name in ["RESULT_PUNTOS", "RESULT_LINEAS", "RESULT_POLIGONOS"]:
            result.extend(project.mapLayersByName(name))
        return result

    def export_results_to_gpkg(self):
        layers = self.current_result_layers()
        if not layers:
            QMessageBox.warning(self, "Sin resultados", "Primero ejecuta una consulta.")
            return

        out_dir = self.export_folder_edit.text().strip()
        if not out_dir or not os.path.isdir(out_dir):
            QMessageBox.warning(self, "Salida no válida", "Selecciona una carpeta de salida válida.")
            return

        out_path = os.path.join(out_dir, "consulta_multiobra.gpkg")
        if os.path.exists(out_path):
            try:
                os.remove(out_path)
            except Exception as e:
                QMessageBox.warning(self, "No se puede sobrescribir", str(e))
                return

        first = True
        for lyr in layers:
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "GPKG"
            options.layerName = lyr.name()
            options.fileEncoding = "UTF-8"
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile if first else QgsVectorFileWriter.CreateOrOverwriteLayer

            res = QgsVectorFileWriter.writeAsVectorFormatV3(
                lyr, out_path, QgsCoordinateTransformContext(), options
            )
            err = res[0] if isinstance(res, tuple) else res
            msg = res[1] if isinstance(res, tuple) and len(res) > 1 else ""
            if err != QgsVectorFileWriter.NoError:
                QMessageBox.warning(self, "Error exportando", str(msg))
                return
            first = False

        QMessageBox.information(self, "Exportación completada", f"GeoPackage generado:\n{out_path}")

    def export_summary_to_csv(self):
        layers = self.current_result_layers()
        if not layers:
            QMessageBox.warning(self, "Sin resultados", "Primero ejecuta una consulta.")
            return

        out_dir = self.export_folder_edit.text().strip()
        if not out_dir or not os.path.isdir(out_dir):
            QMessageBox.warning(self, "Salida no válida", "Selecciona una carpeta de salida válida.")
            return

        out_path = os.path.join(out_dir, "consulta_multiobra_resumen.csv")
        rows = []
        for lyr in layers:
            idx_obra = lyr.fields().indexOf("obra")
            idx_tipo = lyr.fields().indexOf("Tipo") if lyr.fields().indexOf("Tipo") != -1 else lyr.fields().indexOf("TIPO")
            counts = defaultdict(int)
            for feat in lyr.getFeatures():
                obra = str(feat["obra"]) if idx_obra != -1 else ""
                tipo = str(feat[idx_tipo]) if idx_tipo != -1 else ""
                counts[(lyr.name(), obra, tipo)] += 1
            for (layer_name, obra, tipo), total in counts.items():
                rows.append([layer_name, obra, tipo, total])

        with open(out_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f, delimiter=";")
            writer.writerow(["capa", "obra", "tipo", "total"])
            for row in sorted(rows):
                writer.writerow(row)

        QMessageBox.information(self, "Exportación completada", f"Resumen CSV generado:\n{out_path}")

# -*- coding: utf-8 -*-
"""
Pestaña Fotos - OBRA_NUEVA

Reestructuración completa en tres bloques verticales:
1) Georref fotos ámbitos: exporta/copias JPG asociados a elementos de capas GPKG cargadas,
   usando el centroide del elemento asociado como punto de referencia.
2) Georref Fotos: permite insertar fotos una a una pinchando en el lienzo, sin solicitar descripción, y exportarlas.
3) Anejo fotográfico: una capa de fotos por informe (puntos_informe_IS-01, ..., puntos_informe_IF),
   selección desde el lienzo, un fichero o una carpeta con vista previa, simbología QML y
   exportación DOCX con planos generales a escala (escala gráfica y norte).
"""

import csv
import math
import os
import re
import shutil
import tempfile
import time
import zipfile
from collections import OrderedDict
from datetime import datetime
from xml.sax.saxutils import escape as xml_escape

from qgis.PyQt.QtCore import Qt, QSize, QRectF, QPointF, QSizeF, QTimer
from qgis.PyQt.QtGui import QImage, QPainter, QPixmap, QColor, QFont, QPen, QPolygonF
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QGroupBox, QTreeWidget, QTreeWidgetItem, QMessageBox, QCheckBox,
    QLineEdit, QTextEdit, QFileDialog, QListWidget, QDialog, QDialogButtonBox, QInputDialog,
    QAbstractItemView, QSizePolicy, QMenu, QComboBox, QRadioButton, QFormLayout
)
from qgis.core import (
    Qgis, QgsProject, QgsMapLayer, QgsVectorLayer, QgsWkbTypes, QgsFields, QgsField,
    QgsFeature, QgsGeometry, QgsPointXY, QgsVectorFileWriter, QgsCoordinateReferenceSystem,
    QgsCoordinateTransform, QgsCoordinateTransformContext, QgsEditorWidgetSetup,
    QgsMarkerSymbol, QgsPalLayerSettings, QgsTextFormat, QgsVectorLayerSimpleLabeling,
    QgsMapSettings, QgsMapRendererCustomPainterJob, QgsRectangle, QgsTextBackgroundSettings,
    QgsFeatureRequest, QgsDistanceArea, QgsUnitTypes
)
from qgis.gui import QgsMapToolEmitPoint

from ..core.ogr_layer_utils import simple_field
from ..helpers.logging_utils import log_message

# V1.7.16 (A6): tiempo máximo que se dedica a leer con OCR la fecha estampada
# en una foto sin fecha EXIF ni en el nombre. Antes podía probar hasta 120
# combinaciones y dejar QGIS congelado unos 30 s por foto.
OCR_MAX_SECONDS = 6.0


def _exif_sub_ifd(exif, tag):
    """Bloque EXIF anidado (0x8769 Exif, 0x8825 GPS) como diccionario, con
    Pillow moderno (get_ifd) y con versiones antiguas (dict directo)."""
    if not exif:
        return {}
    try:
        if hasattr(exif, "get_ifd"):
            data = exif.get_ifd(tag)
            if data:
                return dict(data)
    except Exception:
        pass
    value = exif.get(tag)
    return dict(value) if isinstance(value, dict) else {}


PLUGIN_DIR = os.path.dirname(os.path.dirname(__file__))
STYLE_PATH = os.path.join(PLUGIN_DIR, "styles", "puntos.qml")

LAYER_AMBITOS = "Fotos"
LAYER_MANUAL = "fotos_georref"
# V1.7.30: una capa de fotos por informe: puntos_informe_IS-01, puntos_informe_IS-02, ...,
# puntos_informe_IF (cada una en su GeoPackage junto a la obra). "puntos_informe" sin código
# es la capa de las versiones anteriores: se sigue pudiendo abrir y exportar.
LAYER_ANEJO = "puntos_informe"
LAYER_ANEJO_PRE = "puntos_informes_pre"
INFORME_CODE_RE = re.compile(r"^(IS-\d{2}|IF)$")
ANEJO_LAYER_RE = re.compile(r"^puntos_informe(?:_(IS-\d{2}|IF))?$")

# V1.7.30: planos generales del DOCX. Se dibujan al tamaño con el que van en el
# documento (16,2 x 10,8 cm) a 254 ppp (1 píxel = 0,1 mm), así la escala elegida
# es la escala real del plano impreso.
PLANO_ANCHO_CM = 16.2
PLANO_ALTO_CM = 10.8
PLANO_PX_POR_CM = 100
ESCALAS_NORMALIZADAS = [500, 1000, 2000, 2500, 5000, 10000, 15000, 20000, 25000, 50000,
                        75000, 100000, 200000, 250000, 500000, 1000000]
ESCALA_AUTO_MIN = 1000      # en automático no se acerca más de 1:1.000
ESCALA_AUTO_MAX = 50000     # ni se aleja más de 1:50.000 (si no cabe, varios planos)
# V1.7.30: las fotos se meten en el DOCX reducidas (lado mayor) y giradas según su EXIF.
DOCX_FOTO_LADO_MAX = 2000
DOCX_FOTO_CALIDAD = 85
FIELD_NUM = "Nº"
FIELD_DESC = "Descripción"
FIELD_PATH = "foto_path"
FIELD_REPORT = "informe_final"
FIELD_DATE = "fecha_foto"
FIELD_STAMP_DATE = "estampar_fecha"

CODE_FIELDS = ["codigo", "código", "CODIGO", "CÓDIGO", "code", "Code"]
# V1.7.16: N_AMB es el Ámbito (así se llama en la tabla CLAVE), no el Tipo.
AMBITO_FIELDS = ["ambito", "ámbito", "Ambito", "Ámbito", "AMBITO", "ÁMBITO", "N_AMB", "n_amb"]
TIPO_FIELDS = ["tipo", "Tipo", "TIPO"]
DESC_FIELDS = ["descripcion", "descripción", "Descripcion", "Descripción", "DESCRIPCION", "comentario", "Comentario", FIELD_DESC]
PHOTO_FIELDS = [
    # V1.7.16: también los campos del modelo de obra, con espacio.
    "Foto 1", "Foto 2", "Foto 3", "Foto 4",
    "photo", "Photo", "PHOTO",
    "foto_path", "Foto_path", "FOTO_PATH", "foto", "Foto", "FOTO",
    "foto_1", "Foto_1", "FOTO_1", "Foto1", "foto1", "foto_2", "Foto_2", "FOTO_2", "Foto2", "foto2",
    "foto_3", "Foto_3", "FOTO_3", "Foto3", "foto3", "imagen", "Imagen", "IMAGEN", "image", "Image", "IMAGE"
]
OP_SUFFIXES = (
    "_puntos", "_punto", "puntos", "punto", "_lineas", "_líneas", "lineas", "líneas", "linea", "línea",
    "_poligonos", "_polígonos", "poligonos", "polígonos", "poligono", "polígono",
)


class PhotoPointMapTool(QgsMapToolEmitPoint):
    """Herramienta de captura estable para insertar una fotografía con un clic en el canvas."""
    def __init__(self, canvas, callback):
        super().__init__(canvas)
        self.canvas = canvas
        self.callback = callback

    def canvasReleaseEvent(self, event):
        if event.button() != Qt.LeftButton:
            return
        point = self.toMapCoordinates(event.pos())
        self.callback(point, Qt.LeftButton)

    def keyReleaseEvent(self, event):
        if event.key() == Qt.Key_Escape and hasattr(self.callback, "__self__"):
            try:
                self.callback.__self__.cancel_placement(silent=False)
            except Exception:
                pass


class PhotoPickMapTool(QgsMapToolEmitPoint):
    """V1.7.19: herramienta de clic para elegir sobre el lienzo la entidad cuya foto se va a colocar."""
    def __init__(self, canvas, callback):
        super().__init__(canvas)
        self.canvas = canvas
        self.callback = callback

    def canvasReleaseEvent(self, event):
        if event.button() != Qt.LeftButton:
            return
        self.callback(self.toMapCoordinates(event.pos()))

    def keyReleaseEvent(self, event):
        if event.key() == Qt.Key_Escape and hasattr(self.callback, "__self__"):
            try:
                self.callback.__self__.cancel_placement(silent=False)
            except Exception:
                pass


class PhotoPreviewDialog(QDialog):
    """Vista previa escalable de fotografía con decisión de estampar la fecha."""
    PLACE = 1
    NEXT = 2
    CANCEL = 0

    def __init__(self, photo_path, allow_next=False, parent=None, detected_date=""):
        super().__init__(parent)
        self.photo_path = photo_path
        self.allow_next = allow_next
        self.detected_date = detected_date or ""
        self.action = self.CANCEL
        self._preview_pixmap = QPixmap(photo_path)
        self.setWindowTitle("Vista previa de fotografía")
        self.setModal(True)
        self.setSizeGripEnabled(True)
        self.setMinimumSize(520, 430)
        self.resize(760, 620)

        layout = QVBoxLayout(self)

        title = QLabel(os.path.basename(photo_path))
        title.setWordWrap(True)
        layout.addWidget(title)

        self.preview = QLabel()
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumSize(360, 220)
        self.preview.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        if self._preview_pixmap.isNull():
            self.preview.setText("No se pudo cargar la vista previa de la imagen.")
        layout.addWidget(self.preview, 1)
        self._update_preview_pixmap()

        date_text = self.detected_date if self.detected_date else "No detectada"
        self.lbl_date = QLabel(f"Fecha detectada: {date_text}")
        self.lbl_date.setWordWrap(True)
        layout.addWidget(self.lbl_date)
        self.chk_stamp_date = QCheckBox("Estampar la fecha en la foto original (sin fecha visible, se pedirá)")
        self.chk_stamp_date.setChecked(not bool(self.detected_date))
        layout.addWidget(self.chk_stamp_date)

        row = QHBoxLayout()
        self.btn_place = QPushButton("Pinchar en lienzo")
        self.btn_place.clicked.connect(self._place)
        row.addWidget(self.btn_place)
        if allow_next:
            self.btn_next = QPushButton("Siguiente imagen")
            self.btn_next.clicked.connect(self._next)
            row.addWidget(self.btn_next)
        self.btn_cancel = QPushButton("Cancelar")
        self.btn_cancel.clicked.connect(self.reject)
        row.addWidget(self.btn_cancel)
        layout.addLayout(row)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_preview_pixmap()

    def _update_preview_pixmap(self):
        if self._preview_pixmap.isNull():
            return
        target = self.preview.contentsRect().size()
        if target.width() < 20 or target.height() < 20:
            return
        scaled = self._preview_pixmap.scaled(target, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.preview.setPixmap(scaled)

    def _place(self):
        self.action = self.PLACE
        self.accept()

    def _next(self):
        self.action = self.NEXT
        self.accept()

    def reject(self):
        self.action = self.CANCEL
        super().reject()


class AnejoPhotoPreviewDialog(QDialog):
    """Vista previa escalable de una foto del anejo, con fecha y descripción.

    V1.7.30: se usa para cada foto de la cola (un fichero o una carpeta). Permite
    saltar la foto, colocarla con el GPS de la propia foto o pinchando en el lienzo,
    y colocar las siguientes con su GPS sin volver a preguntar."""
    PLACE = 1
    GPS = 2
    NEXT = 3
    CANCEL = 0

    def __init__(self, photo_path, parent=None, detected_date="", position_text="", allow_next=False,
                 has_gps=False, suggested_date="", informe_text=""):
        super().__init__(parent)
        self.photo_path = photo_path
        self.detected_date = detected_date or ""
        self.action = self.CANCEL
        self._preview_pixmap = QPixmap(photo_path)
        titulo = "Vista previa · foto para el anejo"
        if informe_text:
            titulo += f" · {informe_text}"
        self.setWindowTitle(titulo)
        self.setModal(True)
        self.setSizeGripEnabled(True)
        self.setMinimumSize(560, 520)
        self.resize(820, 720)

        layout = QVBoxLayout(self)

        title = QLabel((f"{position_text} · " if position_text else "") + os.path.basename(photo_path))
        title.setWordWrap(True)
        layout.addWidget(title)

        self.preview = QLabel()
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumSize(380, 240)
        self.preview.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        if self._preview_pixmap.isNull():
            self.preview.setText("No se pudo cargar la vista previa de la imagen.")
        layout.addWidget(self.preview, 1)
        self._update_preview_pixmap()

        if self.detected_date:
            date_text = self.detected_date
        else:
            date_text = "No detectada · escribe la fecha que se estampará en la foto exportada"
        self.lbl_date = QLabel(f"Fecha detectada: {date_text}")
        self.lbl_date.setWordWrap(True)
        layout.addWidget(self.lbl_date)

        self.chk_stamp_date = QCheckBox("Estampar fecha en la fotografía exportada")
        # V1.7.30: sin fecha detectada, la casilla viene marcada y se propone la
        # última fecha escrita en esta tanda (o se deja vacía).
        self.chk_stamp_date.setChecked(not self.detected_date)
        layout.addWidget(self.chk_stamp_date)

        self.txt_date = QLineEdit()
        self.txt_date.setPlaceholderText("DD/MM/AAAA HH:MM")
        self.txt_date.setText(self.detected_date or suggested_date or "")
        self.txt_date.setEnabled(self.chk_stamp_date.isChecked())
        layout.addWidget(self.txt_date)
        self.chk_stamp_date.toggled.connect(self.txt_date.setEnabled)

        note = QLabel("La fecha solo se imprime sobre la copia de la foto que va al anejo, no sobre la original.")
        note.setWordWrap(True)
        note.setStyleSheet("color: #8A9BBE; font-size: 9pt;")
        layout.addWidget(note)

        self.chk_add_desc = QCheckBox("Añadir descripción de la fotografía")
        self.chk_add_desc.setChecked(False)
        layout.addWidget(self.chk_add_desc)

        lbl_desc = QLabel("Descripción de la fotografía para el anejo:")
        layout.addWidget(lbl_desc)
        self.txt_desc = QTextEdit()
        self.txt_desc.setPlaceholderText("Descripción que aparecerá bajo la foto en el anejo fotográfico")
        self.txt_desc.setMinimumHeight(70)
        self.txt_desc.setEnabled(False)
        layout.addWidget(self.txt_desc)
        self.chk_add_desc.toggled.connect(self.txt_desc.setEnabled)

        self.chk_gps_rest = QCheckBox("Colocar las siguientes fotos con su GPS sin preguntar "
                                      "(las que no tengan GPS se mostrarán aquí)")
        self._allow_next = bool(allow_next)
        self.chk_gps_rest.setVisible(self._allow_next)
        layout.addWidget(self.chk_gps_rest)

        row = QHBoxLayout()
        self.btn_place = QPushButton("Pinchar en lienzo")
        self.btn_place.clicked.connect(self._place)
        row.addWidget(self.btn_place)
        self.btn_gps = QPushButton("Usar el GPS de la foto")
        self.btn_gps.clicked.connect(self._gps)
        self.btn_gps.setEnabled(bool(has_gps))
        if not has_gps:
            self.btn_gps.setToolTip("La foto no tiene coordenadas GPS en su EXIF.")
        row.addWidget(self.btn_gps)
        self.btn_next = QPushButton("Saltar esta foto")
        self.btn_next.clicked.connect(self._next)
        self.btn_next.setVisible(bool(allow_next))
        row.addWidget(self.btn_next)
        self.btn_cancel = QPushButton("Detener")
        self.btn_cancel.setToolTip("Detiene la cola. Al volver a elegir la carpeta se sigue por donde ibas: "
                                   "las fotos que ya están en el informe se omiten.")
        self.btn_cancel.clicked.connect(self.reject)
        row.addWidget(self.btn_cancel)
        layout.addLayout(row)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_preview_pixmap()

    def _update_preview_pixmap(self):
        if self._preview_pixmap.isNull():
            return
        target = self.preview.contentsRect().size()
        if target.width() < 20 or target.height() < 20:
            return
        scaled = self._preview_pixmap.scaled(target, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.preview.setPixmap(scaled)

    def selected_date(self):
        return " ".join(str(self.txt_date.text() or "").strip().split())

    def selected_desc(self):
        if not bool(self.chk_add_desc.isChecked()):
            return ""
        return str(self.txt_desc.toPlainText() or "").strip()

    def stamp_date(self):
        return bool(self.chk_stamp_date.isChecked())

    def gps_rest(self):
        # Se lee tras cerrar el diálogo (ya no está visible): se usa allow_next.
        return bool(self._allow_next and self.chk_gps_rest.isChecked())

    def _place(self):
        self.action = self.PLACE
        self.accept()

    def _gps(self):
        self.action = self.GPS
        self.accept()

    def _next(self):
        self.action = self.NEXT
        self.accept()

    def reject(self):
        self.action = self.CANCEL
        super().reject()


class FechaLoteDialog(QDialog):
    """V1.7.30: fecha para una foto sin fecha, con opción de usarla para el resto de
    fotos sin fecha de la misma tanda (antes salía una ventana por foto)."""

    def __init__(self, photo_path, default_value="", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Fecha de la fotografía")
        self.setModal(True)
        lay = QVBoxLayout(self)
        lbl = QLabel(f"La foto «{os.path.basename(photo_path)}» no tiene fecha.\n"
                     "Indica la fecha que se estampará en la copia del anejo (DD/MM/AAAA HH:MM):")
        lbl.setWordWrap(True)
        lay.addWidget(lbl)
        self.txt = QLineEdit(default_value or datetime.now().strftime("%d/%m/%Y %H:%M"))
        lay.addWidget(self.txt)
        self.chk_rest = QCheckBox("Usar esta fecha para las demás fotos sin fecha de esta tanda")
        lay.addWidget(self.chk_rest)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.fecha = ""

    def _ok(self):
        text = " ".join(str(self.txt.text() or "").strip().split())
        try:
            self.fecha = datetime.strptime(text, "%d/%m/%Y %H:%M").strftime("%d/%m/%Y %H:%M")
        except Exception:
            QMessageBox.warning(self, "Fecha no válida",
                                "Introduce la fecha con formato DD/MM/AAAA HH:MM. Ejemplo: 10/12/2025 11:10")
            return
        self.accept()


class OpcionesDocxDialog(QDialog):
    """V1.7.30: opciones del DOCX en una sola ventana: disposición de las fotos,
    escala del plano general y resumen de fotografías."""

    def __init__(self, parent=None, titulo_informe=""):
        super().__init__(parent)
        self.setWindowTitle("Exportar anejo fotográfico (DOCX)")
        self.setModal(True)
        lay = QVBoxLayout(self)
        if titulo_informe:
            lbl = QLabel(f"<b>{titulo_informe}</b>")
            lay.addWidget(lbl)

        g_disp = QGroupBox("Disposición de las fotografías")
        l_disp = QVBoxLayout(g_disp)
        self.rb_parallel = QRadioButton("Dos fotos en paralelo (8 cm)")
        self.rb_vertical = QRadioButton("Disposición vertical (12 cm)")
        self.rb_parallel.setChecked(True)
        l_disp.addWidget(self.rb_parallel)
        l_disp.addWidget(self.rb_vertical)
        lay.addWidget(g_disp)

        g_esc = QGroupBox("Plano general de localización")
        l_esc = QFormLayout(g_esc)
        self.cmb_escala = QComboBox()
        self.cmb_escala.setEditable(True)
        self.cmb_escala.addItem("Automática")
        for s in ESCALAS_NORMALIZADAS:
            self.cmb_escala.addItem("1:" + _fmt_miles(s))
        l_esc.addRow("Escala:", self.cmb_escala)
        ayuda = QLabel(
            "Escala real del plano impreso en el DOCX (16,2 cm de ancho). Si las fotos no caben en un solo "
            "plano a esa escala se hacen varios, sin separar nunca las dos fotos de una pareja. "
            "Automática: un solo plano entre 1:1.000 y 1:50.000; si no cabe, varios a 1:50.000. "
            "Todos los planos llevan escala gráfica y norte."
        )
        ayuda.setWordWrap(True)
        ayuda.setStyleSheet("color: #8A9BBE; font-size: 9pt;")
        l_esc.addRow(ayuda)
        lay.addWidget(g_esc)

        self.chk_summary = QCheckBox("Insertar resumen de fotografías debajo del último plano general")
        self.chk_summary.setChecked(True)
        lay.addWidget(self.chk_summary)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.escala = None

    def _ok(self):
        text = str(self.cmb_escala.currentText() or "").strip()
        if not text or text.lower().startswith("auto"):
            self.escala = None
            self.accept()
            return
        digits = re.sub(r"[^\d]", "", text.split(":", 1)[-1])
        try:
            value = int(digits)
        except Exception:
            value = 0
        if value < 100 or value > 5000000:
            QMessageBox.warning(self, "Escala no válida", "Escribe la escala como 1:5000 o 1:5.000 (entre 1:100 y 1:5.000.000).")
            return
        self.escala = value
        self.accept()

    def photo_layout(self):
        return "vertical" if self.rb_vertical.isChecked() else "parallel"

    def include_summary(self):
        return bool(self.chk_summary.isChecked())


def _fmt_miles(n):
    """12345 -> '12.345' (separador de miles español)."""
    return f"{int(round(n)):,}".replace(",", ".")


def _es_capa_informe(name):
    """V1.7.30: True para puntos_informe (antigua) y puntos_informe_IS-NN / _IF."""
    return bool(ANEJO_LAYER_RE.match(str(name or "")))


def _codigo_de_capa(name):
    m = ANEJO_LAYER_RE.match(str(name or ""))
    return (m.group(1) or "") if m else None


def _nombre_capa_informe(code):
    return f"{LAYER_ANEJO}_{code}" if code else LAYER_ANEJO


def _texto_informe(code):
    if code == "IF":
        return "Informe final (IF)"
    if code:
        try:
            return f"Informe semestral {int(code.split('-')[1])} ({code})"
        except Exception:
            return f"Informe {code}"
    return "puntos_informe (versión anterior, sin código de informe)"


class FotosTab(QWidget):
    def __init__(self, iface, status_callback=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.status_callback = status_callback or (lambda text: None)
        self.gpkgs = OrderedDict()
        self.pending_manual = []
        self.manual_index = 0
        self.manual_folder_mode = False
        self.current_manual_meta = None
        self.current_anejo_meta = None
        self.pending_anejo = []
        self.anejo_index = 0
        self.map_tool = None
        self.previous_tool = None
        self.placement_mode = None
        self._layer_counters = {}
        self._pick_continuo = False
        self._aviso_originales = False
        # V1.7.28: entidad de origen de las fotos elegidas en el lienzo (para
        # moverla también al punto donde se recoloca su foto).
        self._origen_lienzo = None
        # V1.7.30: informe activo del bloque 3 ("IS-01", ..., "IF"; "" = capa antigua
        # puntos_informe sin código; None = ninguno elegido todavía).
        self.informe_actual = None
        # V1.7.30: fecha que se usa para el resto de fotos sin fecha de una tanda y
        # colocación automática por GPS de las siguientes fotos de la cola.
        self._fecha_lote = None
        self._fecha_sugerida = ""
        self._gps_auto = False
        self._build_ui()
        self.refresh_loaded_gpkgs()
        self._apply_anejo_style_if_exists()
        self._apply_anejo_pre_style_if_exists()
        self._refrescar_informes()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        layout = QVBoxLayout(self)

        intro = QLabel(
            "Fotos: 1) coordenadas de las fotos de ámbitos, 2) ubicación y fecha de fotografías y "
            "3) anejo fotográfico. Cada bloque es un flujo independiente con su propia numeración."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        # 1. Exportación de fotos asociadas a capas del GeoPackage cargado
        g1 = QGroupBox("1 · Fotos asociadas a ámbitos del GeoPackage cargado")
        l1 = QVBoxLayout(g1)
        help1 = QLabel(
            "Detecta los GeoPackage cargados en el lienzo, lee los campos de imagen de sus capas Puntos/Líneas/Polígonos "
            "y escribe en cada foto original las coordenadas (GPS) del centroide de su entidad. No exporta copias."
        )
        help1.setWordWrap(True)
        help1.setStyleSheet("color: #8A9BBE; font-size: 9pt;")
        l1.addWidget(help1)

        row_refresh = QHBoxLayout()
        self.btn_refresh = QPushButton("Actualizar lista")
        self.btn_refresh.clicked.connect(self.refresh_loaded_gpkgs)
        self.btn_select_all = QPushButton("Seleccionar todos")
        self.btn_select_all.clicked.connect(lambda: self._set_all_checked(Qt.Checked))
        self.btn_unselect_all = QPushButton("Deseleccionar todos")
        self.btn_unselect_all.clicked.connect(lambda: self._set_all_checked(Qt.Unchecked))
        row_refresh.addWidget(self.btn_refresh)
        row_refresh.addWidget(self.btn_select_all)
        row_refresh.addWidget(self.btn_unselect_all)
        row_refresh.addStretch()
        l1.addLayout(row_refresh)

        self.tree = QTreeWidget()
        self.tree.setColumnCount(4)
        self.tree.setHeaderLabels(["Usar", "GeoPackage", "Capas origen", "Estado"])
        self.tree.setRootIsDecorated(False)
        l1.addWidget(self.tree)
        self._ajustar_alto_arbol()

        # V1.7.22: el botón va justo debajo de la lista, a la izquierda
        row_export_amb = QHBoxLayout()
        self.btn_export_ambitos = QPushButton("1)  Georref fotos ámbitos")
        self.btn_export_ambitos.setObjectName("run_btn")
        self.btn_export_ambitos.clicked.connect(self.export_ambito_photos)
        row_export_amb.addWidget(self.btn_export_ambitos)
        row_export_amb.addStretch()
        l1.addLayout(row_export_amb)
        layout.addWidget(g1, 0)

        # 2. Ubicación y fecha de las fotografías (V1.7.20: solo ubicación y fecha)
        g2 = QGroupBox("2 · Ubicación y fecha de fotografías")
        l2 = QVBoxLayout(g2)
        help2 = QLabel(
            "Coloca cada fotografía en su ubicación sobre el lienzo y graba sus coordenadas (GPS) en la propia foto "
            "original. Si la foto no tiene fecha, o quieres otra, también puedes estamparla en la foto original. "
            "Elige las fotos con «Seleccionar Fotos» (pinchándolas en el lienzo, un fichero o una carpeta). "
            "Si la eliges pinchando un punto del lienzo (p. ej. de «Importar fotos geoetiquetadas»), ese punto "
            "también se mueve en su capa al sitio donde colocas la foto. "
            "Este bloque no crea capas ni exporta, y no está ligado al anejo fotográfico del bloque 3."
        )
        help2.setWordWrap(True)
        help2.setStyleSheet("color: #8A9BBE; font-size: 9pt;")
        l2.addWidget(help2)
        self.list_manual = QListWidget()
        self._ajustar_alto_lista(self.list_manual)
        self.list_manual.setSelectionMode(QAbstractItemView.ExtendedSelection)
        l2.addWidget(self.list_manual)

        row2a = QHBoxLayout()
        self.btn_manual_select = self._boton_seleccionar_fotos(
            self.select_manual_from_canvas,
            self.select_manual_single_with_preview,
            self.select_manual_folder_with_preview,
            "Pincha sobre el lienzo la entidad cuya foto quieres colocar; después pincha el punto "
            "definitivo y las coordenadas se graban en la foto original. Si la entidad es un punto, "
            "también se mueve en su capa. Se repite hasta cancelar.",
        )
        self.btn_manual_remove = QPushButton("Eliminar seleccionadas de la cola")
        self.btn_manual_remove.clicked.connect(self.remove_selected_manual_photos)
        self.btn_manual_cancel = QPushButton("Cancelar")
        self.btn_manual_cancel.clicked.connect(self.cancel_placement)
        row2a.addWidget(self.btn_manual_select)
        row2a.addWidget(self.btn_manual_remove)
        row2a.addWidget(self.btn_manual_cancel)
        self.btn_manual_start = QPushButton("2)  Iniciar / continuar colocación")
        self.btn_manual_start.clicked.connect(self.start_manual_folder_preview)
        row2a.addWidget(self.btn_manual_start)
        row2a.addStretch()
        l2.addLayout(row2a)
        layout.addWidget(g2, 0)

        # 3. Anejo fotográfico
        g3 = QGroupBox("3 · Anejo fotográfico")
        l3 = QVBoxLayout(g3)
        help3 = QLabel(
            "Cada informe (semestrales IS-01, IS-02… y final IF) tiene su propia capa de fotos, "
            "puntos_informe_<código>, guardada junto a la obra. Elige el informe y después las fotos "
            "con «Seleccionar Fotos»: desde el lienzo (entidades seleccionadas, p. ej. un shapefile con campo de foto), "
            "un fichero o una carpeta (recursiva). Las fotos que ya están en el informe se omiten. "
            "El DOCX lleva plano(s) general(es) a la escala que elijas, con escala y norte, y las fotos por parejas."
        )
        help3.setWordWrap(True)
        help3.setStyleSheet("color: #8A9BBE; font-size: 9pt;")
        l3.addWidget(help3)
        row_inf = QHBoxLayout()
        row_inf.addWidget(QLabel("Informe:"))
        self.cmb_informe = QComboBox()
        self.cmb_informe.setMinimumWidth(260)
        self.cmb_informe.currentIndexChanged.connect(self._on_informe_cambiado)
        row_inf.addWidget(self.cmb_informe)
        self.btn_nuevo_informe = QPushButton("Nuevo informe…")
        self.btn_nuevo_informe.setToolTip("Crea la capa de fotos de un nuevo informe semestral (IS-NN) o del informe final (IF).")
        self.btn_nuevo_informe.clicked.connect(self._nuevo_informe)
        row_inf.addWidget(self.btn_nuevo_informe)
        row_inf.addStretch()
        l3.addLayout(row_inf)
        self.list_anejo = QListWidget()
        self.list_anejo.setMinimumHeight(90)
        l3.addWidget(self.list_anejo)
        row3a = QHBoxLayout()
        self.btn_anejo_select = self._boton_seleccionar_fotos(
            self.import_anejo_photos_from_selection,
            self.select_anejo_single_photo,
            lambda: self.select_anejo_photos_from_folder(),
            "Importa las fotos de TODAS las entidades seleccionadas en el lienzo, de una o varias capas "
            "(p. ej. un shapefile con un campo de foto). Se añaden al informe elegido en la ubicación de "
            "cada entidad, sin pinchar en el lienzo.",
            texto_lienzo="1. Preseleccionadas en el lienzo",
        )
        self.btn_anejo_cancel = QPushButton("Cancelar")
        self.btn_anejo_cancel.clicked.connect(self.cancel_placement)
        row3a.addWidget(self.btn_anejo_select)
        row3a.addWidget(self.btn_anejo_cancel)
        row3a.addStretch()
        l3.addLayout(row3a)

        row3b = QHBoxLayout()
        self.btn_pair_renumber = QPushButton("2)  ⇄  Agrupar por ubicación y renumerar")
        self.btn_pair_renumber.setToolTip(
            "Agrupa las fotos del informe elegido en parejas por proximidad geográfica "
            "y las renumera correlativamente. Dentro de cada pareja, el número impar corresponde "
            "siempre a la foto más antigua."
        )
        self.btn_pair_renumber.clicked.connect(self._pair_and_renumber_informe_final)
        self.btn_anejo_folder_export = QPushButton("3)  Exportar fotos a carpeta")
        self.btn_anejo_folder_export.clicked.connect(
            lambda: self.export_layer_photos(self._capa_informe_existente(), self.informe_actual or "IF"))
        self.btn_anejo_docx = QPushButton("4)  Exportar tabla DOCX")
        self.btn_anejo_docx.setObjectName("run_btn")
        self.btn_anejo_docx.clicked.connect(self.export_docx)
        row3b.addWidget(self.btn_pair_renumber)
        row3b.addWidget(self.btn_anejo_folder_export)
        row3b.addWidget(self.btn_anejo_docx)
        row3b.addStretch()
        l3.addLayout(row3b)
        self.lbl_anejo_status = QLabel("Estado: elige o crea un informe.")
        self.lbl_anejo_status.setStyleSheet("color: #8A9BBE;")
        l3.addWidget(self.lbl_anejo_status)
        layout.addWidget(g3, 1)
        # V1.7.24: los bloques 1 y 2 miden lo que necesitan; el bloque 3 aprovecha el resto

    # V1.7.18: un solo botón "Seleccionar Fotos" con tres orígenes
    def _boton_seleccionar_fotos(self, a_lienzo, a_fichero, a_carpeta, ayuda_lienzo="",
                                 texto_lienzo="1. Seleccionar en el Lienzo"):
        btn = QPushButton("1)  Seleccionar Fotos")
        menu = QMenu(btn)
        menu.setToolTipsVisible(True)
        for texto, funcion, ayuda in (
            (texto_lienzo, a_lienzo, ayuda_lienzo),
            ("2. Seleccionar Fichero", a_fichero, "Elige una única fotografía."),
            ("3. Seleccionar Carpeta", a_carpeta, "Elige una carpeta con fotografías."),
        ):
            accion = menu.addAction(texto)
            accion.setToolTip(ayuda)
            accion.triggered.connect(lambda _=False, f=funcion: f())
        btn.setMenu(menu)
        return btn

    def select_manual_from_canvas(self):
        """Sección 2 · "Seleccionar en el Lienzo" (V1.7.19): activa una herramienta de clic. Se
        pincha sobre el lienzo la entidad (de cualquier capa visible) cuya foto se quiere colocar;
        se abre la vista previa, se pincha el punto definitivo y las coordenadas se graban en la foto
        original. Se repite hasta cancelar (ESC o botón Cancelar)."""
        self._pick_continuo = True
        self._armar_seleccion_lienzo()

    def _armar_seleccion_lienzo(self):
        self.cancel_placement(silent=True)
        self.previous_tool = self.canvas.mapTool()
        self.map_tool = PhotoPickMapTool(self.canvas, self._seleccion_lienzo_clic)
        self.placement_mode = "pick"
        self.canvas.setMapTool(self.map_tool)
        self.iface.messageBar().pushMessage(
            "Fotos",
            "Haz clic sobre la entidad del lienzo cuya foto quieres colocar. ESC cancela.",
            level=Qgis.Info, duration=5)

    def _entidad_con_foto_en(self, point):
        """Entidad con foto más cercana al clic (point en el SRC del lienzo) entre las capas
        visibles. Devuelve (capa, entidad, [fotos existentes]) o None."""
        map_crs = self._map_crs()
        tol = max(self.canvas.mapUnitsPerPixel(), 1e-9) * 10
        root = QgsProject.instance().layerTreeRoot()
        propias = (LAYER_ANEJO_PRE, LAYER_MANUAL)
        mejor = None
        for lyr in QgsProject.instance().mapLayers().values():
            if (lyr.type() != QgsMapLayer.VectorLayer or not lyr.isValid() or lyr.name() in propias
                    or _es_capa_informe(lyr.name())):
                continue
            nodo = root.findLayer(lyr.id())
            if nodo is not None and not nodo.isVisible():
                continue
            try:
                tr = QgsCoordinateTransform(map_crs, lyr.crs(), QgsProject.instance())
                p_lyr = QgsGeometry.fromPointXY(tr.transform(QgsPointXY(point)))
                rect = tr.transformBoundingBox(
                    QgsRectangle(point.x() - tol, point.y() - tol, point.x() + tol, point.y() + tol))
            except Exception:
                continue
            src_path = (lyr.source() or "").split("|")[0]
            for feat in lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
                geom = feat.geometry()
                if geom is None or geom.isEmpty():
                    continue
                fotos = [f for f in self._photo_paths(feat, lyr, src_path) if os.path.exists(f)]
                if not fotos:
                    continue
                d = geom.distance(p_lyr)
                if mejor is None or d < mejor[0]:
                    mejor = (d, lyr, feat, fotos)
        return None if mejor is None else mejor[1:]

    def _seleccion_lienzo_clic(self, point):
        hallada = self._entidad_con_foto_en(point)
        if hallada is None:
            self.iface.messageBar().pushMessage(
                "Fotos", "No hay ninguna entidad con foto en ese punto. Prueba de nuevo o pulsa ESC.",
                level=Qgis.Warning, duration=4)
            return
        lyr, feat, fotos = hallada
        self._origen_lienzo = {"layer_id": lyr.id(), "fid": feat.id(), "movida": False}
        self.pending_manual = list(fotos)
        self.manual_index = 0
        self.manual_folder_mode = len(fotos) > 1
        self._fill_list(self.list_manual, self.pending_manual, 0)
        self.status_callback(
            f"ℹ Georref Fotos: {len(fotos)} fotografía(s) de la capa '{lyr.name()}' elegidas en el lienzo.")
        self.cancel_placement(silent=True)
        self._preview_current_manual_photo(allow_next=self.manual_folder_mode)

    def _rearmar_seleccion_lienzo(self):
        if getattr(self, "_pick_continuo", False):
            self._armar_seleccion_lienzo()

    def _actualizar_gps_foto_original(self, photo_path, point, point_crs):
        """Graba en la foto original las coordenadas donde se ha colocado (EXIF GPS, WGS84)."""
        nombre = os.path.basename(photo_path)
        try:
            tr = QgsCoordinateTransform(point_crs, QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance())
            p = tr.transform(QgsPointXY(point))
            ok = self._escribir_gps_original(photo_path, p.x(), p.y())
        except Exception as exc:
            ok = False
            log_message(f"No se pudo actualizar el GPS de {nombre}: {exc}")
        if ok:
            self.status_callback(f"✔ Georref Fotos: coordenadas actualizadas en la foto original {nombre}.")
        else:
            self.status_callback(f"⚠ Georref Fotos: no se pudieron escribir las coordenadas en la foto original {nombre} "
                                 f"(¿solo lectura, no es JPG o está abierta en otro programa?).")
        return ok

    def _escribir_gps_original(self, path, lon, lat):
        """EXIF GPS en la propia foto (JPG). Conserva la fecha de modificación del fichero, de la que
        puede depender la fecha mostrada en fotos sin fecha EXIF."""
        if os.path.splitext(path)[1].lower() not in (".jpg", ".jpeg") or not os.access(path, os.W_OK):
            return False
        st = os.stat(path)
        ok = False
        try:
            ok = bool(self._write_gps_exif_optional(path, lon, lat))
            if not ok:
                from PIL import Image
                im = Image.open(path)
                im.load()
                if im.format != "JPEG":
                    return False
                exif = im.getexif()
                gps = dict(exif.get_ifd(0x8825))

                def dms(v):
                    v = abs(float(v))
                    d = int(v)
                    m = int((v - d) * 60)
                    return (float(d), float(m), round((v - d - m / 60.0) * 3600.0, 4))
                gps[1] = "N" if lat >= 0 else "S"
                gps[2] = dms(lat)
                gps[3] = "E" if lon >= 0 else "W"
                gps[4] = dms(lon)
                exif[0x8825] = gps
                tmp = path + ".obra_tmp"
                kwargs = {"exif": exif, "quality": "keep"}
                if im.info.get("icc_profile"):
                    kwargs["icc_profile"] = im.info["icc_profile"]
                im.save(tmp, "JPEG", **kwargs)
                im.close()
                os.replace(tmp, path)
                ok = True
        except Exception as exc:
            log_message(f"No se pudo escribir el GPS en {path}: {exc}")
            ok = False
            try:
                if os.path.exists(path + ".obra_tmp"):
                    os.remove(path + ".obra_tmp")
            except Exception:
                pass
        finally:
            try:
                os.utime(path, (st.st_atime, st.st_mtime))
            except Exception:
                pass
        return ok

    # V1.7.25: alto de una lista de N filas, a prueba de hojas de estilo con relleno grande:
    # se toma el mayor entre lo que mide Qt y la altura de letra más un margen generoso
    def _alto_fila(self, lista):
        n = lista.model().rowCount() if lista.model() is not None else 0
        medida = lista.sizeHintForRow(0) if n else 0
        return max(medida, lista.fontMetrics().height() + 14)

    def _ajustar_alto_arbol(self):
        n = self.tree.topLevelItemCount()
        filas = min(max(n, 3), 8)
        cab = max(self.tree.header().sizeHint().height(), self.tree.fontMetrics().height() + 14)
        self.tree.setFixedHeight(cab + self._alto_fila(self.tree) * filas + 2 * self.tree.frameWidth() + 6)

    def _ajustar_alto_lista(self, lista, minimo=3, maximo=6):
        filas = min(max(lista.count(), minimo), maximo)
        lista.setFixedHeight(self._alto_fila(lista) * filas + 2 * lista.frameWidth() + 6)

    def _ajustar_listas(self):
        self._ajustar_alto_arbol()
        self._ajustar_alto_lista(self.list_manual)
        self.list_anejo.setMinimumHeight(self._alto_fila(self.list_anejo) * 3 + 2 * self.list_anejo.frameWidth() + 6)

    def showEvent(self, event):
        super().showEvent(event)
        self._ajustar_listas()
        self._refrescar_informes()

    # ------------------------------------------------------------------ GeoPackage discovery
    def refresh_loaded_gpkgs(self):
        self.tree.clear()
        self.gpkgs = self._find_loaded_gpkgs()
        if not self.gpkgs:
            self._ajustar_alto_arbol()
            self.status_callback("⚠ Fotos: no hay GeoPackage cargados en el lienzo.")
            self._refresh_status_labels()
            return
        for gpkg_path, info in self.gpkgs.items():
            op_layers = info.get("operational_layers", [])
            state = "OK" if op_layers else "Sin capas Puntos/Líneas/Polígonos"
            item = QTreeWidgetItem(["", os.path.basename(gpkg_path), str(len(op_layers)), state])
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(0, Qt.Checked if op_layers else Qt.Unchecked)
            item.setData(0, Qt.UserRole, gpkg_path)
            self.tree.addTopLevelItem(item)
        for i in range(self.tree.columnCount()):
            self.tree.resizeColumnToContents(i)
        self._ajustar_alto_arbol()
        self.status_callback(f"ℹ Fotos: {len(self.gpkgs)} GeoPackage cargados detectados.")
        self._refresh_status_labels()

    def _find_loaded_gpkgs(self):
        gpkgs = OrderedDict()
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() != QgsMapLayer.VectorLayer or not layer.isValid():
                continue
            source = layer.source() or ""
            if ".gpkg" not in source.lower():
                continue
            gpkg_path = source.split("|")[0]
            if not gpkg_path.lower().endswith(".gpkg"):
                continue
            if gpkg_path not in gpkgs:
                gpkgs[gpkg_path] = {"layers": [], "operational_layers": []}
            gpkgs[gpkg_path]["layers"].append(layer)
            if self._is_operational_layer(layer):
                gpkgs[gpkg_path]["operational_layers"].append(layer)
        return gpkgs

    def _is_operational_layer(self, layer):
        name = layer.name().lower().replace("í", "i")
        return any(name.endswith(s.replace("í", "i")) or name == s.replace("_", "") for s in OP_SUFFIXES)

    def _selected_gpkg_paths(self):
        paths = []
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if item.checkState(0) == Qt.Checked:
                paths.append(item.data(0, Qt.UserRole))
        return paths

    def _set_all_checked(self, state):
        for i in range(self.tree.topLevelItemCount()):
            self.tree.topLevelItem(i).setCheckState(0, state)

    def _primary_gpkg_path(self):
        # V201: se comprueba contra lo que hay cargado AHORA en el proyecto
        # (la lista de la pestaña puede haberse quedado antigua).
        live = self._find_loaded_gpkgs()
        paths = [p for p in self._selected_gpkg_paths() if p in live] or list(live.keys())
        return paths[0] if paths else None

    # ------------------------------------------------------------------ Block 1: export ambitos photos
    def export_ambito_photos(self):
        """Bloque 1 (V1.7.22): escribe en cada foto asociada a una entidad las coordenadas (EXIF GPS,
        WGS84) del centroide de esa entidad. Ya no exporta copias ni crea manifiesto: la foto de
        origen es la que se actualiza."""
        paths = self._selected_gpkg_paths()
        if not paths:
            QMessageBox.warning(self, "Fotos", "Selecciona al menos un GeoPackage cargado.")
            return
        # V201: capas releídas del proyecto en este momento; las guardadas al
        # abrir la pestaña pueden haberse eliminado (recarga de la obra).
        self.gpkgs = self._find_loaded_gpkgs()
        trabajo, errores, repetidas, entidades = {}, [], 0, 0
        for gpkg_path in paths:
            for layer in self.gpkgs.get(gpkg_path, {}).get("operational_layers", []):
                for src_feat in layer.getFeatures():
                    geom = src_feat.geometry()
                    centroid = self._safe_centroid(geom) if geom else None
                    if centroid is None:
                        continue
                    pt = centroid.asPoint()
                    lon, lat = self._to_lonlat(layer.crs(), pt.x(), pt.y())
                    if lon is None or lat is None:
                        continue
                    fotos = self._photo_paths(src_feat, layer, gpkg_path)
                    if fotos:
                        entidades += 1
                    for photo in fotos:
                        if not os.path.exists(photo):
                            errores.append(f"No existe imagen: {photo}")
                            continue
                        clave = os.path.normcase(os.path.abspath(photo))
                        if clave in trabajo:
                            # una misma foto asociada a varias entidades: se respeta la primera
                            if abs(trabajo[clave][1] - lon) > 2e-6 or abs(trabajo[clave][2] - lat) > 2e-6:
                                repetidas += 1
                            continue
                        trabajo[clave] = (photo, lon, lat)
        if not trabajo:
            msg = "No se han encontrado fotografías asociadas a las entidades de los GeoPackage elegidos."
            if errores:
                msg += "\n\nAvisos:\n" + "\n".join(errores[:15])
            QMessageBox.information(self, "Georref fotos ámbitos", msg)
            return
        no_jpg = [v[0] for v in trabajo.values() if os.path.splitext(v[0])[1].lower() not in (".jpg", ".jpeg")]
        resp = QMessageBox.question(
            self,
            "Georref fotos ámbitos",
            f"Se grabarán las coordenadas del centroide de cada entidad en {len(trabajo) - len(no_jpg)} fotografía(s) "
            f"JPG ORIGINALES (de {entidades} entidad(es)); no se hacen copias.\n\n¿Continuar?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if resp != QMessageBox.Yes:
            return
        escritas = ya_correctas = fallidas = 0
        for photo, lon, lat in trabajo.values():
            if os.path.splitext(photo)[1].lower() not in (".jpg", ".jpeg"):
                continue
            actual = self._read_photo_gps_lonlat(photo)
            if actual and abs(actual[0] - lon) <= 2e-6 and abs(actual[1] - lat) <= 2e-6:
                ya_correctas += 1
                continue
            if self._escribir_gps_original(photo, lon, lat):
                escritas += 1
            else:
                fallidas += 1
                errores.append(f"No se pudo escribir en {photo} (¿solo lectura o abierta en otro programa?)")
        msg = f"Coordenadas escritas en {escritas} fotografía(s)."
        if ya_correctas:
            msg += f"\nYa tenían esas coordenadas: {ya_correctas}."
        if no_jpg:
            msg += f"\nNo son JPG y no se han modificado: {len(no_jpg)}."
            errores.extend(f"No es JPG, sin modificar: {p}" for p in no_jpg)
        if repetidas:
            msg += f"\nFotos asociadas a varias entidades con ubicaciones distintas (se usó la primera): {repetidas}."
        if errores:
            msg += "\n\nAvisos:\n" + "\n".join(errores[:15])
        QMessageBox.information(self, "Georref fotos ámbitos", msg)
        self.status_callback(f"✔ Georref fotos ámbitos: coordenadas escritas en {escritas} foto(s); "
                             f"{ya_correctas} ya correctas; {len(no_jpg)} no JPG; {fallidas} con error.")

    # ------------------------------------------------------------------ Blocks 2/3: placement
    def select_manual_single_with_preview(self):
        """Sección 2: selecciona una imagen, muestra vista previa y prepara el clic en canvas."""
        photo = self._select_single_image_file()
        if not photo:
            return
        self._origen_lienzo = None
        self.pending_manual = [photo]
        self.manual_index = 0
        self.manual_folder_mode = False
        self._fill_list(self.list_manual, self.pending_manual, 0)
        self._preview_current_manual_photo(allow_next=False)

    def select_manual_folder_with_preview(self):
        """Sección 2: selecciona carpeta y recorre imágenes con vista previa, colocar o siguiente."""
        files = self._select_image_files_from_folder()
        if not files:
            return
        self._origen_lienzo = None
        self.pending_manual = files
        self.manual_index = 0
        self.manual_folder_mode = True
        self._fill_list(self.list_manual, self.pending_manual, 0)
        self.status_callback(f"ℹ Georref Fotos: {len(files)} fotografía(s) detectada(s) en la carpeta. Revisa la lista y elimina las descartadas antes de iniciar.")
        self.iface.messageBar().pushMessage(
            "Georref Fotos",
            "Carpeta cargada. Selecciona en la lista las imágenes que quieras descartar y pulsa 'Eliminar seleccionadas de la cola'. Después inicia la colocación.",
            level=Qgis.Info,
            duration=7,
        )


    def start_manual_folder_preview(self):
        """Inicia o continúa el recorrido de la cola manual tras revisar/eliminar fotos."""
        if not self.pending_manual:
            QMessageBox.warning(self, "Georref Fotos", "No hay fotografías cargadas en la cola.")
            return
        if self.manual_index >= len(self.pending_manual):
            QMessageBox.information(self, "Georref Fotos", "No quedan más fotografías pendientes en la cola.")
            return
        self._preview_current_manual_photo(allow_next=self.manual_folder_mode)

    def remove_selected_manual_photos(self):
        """Elimina de la cola las imágenes seleccionadas antes de su inserción en el lienzo."""
        if not self.pending_manual:
            QMessageBox.information(self, "Georref Fotos", "No hay fotografías cargadas en la cola.")
            return

        selected_rows = sorted({idx.row() for idx in self.list_manual.selectedIndexes()}, reverse=True)
        if not selected_rows:
            row = self.list_manual.currentRow()
            if row >= 0:
                selected_rows = [row]

        if not selected_rows:
            QMessageBox.information(self, "Georref Fotos", "Selecciona una o varias fotografías de la lista para eliminarlas de la cola.")
            return

        locked_rows = [r for r in selected_rows if r < self.manual_index]
        rows_to_remove = [r for r in selected_rows if r >= self.manual_index and r < len(self.pending_manual)]

        if locked_rows and not rows_to_remove:
            QMessageBox.warning(
                self,
                "Georref Fotos",
                "Las fotografías ya colocadas no se eliminan desde la cola (sus coordenadas ya están grabadas en la foto original).",
            )
            return

        if not rows_to_remove:
            return

        names = [os.path.basename(self.pending_manual[r]) for r in sorted(rows_to_remove)]
        reply = QMessageBox.question(
            self,
            "Eliminar fotografías de la cola",
            "Se eliminarán de la cola y no se georreferenciarán/exportarán estas fotografías:\n\n"
            + "\n".join(names[:20])
            + ("\n..." if len(names) > 20 else ""),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return

        removing_current = self.manual_index in rows_to_remove
        for r in rows_to_remove:
            del self.pending_manual[r]

        if self.manual_index > len(self.pending_manual):
            self.manual_index = len(self.pending_manual)
        if removing_current:
            self.current_manual_meta = None
            self.cancel_placement(silent=True)

        self._fill_list(self.list_manual, self.pending_manual, self.manual_index)
        remaining = max(0, len(self.pending_manual) - self.manual_index)
        self.status_callback(f"ℹ Georref Fotos: {len(rows_to_remove)} fotografía(s) eliminada(s) de la cola. Pendientes: {remaining}.")
        if locked_rows:
            QMessageBox.information(
                self,
                "Georref Fotos",
                "Se han eliminado solo las fotografías pendientes. Las ya colocadas conservan sus coordenadas.",
            )

    def select_manual_photos(self, from_folder=False):
        """Compatibilidad con llamadas antiguas."""
        if from_folder:
            self.select_manual_folder_with_preview()
        else:
            self.select_manual_single_with_preview()

    # ------------------------------------------------------------------ V1.7.30 · informes
    def _carpeta_informes(self):
        """Carpeta donde se guardan los GeoPackage de fotos de los informes (junto a la obra)."""
        path = self._project_photo_gpkg_path(LAYER_ANEJO)
        return os.path.dirname(path) if path else None

    def _informes_disponibles(self):
        """Códigos de informe con capa cargada o con GeoPackage junto a la obra.
        Devuelve una lista ordenada: IS-01, IS-02, ..., IF y, al final, "" si existe la
        capa antigua puntos_informe sin código."""
        codes = set()
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.type() == QgsMapLayer.VectorLayer:
                code = _codigo_de_capa(lyr.name())
                if code is not None:
                    codes.add(code)
        folder = self._carpeta_informes()
        if folder and os.path.isdir(folder):
            try:
                for name in os.listdir(folder):
                    base, ext = os.path.splitext(name)
                    if ext.lower() == ".gpkg":
                        code = _codigo_de_capa(base)
                        if code is not None:
                            codes.add(code)
            except Exception:
                pass

        def orden(c):
            if c.startswith("IS-"):
                return (0, c)
            if c == "IF":
                return (1, c)
            return (2, c)
        return sorted(codes, key=orden)

    def _refrescar_informes(self, seleccionar=None):
        if not hasattr(self, "cmb_informe"):
            return
        codes = self._informes_disponibles()
        actual = seleccionar if seleccionar is not None else self.informe_actual
        if seleccionar is None and actual is not None and actual not in codes:
            # El informe elegido aún no tiene capa (recién creado): se mantiene en la lista.
            codes.append(actual)
        self.cmb_informe.blockSignals(True)
        try:
            self.cmb_informe.clear()
            if not codes:
                self.cmb_informe.addItem("— sin informes: pulsa «Nuevo informe…» —", None)
            for code in codes:
                self.cmb_informe.addItem(_texto_informe(code), code)
            if actual is None and codes:
                # Por defecto, el informe más reciente (el último semestral o el final).
                con_codigo = [c for c in codes if c]
                actual = con_codigo[-1] if con_codigo else codes[0]
            idx = self.cmb_informe.findData(actual) if actual is not None else -1
            self.cmb_informe.setCurrentIndex(max(idx, 0))
        finally:
            self.cmb_informe.blockSignals(False)
        nuevo = self.cmb_informe.currentData()
        if nuevo != self.informe_actual:
            self._cambiar_informe(nuevo)
        else:
            self._refresh_status_labels()

    def _on_informe_cambiado(self, _index):
        self._cambiar_informe(self.cmb_informe.currentData())

    def _cambiar_informe(self, code):
        if code == self.informe_actual:
            return
        if self.placement_mode == "anejo":
            self.cancel_placement(silent=True)
        self.informe_actual = code
        self.pending_anejo = []
        self.anejo_index = 0
        self.current_anejo_meta = None
        self._fill_list(self.list_anejo, [], 0)
        layer = self._capa_informe_existente()
        if layer is not None:
            try:
                self.iface.setActiveLayer(layer)
            except Exception:
                pass
        self._refresh_status_labels()

    def _anejo_layer_name(self):
        return _nombre_capa_informe(self.informe_actual or "")

    def _capa_informe_existente(self, cargar=True):
        """Capa del informe activo si está cargada o si existe su GeoPackage (se carga).
        No crea capas nuevas."""
        if self.informe_actual is None:
            return None
        name = self._anejo_layer_name()
        layer = self._find_layer(name)
        if layer is None and cargar:
            layer = self._load_existing_photo_layer(name)
        return layer

    def _exigir_informe(self):
        """Asegura que hay un informe elegido; si no hay ninguno, ofrece crearlo."""
        if self.informe_actual is not None:
            return True
        QMessageBox.information(self, "Anejo fotográfico",
                                "Primero elige el informe al que van las fotos o crea uno con «Nuevo informe…».")
        return self._nuevo_informe()

    def _nuevo_informe(self):
        existentes = set(self._informes_disponibles())
        nums = [int(c.split("-")[1]) for c in existentes if c.startswith("IS-")]
        siguiente = f"IS-{(max(nums) + 1 if nums else 1):02d}"
        opciones = [f"{siguiente} · Informe semestral {int(siguiente[3:])}"]
        if "IF" not in existentes:
            opciones.append("IF · Informe final")
        opciones.append("Otro informe semestral (escribir el código IS-NN)…")
        item, ok = QInputDialog.getItem(self, "Nuevo informe", "Informe para el que se van a añadir fotos:",
                                        opciones, 0, False)
        if not ok or not item:
            return False
        if item.startswith("Otro"):
            text, ok = QInputDialog.getText(self, "Nuevo informe", "Código del informe semestral (p. ej. IS-03):")
            if not ok:
                return False
            code = str(text or "").strip().upper().replace("_", "-").replace(" ", "")
            m = re.match(r"^IS-?(\d{1,2})$", code)
            if not m:
                QMessageBox.warning(self, "Nuevo informe", "El código debe ser IS- seguido de un número (IS-01 … IS-99).")
                return False
            code = f"IS-{int(m.group(1)):02d}"
        else:
            code = item.split(" ", 1)[0]
        if not INFORME_CODE_RE.match(code):
            return False
        if code in existentes:
            QMessageBox.information(self, "Nuevo informe", f"El informe {code} ya existe; se selecciona.")
        self.informe_actual = None  # fuerza el cambio
        self._refrescar_informes(seleccionar=code)
        if self.cmb_informe.findData(code) < 0:
            self.cmb_informe.addItem(_texto_informe(code), code)
            self.cmb_informe.setCurrentIndex(self.cmb_informe.findData(code))
        self._cambiar_informe(code)
        self.status_callback(f"ℹ Anejo fotográfico: informe activo {code}. La capa {self._anejo_layer_name()} "
                             "se crea al añadir la primera foto.")
        return True

    def _rutas_en_informe(self, layer):
        """Rutas (normalizadas) de las fotos que ya están en la capa del informe."""
        rutas = set()
        if layer is None or not layer.isValid() or FIELD_PATH not in [f.name() for f in layer.fields()]:
            return rutas
        for feat in layer.getFeatures():
            p = str(feat[FIELD_PATH] or "").strip()
            if p:
                rutas.add(os.path.normcase(os.path.abspath(p)))
        return rutas

    # ------------------------------------------------------------------ V1.7.30 · cola del anejo
    def select_anejo_photos_from_folder(self):
        if not self._exigir_informe():
            return
        files = self._select_image_files_from_folder(prefijo_informe=self.informe_actual or "IF", recursive=True)
        if files:
            self._iniciar_cola_anejo(files)

    def select_anejo_single_photo(self):
        if not self._exigir_informe():
            return
        photo = self._select_single_image_file()
        if not photo:
            return
        self._iniciar_cola_anejo([photo])

    def _iniciar_cola_anejo(self, files):
        """Prepara la cola: omite las fotos que ya están en el informe (así, al volver a
        elegir la misma carpeta se continúa por donde se dejó) y la recorre con vista previa."""
        layer = self._capa_informe_existente()
        ya = self._rutas_en_informe(layer)
        nuevas = [f for f in files if os.path.normcase(os.path.abspath(f)) not in ya]
        omitidas = len(files) - len(nuevas)
        if not nuevas:
            QMessageBox.information(self, "Anejo fotográfico",
                                    f"Las {len(files)} foto(s) elegidas ya están en el informe {self.informe_actual or ''}.".replace("  ", " "))
            return
        if omitidas:
            self.iface.messageBar().pushMessage(
                "Fotos", f"{omitidas} foto(s) ya estaban en el informe y se omiten. Quedan {len(nuevas)}.",
                level=Qgis.Info, duration=6)
        self.cancel_placement(silent=True)
        self.pending_anejo = nuevas
        self.anejo_index = 0
        self.current_anejo_meta = None
        self._fecha_lote = None
        self._fecha_sugerida = ""
        self._gps_auto = False
        self._fill_list(self.list_anejo, nuevas, 0)
        self.status_callback(f"ℹ Anejo fotográfico ({self.informe_actual or 'puntos_informe'}): {len(nuevas)} foto(s) en cola.")
        self._procesar_cola_anejo()

    def _procesar_cola_anejo(self):
        """Muestra la vista previa de la foto actual de la cola y actúa según el botón."""
        total = len(self.pending_anejo)
        while self.anejo_index < total:
            idx = self.anejo_index
            photo = self.pending_anejo[idx]
            self._fill_list(self.list_anejo, self.pending_anejo, idx)
            gps = self._read_photo_gps_lonlat(photo)
            detected_date = self._photo_date_for_display(photo)

            if self._gps_auto and gps is not None:
                if detected_date:
                    meta = {"photo": photo, "fecha_foto": detected_date, "estampar_fecha": False, "descripcion": ""}
                else:
                    date_meta = self._ensure_anejo_photo_date(photo)
                    if date_meta is None:
                        self._detener_cola()
                        return
                    meta = {"photo": photo, "fecha_foto": date_meta[0], "estampar_fecha": date_meta[1], "descripcion": ""}
                if self._insert_anejo_photo_at_own_coordinates(photo, meta, gps=gps):
                    self.anejo_index += 1
                    continue
                self._detener_cola()
                return

            dlg = AnejoPhotoPreviewDialog(
                photo, parent=self, detected_date=detected_date,
                position_text=f"Foto {idx + 1} de {total}" if total > 1 else "",
                allow_next=total > 1, has_gps=gps is not None,
                suggested_date=self._fecha_lote or self._fecha_sugerida,
                informe_text=self.informe_actual or "puntos_informe",
            )
            dlg.exec_()
            action = dlg.action
            stamp_checked = bool(dlg.stamp_date())
            selected_date = dlg.selected_date()
            selected_desc = dlg.selected_desc()
            gps_rest = dlg.gps_rest()
            dlg.deleteLater()
            dlg = None

            if action == AnejoPhotoPreviewDialog.CANCEL:
                self._detener_cola()
                return
            if action == AnejoPhotoPreviewDialog.NEXT:
                self.anejo_index += 1
                continue

            fecha_foto = detected_date or ""
            if stamp_checked:
                fecha_foto = self._normalize_photo_date(selected_date)
                if not fecha_foto:
                    QMessageBox.warning(
                        self, "Fecha no válida",
                        "Para estampar la fecha debes indicar un valor con formato DD/MM/AAAA HH:MM. Ejemplo: 10/12/2025 11:10",
                    )
                    continue  # se vuelve a mostrar la misma foto
                if not detected_date:
                    self._fecha_sugerida = fecha_foto
            meta = {"photo": photo, "fecha_foto": fecha_foto, "estampar_fecha": stamp_checked,
                    "descripcion": selected_desc}
            if gps_rest:
                self._gps_auto = True

            if action == AnejoPhotoPreviewDialog.GPS:
                if self._insert_anejo_photo_at_own_coordinates(photo, meta, gps=gps):
                    self.anejo_index += 1
                continue
            if action == AnejoPhotoPreviewDialog.PLACE:
                self.current_anejo_meta = meta
                self.start_placement("anejo")
                return  # _add_photo_point continúa la cola después del clic
        self._terminar_cola_anejo()

    def _detener_cola(self):
        self.cancel_placement(silent=True)
        quedan = len(self.pending_anejo) - self.anejo_index
        self.current_anejo_meta = None
        self._refresh_status_labels()
        if quedan > 0:
            self.iface.messageBar().pushMessage(
                "Fotos", f"Cola detenida: quedan {quedan} foto(s). Vuelve a elegir la carpeta para seguir "
                "(las ya colocadas se omiten).", level=Qgis.Warning, duration=8)

    def _terminar_cola_anejo(self):
        self.cancel_placement(silent=True)
        colocadas = self.anejo_index
        self.current_anejo_meta = None
        self.pending_anejo = []
        self.anejo_index = 0
        self._fill_list(self.list_anejo, [], 0)
        self._refresh_status_labels()
        if colocadas:
            self.iface.messageBar().pushMessage(
                "Fotos", f"Cola terminada: fotos revisadas en el informe {self.informe_actual or 'puntos_informe'}.",
                level=Qgis.Success, duration=5)

    def import_anejo_photos_from_selection(self):
        """Anejo fotográfico: importa fotos ya cargadas como atributo en capas vectoriales
        (p. ej. un shapefile) usando las entidades seleccionadas directamente en el lienzo.
        V1.7.18: selección múltiple, de varias entidades y de varias capas a la vez (si no hay
        nada seleccionado en ninguna capa, se avisa). Cada foto encontrada se añade a
        puntos_informe en la ubicación (centroide) de su entidad de origen, sin pinchar en el lienzo.
        V1.7.30: va a la capa del informe elegido y omite las fotos que ya están en él."""
        if not self._exigir_informe():
            return
        propias = (LAYER_ANEJO_PRE, LAYER_MANUAL)
        fuentes = []
        for lyr in QgsProject.instance().mapLayers().values():
            if (lyr.type() != QgsMapLayer.VectorLayer or not lyr.isValid() or lyr.name() in propias
                    or _es_capa_informe(lyr.name())):
                continue
            if lyr.selectedFeatureCount() > 0:
                fuentes.append((lyr, list(lyr.getSelectedFeatures())))
        if not fuentes:
            QMessageBox.warning(
                self,
                "Anejo fotográfico",
                "No hay entidades seleccionadas en el lienzo. Selecciona (una o varias, en una o "
                "varias capas) las entidades que tengan fotos a importar.",
            )
            return
        if len(fuentes) > 1:
            detalle = "\n".join(f"  · {l.name()}: {len(f)} entidad(es)" for l, f in fuentes)
            resp = QMessageBox.question(
                self,
                "Anejo fotográfico",
                "Hay entidades seleccionadas en varias capas:\n\n" + detalle + "\n\n¿Importar las fotos de todas ellas?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes,
            )
            if resp != QMessageBox.Yes:
                return

        anejo_layer = self.ensure_point_layer(self._anejo_layer_name(), save_to_gpkg=False)
        if anejo_layer is None or not anejo_layer.isValid():
            QMessageBox.critical(self, "Anejo fotográfico", f"No se pudo crear/activar la capa {self._anejo_layer_name()}.")
            return

        added = 0
        skipped_no_photo = 0
        ya_en_informe = 0
        missing = []
        vistos = set()
        rutas_previas = self._rutas_en_informe(anejo_layer)
        self._fecha_lote = None
        for src_layer, feats in fuentes:
            src_path = (src_layer.source() or "").split("|")[0]
            transform = None
            if src_layer.crs() != anejo_layer.crs():
                try:
                    transform = QgsCoordinateTransform(src_layer.crs(), anejo_layer.crs(), QgsProject.instance())
                except Exception:
                    transform = None
            for feat in feats:
                geom = feat.geometry()
                centroid = self._safe_centroid(geom) if geom else None
                if centroid is None:
                    continue
                pt = centroid.asPoint()
                if transform is not None:
                    try:
                        pt = transform.transform(QgsPointXY(pt))
                    except Exception:
                        pass
                photos = self._photo_paths(feat, src_layer, src_path)
                if not photos:
                    skipped_no_photo += 1
                    continue
                for photo in photos:
                    if not os.path.exists(photo):
                        missing.append(photo)
                        continue
                    ruta_norm = os.path.normcase(os.path.abspath(photo))
                    if ruta_norm in rutas_previas:
                        ya_en_informe += 1
                        continue
                    clave = (ruta_norm, round(pt.x(), 3), round(pt.y(), 3))
                    if clave in vistos:
                        continue
                    vistos.add(clave)
                    date_meta = self._ensure_anejo_photo_date(photo)
                    if date_meta is None:
                        continue
                    fecha_foto, estampar_fecha = date_meta
                    anejo_layer, _num = self._add_photo_feature_to_layer(
                        anejo_layer, photo, QgsPointXY(pt), report=True, desc="",
                        fecha_foto=fecha_foto, estampar_fecha=estampar_fecha,
                    )
                    if anejo_layer is None:
                        return
                    added += 1

        self._refresh_status_labels()
        msg = f"Fotos importadas al informe {self.informe_actual or 'puntos_informe'}: {added}."
        if ya_en_informe:
            msg += f"\nFotos que ya estaban en el informe (omitidas): {ya_en_informe}."
        if skipped_no_photo:
            msg += f"\nEntidades seleccionadas sin foto detectada: {skipped_no_photo}."
        if missing:
            msg += "\n\nAvisos (ruta de imagen no encontrada):\n" + "\n".join(missing[:15])
        QMessageBox.information(self, "Anejo fotográfico", msg)
        self.status_callback(f"✔ Anejo fotográfico: {added} foto(s) importadas desde selección del lienzo.")

    def _ensure_anejo_photo_date(self, photo_path):
        """Devuelve ``(fecha_foto, estampar_fecha)`` o ``None`` si se cancela.

        Contrato único para los puntos del anejo: si hay fecha legible en EXIF,
        nombre de fichero u OCR visible se conserva como metadato y no se
        reestampa; si no hay fecha, se pide al usuario y se marca para
        estamparla al exportar.
        """
        detected_date = self._photo_date_for_display(photo_path)
        if detected_date:
            return (detected_date, False)
        # V1.7.30: una sola pregunta por tanda si se marca «usar para las demás».
        if self._fecha_lote:
            return (self._fecha_lote, True)
        dlg = FechaLoteDialog(photo_path, default_value=self._fecha_sugerida, parent=self)
        ok = dlg.exec_() == QDialog.Accepted
        fecha_foto = dlg.fecha if ok else ""
        usar_resto = bool(dlg.chk_rest.isChecked())
        dlg.deleteLater()
        if not fecha_foto:
            return None
        self._fecha_sugerida = fecha_foto
        if usar_resto:
            self._fecha_lote = fecha_foto
        return (fecha_foto, True)

    def _confirmar_modificar_originales(self):
        """Una sola vez por sesión: el bloque 2 modifica las fotos originales, no copias."""
        if getattr(self, "_aviso_originales", False):
            return True
        resp = QMessageBox.question(
            self,
            "Georref Fotos",
            "Este bloque graba las coordenadas (y la fecha, si decides estamparla) en las fotografías "
            "ORIGINALES, no en copias. Las que no son JPG (p. ej. PNG) no se tocan: se crea un JPG con el mismo "
            "nombre en la misma carpeta.\n\n¿Continuar?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        self._aviso_originales = (resp == QMessageBox.Yes)
        return self._aviso_originales

    def _preview_current_manual_photo(self, allow_next=False):
        """Muestra la imagen actual. Si se acepta, pide clic; si se pasa, avanza."""
        if self.manual_index >= len(self.pending_manual):
            self.cancel_placement(silent=True)
            self.iface.messageBar().pushMessage("Fotos", "No quedan más imágenes pendientes.", level=Qgis.Info, duration=4)
            self._rearmar_seleccion_lienzo()
            return
        if not self._confirmar_modificar_originales():
            self.cancel_placement(silent=False)
            return
        photo = self.pending_manual[self.manual_index]
        detected_date = self._photo_date_for_display(photo)
        dlg = PhotoPreviewDialog(photo, allow_next=allow_next, parent=self, detected_date=detected_date)
        dlg.exec_()
        # V201: se leen las opciones y se libera el diálogo (guardaba la foto
        # a tamaño completo y se acumulaban al recorrer una carpeta).
        action = dlg.action
        stamp_checked = bool(dlg.chk_stamp_date.isChecked())
        dlg.deleteLater()
        dlg = None
        if action == PhotoPreviewDialog.CANCEL:
            self.cancel_placement(silent=False)
            return
        if action == PhotoPreviewDialog.NEXT:
            self.manual_index += 1
            self._fill_list(self.list_manual, self.pending_manual, self.manual_index)
            self._preview_current_manual_photo(allow_next=allow_next)
            return

        fecha_foto = detected_date or ""
        if stamp_checked:
            fecha_foto = self._ask_photo_date(photo, default_value=fecha_foto, destino="en la foto original")
            if not fecha_foto:
                return
        # V1.7.20: este bloque solo trata ubicación y fecha; no crea capas.
        self.current_manual_meta = {
            "photo": photo,
            "fecha_foto": fecha_foto,
            "estampar_fecha": stamp_checked,
        }
        self.status_callback("ℹ Georref Fotos: imagen validada. Pendiente de pinchar punto en el lienzo.")
        self.start_placement("manual")

    def _select_single_image_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Seleccionar fotografía", "", "Imágenes (*.jpg *.jpeg *.png *.JPG *.JPEG *.PNG)"
        )
        return file_path or ""

    def _select_image_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Seleccionar fotografías", "", "Imágenes (*.jpg *.jpeg *.png *.JPG *.JPEG *.PNG)"
        )
        return list(files or [])

    def _select_image_files_from_folder(self, prefijo_informe=None, recursive=False):
        """Fotos de una carpeta (recursiva si se pide).

        V1.7.30: con prefijo_informe se toman las fotos cuyo nombre empieza por el código del
        informe (IF…, IS-01 / IS01 / IS_01…). Si no hay ninguna, se ofrece usar todas."""
        folder = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta de fotografías", "")
        if not folder:
            return []
        exts = (".jpg", ".jpeg", ".png")
        if recursive:
            iterator = []
            for root, _dirs, names in os.walk(folder):
                for name in names:
                    iterator.append(os.path.join(root, name))
        else:
            iterator = [os.path.join(folder, f) for f in os.listdir(folder)]
        todas = [p for p in sorted(iterator, key=lambda p: os.path.normcase(p))
                 if os.path.basename(p).lower().endswith(exts)]
        if not prefijo_informe:
            return todas
        code = str(prefijo_informe).upper()
        prefijos = (code,) if code == "IF" else (code, code.replace("-", ""), code.replace("-", "_"))
        files = [p for p in todas if os.path.basename(p).upper().startswith(prefijos)]
        if files:
            return files
        if not todas:
            QMessageBox.warning(self, "Anejo fotográfico", "No hay imágenes (JPG/PNG) en la carpeta ni en sus subcarpetas.")
            return []
        resp = QMessageBox.question(
            self, "Anejo fotográfico",
            f"Ninguna imagen de la carpeta empieza por {code}.\n\n"
            f"¿Usar todas las imágenes de la carpeta y sus subcarpetas ({len(todas)})?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
        )
        return todas if resp == QMessageBox.Yes else []

    def _insert_anejo_photo_at_own_coordinates(self, photo_path, meta=None, gps=None):
        """Añade la foto al informe en las coordenadas GPS de su EXIF. Devuelve True si se añadió.
        V1.7.30: ya no vacía la cola (la recorre _procesar_cola_anejo)."""
        lonlat = gps if gps is not None else self._read_photo_gps_lonlat(photo_path)
        if lonlat is None:
            QMessageBox.warning(
                self,
                "Anejo fotográfico",
                "La fotografía no contiene coordenadas GPS EXIF válidas. Usa la opción de pinchar en el lienzo.",
            )
            return False
        lon, lat = lonlat
        layer_name = self._anejo_layer_name()
        layer = self.ensure_point_layer(layer_name, save_to_gpkg=False)
        if layer is None or not layer.isValid():
            QMessageBox.critical(self, "Anejo fotográfico", f"No se pudo crear/activar la capa {layer_name}.")
            return False
        try:
            src = QgsCoordinateReferenceSystem("EPSG:4326")
            tr = QgsCoordinateTransform(src, layer.crs(), QgsProject.instance())
            pt = tr.transform(QgsPointXY(float(lon), float(lat)))
        except Exception:
            pt = QgsPointXY(float(lon), float(lat))
        if meta and meta.get("photo") == photo_path:
            fecha_foto = meta.get("fecha_foto", "") or ""
            estampar_fecha = bool(meta.get("estampar_fecha", False))
            desc = meta.get("descripcion", "") or ""
        else:
            date_meta = self._ensure_anejo_photo_date(photo_path)
            if date_meta is None:
                return False
            fecha_foto, estampar_fecha = date_meta
            desc = ""
        layer, num = self._add_photo_feature_to_layer(layer, photo_path, pt, report=True, desc=desc,
                                                      fecha_foto=fecha_foto, estampar_fecha=estampar_fecha)
        if layer is None:
            return False
        self._refresh_status_labels()
        self.iface.messageBar().pushMessage("Fotos", f"Foto {num} insertada con las coordenadas GPS de la foto.",
                                            level=Qgis.Success, duration=3)
        return True

    def _add_photo_feature_to_layer(self, layer, photo_path, point, report=False, desc="", fecha_foto="",
                                    estampar_fecha=False, point_crs=None):
        # V1.7.16: el punto pinchado viene en el SRC del lienzo (point_crs);
        # se pasa al de la capa. Antes se guardaba sin transformar y, con la
        # capa en otro SRC, la foto quedaba a cientos de km del clic.
        point = QgsPointXY(point)
        if point_crs is not None and point_crs.isValid() and layer.crs().isValid() and point_crs != layer.crs():
            try:
                point = QgsCoordinateTransform(point_crs, layer.crs(), QgsProject.instance()).transform(point)
            except Exception as exc:
                QMessageBox.critical(self, "Fotos", f"No se pudo pasar el punto al sistema de coordenadas de la capa:\n{exc}")
                return None, None
        field_names = [f.name() for f in layer.fields()]
        missing = [n for n in (FIELD_NUM, FIELD_PATH) if n not in field_names]
        if missing:
            # V1.7.16: si no se pudieron añadir los campos de foto (GeoPackage
            # bloqueado o de solo lectura) se avisa en vez de fallar.
            QMessageBox.critical(self, "Fotos", f"La capa {layer.name()} no tiene los campos {', '.join(missing)} "
                                 "y no se pudieron añadir (¿GeoPackage bloqueado o de solo lectura?).")
            return None, None
        num = self._next_number(layer)
        feat = QgsFeature(layer.fields())
        feat.setGeometry(QgsGeometry.fromPointXY(point))
        lon, lat = self._to_lonlat(layer.crs(), point.x(), point.y())
        values = {
            FIELD_NUM: num, FIELD_DESC: desc or "", FIELD_PATH: photo_path,
            FIELD_REPORT: 1 if report else 0, FIELD_DATE: fecha_foto or "",
            FIELD_STAMP_DATE: 1 if estampar_fecha else 0,
            "x": float(point.x()), "y": float(point.y()), "lon": lon, "lat": lat,
        }
        for name, value in values.items():
            if name in field_names:
                feat[name] = value
        was_editing = layer.isEditable()
        if not was_editing and not layer.startEditing():
            QMessageBox.critical(self, "Fotos", "No se pudo iniciar la edición de la capa de fotografías.")
            return None, None

        ok = layer.addFeature(feat)
        if not ok:
            # No hacer rollback si la capa ya estaba en edición: podríamos descartar
            # cambios previos del usuario o de otra herramienta.
            if not was_editing:
                layer.rollBack()
            QMessageBox.critical(self, "Fotos", "No se pudo añadir la fotografía a la capa.")
            return None, None

        if not was_editing:
            if not layer.commitChanges():
                errors = "; ".join(layer.commitErrors()) if hasattr(layer, "commitErrors") else ""
                try:
                    layer.rollBack()
                except Exception:
                    pass
                QMessageBox.critical(self, "Fotos", "No se pudieron guardar los cambios en la capa.\n" + errors)
                return None, None

        layer.updateExtents()
        layer.triggerRepaint()
        if layer.providerType() == "memory":
            saved_layer = self._try_save_layer_to_project_gpkg(layer, layer.name())
            if saved_layer is not None and saved_layer.isValid():
                layer = saved_layer
        self.iface.setActiveLayer(layer)
        return layer, num

    def start_placement(self, mode):
        pending = self.pending_manual if mode == "manual" else self.pending_anejo
        layer_name = LAYER_MANUAL if mode == "manual" else self._anejo_layer_name()
        if not pending:
            QMessageBox.warning(self, "Fotos", "Primero selecciona fotografías.")
            return
        # Evitamos escribir en disco antes del clic: así no bloquea la previsualización
        # ni falla si OGR/QGIS tiene el GeoPackage abierto en modo actualización.
        if mode != "manual":
            layer = self.ensure_point_layer(layer_name, save_to_gpkg=False)
            if layer is None or not layer.isValid():
                QMessageBox.critical(self, "Fotos", f"No se pudo crear/activar la capa {layer_name}.")
                return
        self.cancel_placement(silent=True)
        self.previous_tool = self.canvas.mapTool()
        self.map_tool = PhotoPointMapTool(self.canvas, self._add_photo_point)
        self.placement_mode = mode
        self.canvas.setMapTool(self.map_tool)
        self.iface.messageBar().pushMessage("Fotos", "Haz clic en el lienzo para colocar la fotografía actual. ESC cancela.", level=Qgis.Info, duration=5)

    def cancel_placement(self, silent=False):
        # V1.7.16: la herramienta llama directamente a _add_photo_point (no hay
        # señal que desconectar); se quita del lienzo si sigue activa.
        if self.map_tool and not self.previous_tool:
            try:
                if self.canvas.mapTool() is self.map_tool:
                    self.canvas.unsetMapTool(self.map_tool)
            except Exception:
                pass
        if self.previous_tool:
            self.canvas.setMapTool(self.previous_tool)
        self.map_tool = None
        self.previous_tool = None
        self.placement_mode = None
        if not silent:
            self._pick_continuo = False
            self.iface.messageBar().pushMessage("Fotos", "Colocación cancelada.", level=Qgis.Warning, duration=3)

    def _colocar_foto_manual(self, point):
        """Bloque 2 (V1.7.20): graba en la foto original la fecha estampada (si se pidió) y las
        coordenadas del punto pinchado. No crea capas."""
        idx = self.manual_index
        if idx >= len(self.pending_manual):
            self.cancel_placement(silent=True)
            return
        meta = self.current_manual_meta or {}
        photo_path = meta.get("photo") or self.pending_manual[idx]
        if os.path.splitext(photo_path)[1].lower() not in (".jpg", ".jpeg"):
            # la vista previa ya detectó la fecha (EXIF, nombre u OCR): no se repite la lectura
            fecha_exif = meta["fecha_foto"] if "fecha_foto" in meta else (self._photo_date_for_display(photo_path) or "")
            jpg = self._crear_jpg_desde(photo_path, fecha_exif)
            if jpg:
                self.status_callback(
                    f"ℹ Georref Fotos: {os.path.basename(photo_path)} no es JPG; se ha creado "
                    f"{os.path.basename(jpg)} en la misma carpeta y es el que recibe la ubicación y la fecha.")
                self._actualizar_ruta_origen(photo_path, jpg)
                photo_path = jpg
            else:
                self.status_callback(
                    f"⚠ Georref Fotos: no se pudo crear el JPG de {os.path.basename(photo_path)}; "
                    f"la foto no se ha georreferenciado.")
                self._avanzar_cola_manual()
                return
        nombre = os.path.basename(photo_path)
        if meta.get("estampar_fecha") and meta.get("fecha_foto"):
            if self._estampar_fecha_original(photo_path, meta["fecha_foto"]):
                self.status_callback(f"✔ Georref Fotos: fecha {meta['fecha_foto']} estampada en la foto original {nombre}.")
            else:
                self.status_callback(f"⚠ Georref Fotos: no se pudo estampar la fecha en la foto original {nombre}.")
        self._actualizar_gps_foto_original(photo_path, point, self._map_crs())
        self._mover_entidad_origen(point, self._map_crs())
        self._avanzar_cola_manual()

    # Campos de coordenadas que se actualizan junto con el punto, si existen:
    # (campo X, campo Y, en WGS84). "longitude"/"latitude" los crea el
    # algoritmo de QGIS "Importar fotos geoetiquetadas".
    _CAMPOS_COORD = (("longitude", "latitude", True), ("lon", "lat", True), ("x", "y", False))

    def _mover_entidad_origen(self, point, point_crs):
        """V1.7.28: si la foto se eligió pinchando su entidad en el lienzo y esa entidad es un
        punto, se mueve en su capa al punto donde se ha recolocado la foto (y se actualizan sus
        campos de coordenadas, si los tiene). Solo con la primera foto colocada de la entidad.
        Líneas y polígonos no se tocan."""
        origen = self._origen_lienzo
        if not origen or origen.get("movida"):
            return
        origen["movida"] = True
        lyr = QgsProject.instance().mapLayer(origen["layer_id"])
        if lyr is None or not lyr.isValid():
            self.status_callback("⚠ Georref Fotos: la capa de origen ya no está en el proyecto; no se ha movido el punto.")
            return
        if QgsWkbTypes.geometryType(lyr.wkbType()) != QgsWkbTypes.PointGeometry:
            self.status_callback(
                f"ℹ Georref Fotos: '{lyr.name()}' no es una capa de puntos; su geometría no se modifica.")
            return
        feat = lyr.getFeature(origen["fid"])
        geom = QgsGeometry(feat.geometry()) if feat.isValid() else None
        if geom is None or geom.isEmpty():
            self.status_callback(f"⚠ Georref Fotos: no se encontró la entidad de origen en '{lyr.name()}'.")
            return
        try:
            pt = QgsPointXY(point)
            if point_crs is not None and point_crs.isValid() and lyr.crs().isValid() and point_crs != lyr.crs():
                pt = QgsCoordinateTransform(point_crs, lyr.crs(), QgsProject.instance()).transform(pt)
        except Exception as exc:
            self.status_callback(f"⚠ Georref Fotos: no se pudo pasar el punto al SRC de '{lyr.name()}': {exc}")
            return
        # moveVertex conserva el tipo de geometría (multipunto, Z, M): la altitud
        # que trae "Importar fotos geoetiquetadas" no se pierde.
        if geom.constGet().nCoordinates() != 1:
            self.status_callback(
                f"ℹ Georref Fotos: la entidad de '{lyr.name()}' tiene varios puntos; no se modifica.")
            return
        v = geom.vertexAt(0)
        v.setX(pt.x())
        v.setY(pt.y())
        if not geom.moveVertex(v, 0):
            self.status_callback(f"⚠ Georref Fotos: no se pudo mover la entidad de '{lyr.name()}'.")
            return

        cambios = {}
        names = {f.name().lower(): i for i, f in enumerate(lyr.fields())}
        lonlat = None
        for cx, cy, wgs84 in self._CAMPOS_COORD:
            if cx in names and cy in names:
                if wgs84:
                    if lonlat is None:
                        lonlat = self._to_lonlat(lyr.crs(), pt.x(), pt.y())
                    vx, vy = lonlat
                else:
                    vx, vy = float(pt.x()), float(pt.y())
                if vx is not None and vy is not None:
                    cambios[names[cx]] = vx
                    cambios[names[cy]] = vy

        self._aplicar_cambios_origen(lyr, feat.id(), geom, cambios, "punto movido")

    def _aplicar_cambios_origen(self, lyr, fid, geom, cambios, que):
        """Aplica en la entidad de origen una geometría nueva (o None) y valores de campos
        {índice: valor}. Si la capa no estaba en edición se guarda; si ya lo estaba, el cambio
        queda en su edición (no se guardan ni se descartan los demás cambios del usuario)."""
        was_editing = lyr.isEditable()
        if not was_editing and not lyr.startEditing():
            self.status_callback(
                f"⚠ Georref Fotos: '{lyr.name()}' no se puede editar (¿solo lectura?); {que}: no aplicado.")
            return False
        ok = True
        if geom is not None:
            ok = lyr.changeGeometry(fid, geom)
        for idx, val in cambios.items():
            ok = lyr.changeAttributeValue(fid, idx, val) and ok
        if not ok:
            if not was_editing:
                lyr.rollBack()
            self.status_callback(f"⚠ Georref Fotos: {que}: no se pudo aplicar en '{lyr.name()}'.")
            return False
        if not was_editing:
            if not lyr.commitChanges():
                errors = "; ".join(lyr.commitErrors()) if hasattr(lyr, "commitErrors") else ""
                lyr.rollBack()
                self.status_callback(f"⚠ Georref Fotos: {que}: no se pudo guardar en '{lyr.name()}'. {errors}")
                return False
            self.status_callback(f"✔ Georref Fotos: {que} y guardado en la capa '{lyr.name()}'.")
        else:
            self.status_callback(
                f"✔ Georref Fotos: {que} en la capa '{lyr.name()}' (en edición: guarda los cambios de la capa).")
        lyr.triggerRepaint()
        return True

    def _actualizar_ruta_origen(self, foto_vieja, foto_nueva):
        """V1.7.29: si una foto elegida en el lienzo no era JPG y se ha creado su JPG, la entidad
        de origen pasa a apuntar al JPG: en cada campo de texto cuyo valor termina en el nombre de
        la foto vieja (ruta completa, relativa o solo el nombre, p. ej. "photo" y "filename" de
        «Importar fotos geoetiquetadas») se cambia ese nombre por el del JPG. La carpeta no cambia.
        Vale para puntos, líneas y polígonos."""
        origen = self._origen_lienzo
        if not origen:
            return
        lyr = QgsProject.instance().mapLayer(origen["layer_id"])
        if lyr is None or not lyr.isValid():
            return
        feat = lyr.getFeature(origen["fid"])
        if not feat.isValid():
            return
        viejo = os.path.basename(foto_vieja)
        nuevo = os.path.basename(foto_nueva)
        cambios = {}
        for i, field in enumerate(lyr.fields()):
            val = feat[field.name()]
            if val is None or not isinstance(val, str):
                continue
            txt = val.strip().strip('"').strip("'")
            if txt.lower().endswith(viejo.lower()) and (len(txt) == len(viejo) or txt[-len(viejo) - 1] in "/\\"):
                cambios[i] = txt[:len(txt) - len(viejo)] + nuevo
        if cambios:
            self._aplicar_cambios_origen(lyr, feat.id(), None, cambios, f"ruta de la foto cambiada a {nuevo}")

    def _avanzar_cola_manual(self):
        self.manual_index += 1
        self.current_manual_meta = None
        self._fill_list(self.list_manual, self.pending_manual, self.manual_index)
        remaining = len(self.pending_manual) - self.manual_index
        self.cancel_placement(silent=True)
        if remaining <= 0:
            self.iface.messageBar().pushMessage("Fotos", "Todas las fotografías de la cola están colocadas.", level=Qgis.Success, duration=5)
            self._rearmar_seleccion_lienzo()
        else:
            self.iface.messageBar().pushMessage("Fotos", f"Foto colocada. Quedan {remaining}.", level=Qgis.Success, duration=3)
            if self.manual_folder_mode:
                self._preview_current_manual_photo(allow_next=True)

    def _crear_jpg_desde(self, path, fecha=""):
        """V1.7.21: si la foto no es JPG (p. ej. PNG) no se modifica: se crea un JPG con el mismo nombre
        en la misma carpeta (si ya existe, con sufijo _georref) y es ese JPG el que recibe las
        coordenadas y la fecha. La fecha de modificación se conserva. Devuelve la ruta o ''."""
        try:
            from PIL import Image, ImageOps
            carpeta, nombre = os.path.split(path)
            base = os.path.splitext(nombre)[0]
            destino = os.path.join(carpeta, base + ".jpg")
            n = 0
            while os.path.exists(destino):
                n += 1
                destino = os.path.join(carpeta, f"{base}_georref{'' if n == 1 else '_' + str(n)}.jpg")
            st = os.stat(path)
            with Image.open(path) as im:
                exif = im.getexif()
                im2 = ImageOps.exif_transpose(im)
                if im2.mode in ("RGBA", "LA", "P") and ("transparency" in im2.info or im2.mode in ("RGBA", "LA")):
                    rgba = im2.convert("RGBA")
                    rgb = Image.new("RGB", rgba.size, (255, 255, 255))
                    rgb.paste(rgba, mask=rgba.split()[-1])
                else:
                    rgb = im2.convert("RGB")
                kwargs = {"quality": 95}
                if exif or fecha:
                    exif[0x0112] = 1
                    if fecha:
                        try:
                            dt = datetime.strptime(fecha, "%d/%m/%Y %H:%M").strftime("%Y:%m:%d %H:%M:00")
                            sub = dict(exif.get_ifd(0x8769))
                            sub[0x9003] = dt
                            sub[0x9004] = dt
                            exif[0x8769] = sub
                        except Exception:
                            pass
                    kwargs["exif"] = exif
                rgb.save(destino, "JPEG", **kwargs)
            try:
                os.utime(destino, (st.st_atime, st.st_mtime))
            except Exception:
                pass
            return destino
        except Exception as exc:
            log_message(f"No se pudo crear el JPG de {path}: {exc}")
            return ""

    def _estampar_fecha_original(self, path, fecha):
        """Estampa la fecha en la foto original y la escribe también como fecha EXIF, para que no
        se vuelva a pedir. Conserva la fecha de modificación del fichero."""
        if not os.access(path, os.W_OK):
            return False
        st = os.stat(path)
        try:
            return bool(self._stamp_visible_date(path, fecha, escribir_exif=True))
        finally:
            try:
                os.utime(path, (st.st_atime, st.st_mtime))
            except Exception:
                pass

    def _add_photo_point(self, point, button):
        if button != Qt.LeftButton or self.placement_mode not in ("manual", "anejo"):
            return
        if self.placement_mode == "manual":
            self._colocar_foto_manual(point)
            return
        pending, idx, layer_name = self.pending_anejo, self.anejo_index, self._anejo_layer_name()
        if idx >= len(pending):
            self.cancel_placement(silent=True)
            return
        layer = self.ensure_point_layer(layer_name, save_to_gpkg=False)
        if layer is None or not layer.isValid():
            QMessageBox.critical(self, "Fotos", f"No se pudo crear/activar la capa {layer_name}.")
            return
        photo_path = pending[idx]
        desc = ""
        if self.current_anejo_meta and self.current_anejo_meta.get("photo") == photo_path:
            fecha_foto = self.current_anejo_meta.get("fecha_foto", "") or ""
            estampar_fecha = bool(self.current_anejo_meta.get("estampar_fecha", False))
            desc = self.current_anejo_meta.get("descripcion", "") or ""
        else:
            date_meta = self._ensure_anejo_photo_date(photo_path)
            if date_meta is None:
                return
            fecha_foto, estampar_fecha = date_meta
        map_crs = self._map_crs()
        layer, num = self._add_photo_feature_to_layer(layer, photo_path, point, report=True, desc=desc,
                                                      fecha_foto=fecha_foto, estampar_fecha=estampar_fecha,
                                                      point_crs=map_crs)
        if layer is None:
            return
        self.anejo_index += 1
        self.current_anejo_meta = None
        self._refresh_status_labels()
        self.iface.messageBar().pushMessage("Fotos", f"Foto {num} insertada en {layer_name}.", level=Qgis.Success, duration=3)
        # V1.7.30: la siguiente foto de la cola se muestra con su vista previa.
        QTimer.singleShot(0, self._procesar_cola_anejo)

    def ensure_point_layer(self, layer_name, save_to_gpkg=False):
        layer = self._find_layer(layer_name)
        if layer is not None:
            # V1.7.16: con la capa ya cargada no se vuelve a aplicar su
            # estilo (en cada clic se perdían los cambios de simbología del
            # usuario); solo se garantizan los campos y el visor de la foto.
            self._ensure_photo_fields(layer)
            self._configure_photo_layer(layer, apply_style=False)
            self._refresh_status_labels()
            return layer
        # V201: si la capa no está cargada pero ya existe en su GeoPackage
        # junto a la obra (fotos de días anteriores), se carga esa en vez de
        # crear una vacía en memoria -- al guardarla, la vacía sustituía a la
        # existente y se perdían todos sus puntos.
        layer = self._load_existing_photo_layer(layer_name)
        if layer is not None:
            self.iface.setActiveLayer(layer)
            self._refresh_status_labels()
            return layer
        gpkg_path = self._project_photo_gpkg_path(layer_name) if save_to_gpkg else None
        crs = QgsProject.instance().crs() if QgsProject.instance().crs().isValid() else QgsCoordinateReferenceSystem("EPSG:25830")
        uri = f"Point?crs={crs.authid()}"
        layer = QgsVectorLayer(uri, layer_name, "memory")
        self._ensure_photo_fields(layer)
        self._configure_photo_layer(layer)
        QgsProject.instance().addMapLayer(layer)
        if gpkg_path:
            saved = self._try_save_layer_to_project_gpkg(layer, layer_name)
            if saved is not None and saved.isValid():
                layer = saved
        self.iface.setActiveLayer(layer)
        self._refresh_status_labels()
        return layer

    def _ensure_photo_fields(self, layer):
        existing = [f.name() for f in layer.fields()]
        to_add = []
        # V1.7.16 (A7): tipos de campo válidos en QGIS 3 y QGIS 4 (simple_field
        # usa QMetaType si está disponible).
        for name, kind, length in [
            (FIELD_NUM, "INTEGER", 0), (FIELD_DESC, "TEXT", 254), (FIELD_PATH, "TEXT", 1024),
            (FIELD_REPORT, "INTEGER", 0),
            (FIELD_DATE, "TEXT", 32), (FIELD_STAMP_DATE, "INTEGER", 0),
            ("x", "REAL", 0), ("y", "REAL", 0), ("lon", "REAL", 0), ("lat", "REAL", 0),
        ]:
            if name not in existing:
                field = simple_field(name, kind)
                if length:
                    field.setLength(length)
                to_add.append(field)
        if to_add:
            ok = layer.dataProvider().addAttributes(to_add)
            layer.updateFields()
            if not ok:
                log_message(f"No se pudieron añadir los campos de foto a {layer.name()}.", Qgis.Warning)

    def _configure_photo_layer(self, layer, apply_style=True):
        if not apply_style:
            pass
        elif _es_capa_informe(layer.name()):
            # puntos_informe debe conservar exactamente la simbología corporativa
            # proporcionada por el usuario. No se fuerza ningún etiquetado por código
            # después de cargar el QML para no sobrescribir el estilo.
            self._apply_anejo_style(layer)
        elif layer.name() == LAYER_ANEJO_PRE:
            # Capa previa de revisión: misma base que puntos_informe, pero con
            # etiqueta diferenciada mediante fondo amarillo.
            self._apply_anejo_pre_style(layer)
        else:
            try:
                symbol = QgsMarkerSymbol.createSimple({"name": "circle", "size": "4.5", "outline_width": "0.5"})
                layer.renderer().setSymbol(symbol)
            except Exception:
                pass
        try:
            idx = layer.fields().indexFromName(FIELD_PATH)
            if idx >= 0:
                layer.setEditorWidgetSetup(idx, QgsEditorWidgetSetup("ExternalResource", {
                    "DocumentViewer": 1, "DocumentViewerHeight": 260, "DocumentViewerWidth": 420,
                    "FileWidget": True, "RelativeStorage": 0, "StorageMode": 0,
                }))
        except Exception:
            pass
        layer.triggerRepaint()

    def _apply_anejo_style(self, layer):
        """Aplica el QML oficial de puntos_informe sin modificarlo después."""
        if layer is None or not layer.isValid() or not _es_capa_informe(layer.name()):
            return False
        if not os.path.exists(STYLE_PATH):
            log_message(f"No se encontró el estilo puntos.qml en: {STYLE_PATH}", Qgis.Warning)
            # Fallback mínimo solo si falta el QML empaquetado.
            try:
                symbol = QgsMarkerSymbol.createSimple({"name": "circle", "size": "2", "color": "231,113,72", "outline_width": "0"})
                layer.renderer().setSymbol(symbol)
            except Exception:
                pass
            return False
        try:
            result = layer.loadNamedStyle(STYLE_PATH)
            ok = result[0] if isinstance(result, tuple) else bool(result)
            msg = result[1] if isinstance(result, tuple) and len(result) > 1 else ""
            if not ok:
                log_message(f"No se pudo cargar puntos.qml: {msg}", Qgis.Warning)
                return False
            layer.setLabelsEnabled(True)
            layer.triggerRepaint()
            try:
                self.iface.layerTreeView().refreshLayerSymbology(layer.id())
            except Exception:
                pass
            return True
        except Exception as exc:
            log_message(f"Error cargando puntos.qml: {exc}", Qgis.Warning)
            return False

    def _apply_anejo_style_if_exists(self):
        for layer in list(QgsProject.instance().mapLayers().values()):
            if layer.type() == QgsMapLayer.VectorLayer and _es_capa_informe(layer.name()):
                self._ensure_photo_fields(layer)
                self._apply_anejo_style(layer)

    def _apply_anejo_pre_style_if_exists(self):
        layer = self._find_layer(LAYER_ANEJO_PRE)
        if layer is not None:
            self._ensure_photo_fields(layer)
            self._apply_anejo_pre_style(layer)

    def _apply_anejo_pre_style(self, layer):
        """Aplica estilo de revisión previa: base puntos.qml y etiqueta con fondo amarillo."""
        if layer is None or not layer.isValid() or layer.name() != LAYER_ANEJO_PRE:
            return False
        if os.path.exists(STYLE_PATH):
            try:
                layer.loadNamedStyle(STYLE_PATH)
            except Exception as exc:
                log_message(f"No se pudo cargar puntos.qml en {LAYER_ANEJO_PRE}: {exc}", Qgis.Warning)
        else:
            try:
                symbol = QgsMarkerSymbol.createSimple({"name": "circle", "size": "2", "color": "231,113,72", "outline_width": "0"})
                layer.renderer().setSymbol(symbol)
            except Exception:
                pass
        try:
            labeling = layer.labeling()
            settings = labeling.settings() if labeling is not None and hasattr(labeling, "settings") else QgsPalLayerSettings()
        except Exception:
            settings = QgsPalLayerSettings()
        try:
            settings.fieldName = "concat('Foto: ', \"Nº\")"
            settings.isExpression = True
        except Exception:
            settings.fieldName = FIELD_NUM
        try:
            fmt = settings.format() if hasattr(settings, "format") else QgsTextFormat()
        except Exception:
            fmt = QgsTextFormat()
        try:
            if fmt.font().family() == "":
                fmt.setFont(QFont("Arial"))
            if fmt.size() <= 0:
                fmt.setSize(10)
            bg = QgsTextBackgroundSettings()
            bg.setEnabled(True)
            bg.setFillColor(QColor(255, 255, 0))
            try:
                bg.setStrokeColor(QColor(0, 0, 0))
            except Exception:
                pass
            try:
                bg.setSize(QSizeF(1.2, 0.8))
            except Exception:
                pass
            fmt.setBackground(bg)
            settings.setFormat(fmt)
            layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
            layer.setLabelsEnabled(True)
        except Exception as exc:
            log_message(f"No se pudo configurar etiqueta amarilla en {LAYER_ANEJO_PRE}: {exc}", Qgis.Warning)
        layer.triggerRepaint()
        try:
            self.iface.layerTreeView().refreshLayerSymbology(layer.id())
        except Exception:
            pass
        return True

    def _try_save_layer_to_project_gpkg(self, layer, layer_name):
        """Guarda la capa en GPKG sin romper el flujo si OGR bloquea el archivo."""
        if not self._project_photo_gpkg_path(layer_name):
            if not getattr(self, "_warned_no_folder", False):
                self._warned_no_folder = True
                self.iface.messageBar().pushMessage(
                    "Fotos",
                    f"La capa {layer_name} se queda en memoria: carga la obra o guarda el proyecto para "
                    "que se guarde en un GeoPackage junto a ellos.",
                    level=Qgis.Warning, duration=8,
                )
            return None
        try:
            return self._save_layer_to_project_gpkg(layer, layer_name)
        except Exception as exc:
            log_message(
                f"No se pudo guardar {layer_name} en GeoPackage; se mantiene en memoria: {exc}",
                Qgis.Warning,
            )
            self.iface.messageBar().pushMessage(
                "Fotos",
                f"La capa {layer_name} se ha creado en memoria, pero no se pudo guardar aún en GeoPackage. "
                "Guarda/exporta al finalizar o revisa que el GPKG no esté bloqueado.",
                level=Qgis.Warning,
                duration=7,
            )
            return None

    def _save_layer_to_project_gpkg(self, layer, layer_name):
        gpkg = self._project_photo_gpkg_path(layer_name)
        if not gpkg:
            return None
        folder = os.path.dirname(gpkg)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder, exist_ok=True)

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = layer_name
        options.fileEncoding = "UTF-8"
        # Si el archivo no existe hay que crear el GeoPackage completo; si existe,
        # solo se sobrescribe/actualiza la capa. Usar siempre CreateOrOverwriteLayer
        # sobre un fichero inexistente provoca el error OGR de apertura en modo actualizar.
        if os.path.exists(gpkg):
            # V201: nunca se sustituye una capa de fotos que ya existe en el
            # fichero por una capa en memoria (se perderían sus puntos).
            if layer.providerType() == "memory" and self._gpkg_has_table(gpkg, layer_name):
                raise RuntimeError(
                    f"{os.path.basename(gpkg)} ya contiene la capa {layer_name}; "
                    "cárgala en el proyecto para seguir añadiendo fotos en ella."
                )
            options.actionOnExistingFile = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer
        else:
            options.actionOnExistingFile = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteFile

        err = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer,
            gpkg,
            QgsProject.instance().transformContext(),
            options,
        )
        err_code = err[0] if isinstance(err, tuple) else err
        err_msg = err[1] if isinstance(err, tuple) and len(err) > 1 else ""
        if err_code != QgsVectorFileWriter.WriterError.NoError:
            raise RuntimeError(err_msg or f"Error guardando {layer_name}: {err_code}")

        uri = f"{gpkg}|layername={layer_name}"
        if layer.providerType() == "memory":
            lyr_id = layer.id()
            new_layer = QgsVectorLayer(uri, layer_name, "ogr")
            if new_layer.isValid():
                self._ensure_photo_fields(new_layer)
                self._configure_photo_layer(new_layer)
                QgsProject.instance().removeMapLayer(lyr_id)
                QgsProject.instance().addMapLayer(new_layer)
                return new_layer
        return layer

    def _load_existing_photo_layer(self, layer_name):
        try:
            gpkg = self._project_photo_gpkg_path(layer_name)
        except Exception:
            gpkg = None
        if not gpkg or not os.path.exists(gpkg):
            return None
        layer = QgsVectorLayer(f"{gpkg}|layername={layer_name}", layer_name, "ogr")
        if not layer.isValid():
            return None
        self._ensure_photo_fields(layer)
        self._configure_photo_layer(layer)
        QgsProject.instance().addMapLayer(layer)
        return layer

    def _gpkg_has_table(self, gpkg, table_name):
        import sqlite3
        try:
            conn = sqlite3.connect(gpkg)
            try:
                row = conn.execute(
                    "SELECT 1 FROM gpkg_contents WHERE lower(table_name)=lower(?)", (table_name,)
                ).fetchone()
                return row is not None
            finally:
                conn.close()
        except Exception:
            return False

    def _project_photo_gpkg_path(self, layer_name):
        base = self._primary_gpkg_path()
        if base:
            return os.path.join(os.path.dirname(base), f"{layer_name}.gpkg")
        proj_path = QgsProject.instance().fileName()
        if not proj_path:
            # V1.7.16: antes se usaba la carpeta del usuario, y la siguiente
            # obra en las mismas condiciones cargaba las fotos de la anterior.
            return None
        return os.path.join(os.path.dirname(proj_path), f"{layer_name}.gpkg")

    def _find_layer(self, name):
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == name and lyr.type() == QgsMapLayer.VectorLayer:
                return lyr
        return None

    # ------------------------------------------------------------------ Exports
    def export_layer_photos(self, layer, prefix=None):
        # prefix se conserva por compatibilidad con llamadas antiguas; el prefijo
        # real de fichero se decide por semántica de capa/campo: IF o FR.
        if layer is None or not layer.isValid():
            QMessageBox.warning(self, "Fotos", "No se ha localizado la capa de fotografías.")
            return
        out_dir = QFileDialog.getExistingDirectory(self, "Carpeta para exportar fotografías georreferenciadas", "")
        if not out_dir:
            return
        rows, errors = [], []
        for feat in layer.getFeatures():
            photo = str(feat[FIELD_PATH] or "").strip() if FIELD_PATH in [f.name() for f in layer.fields()] else ""
            if not photo or not os.path.exists(photo):
                errors.append(f"Foto no encontrada en FID {feat.id()}: {photo}")
                continue
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue
            pt = self._point_of(geom)
            if pt is None:
                continue
            lon, lat = self._to_lonlat(layer.crs(), pt.x(), pt.y())
            names = [f.name() for f in layer.fields()]
            num = feat[FIELD_NUM] if FIELD_NUM in names else len(rows) + 1
            desc = str(feat[FIELD_DESC] or "").strip() if FIELD_DESC in names else ""
            report_val = feat[FIELD_REPORT] if FIELD_REPORT in names else 0
            try:
                is_report = bool(int(report_val))
            except Exception:
                is_report = str(report_val).strip().lower() in ("si", "sí", "true", "1", "yes")
            if desc:
                is_report = True
            fecha_foto = str(feat[FIELD_DATE] or "").strip() if FIELD_DATE in names else ""
            stamp_val = feat[FIELD_STAMP_DATE] if FIELD_STAMP_DATE in names else 0
            try:
                stamp_date = bool(int(stamp_val))
            except Exception:
                stamp_date = str(stamp_val).strip().lower() in ("si", "sí", "true", "1", "yes")
            # Nombre de exportación corto: solo prefijo IF/FR + nombre original.
            # La capa puntos_informe siempre representa informe final, incluso si
            # procede de capas antiguas sin campo informe_final/descripción.
            if _es_capa_informe(layer.name()):
                # V1.7.30: prefijo con el código del informe (IF_, IS-01_…).
                is_report = True
                base_prefix = _codigo_de_capa(layer.name()) or "IF"
            elif layer.name() == LAYER_ANEJO_PRE:
                is_report = True
                base_prefix = "IF"
            else:
                base_prefix = "IF" if is_report else "FR"
            dst_name = self._prefixed_original_name(photo, base_prefix, out_dir)
            dst = os.path.join(out_dir, dst_name)
            try:
                shutil.copy2(photo, dst)
            except Exception as exc:
                # V1.7.16: una foto que no se puede copiar ya no corta la
                # exportación de las demás.
                errors.append(f"No se pudo copiar {photo}: {exc}")
                continue
            fecha_estampada = "NO"
            if stamp_date and fecha_foto:
                fecha_estampada = "SI" if self._stamp_visible_date(dst, fecha_foto) else "NO"
            # V1.7.22: sin casilla; se intenta siempre (la copia exportada lleva sus coordenadas).
            exif_ok = self._escribir_gps_original(dst, lon, lat)
            rows.append({"archivo": dst_name, "origen": photo, "descripcion": desc, "informe_final": "SI" if is_report else "NO", "fecha_foto": fecha_foto, "fecha_estampada": fecha_estampada, "x": pt.x(), "y": pt.y(), "lon": lon, "lat": lat, "exif_gps": "SI" if exif_ok else "NO"})
        self._write_manifest(out_dir, rows)
        msg = f"Fotografías exportadas: {len(rows)}\nCarpeta: {out_dir}\nSe ha creado manifest_fotos.csv."
        if errors:
            msg += "\n\nAvisos:\n" + "\n".join(errors[:10])
        QMessageBox.information(self, "Exportar a carpeta", msg)

    def export_docx(self):
        """Anejo fotográfico del informe elegido en DOCX.

        V1.7.30:
        - Las parejas se forman por Nº (1-2, 3-4…), no por posición: si falta una foto
          queda su hueco y las demás parejas no se desplazan. Se avisa de las fotos que
          no se encuentran, de Nº repetidos o vacíos y de parejas incompletas.
        - Las fotos van reducidas (lado mayor 2000 px) y giradas según su EXIF.
        - Se pregunta la escala del plano general; cada plano lleva escala gráfica y norte."""
        layer = self._capa_informe_existente()
        if layer is None or layer.featureCount() == 0:
            QMessageBox.warning(self, "Anejo fotográfico", "El informe elegido no existe o no contiene fotografías.")
            return
        code = _codigo_de_capa(layer.name()) or ""
        names = [f.name() for f in layer.fields()]

        # ── 1. Fotos de la capa y comprobaciones ───────────────────────────
        rows, missing, sin_num, por_num = [], [], [], {}
        for feat in layer.getFeatures():
            photo = str(feat[FIELD_PATH] or "").strip() if FIELD_PATH in names else ""
            raw = feat[FIELD_NUM] if FIELD_NUM in names else None
            try:
                num = int(raw) if raw not in (None, "") else 0
            except Exception:
                num = 0
            if num <= 0:
                sin_num.append(os.path.basename(photo) or f"FID {feat.id()}")
                continue
            por_num.setdefault(num, []).append(feat.id())
            if not photo or not os.path.exists(photo):
                missing.append(f"Foto {num}: {photo or '(sin ruta)'}")
                continue
            try:
                stamp_date = bool(int(feat[FIELD_STAMP_DATE] or 0)) if FIELD_STAMP_DATE in names else False
            except Exception:
                stamp_date = False
            rows.append({
                "num": num,
                "fid": feat.id(),
                "desc": str(feat[FIELD_DESC] or "").strip() if FIELD_DESC in names else "",
                "path": photo,
                "fecha_foto": str(feat[FIELD_DATE] or "").strip() if FIELD_DATE in names else "",
                "estampar_fecha": stamp_date,
            })
        repetidos = sorted(n for n, fids in por_num.items() if len(fids) > 1)
        if sin_num or repetidos:
            partes = []
            if repetidos:
                partes.append("Nº repetidos: " + ", ".join(str(n) for n in repetidos))
            if sin_num:
                partes.append("Fotos sin Nº: " + ", ".join(sin_num[:10]) + (" …" if len(sin_num) > 10 else ""))
            QMessageBox.warning(
                self, "Anejo fotográfico",
                "No se puede montar el anejo por parejas:\n\n" + "\n".join(partes) +
                "\n\nUsa «Agrupar por ubicación y renumerar» o corrige el campo Nº en la tabla de atributos.",
            )
            return
        if not rows:
            QMessageBox.warning(self, "Anejo fotográfico", "No se encuentra ninguna de las fotografías del informe en su ruta.")
            return
        rows.sort(key=lambda r: r["num"])

        pairs = self._parejas_por_numero(rows)
        incompletas = [p for p in pairs if p[0] is None or p[1] is None]
        avisos = []
        if missing:
            avisos.append("Fotos que no se encuentran en su ruta (quedará su hueco):\n  " + "\n  ".join(missing[:12]) +
                          ("\n  …" if len(missing) > 12 else ""))
        if incompletas:
            sueltas = [str((p[0] or p[1])["num"]) for p in incompletas]
            avisos.append("Fotos sin pareja: " + ", ".join(sueltas[:20]) + (" …" if len(sueltas) > 20 else ""))
        if avisos:
            resp = QMessageBox.question(
                self, "Anejo fotográfico", "\n\n".join(avisos) + "\n\n¿Generar el anejo igualmente?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
            )
            if resp != QMessageBox.Yes:
                return

        # ── 2. Opciones (disposición, escala, resumen) ─────────────────────
        titulo = "ANEJO FOTOGRÁFICO"
        if code == "IF":
            titulo += " · INFORME FINAL"
        elif code:
            titulo += f" · INFORME SEMESTRAL {code}"
        opts = OpcionesDocxDialog(self, titulo_informe=_texto_informe(code))
        if opts.exec_() != QDialog.Accepted:
            return
        photo_layout = opts.photo_layout()
        escala = opts.escala
        include_summary = opts.include_summary()
        opts.deleteLater()

        summary_lines = []
        if include_summary:
            text, ok = QInputDialog.getMultiLineText(
                self,
                "Resumen de fotografías",
                "Revisa o edita el resumen por parejas que se insertará bajo el último plano general:",
                self._default_photo_pair_summary(rows),
            )
            if not ok:
                return
            summary_lines = [ln.strip().lstrip("•").strip() for ln in str(text or "").splitlines() if ln.strip()]

        out_dir = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta de descarga del DOCX", "")
        if not out_dir:
            return
        out_path = self._unique_docx_path(out_dir, f"anejo_fotografico_{code}.docx" if code else "anejo_fotografico.docx")

        # ── 3. Fotos preparadas, planos y documento ───────────────────────
        tmp = tempfile.mkdtemp(prefix="obra_nueva_fotos_")
        try:
            for pos, row in enumerate(rows, start=1):
                dst = os.path.join(tmp, "foto_%04d.jpg" % pos)
                dst = self._preparar_foto_docx(row["path"], dst)
                if row.get("estampar_fecha") and row.get("fecha_foto") and dst != row["path"]:
                    self._stamp_visible_date(dst, row.get("fecha_foto"))
                row["path"] = dst
            nums = {r["num"] for r in rows}
            situation_maps = self._capture_situation_maps(layer, tmp, escala=escala, nums_incluidos=nums)
            SimpleDocxReport(out_path).build(
                situation_maps, self._parejas_por_numero(rows), photo_layout=photo_layout,
                summary_lines=summary_lines, title=titulo,
            )
            QMessageBox.information(self, "Anejo fotográfico", f"DOCX generado:\n{out_path}")
        except Exception as exc:
            log_message(f"Error generando el DOCX del anejo: {exc}", Qgis.Critical)
            QMessageBox.critical(self, "Anejo fotográfico", f"No se pudo generar el DOCX:\n{exc}")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    @staticmethod
    def _parejas_por_numero(rows):
        """[(foto impar | None, foto par | None), ...] por Nº: 1-2, 3-4, 5-6…"""
        grupos = OrderedDict()
        for row in sorted(rows, key=lambda r: r["num"]):
            k = (int(row["num"]) + 1) // 2
            grupos.setdefault(k, [None, None])
            grupos[k][0 if int(row["num"]) % 2 == 1 else 1] = row
        return [tuple(v) for v in grupos.values()]

    def _preparar_foto_docx(self, src, dst):
        """Copia de la foto para el DOCX: girada según su EXIF y con el lado mayor reducido
        a DOCX_FOTO_LADO_MAX píxeles. Si Pillow falla se usa una copia tal cual."""
        try:
            from PIL import Image, ImageOps
            with Image.open(src) as im:
                exif = im.getexif()
                img = ImageOps.exif_transpose(im)
                if img.mode not in ("RGB", "L"):
                    img = img.convert("RGB")
                img.thumbnail((DOCX_FOTO_LADO_MAX, DOCX_FOTO_LADO_MAX), Image.LANCZOS)
                kwargs = {"quality": DOCX_FOTO_CALIDAD, "optimize": True}
                if exif:
                    exif[0x0112] = 1  # ya está girada
                    kwargs["exif"] = exif.tobytes()
                img.save(dst, "JPEG", **kwargs)
            return dst
        except Exception as exc:
            log_message(f"No se pudo reducir {src} para el DOCX; se usa la original: {exc}", Qgis.Warning)
            dst = os.path.splitext(dst)[0] + (os.path.splitext(src)[1].lower() or ".jpg")
            try:
                shutil.copy2(src, dst)
                return dst
            except Exception:
                return src

    def _unique_docx_path(self, out_dir, filename):
        base, ext = os.path.splitext(filename)
        if not ext:
            ext = ".docx"
        candidate = os.path.join(out_dir, base + ext)
        i = 2
        while os.path.exists(candidate):
            candidate = os.path.join(out_dir, f"{base}_{i}{ext}")
            i += 1
        return candidate

    def _default_photo_pair_summary(self, rows):
        """V1.7.30: por parejas de Nº; sin descripción ya no queda «Fotos 1 y 2, .»."""
        lines = []
        for a, b in self._parejas_por_numero(rows):
            fotos = [r for r in (a, b) if r is not None]
            descs = []
            for r in fotos:
                d = str(r.get("desc", "") or "").strip().rstrip(".")
                if d and d not in descs:
                    descs.append(d)
            if len(fotos) == 2:
                cab = f"Fotos {fotos[0]['num']} y {fotos[1]['num']}"
            else:
                cab = f"Foto {fotos[0]['num']}"
            lines.append(f"{cab}, {' y '.join(descs)}." if descs else f"{cab}.")
        return "\n".join(lines)

    # ------------------------------------------------------------------ V1.7.30 · planos generales
    def _capture_situation_maps(self, layer, tmp_dir, escala=None, nums_incluidos=None):
        """Planos generales de localización a escala real del DOCX.

        Cada plano mide PLANO_ANCHO_CM x PLANO_ALTO_CM en el documento. Con una escala
        fija, las parejas (por Nº) se agrupan en orden en planos de ese tamaño sin
        separar nunca una pareja; si una pareja sola no cabe, ese plano se aleja a la
        escala normalizada siguiente. En automático se busca un solo plano entre
        ESCALA_AUTO_MIN y ESCALA_AUTO_MAX; si no cabe, varios a ESCALA_AUTO_MAX.
        Devuelve [(png, escala), ...]."""
        puntos = self._puntos_plano(layer, nums_incluidos)
        if not puntos:
            return []
        map_crs = self._map_crs()
        cx_all = sum(p["pt"].x() for p in puntos) / len(puntos)
        cy_all = sum(p["pt"].y() for p in puntos) / len(puntos)
        mpu = self._metros_por_unidad(map_crs, QgsPointXY(cx_all, cy_all))

        def caja(pts):
            xs = [p["pt"].x() for p in pts]
            ys = [p["pt"].y() for p in pts]
            return min(xs), min(ys), max(xs), max(ys)

        def cabe(pts, s):
            # 80 % del marco: deja sitio a las llamadas «Foto: N» y a la escala/norte.
            x0, y0, x1, y1 = caja(pts)
            ancho_u = (PLANO_ANCHO_CM / 100.0) * s / mpu * 0.80
            alto_u = (PLANO_ALTO_CM / 100.0) * s / mpu * 0.80
            return (x1 - x0) <= ancho_u and (y1 - y0) <= alto_u

        if escala is None:
            escala = next((s for s in ESCALAS_NORMALIZADAS
                           if ESCALA_AUTO_MIN <= s <= ESCALA_AUTO_MAX and cabe(puntos, s)), ESCALA_AUTO_MAX)

        # Parejas en orden de Nº
        grupos = OrderedDict()
        for p in puntos:
            grupos.setdefault((p["num"] + 1) // 2, []).append(p)
        planos = []
        actual = []
        for pts in grupos.values():
            if actual and cabe(actual + pts, escala):
                actual = actual + pts
            else:
                if actual:
                    planos.append(actual)
                actual = list(pts)
        if actual:
            planos.append(actual)

        out_size = QSize(int(PLANO_ANCHO_CM * PLANO_PX_POR_CM), int(PLANO_ALTO_CM * PLANO_PX_POR_CM))
        result = []
        for i, pts in enumerate(planos, start=1):
            s = escala
            if not cabe(pts, s):
                s = next((e for e in ESCALAS_NORMALIZADAS if e > s and cabe(pts, e)), None)
                if s is None:
                    s = escala
                    while not cabe(pts, s):
                        s *= 2
            x0, y0, x1, y1 = caja(pts)
            cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
            half_w = (PLANO_ANCHO_CM / 100.0) * s / mpu / 2.0
            half_h = (PLANO_ALTO_CM / 100.0) * s / mpu / 2.0
            extent = QgsRectangle(cx - half_w, cy - half_h, cx + half_w, cy + half_h)
            out_png = os.path.join(tmp_dir, f"situacion_{i:02d}.png")
            self._capture_situation_extent(extent, out_png, out_size, layer, s, mpu, nums_incluidos)
            result.append((out_png, s))
        return result

    def _metros_por_unidad(self, crs, centro):
        """Metros que mide una unidad de mapa (1 en UTM; en grados se mide sobre el elipsoide)."""
        try:
            if crs.isValid() and not crs.isGeographic():
                try:
                    metros = Qgis.DistanceUnit.Meters
                except AttributeError:
                    metros = QgsUnitTypes.DistanceMeters
                f = QgsUnitTypes.fromUnitToUnitFactor(crs.mapUnits(), metros)
                if f and f > 0:
                    return float(f)
            da = QgsDistanceArea()
            da.setSourceCrs(crs, QgsProject.instance().transformContext())
            ell = QgsProject.instance().ellipsoid()
            da.setEllipsoid(ell if ell and ell.upper() != "NONE" else "EPSG:7030")
            d = 0.001
            m = da.measureLine(QgsPointXY(centro.x() - d, centro.y()), QgsPointXY(centro.x() + d, centro.y()))
            return m / (2 * d) if m > 0 else 1.0
        except Exception:
            return 1.0

    def _puntos_plano(self, layer, nums_incluidos=None):
        """Puntos del informe en el SRC del lienzo: [{'num', 'pt'}] ordenados por Nº."""
        items = []
        if layer is None or not layer.isValid():
            return items
        names = [f.name() for f in layer.fields()]
        transform = None
        try:
            map_crs = self._map_crs()
            if layer.crs().isValid() and map_crs.isValid() and layer.crs() != map_crs:
                transform = QgsCoordinateTransform(layer.crs(), map_crs, QgsProject.instance())
        except Exception:
            transform = None
        for feat in layer.getFeatures():
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue
            pt = self._point_of(geom)
            if pt is None:
                continue
            try:
                num = int(feat[FIELD_NUM]) if FIELD_NUM in names and feat[FIELD_NUM] not in (None, "") else 0
            except Exception:
                num = 0
            if num <= 0 or (nums_incluidos is not None and num not in nums_incluidos):
                continue
            try:
                if transform is not None:
                    pt = transform.transform(QgsPointXY(pt))
            except Exception:
                pass
            items.append({"num": num, "pt": QgsPointXY(pt)})
        items.sort(key=lambda x: x["num"])
        return items

    def _capture_situation_extent(self, extent, out_png, out_size, anejo_layer, escala, mpu, nums_incluidos=None):
        """Renderiza el plano (a 254 ppp, para que los símbolos en mm salgan a su tamaño real
        impreso) y dibuja encima las llamadas «Foto: N», la escala gráfica y el norte."""
        old_labels_enabled = None
        try:
            if anejo_layer is not None and anejo_layer.isValid():
                old_labels_enabled = anejo_layer.labelsEnabled()
                # Las llamadas se pintan a mano (sin descartes del motor de etiquetas).
                anejo_layer.setLabelsEnabled(False)
            settings = QgsMapSettings()
            settings.setLayers(self._situation_canvas_layers(anejo_layer))
            settings.setDestinationCrs(self._map_crs())
            settings.setOutputSize(out_size)
            settings.setOutputDpi(PLANO_PX_POR_CM * 2.54)
            settings.setExtent(extent)
            image = QImage(out_size, QImage.Format_ARGB32_Premultiplied)
            image.fill(Qt.white)
            painter = QPainter(image)
            job = QgsMapRendererCustomPainterJob(settings, painter)
            job.start()
            job.waitForFinished()
            painter.end()
            render_extent = settings.visibleExtent()
        finally:
            if anejo_layer is not None and anejo_layer.isValid() and old_labels_enabled is not None:
                anejo_layer.setLabelsEnabled(old_labels_enabled)

        reservados = self._draw_scale_and_north(image, escala, mpu)
        self._draw_situation_photo_labels(image, render_extent, anejo_layer, reservados, nums_incluidos)
        image.save(out_png, "PNG")

    def _situation_canvas_layers(self, anejo_layer=None):
        """Capas visibles del lienzo para el plano. V1.7.30: sin las capas de fotos de otros
        informes (solo se ven los puntos del informe que se exporta)."""
        layers = []
        try:
            canvas_layers = list(self.canvas.layers())
        except Exception:
            canvas_layers = []
        for lyr in canvas_layers:
            try:
                if not (lyr and lyr.isValid()):
                    continue
                if lyr.type() not in (QgsMapLayer.VectorLayer, QgsMapLayer.RasterLayer, QgsMapLayer.VectorTileLayer):
                    continue
                if _es_capa_informe(lyr.name()) and lyr is not anejo_layer:
                    continue
                if lyr not in layers:
                    layers.append(lyr)
            except Exception:
                continue
        if anejo_layer is not None:
            try:
                if anejo_layer.isValid() and anejo_layer not in layers:
                    layers.insert(0, anejo_layer)
            except Exception:
                pass
        return layers

    def _draw_scale_and_north(self, image, escala, mpu):
        """Escala gráfica (abajo a la izquierda) y norte (arriba a la derecha). Devuelve los
        rectángulos ocupados para que las llamadas de las fotos no los tapen."""
        reservados = []
        px_por_m_papel = PLANO_PX_POR_CM * 100.0
        painter = QPainter(image)
        try:
            painter.setRenderHint(QPainter.Antialiasing, True)
            font = QFont("Arial")
            font.setPixelSize(24)
            painter.setFont(font)
            fm = painter.fontMetrics()

            # Escala gráfica: longitud redonda (1-2-5) de unos 4 cm de papel, en 4 tramos.
            objetivo_m = 0.04 * escala
            base = 10 ** math.floor(math.log10(objetivo_m))
            largo_m = max(m * base for m in (1, 2, 5, 10) if m * base <= objetivo_m * 1.0001)
            largo_px = largo_m / escala * px_por_m_papel
            margen = 22
            bar_h = 12
            texto_esc = f"Escala 1:{_fmt_miles(escala)}"

            def fmt_d(m):
                if largo_m >= 1000:
                    v = m / 1000.0
                    return (f"{v:.1f}".rstrip("0").rstrip(".") if v % 1 else str(int(v))).replace(".", ",")
                return (f"{m:.1f}".rstrip("0").rstrip(".") if m % 1 else str(int(m))).replace(".", ",")
            unidad = "km" if largo_m >= 1000 else "m"
            etiquetas = [fmt_d(largo_m * k / 4.0) for k in (0, 2, 4)]
            etiquetas[-1] += f" {unidad}"
            caja_w = int(largo_px + 2 * margen + fm.horizontalAdvance(etiquetas[-1]) / 2 + 10)
            caja_w = max(caja_w, fm.horizontalAdvance(texto_esc) + 2 * margen)
            caja_h = fm.height() * 2 + bar_h + 26
            caja = QRectF(14, image.height() - caja_h - 14, caja_w, caja_h)
            painter.fillRect(caja, QColor(255, 255, 255, 230))
            painter.setPen(QPen(QColor(0, 0, 0), 2))
            painter.drawRect(caja)
            x0 = caja.x() + margen
            painter.drawText(QRectF(x0, caja.y() + 6, caja_w - 2 * margen, fm.height()),
                             Qt.AlignLeft | Qt.AlignVCenter, texto_esc)
            y_bar = caja.y() + 10 + fm.height()
            tramo = largo_px / 4.0
            for k in range(4):
                r = QRectF(x0 + k * tramo, y_bar, tramo, bar_h)
                painter.fillRect(r, QColor(0, 0, 0) if k % 2 == 0 else QColor(255, 255, 255))
                painter.drawRect(r)
            for k, txt in zip((0, 2, 4), etiquetas):
                tx = x0 + k * tramo
                w = fm.horizontalAdvance(txt)
                painter.drawText(QRectF(tx - (0 if k == 0 else w / 2), y_bar + bar_h + 2, w + 4, fm.height()),
                                 Qt.AlignLeft | Qt.AlignVCenter, txt)
            reservados.append(caja)

            # Norte: flecha de dos colores con «N».
            nw, nh = 64, 104
            caja_n = QRectF(image.width() - nw - 14, 14, nw, nh)
            painter.fillRect(caja_n, QColor(255, 255, 255, 230))
            painter.setPen(QPen(QColor(0, 0, 0), 2))
            painter.drawRect(caja_n)
            cxn = caja_n.center().x()
            top = caja_n.y() + 12
            bottom = caja_n.bottom() - 34
            mid_y = bottom - (bottom - top) * 0.25
            izq = QPolygonF([QPointF(cxn, top), QPointF(cxn - 18, bottom), QPointF(cxn, mid_y)])
            der = QPolygonF([QPointF(cxn, top), QPointF(cxn + 18, bottom), QPointF(cxn, mid_y)])
            painter.setBrush(QColor(0, 0, 0))
            painter.drawPolygon(izq)
            painter.setBrush(QColor(255, 255, 255))
            painter.drawPolygon(der)
            fnt = QFont("Arial")
            fnt.setPixelSize(26)
            fnt.setBold(True)
            painter.setFont(fnt)
            painter.drawText(QRectF(caja_n.x(), bottom + 2, nw, 30), Qt.AlignCenter, "N")
            reservados.append(caja_n)
        finally:
            painter.end()
        return reservados

    def _draw_situation_photo_labels(self, image, extent, layer, reservados=None, nums_incluidos=None):
        """Dibuja todas las llamadas «Foto: Nº» sobre el PNG (en píxeles, sin descartes)."""
        if layer is None or not layer.isValid() or extent is None or extent.isEmpty():
            return
        labels = self._situation_label_items(layer, extent, image.size(), nums_incluidos)
        if not labels:
            return
        painter = QPainter(image)
        try:
            painter.setRenderHint(QPainter.Antialiasing, True)
            label_scale = 2.0
            font = QFont("Arial")
            font.setPixelSize(26)
            font.setBold(True)
            painter.setFont(font)
            fm = painter.fontMetrics()
            sep = int(4 * label_scale)
            placed = [QRectF(r.x() - sep, r.y() - sep, r.width() + 2 * sep, r.height() + 2 * sep)
                      for r in (reservados or [])]
            base_offsets = [
                (18, -38), (18, 10), (-96, -38), (-96, 10),
                (18, -70), (18, 42), (-96, -70), (-96, 42),
                (42, -20), (-120, -20), (42, 24), (-120, 24),
                (18, -102), (18, 74), (-96, -102), (-96, 74),
            ]
            offsets = [(int(dx * label_scale), int(dy * label_scale)) for dx, dy in base_offsets]
            for item in labels:
                text = f"Foto: {item['num']}"
                pad_x, pad_y = int(7 * label_scale), int(4 * label_scale)
                box_w = fm.horizontalAdvance(text) + 2 * pad_x
                box_h = fm.height() + 2 * pad_y
                ax, ay = item["px"], item["py"]
                rect = None
                for dx, dy in offsets:
                    candidate = self._clamp_label_rect(QRectF(ax + dx, ay + dy, box_w, box_h), image.width(), image.height())
                    grown = QRectF(candidate.x() - sep, candidate.y() - sep, candidate.width() + 2 * sep, candidate.height() + 2 * sep)
                    if not any(grown.intersects(prev) for prev in placed):
                        rect = candidate
                        break
                if rect is None:
                    # Último recurso: el primer hueco libre bajo el norte, apilando hacia abajo.
                    y = 14 + 104 + 2 * sep
                    rect = self._clamp_label_rect(QRectF(image.width() - box_w - 14, y, box_w, box_h), image.width(), image.height())
                    while any(QRectF(rect.x() - sep, rect.y() - sep, rect.width() + 2 * sep, rect.height() + 2 * sep).intersects(p) for p in placed) \
                            and rect.bottom() + box_h < image.height():
                        rect = QRectF(rect.x(), rect.y() + box_h + sep, box_w, box_h)
                callout_end = self._nearest_rect_point(rect, ax, ay)
                painter.setPen(QPen(QColor(0, 0, 0), int(2 * label_scale)))
                painter.drawLine(QPointF(ax, ay), callout_end)
                painter.fillRect(rect, QColor(0, 0, 0))
                painter.setPen(QPen(QColor(255, 255, 255), 1))
                painter.drawText(rect.adjusted(pad_x, pad_y, -pad_x, -pad_y), Qt.AlignCenter, text)
                placed.append(QRectF(rect.x() - sep, rect.y() - sep, rect.width() + 2 * sep, rect.height() + 2 * sep))
        finally:
            painter.end()

    def _situation_label_items(self, layer, extent, out_size, nums_incluidos=None):
        items = []
        for p in self._puntos_plano(layer, nums_incluidos):
            pt = p["pt"]
            if not extent.contains(pt):
                continue
            px = (float(pt.x()) - extent.xMinimum()) / max(extent.width(), 1e-9) * out_size.width()
            py = (extent.yMaximum() - float(pt.y())) / max(extent.height(), 1e-9) * out_size.height()
            items.append({"num": p["num"], "px": px, "py": py})
        return items

    def _clamp_label_rect(self, rect, image_w, image_h):
        x = min(max(rect.x(), 4), max(4, image_w - rect.width() - 4))
        y = min(max(rect.y(), 4), max(4, image_h - rect.height() - 4))
        return QRectF(x, y, rect.width(), rect.height())

    def _nearest_rect_point(self, rect, ax, ay):
        x = min(max(ax, rect.left()), rect.right())
        y = min(max(ay, rect.top()), rect.bottom())
        return QPointF(x, y)

    # ------------------------------------------------------------------ Shared helpers
    def _photo_paths(self, feat, layer, gpkg_path):
        names = [field.name() for field in layer.fields()]
        lower_map = {n.lower(): n for n in names}
        candidates = []
        for cand in PHOTO_FIELDS:
            real = cand if cand in names else lower_map.get(cand.lower())
            if real and real not in candidates:
                candidates.append(real)
        for name in names:
            low = name.lower()
            if ("foto" in low or "photo" in low or "image" in low or "imagen" in low or "picture" in low) and name not in candidates:
                candidates.append(name)
        base_dir = os.path.dirname(gpkg_path)
        project_dir = os.path.dirname(QgsProject.instance().fileName()) if QgsProject.instance().fileName() else base_dir
        img_exts = (".jpg", ".jpeg", ".png", ".tif", ".tiff")
        null_tokens = {"", "null", "none", "nan", "<null>", "sin foto", "s/f"}

        paths, seen = [], set()
        for field_name in candidates:
            val = feat[field_name]
            if val is None:
                continue
            for chunk in str(val).replace("\r", ";").replace("\n", ";").replace("|", ";").split(";"):
                raw = chunk.strip().strip('"').strip("'")
                if raw.lower() in null_tokens:
                    continue
                # Evita interpretar valores alfanuméricos, códigos o NULL de campos no fotográficos como rutas.
                if not raw.lower().endswith(img_exts):
                    continue

                alternatives = []
                if os.path.isabs(raw):
                    alternatives.append(os.path.normpath(raw))
                else:
                    alternatives.extend([
                        os.path.normpath(os.path.join(base_dir, raw)),
                        os.path.normpath(os.path.join(project_dir, raw)),
                        os.path.normpath(os.path.join(base_dir, "fotos", raw)),
                        os.path.normpath(os.path.join(base_dir, "Fotos", raw)),
                        os.path.normpath(os.path.join(base_dir, "FOTOS", raw)),
                        os.path.normpath(os.path.join(base_dir, "imagenes", raw)),
                        os.path.normpath(os.path.join(base_dir, "Imágenes", raw)),
                    ])

                # Prioriza la alternativa existente; si ninguna existe, conserva la primera para informar del aviso real.
                path = next((a for a in alternatives if os.path.exists(a)), alternatives[0])
                key = os.path.normcase(path)
                if key not in seen:
                    seen.add(key)
                    paths.append(path)
        return paths

    def _map_crs(self):
        """SRC del lienzo (en el que llegan los clics y se dibujan los planos)."""
        try:
            crs = self.canvas.mapSettings().destinationCrs()
            if crs.isValid():
                return crs
        except Exception:
            pass
        return QgsProject.instance().crs()

    @staticmethod
    def _point_of(geom):
        """QgsPointXY de una geometría: el punto; el primero de un multipunto
        (V1.7.16: asPoint() fallaba con multipuntos de varias partes); el
        centroide en el resto de casos."""
        if geom is None or geom.isEmpty():
            return None
        try:
            if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.PointGeometry:
                if QgsWkbTypes.isMultiType(geom.wkbType()):
                    pts = geom.asMultiPoint()
                    return QgsPointXY(pts[0]) if pts else None
                return QgsPointXY(geom.asPoint())
            c = geom.centroid()
            if c is not None and not c.isEmpty():
                return QgsPointXY(c.asPoint())
        except Exception:
            return None
        return None

    def _safe_centroid(self, geom):
        try:
            if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.PointGeometry:
                if QgsWkbTypes.isMultiType(geom.wkbType()):
                    pt = self._point_of(geom)
                    return QgsGeometry.fromPointXY(pt) if pt is not None else None
                return geom
            c = geom.centroid()
            if c and not c.isEmpty():
                return c
            p = geom.pointOnSurface()
            if p and not p.isEmpty():
                return p
        except Exception:
            return None
        return None

    def _attr(self, feat, layer, candidates):
        names = [field.name() for field in layer.fields()]
        lower_map = {n.lower(): n for n in names}
        for cand in candidates:
            real = cand if cand in names else lower_map.get(cand.lower())
            if real:
                val = feat[real]
                return "" if val is None else str(val)
        return ""

    def _to_lonlat(self, crs, x, y):
        # V1.7.16: sin SRC válido no se inventan coordenadas geográficas
        # (antes se devolvían X/Y proyectadas como si fueran lon/lat).
        if crs is None or not crs.isValid():
            return None, None
        try:
            dest = QgsCoordinateReferenceSystem("EPSG:4326")
            tr = QgsCoordinateTransform(crs, dest, QgsProject.instance())
            p = tr.transform(QgsPointXY(x, y))
            return float(p.x()), float(p.y())
        except Exception:
            return None, None

    def _photo_date_for_display(self, photo_path):
        """Devuelve fecha en formato DD/MM/AAAA HH:MM.

        Orden de búsqueda:
        1) EXIF de la cámara.
        2) Nombre de archivo.
        3) Fecha estampada visualmente en la fotografía mediante OCR opcional.

        La lectura visual requiere que el entorno de QGIS tenga Tesseract disponible
        como ejecutable del sistema o como módulo pytesseract. Si no está disponible,
        el flujo continúa sin romperse y se pide la fecha manualmente.
        """
        # 1) EXIF DateTimeOriginal / DateTimeDigitized / DateTime
        try:
            from PIL import Image, ExifTags
            img = Image.open(photo_path)
            exif = img.getexif()
            # V201: DateTimeOriginal y DateTimeDigitized están en el bloque
            # Exif (0x8769), no en el principal: con getexif() a secas solo
            # se encontraba DateTime (fecha de modificación).
            exif_ifd = _exif_sub_ifd(exif, 0x8769)
            modified = self._normalize_photo_date(exif.get(0x0132)) if exif else ""
            for tag_id, source in ((0x9003, exif_ifd), (0x9004, exif_ifd)):
                value = source.get(tag_id) if source else None
                formatted = self._normalize_photo_date(value)
                if formatted:
                    return formatted
        except Exception as exc:
            modified = ""
            log_message(f"No se pudo leer fecha EXIF de {photo_path}: {exc}", Qgis.Info)

        # 2) Nombre típico IMG_20251210_111007.jpg / 20251210-111007
        try:
            name_date = self._photo_date_from_filename(photo_path)
            if name_date:
                return name_date
        except Exception as exc:
            log_message(f"No se pudo leer fecha desde nombre de archivo {photo_path}: {exc}", Qgis.Info)

        # V1.7.16: la fecha de MODIFICACIÓN (DateTime) va después de la del
        # nombre del fichero: la cambia cualquier programa que edite la foto.
        if modified:
            return modified

        # 3) Fecha visible estampada dentro de la imagen.
        try:
            visible_date = self._photo_date_from_visible_stamp(photo_path)
            if visible_date:
                return visible_date
        except Exception as exc:
            log_message(f"No se pudo leer fecha visible estampada de {photo_path}: {exc}", Qgis.Info)

        return ""

    def _photo_date_from_filename(self, photo_path):
        """Detecta fechas habituales embebidas en el nombre de archivo."""
        import re
        name = os.path.basename(photo_path)
        patterns = (
            r"(20\d{2})(\d{2})(\d{2})[_\- ]?(\d{2})(\d{2})(\d{2})?",
            r"(\d{2})[\-_/\.](\d{2})[\-_/\.](20\d{2})[_\- ]+(\d{2})[\.:hH](\d{2})",
        )
        for pattern in patterns:
            m = re.search(pattern, name)
            if not m:
                continue
            groups = tuple(g or "" for g in m.groups())
            if pattern.startswith("(20"):
                y, mo, d, h, mi, _sec = groups
            else:
                d, mo, y, h, mi = groups
            normalized = self._normalize_photo_date(f"{d}/{mo}/{y} {h}:{mi}")
            if normalized:
                return normalized
        return ""

    def _photo_date_from_visible_stamp(self, photo_path):
        """Intenta leer una fecha ya estampada visualmente en la foto.

        Usa OCR opcional con Tesseract. Para hacerlo más fiable, analiza primero
        franjas inferiores y laterales, que es donde suelen aparecer las fechas
        impresas por cámara/app, y aplica varios preprocesados simples.
        """
        try:
            from PIL import Image, ImageOps, ImageEnhance, ImageFilter
        except Exception:
            return ""

        if not self._ocr_available():
            return ""
        img = Image.open(photo_path).convert("RGB")
        w, h = img.size
        if w < 80 or h < 80:
            return ""

        # V1.7.16 (A6): solo las zonas donde las cámaras y apps estampan la
        # fecha (franja inferior y esquina inferior derecha), pocas variantes
        # y un tiempo máximo por foto.
        deadline = time.monotonic() + OCR_MAX_SECONDS
        crops = [
            img.crop((int(w * 0.30), int(h * 0.75), w, h)),
            img.crop((0, int(h * 0.70), w, h)),
        ]
        for crop in crops:
            for prepared in self._ocr_prepared_images(crop):
                if time.monotonic() > deadline:
                    log_message(
                        f"OCR de fecha sin resultado en {OCR_MAX_SECONDS:.0f} s: {os.path.basename(photo_path)}",
                        Qgis.Info)
                    return ""
                text = self._run_ocr_on_image(prepared, deadline)
                detected = self._extract_photo_date_from_text(text)
                if detected:
                    return detected
        return ""

    def _ocr_available(self):
        """True si hay Tesseract (pytesseract o ejecutable). Se comprueba una vez."""
        cached = getattr(self, "_ocr_ok", None)
        if cached is not None:
            return cached
        ok = False
        for cmd in self._candidate_tesseract_commands():
            if (cmd == "tesseract" and shutil.which("tesseract")) or (cmd != "tesseract" and os.path.exists(cmd)):
                ok = True
                break
        self._ocr_ok = ok
        return ok

    def _ocr_prepared_images(self, image):
        """Genera variantes sencillas para mejorar lectura OCR de texto blanco/negro."""
        try:
            from PIL import ImageOps, ImageEnhance, ImageFilter
        except Exception as exc:
            log_message(f"PIL no disponible para preparar OCR: {exc}", Qgis.Info)
            return []
        variants = []
        gray = ImageOps.grayscale(image)
        # Ampliación moderada: mejora textos pequeños sin disparar el tiempo.
        scale = 2 if max(gray.size) < 1800 else 1
        resized = gray.resize((gray.width * scale, gray.height * scale)) if scale > 1 else gray
        sharp = ImageEnhance.Sharpness(resized).enhance(2.2).filter(ImageFilter.SHARPEN)
        contrast = ImageOps.autocontrast(ImageEnhance.Contrast(sharp).enhance(2.0))
        # V1.7.16: 4 variantes (antes 10): texto claro y oscuro, con y sin umbral.
        variants.append(contrast)
        variants.append(ImageOps.invert(contrast))
        bw = contrast.point(lambda p: 255 if p > 160 else 0)
        variants.append(bw)
        variants.append(ImageOps.invert(bw))
        return variants

    def _candidate_tesseract_commands(self):
        """Rutas habituales de Tesseract en Windows/QGIS y PATH del sistema."""
        import os as _os
        candidates = []
        env_cmd = _os.environ.get("TESSERACT_CMD") or _os.environ.get("TESSERACT_PATH")
        if env_cmd:
            candidates.append(env_cmd)
        candidates.extend([
            "tesseract",
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        ])
        seen = set()
        result = []
        for cmd in candidates:
            if cmd and cmd not in seen:
                seen.add(cmd)
                result.append(cmd)
        return result

    def _run_ocr_on_image(self, image, deadline=None):
        """Ejecuta OCR mediante pytesseract o ejecutable tesseract si existen."""
        # psm 7 funciona mejor para una única línea de fecha; psm 11 de respaldo.
        configs = [
            "--psm 7 -c tessedit_char_whitelist=0123456789/:.- hH",
            "--psm 11 -c tessedit_char_whitelist=0123456789/:.- hH",
        ]

        def remaining():
            return 3.0 if deadline is None else max(0.5, min(3.0, deadline - time.monotonic()))
        try:
            import pytesseract
            for cmd in self._candidate_tesseract_commands():
                if cmd != "tesseract" and os.path.exists(cmd):
                    try:
                        pytesseract.pytesseract.tesseract_cmd = cmd
                    except Exception:
                        pass
                    break
            chunks = []
            for config in configs:
                if deadline is not None and time.monotonic() > deadline:
                    break
                try:
                    chunks.append(pytesseract.image_to_string(image, config=config, timeout=remaining()) or "")
                except Exception:
                    continue
            if chunks:
                return "\n".join(chunks)
        except Exception:
            pass

        try:
            import subprocess, tempfile, os as _os
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                tmp_path = tmp.name
            try:
                image.save(tmp_path)
                for cmd in self._candidate_tesseract_commands():
                    if cmd != "tesseract" and not _os.path.exists(cmd):
                        continue
                    for psm in ("7", "11"):
                        if deadline is not None and time.monotonic() > deadline:
                            return ""
                        try:
                            proc = subprocess.run(
                                [cmd, tmp_path, "stdout", "--psm", psm, "-c", "tessedit_char_whitelist=0123456789/:.- hH"],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.DEVNULL,
                                timeout=remaining(),
                                text=True,
                            )
                        except Exception:
                            continue
                        if proc.stdout:
                            return proc.stdout
                return ""
            finally:
                try:
                    _os.remove(tmp_path)
                except Exception:
                    pass
        except Exception:
            return ""

    def _extract_photo_date_from_text(self, text):
        """Extrae y normaliza fecha/hora desde texto OCR ruidoso."""
        if not text:
            return ""
        import re
        cleaned = str(text)
        cleaned = cleaned.replace("I", "1").replace("l", "1").replace("O", "0").replace("o", "0")
        cleaned = re.sub(r"\s+", " ", cleaned)

        patterns = (
            # 10/12/2025 11:10, 10-12-2025 11.10, 10.12.2025 11h10
            r"(?<!\d)(\d{1,2})[\s/\-.](\d{1,2})[\s/\-.](20\d{2})\s+(\d{1,2})[\s:.hH](\d{2})(?!\d)",
            # 2025/12/10 11:10
            r"(?<!\d)(20\d{2})[\s/\-.](\d{1,2})[\s/\-.](\d{1,2})\s+(\d{1,2})[\s:.hH](\d{2})(?!\d)",
            # 10122025 1110 o 20251210 1110, por si OCR elimina separadores
            r"(?<!\d)(\d{2})(\d{2})(20\d{2})\s*(\d{2})(\d{2})(?!\d)",
            r"(?<!\d)(20\d{2})(\d{2})(\d{2})\s*(\d{2})(\d{2})(?!\d)",
        )
        for i, pattern in enumerate(patterns):
            m = re.search(pattern, cleaned)
            if not m:
                continue
            g = m.groups()
            if i == 0:
                d, mo, y, h, mi = g
            elif i == 1:
                y, mo, d, h, mi = g
            elif i == 2:
                d, mo, y, h, mi = g
            else:
                y, mo, d, h, mi = g
            normalized = self._normalize_photo_date(f"{int(d):02d}/{int(mo):02d}/{y} {int(h):02d}:{mi}")
            if normalized:
                return normalized
        return ""

    def _normalize_photo_date(self, value):
        if not value:
            return ""
        text = str(value).strip()
        for fmt in (
            "%Y:%m:%d %H:%M:%S",
            "%Y-%m-%d %H:%M:%S",
            "%Y/%m/%d %H:%M:%S",
            "%Y%m%d_%H%M%S",
            "%d/%m/%Y %H:%M",
            "%d-%m-%Y %H:%M",
            "%d.%m.%Y %H:%M",
        ):
            try:
                dt = datetime.strptime(text, fmt)
                if 2000 <= dt.year <= 2099:
                    return dt.strftime("%d/%m/%Y %H:%M")
            except Exception:
                pass
        return ""

    def _ask_photo_date(self, photo_path, default_value="", destino="al exportar"):
        """Pregunta fecha visible para fotos sin fecha y valida DD/MM/AAAA HH:MM."""
        default_value = default_value or datetime.now().strftime("%d/%m/%Y %H:%M")
        while True:
            text, ok = QInputDialog.getText(
                self,
                "Fecha de la fotografía",
                f"Indica la fecha que se estampará {destino}\nFormato: DD/MM/AAAA HH:MM",
                text=default_value,
            )
            if not ok:
                return ""
            text = " ".join(str(text or "").strip().split())
            try:
                return datetime.strptime(text, "%d/%m/%Y %H:%M").strftime("%d/%m/%Y %H:%M")
            except Exception:
                QMessageBox.warning(self, "Fecha no válida", "Introduce la fecha con formato DD/MM/AAAA HH:MM. Ejemplo: 10/12/2025 11:10")

    def _stamp_visible_date(self, image_path, date_text, escribir_exif=False):
        """Estampa la fecha en la esquina inferior derecha manteniendo formato DD/MM/AAAA HH:MM."""
        try:
            from PIL import Image, ImageDraw, ImageFont, ImageOps
            # V1.7.16: se conserva el EXIF (fecha, GPS, cámara). La foto se
            # gira según su orientación antes de estampar y la orientación
            # queda "normal": antes se perdía todo el EXIF y las fotos
            # verticales de móvil salían giradas.
            original = Image.open(image_path)
            exif = original.getexif()
            img = ImageOps.exif_transpose(original).convert("RGB")
            draw = ImageDraw.Draw(img)
            w, h = img.size
            font_size = max(24, int(w * 0.026))
            font = None
            for candidate in (
                "C:/Windows/Fonts/arial.ttf",
                "C:/Windows/Fonts/segoeui.ttf",
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            ):
                try:
                    font = ImageFont.truetype(candidate, font_size)
                    break
                except Exception:
                    pass
            if font is None:
                font = ImageFont.load_default()
            bbox = draw.textbbox((0, 0), date_text, font=font)
            tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
            margin_x = max(30, int(w * 0.035))
            margin_y = max(24, int(h * 0.045))
            x = w - tw - margin_x
            y = h - th - margin_y
            # sombra suave/contorno para lectura sobre fondo variable
            for dx, dy in ((-2, -2), (-2, 2), (2, -2), (2, 2), (0, 2), (2, 0)):
                draw.text((x + dx, y + dy), date_text, font=font, fill=(0, 0, 0))
            draw.text((x, y), date_text, font=font, fill=(255, 255, 255))
            save_kwargs = {"quality": 95}
            if exif or escribir_exif:
                exif[0x0112] = 1
                if escribir_exif:
                    try:
                        dt = datetime.strptime(date_text, "%d/%m/%Y %H:%M").strftime("%Y:%m:%d %H:%M:00")
                        sub = dict(exif.get_ifd(0x8769))
                        sub[0x9003] = dt
                        sub[0x9004] = dt
                        exif[0x8769] = sub
                    except Exception:
                        pass
                save_kwargs["exif"] = exif.tobytes()
            img.save(image_path, **save_kwargs)
            return True
        except Exception as exc:
            log_message(f"No se pudo estampar fecha en {image_path}: {exc}", Qgis.Warning)
            return False

    def _read_photo_gps_lonlat(self, photo_path):
        """Lee coordenadas GPS EXIF y devuelve (lon, lat) en EPSG:4326."""
        try:
            from PIL import Image, ExifTags
            img = Image.open(photo_path)
            exif = img.getexif()
            if not exif:
                return None
            # V201: el bloque GPS (0x8825) se lee con get_ifd(); con
            # exif.get() las versiones actuales de Pillow devuelven solo un
            # número y nunca se encontraban coordenadas.
            gps_raw = _exif_sub_ifd(exif, 0x8825)
            if not gps_raw:
                return None
            gps = {}
            for key, value in gps_raw.items():
                gps[ExifTags.GPSTAGS.get(key, key)] = value

            def rational_to_float(v):
                try:
                    return float(v[0]) / float(v[1])
                except Exception:
                    return float(v)

            def dms_to_deg(values, ref):
                d = rational_to_float(values[0])
                m = rational_to_float(values[1])
                sec = rational_to_float(values[2])
                deg = d + (m / 60.0) + (sec / 3600.0)
                if str(ref).upper() in ("S", "W"):
                    deg *= -1.0
                return deg

            lat_values = gps.get("GPSLatitude")
            lat_ref = gps.get("GPSLatitudeRef")
            lon_values = gps.get("GPSLongitude")
            lon_ref = gps.get("GPSLongitudeRef")
            if not lat_values or not lon_values or not lat_ref or not lon_ref:
                return None
            lat = dms_to_deg(lat_values, lat_ref)
            lon = dms_to_deg(lon_values, lon_ref)
            # V1.7.16: 0,0 es lo que guardan los móviles sin señal GPS.
            if abs(lat) < 1e-7 and abs(lon) < 1e-7:
                return None
            return (lon, lat)
        except Exception as exc:
            log_message(f"No se pudieron leer coordenadas GPS EXIF de {photo_path}: {exc}", Qgis.Warning)
            return None

    def _layer_counter_key(self, layer):
        """Clave estable para numeración incremental por capa durante la sesión."""
        try:
            source = layer.source() or ""
        except Exception:
            source = ""
        try:
            layer_id = layer.id() or ""
        except Exception:
            layer_id = ""
        return f"{layer.name()}::{source or layer_id}"

    def _next_number(self, layer):
        """Siguiente Nº de la capa: el mayor Nº que tiene AHORA + 1.

        V1.7.16: antes se calculaba una sola vez por sesión y no se enteraba
        de los borrados ni de "Agrupar y renumerar" (podía repetir Nº). Se
        recuerda también el último Nº dado, por si el proveedor tarda en
        devolver la entidad recién añadida."""
        key = self._layer_counter_key(layer)
        max_num = 0
        present = set()
        if FIELD_NUM in [f.name() for f in layer.fields()]:
            for feat in layer.getFeatures():
                try:
                    n = int(feat[FIELD_NUM] or 0)
                except Exception:
                    continue
                present.add(n)
                max_num = max(max_num, n)
        last = self._layer_counters.get(key)
        if last is not None and last > max_num and layer.featureCount() > len(present):
            max_num = last
        self._layer_counters[key] = max_num + 1
        return max_num + 1

    def _fill_list(self, widget, files, current_index):
        widget.clear()
        for i, path in enumerate(files):
            prefix = "▶ " if i == current_index else "   "
            widget.addItem(prefix + os.path.basename(path))
        if 0 <= current_index < widget.count():
            widget.setCurrentRow(current_index)
        if widget is getattr(self, 'list_manual', None):
            self._ajustar_alto_lista(widget)

    def _refresh_status_labels(self):
        if self.informe_actual is None:
            self.lbl_anejo_status.setText("Estado: elige o crea un informe.")
            return
        name = self._anejo_layer_name()
        anejo = self._find_layer(name)
        if anejo is None:
            gpkg = self._project_photo_gpkg_path(name)
            if gpkg and os.path.exists(gpkg):
                self.lbl_anejo_status.setText(f"Estado: {name} guardada junto a la obra (se carga al usarla).")
            else:
                self.lbl_anejo_status.setText(f"Estado: {name} sin fotos todavía (se crea con la primera).")
        else:
            self.lbl_anejo_status.setText(f"Estado: {name} · {anejo.featureCount()} foto(s).")

    def _prefixed_original_name(self, photo_path, prefix, out_dir=None):
        """Devuelve nombre corto y consistente: FR_/IF_ + nombre original.

        Si el archivo de origen ya venía prefijado con FR_ o IF_, se elimina ese
        prefijo previo y se aplica siempre el prefijo del flujo actual. Así una
        foto de puntos_informe no puede salir accidentalmente como FR_ por traer
        ese prefijo en origen, ni una foto normal puede heredar IF_.
        """
        prefix_txt = str(prefix).upper()
        if INFORME_CODE_RE.match(prefix_txt):
            prefix = prefix_txt
        else:
            prefix = "IF" if prefix_txt.startswith("IF") else "FR"
        original = self._safe_filename(os.path.basename(photo_path))
        m = re.match(r"^(FR|IF|IS-?\d{2})_", original, re.IGNORECASE)
        if m:
            original = original[m.end():] or "foto.jpg"
        candidate = f"{prefix}_{original}"

        if not out_dir:
            return candidate

        base, ext = os.path.splitext(candidate)
        final_name = candidate
        i = 2
        while os.path.exists(os.path.join(out_dir, final_name)):
            final_name = f"{base}_{i}{ext}"
            i += 1
        return final_name

    def _safe_filename(self, text):
        # V1.7.16: se admiten letras y números de cualquier idioma ("nº3",
        # "güell") y, al recortar a 120 caracteres, se conserva la extensión.
        out = "".join(c if (c.isalnum() or c in "-_ .") else "_" for c in str(text))
        out = out.strip().replace(" ", "_") or "foto"
        base, ext = os.path.splitext(out)
        if len(out) > 120:
            out = base[:max(1, 120 - len(ext))] + ext
        return out

    def _write_manifest(self, out_dir, rows):
        path = os.path.join(out_dir, "manifest_fotos.csv")
        # V1.7.16: si ya hay un manifiesto en la carpeta (otra capa exportada
        # antes) se conservan sus filas; antes se sobrescribía.
        if os.path.exists(path):
            try:
                with open(path, newline="", encoding="utf-8-sig") as fh:
                    previous = list(csv.DictReader(fh, delimiter=";"))
                new_names = {str(r.get("archivo")) for r in rows}
                rows = [r for r in previous if str(r.get("archivo")) not in new_names] + list(rows)
            except Exception as exc:
                log_message(f"No se pudo leer el manifiesto anterior: {exc}", Qgis.Warning)
        keys = []
        for row in rows:
            for k in row.keys():
                if k not in keys:
                    keys.append(k)
        if not keys:
            keys = ["archivo", "x", "y", "lon", "lat", "exif_gps"]
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=keys, delimiter=";")
            writer.writeheader()
            for row in rows:
                writer.writerow(row)

    def _write_gps_exif_optional(self, jpg_path, lon, lat):
        """Intenta escribir GPS EXIF si piexif está disponible en el Python de QGIS.
        Si no lo está, devuelve False y el CSV mantiene las coordenadas.
        """
        if os.path.splitext(jpg_path)[1].lower() not in (".jpg", ".jpeg"):
            return False
        if lon is None or lat is None:
            return False
        try:
            import piexif  # type: ignore
            def deg_to_dms_rational(deg):
                deg_abs = abs(float(deg))
                d = int(deg_abs)
                m_float = (deg_abs - d) * 60
                m = int(m_float)
                s = round((m_float - m) * 60 * 10000)
                return ((d, 1), (m, 1), (s, 10000))
            exif_dict = piexif.load(jpg_path)
            gps = exif_dict.get("GPS", {})
            gps[piexif.GPSIFD.GPSLatitudeRef] = "N" if lat >= 0 else "S"
            gps[piexif.GPSIFD.GPSLatitude] = deg_to_dms_rational(lat)
            gps[piexif.GPSIFD.GPSLongitudeRef] = "E" if lon >= 0 else "W"
            gps[piexif.GPSIFD.GPSLongitude] = deg_to_dms_rational(lon)
            exif_dict["GPS"] = gps
            piexif.insert(piexif.dump(exif_dict), jpg_path)
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------ Agrupación IF por ubicación
    def _pair_and_renumber_informe_final(self):
        """Agrupa las fotos de informe final en parejas por proximidad geográfica
        y renumera toda la capa puntos_informe correlativamente.

        Regla de numeración:
        - Las fotos IF se agrupan en parejas por cercanía espacial (clustering greedy
          por distancia mínima entre puntos no emparejados).
        - Dentro de cada pareja, el número IMPAR va a la foto más antigua y el número
          PAR a la más reciente.
        - Las fotos no marcadas como IF conservan su orden relativo al final de la
          numeración, sin alterar su contenido.

        Algoritmo de emparejamiento:
        - Se parte de la foto IF más al noroeste (mayor latitud, menor longitud)
          como ancla inicial.
        - Se le asigna como compañera la foto IF más cercana que aún no esté emparejada.
        - Se repite hasta agotar las fotos IF.
        - Si el número de fotos IF es impar, la última queda sola en su pareja.
        """
        layer = self._capa_informe_existente()
        if layer is None or not layer.isValid():
            QMessageBox.warning(self, "Renumeración",
                                "El informe elegido todavía no tiene fotos (o no hay informe elegido).")
            return

        names = [f.name() for f in layer.fields()]
        if FIELD_NUM not in names or FIELD_REPORT not in names:
            QMessageBox.warning(self, "Renumeración",
                                "La capa no tiene los campos esperados (Nº, informe_final).")
            return

        # ── 1. Recoger features ───────────────────────────────────────────────
        if_feats  = []   # marcadas informe_final = 1
        nif_feats = []   # resto

        for feat in layer.getFeatures():
            try:
                is_if = bool(int(feat[FIELD_REPORT] or 0))
            except Exception:
                is_if = False

            geom = feat.geometry()
            if geom and not geom.isEmpty():
                pt = self._point_of(geom)
            else:
                pt = None

            fecha_raw = str(feat[FIELD_DATE] or "").strip() if FIELD_DATE in names else ""

            record = {
                "fid":   feat.id(),
                "pt":    pt,
                "fecha": fecha_raw,
            }
            if is_if:
                if_feats.append(record)
            else:
                nif_feats.append(record)

        if not if_feats:
            QMessageBox.information(self, "Renumeración",
                                    f"No hay fotografías marcadas para el informe en {layer.name()}.")
            return

        n_if = len(if_feats)
        if n_if % 2 != 0:
            resp = QMessageBox.question(
                self,
                "Número impar de fotos",
                f"Hay {n_if} fotos en el informe (número impar).\n"
                "La última pareja quedará incompleta.\n\n¿Continuar igualmente?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if resp != QMessageBox.Yes:
                return

        # ── 2. Parsear fecha a datetime para comparar antigüedad ──────────────
        from datetime import datetime as _dt

        def _parse_fecha(s):
            for fmt in ("%d/%m/%Y %H:%M", "%d/%m/%Y", "%Y-%m-%d %H:%M:%S",
                        "%Y:%m:%d %H:%M:%S", "%Y/%m/%d %H:%M:%S"):
                try:
                    return _dt.strptime(s.strip(), fmt)
                except Exception:
                    pass
            return None  # sin fecha → se tratará como la más reciente

        for r in if_feats:
            r["dt"] = _parse_fecha(r["fecha"])

        # ── 3. Emparejamiento greedy por distancia mínima ─────────────────────
        import math

        def _dist(a, b):
            """Distancia euclidiana en unidades de mapa (suficiente para ordenar)."""
            if a is None or b is None:
                return float("inf")
            return math.hypot(a.x() - b.x(), a.y() - b.y())

        # Ancla inicial: foto más al noroeste (mayor y, menor x como desempate)
        remaining = sorted(
            if_feats,
            key=lambda r: (-(r["pt"].y() if r["pt"] else 0),
                            r["pt"].x() if r["pt"] else 0)
        )

        pairs = []   # lista de [rec_a, rec_b | None]
        used = set()

        while remaining:
            anchor = remaining.pop(0)
            used.add(anchor["fid"])

            best = None
            best_d = float("inf")
            for cand in remaining:
                d = _dist(anchor["pt"], cand["pt"])
                if d < best_d:
                    best_d = d
                    best = cand

            if best is not None:
                remaining.remove(best)
                used.add(best["fid"])
                pairs.append([anchor, best])
            else:
                pairs.append([anchor, None])  # pareja incompleta

        # ── 4. Asignar números: impar → más antigua, par → más reciente ───────
        fid_to_new_num = {}
        counter = 1

        for pair in pairs:
            a, b = pair
            if b is None:
                # Solo una foto en esta pareja: recibe el número impar
                fid_to_new_num[a["fid"]] = counter
                counter += 2  # dejamos hueco par vacío para mantener la lógica
                continue

            dt_a = a["dt"]
            dt_b = b["dt"]

            if dt_a is None and dt_b is None:
                older, newer = a, b   # sin fechas: ancla recibe impar
            elif dt_a is None:
                older, newer = b, a   # b tiene fecha y puede ser más antigua
            elif dt_b is None:
                older, newer = a, b
            else:
                if dt_a <= dt_b:
                    older, newer = a, b
                else:
                    older, newer = b, a

            fid_to_new_num[older["fid"]] = counter       # impar
            fid_to_new_num[newer["fid"]] = counter + 1   # par
            counter += 2

        # ── 5. Números para fotos NO informe final (tras las IF) ─────────────
        nif_by_fid = {r["fid"]: r for r in nif_feats}

        nif_original = []
        for feat in layer.getFeatures():
            fid = feat.id()
            if fid in nif_by_fid:
                try:
                    n = int(feat[FIELD_NUM] or 0)
                except Exception:
                    n = 0
                nif_original.append((n, fid))
        nif_original.sort()

        for _, fid in nif_original:
            fid_to_new_num[fid] = counter
            counter += 1

        # ── 6. Aplicar los nuevos Nº a la capa ───────────────────────────────
        # V201: no se tocan ediciones pendientes del usuario.
        if layer.isEditable() and layer.isModified():
            QMessageBox.warning(
                self, "Renumeración",
                f"La capa {layer.name()} tiene cambios sin guardar. "
                "Guárdalos o descártalos y vuelve a renumerar."
            )
            return
        if layer.isEditable():
            layer.rollBack()
        layer.startEditing()
        try:
            num_idx = layer.fields().indexFromName(FIELD_NUM)
            if num_idx < 0:
                raise ValueError(f"Campo {FIELD_NUM!r} no encontrado en la capa.")

            for fid, new_num in fid_to_new_num.items():
                layer.changeAttributeValue(fid, num_idx, new_num)

            if not layer.commitChanges():
                errors = layer.commitErrors()
                raise RuntimeError("\n".join(errors))
        except Exception as exc:
            layer.rollBack()
            QMessageBox.critical(self, "Renumeración",
                                  f"Error al guardar los cambios:\n{exc}")
            return

        # ── 7. Refrescar simbología y avisar ─────────────────────────────────
        layer.triggerRepaint()
        n_pairs_complete   = sum(1 for p in pairs if p[1] is not None)
        n_pairs_incomplete = sum(1 for p in pairs if p[1] is None)
        msg = (
            f"Renumeración completada.\n"
            f"· {n_if} fotos en {len(pairs)} parejas "
            f"({n_pairs_complete} completas, {n_pairs_incomplete} incompletas).\n"
            f"· {len(nif_feats)} fotos no marcadas para el informe, renumeradas al final."
        )
        QMessageBox.information(self, "Renumeración", msg)
        self.status_callback(
            f"✔ {layer.name()}: renumeración por parejas aplicada ({n_if} fotos → {len(pairs)} parejas)."
        )



class SimpleDocxReport:
    """Generador DOCX mínimo sin dependencia externa python-docx."""
    def __init__(self, out_path):
        self.out_path = out_path
        self.media = []
        self.rels = []
        self.next_rid = 1
        self.next_docpr_id = 1

    def build(self, situation_paths, photo_pairs, photo_layout="parallel", summary_lines=None, title="ANEJO FOTOGRÁFICO"):
        """V1.7.30: situation_paths = [(png, escala)] (o rutas sueltas); photo_pairs =
        [(foto impar | None, foto par | None)] ya agrupadas por Nº."""
        self.media = []
        self.rels = []
        self.next_rid = 1
        self.next_docpr_id = 1
        if isinstance(situation_paths, str):
            situation_paths = [situation_paths]
        situation_paths = [sp if isinstance(sp, (tuple, list)) else (sp, None) for sp in (situation_paths or [])]
        photo_pairs = self._normalizar_parejas(photo_pairs)
        summary_lines = summary_lines or []
        body = []
        body.append(self._p(title or "ANEJO FOTOGRÁFICO", bold=True, size=26, align="center"))
        total_maps = len(situation_paths)
        for idx, (situation_path, escala) in enumerate(situation_paths, start=1):
            # v158: los planos generales no llevan título superior. Solo se
            # mantiene el pie bajo el plano y se intenta colocar dos planos por
            # página cuando la altura real del documento lo permita.
            body.append(self._image_paragraph(situation_path, width_cm=PLANO_ANCHO_CM, align="center"))
            pie = f"Localización de las fotos de los emplazamientos {idx}/{total_maps}"
            if escala:
                pie += f" · Escala 1:{_fmt_miles(escala)}"
            body.append(self._p(pie, size=18, align="center"))
            if idx == total_maps and summary_lines:
                body.append(self._p("Resumen de fotografías", bold=True, size=20, align="left"))
                for line in summary_lines:
                    body.append(self._bullet_p(line, size=18))
            if total_maps and (idx % 2 == 0 or idx == total_maps):
                body.append(self._page_break())
        if not situation_paths and summary_lines:
            body.append(self._p("Resumen de fotografías", bold=True, size=20, align="left"))
            for line in summary_lines:
                body.append(self._bullet_p(line, size=18))
            body.append(self._page_break())
        if photo_layout == "vertical":
            # v162: en disposición vertical se evita anidar tablas dentro de
            # celdas, porque Word puede reparar el DOCX. Se usa una tabla
            # global plana y se aplica keepNext/cantSplit para mantener la
            # pareja junta siempre que sea posible.
            body.append(self._photo_vertical_pairs_global_table(photo_pairs, max_width_cm=12.0, min_width_cm=7.0))
        else:
            # v158: una única tabla global con parejas horizontales. Cada pareja
            # ocupa dos filas: imágenes y pies de foto. Se intenta colocar hasta
            # tres parejas por página manteniendo el ancho de 8 cm por foto.
            body.append(self._photo_pairs_global_table(photo_pairs, width_cm=8.0, pairs_per_page=3))
        self._write_zip(self._document_xml("".join(body)))

    @staticmethod
    def _normalizar_parejas(items):
        """Acepta parejas [(a, b)] o, por compatibilidad, una lista de filas (por posición)."""
        items = list(items or [])
        if items and isinstance(items[0], dict):
            return [(items[i], items[i + 1] if i + 1 < len(items) else None) for i in range(0, len(items), 2)]
        return [tuple(p) for p in items]

    def _write_zip(self, document_xml):
        with zipfile.ZipFile(self.out_path, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml", self._content_types())
            z.writestr("_rels/.rels", self._root_rels())
            z.writestr("word/document.xml", document_xml)
            z.writestr("word/_rels/document.xml.rels", self._document_rels())
            z.writestr("docProps/core.xml", self._core_props())
            z.writestr("docProps/app.xml", self._app_props())
            for item in self.media:
                z.write(item["src"], "word/media/" + item["name"])

    def _add_image(self, path):
        ext = os.path.splitext(path)[1].lower().lstrip(".") or "png"
        if ext == "jpeg":
            ext = "jpg"
        media_name = "image%d.%s" % (len(self.media) + 1, ext)
        rid = "rId%d" % self.next_rid
        self.next_rid += 1
        self.media.append({"src": path, "name": media_name, "ext": ext})
        self.rels.append((rid, "media/" + media_name))
        return rid

    def _image_paragraph(self, path, width_cm=7.4, align="center", keep_next=False):
        rid = self._add_image(path)
        width_emu = int(width_cm / 2.54 * 914400)
        img = QImage(path)
        width_px, height_px = img.width(), img.height()
        height_emu = int(width_emu * height_px / width_px) if width_px > 0 and height_px > 0 else int(width_emu * 0.66)
        docpr_id = self.next_docpr_id
        self.next_docpr_id += 1
        return self._p_raw(self._drawing(rid, width_emu, height_emu, docpr_id), align=align, keep_next=keep_next)

    def _photo_pairs_global_table(self, pairs, width_cm=8.0, pairs_per_page=3):
        """Tabla global de parejas en horizontal.

        v157: todas las parejas pertenecen a una única tabla. Cada pareja usa
        una fila para imágenes y otra fila independiente para pies de foto. Las
        imágenes se alinean abajo dentro de la celda y los pies quedan centrados
        con altura automática.
        """
        trs = []
        pair_index = 0
        total_pairs = len(pairs)
        for left, right in pairs:
            pair_index += 1
            left_img = self._photo_image_content(left, width_cm=width_cm) if left else self._p("", size=16)
            right_img = self._photo_image_content(right, width_cm=width_cm) if right else self._p("", size=16)
            left_cap = self._photo_caption_content(left) if left else self._p("", size=16, align="center")
            right_cap = self._photo_caption_content(right) if right else self._p("", size=16, align="center")
            trs.append(self._tr_cells([left_img, right_img], valign="bottom"))
            trs.append(self._tr_cells([left_cap, right_cap], valign="center"))
            if pairs_per_page and pair_index % pairs_per_page == 0 and pair_index < total_pairs:
                # Page break inside the global table: keeps one continuous table
                # while starting the next group of up to three pairs on a new page.
                trs.append(self._tr_page_break(columns=2))
        return self._table_xml(trs, columns=2)

    def _photo_vertical_global_table(self, rows, width_cm=12.0):
        """Compatibilidad interna: tabla global de fotografías en vertical."""
        trs = []
        for row in rows:
            trs.append(self._tr_single(self._photo_image_content(row, width_cm=width_cm), width_dxa="9000", valign="center", cant_split=True))
            trs.append(self._tr_single(self._photo_caption_content(row), width_dxa="9000", valign="center", cant_split=True))
        return self._table_xml(trs, columns=1)

    def _photo_vertical_pairs_global_table(self, pairs, max_width_cm=12.0, min_width_cm=7.0):
        """Tabla global vertical manteniendo cada pareja junta sin corromper DOCX.

        v162: se elimina la tabla anidada de v161. Word puede considerar no
        legible un DOCX cuando una tabla completa se inserta directamente dentro
        de una celda generada a mano. Esta versión usa una única tabla plana:
        foto, pie, foto, pie. Para cada pareja se aplica cantSplit a las filas y
        keepNext a los párrafos internos, de modo que Word intente mantener las
        cuatro filas de la pareja en la misma página. El ancho se calcula por
        pareja y puede reducirse hasta min_width_cm si hace falta.
        """
        trs = []
        total_pairs = len(pairs)
        pair_index = 0
        for pareja in pairs:
            pair_index += 1
            pair = [r for r in pareja if r]
            width_cm = self._best_vertical_pair_width(pair, max_width_cm=max_width_cm, min_width_cm=min_width_cm)
            for idx, row in enumerate(pair):
                # keepNext en todas las filas salvo el último pie de la pareja.
                # cantSplit evita que Word parta una fila con imagen/pie.
                keep_next = not (idx == len(pair) - 1)
                trs.append(self._tr_single(
                    self._photo_image_content(row, width_cm=width_cm, keep_next=True),
                    width_dxa="9000", valign="center", cant_split=True
                ))
                trs.append(self._tr_single(
                    self._photo_caption_content(row, keep_next=keep_next),
                    width_dxa="9000", valign="center", cant_split=True
                ))
            if pair_index < total_pairs:
                # Separación ligera entre parejas sin forzar salto de página.
                trs.append(self._tr_single(self._p("", size=4), width_dxa="9000", valign="center"))
        return self._table_xml(trs, columns=1)

    def _best_vertical_pair_width(self, pair, max_width_cm=12.0, min_width_cm=7.0):
        """Devuelve el mayor ancho que permite conservar la pareja en página."""
        ratios = []
        for row in pair or []:
            path = row.get("path") if isinstance(row, dict) else None
            img = QImage(path) if path else QImage()
            if img.width() > 0 and img.height() > 0:
                ratios.append(float(img.height()) / float(img.width()))
            else:
                ratios.append(0.75)
        if not ratios:
            return max_width_cm
        # A4 vertical con márgenes del documento: se reserva espacio para los
        # pies, márgenes de tabla y tolerancia de Word.
        available_image_height_cm = 22.2
        required_width = available_image_height_cm / max(0.1, sum(ratios))
        return max(float(min_width_cm), min(float(max_width_cm), required_width))

    def _photo_image_content(self, row, width_cm, keep_next=False):
        return self._image_paragraph(row["path"], width_cm=width_cm, align="center", keep_next=keep_next)

    def _photo_caption_content(self, row, keep_next=False):
        cap_text = "Foto %s.    %s" % (row["num"], row["desc"]) if row.get("num") else row.get("desc", "")
        return self._p(cap_text, bold_num=True, size=16, align="center", keep_next=keep_next)

    def _table_xml(self, rows_xml, columns=2):
        grid = '<w:tblGrid>' + ''.join('<w:gridCol w:w="4500"/>' for _ in range(max(1, columns))) + '</w:tblGrid>'
        props = (
            '<w:tblPr>'
            '<w:tblW w:w="0" w:type="auto"/>'
            '<w:jc w:val="center"/>'
            '<w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/><w:insideH w:val="nil"/><w:insideV w:val="nil"/></w:tblBorders>'
            '<w:tblCellMar><w:left w:w="120" w:type="dxa"/><w:right w:w="120" w:type="dxa"/><w:top w:w="80" w:type="dxa"/><w:bottom w:w="80" w:type="dxa"/></w:tblCellMar>'
            '</w:tblPr>'
        )
        return '<w:tbl>' + props + grid + ''.join(rows_xml) + '</w:tbl>'

    def _tr(self, left, right):
        return self._tr_cells([left, right], valign="bottom")

    def _tr_cells(self, cells, valign="bottom", width_dxa="4500", cant_split=False):
        tr_pr = '<w:trPr><w:cantSplit/></w:trPr>' if cant_split else ''
        return '<w:tr>' + tr_pr + ''.join(self._tc(cell, width_dxa=width_dxa, valign=valign) for cell in cells) + '</w:tr>'

    def _tr_single(self, content, width_dxa="9000", valign="center", cant_split=False):
        tr_pr = '<w:trPr><w:cantSplit/></w:trPr>' if cant_split else ''
        return '<w:tr>' + tr_pr + self._tc(content, width_dxa=width_dxa, valign=valign) + '</w:tr>'

    def _tr_page_break(self, columns=2):
        span = max(1, int(columns or 1))
        tc_pr = '<w:tcPr><w:gridSpan w:val="%s"/><w:vAlign w:val="center"/></w:tcPr>' % span
        return '<w:tr><w:tc>' + tc_pr + self._page_break() + '</w:tc></w:tr>'

    def _tc(self, content, width_dxa="4500", valign="bottom"):
        # v156: w:vAlign controla la alineación vertical de la celda. En las
        # parejas en paralelo se usa bottom para que, si una foto es más baja
        # que la otra, ambas apoyen visualmente en la parte inferior.
        return '<w:tc><w:tcPr><w:tcW w:w="%s" w:type="dxa"/><w:vAlign w:val="%s"/></w:tcPr>' % (width_dxa, valign) + content + '</w:tc>'

    def _bullet_p(self, text, size=18):
        return self._p("•  " + str(text), size=size, align=None)

    def _p(self, text, bold=False, bold_num=False, size=20, align=None, keep_next=False):
        text = xml_escape(str(text))
        if bold_num and text.startswith("Foto ") and "." in text:
            prefix, rest = text.split(".", 1)
            return self._p_raw(self._run(prefix + ".", bold=True, size=size) + self._run(rest, bold=False, size=size), align=align, keep_next=keep_next)
        return self._p_raw(self._run(text, bold=bold, size=size), align=align, keep_next=keep_next)

    def _p_raw(self, raw_runs, align=None, keep_next=False):
        ppr_items = []
        if keep_next:
            ppr_items.append('<w:keepNext/>')
        if align:
            ppr_items.append('<w:jc w:val="%s"/>' % align)
        ppr = '<w:pPr>' + ''.join(ppr_items) + '</w:pPr>' if ppr_items else ''
        return '<w:p>' + ppr + raw_runs + '</w:p>' 

    def _run(self, text, bold=False, size=20):
        b = '<w:b/>' if bold else ''
        return '<w:r><w:rPr>%s<w:sz w:val="%s"/><w:szCs w:val="%s"/></w:rPr><w:t xml:space="preserve">%s</w:t></w:r>' % (b, size, size, text)

    def _page_break(self):
        return '<w:p><w:r><w:br w:type="page"/></w:r></w:p>'

    def _drawing(self, rid, cx, cy, docpr_id):
        name = "Imagen %s" % int(docpr_id)
        return '<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="%s" cy="%s"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:docPr id="%s" name="%s"/><wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/></wp:cNvGraphicFramePr><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="%s" name="%s"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%s" cy="%s"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>' % (cx, cy, docpr_id, name, docpr_id, name, rid, cx, cy)

    def _document_xml(self, body):
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>' + body + '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="900" w:right="900" w:bottom="900" w:left="900" w:header="450" w:footer="450" w:gutter="0"/></w:sectPr></w:body></w:document>'

    def _content_types(self):
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Default Extension="jpg" ContentType="image/jpeg"/><Default Extension="jpeg" ContentType="image/jpeg"/><Default Extension="tif" ContentType="image/tiff"/><Default Extension="tiff" ContentType="image/tiff"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>'

    def _root_rels(self):
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>'

    def _document_rels(self):
        items = ['<Relationship Id="%s" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="%s"/>' % (rid, target) for rid, target in self.rels]
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + ''.join(items) + '</Relationships>'

    def _core_props(self):
        now = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>Anejo Fotográfico</dc:title><dc:creator>OBRA_NUEVA</dc:creator><cp:lastModifiedBy>OBRA_NUEVA</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">' + now + '</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">' + now + '</dcterms:modified></cp:coreProperties>'

    def _app_props(self):
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>OBRA_NUEVA</Application></Properties>'

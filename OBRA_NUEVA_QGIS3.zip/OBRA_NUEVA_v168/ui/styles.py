# -*- coding: utf-8 -*-
"""
OBRA_NUEVA - Hoja de estilos visual global
Paleta profesional azul/gris oscuro inspirada en herramientas GIS de ingeniería.
"""

# ── Paleta de colores ──────────────────────────────────────────────────────────
COLOR = {
    "bg":           "#1E2433",   # fondo principal (azul noche)
    "bg_surface":   "#252D3D",   # fondo de paneles / groupbox
    "bg_input":     "#1A2030",   # fondo de campos de texto
    "bg_hover":     "#2E3A52",   # hover en botones secundarios
    "bg_selected":  "#1A3560",   # fila/ítem seleccionado

    "accent":       "#4A90D9",   # azul primario (botones principales)
    "accent_hover": "#5BA3E8",   # hover de botones principales
    "accent_press": "#3A7ABF",   # pressed de botones principales

    "success":      "#27AE60",   # verde éxito
    "warning":      "#E67E22",   # naranja advertencia
    "danger":       "#E74C3C",   # rojo peligro

    "border":       "#374461",   # borde general
    "border_focus": "#4A90D9",   # borde cuando el campo tiene foco

    "text":         "#E8EDF5",   # texto principal
    "text_muted":   "#8A9BBE",   # texto secundario / labels
    "text_disabled":"#4A5568",   # texto deshabilitado

    "tab_active":   "#4A90D9",   # línea inferior de pestaña activa
    "tab_bg":       "#1E2433",   # fondo de pestañas inactivas
    "tab_hover":    "#2E3A52",   # hover de pestaña

    "console_bg":   "#141820",   # fondo consola de estado
    "console_text": "#7EC8A8",   # texto consola (verde terminal)

    "header_bg":    "#131926",   # fondo de la cabecera del diálogo
    "scrollbar":    "#374461",   # scrollbar track
    "scrollbar_h":  "#4A90D9",   # scrollbar handle
}

FONT_FAMILY = "Segoe UI, Roboto, Arial, sans-serif"
FONT_SIZE_BASE = 9         # pt — tamaño base para QGIS
FONT_SIZE_SMALL = 8
FONT_SIZE_TITLE = 11
RADIUS = "6px"
RADIUS_SM = "4px"
BORDER_WIDTH = "1px"


def get_stylesheet() -> str:
    """Devuelve el QSS completo para aplicar al diálogo principal."""
    c = COLOR
    return f"""

/* ═══════════════════════════════════════════════
   DIÁLOGO PRINCIPAL
═══════════════════════════════════════════════ */
QDialog {{
    background-color: {c['bg']};
    color: {c['text']};
    font-family: {FONT_FAMILY};
    font-size: {FONT_SIZE_BASE}pt;
}}

QWidget {{
    background-color: {c['bg']};
    color: {c['text']};
    font-family: {FONT_FAMILY};
    font-size: {FONT_SIZE_BASE}pt;
}}

/* ═══════════════════════════════════════════════
   CABECERA
═══════════════════════════════════════════════ */
QWidget#header_widget {{
    background-color: {c['header_bg']};
    border-bottom: 2px solid {c['accent']};
    padding: 4px 8px;
}}

/* ═══════════════════════════════════════════════
   PESTAÑAS (QTabWidget / QTabBar)
═══════════════════════════════════════════════ */
QTabWidget::pane {{
    border: {BORDER_WIDTH} solid {c['border']};
    border-top: 2px solid {c['border']};
    background-color: {c['bg_surface']};
    border-radius: 0px 0px {RADIUS} {RADIUS};
}}

QTabBar {{
    background-color: {c['bg']};
    border: none;
}}

QTabBar::tab {{
    background-color: {c['tab_bg']};
    color: {c['text_muted']};
    border: {BORDER_WIDTH} solid {c['border']};
    border-bottom: none;
    padding: 7px 20px;
    margin-right: 2px;
    border-radius: {RADIUS_SM} {RADIUS_SM} 0px 0px;
    font-size: {FONT_SIZE_BASE}pt;
    font-weight: normal;
    min-width: 90px;
}}

QTabBar::tab:hover {{
    background-color: {c['tab_hover']};
    color: {c['text']};
}}

QTabBar::tab:selected {{
    background-color: {c['bg_surface']};
    color: {c['text']};
    font-weight: bold;
    border-top: 2px solid {c['accent']};
    border-left: {BORDER_WIDTH} solid {c['border']};
    border-right: {BORDER_WIDTH} solid {c['border']};
    border-bottom: none;
    padding-bottom: 8px;
}}

/* ═══════════════════════════════════════════════
   GROUPBOX
═══════════════════════════════════════════════ */
QGroupBox {{
    background-color: {c['bg_surface']};
    border: {BORDER_WIDTH} solid {c['border']};
    border-radius: {RADIUS};
    margin-top: 14px;
    padding: 8px 10px 8px 10px;
    font-weight: bold;
    color: {c['text_muted']};
    font-size: {FONT_SIZE_SMALL}pt;
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 10px;
    top: -2px;
    padding: 0 6px;
    background-color: {c['bg_surface']};
    color: {c['accent']};
    font-size: {FONT_SIZE_SMALL}pt;
    font-weight: bold;
    letter-spacing: 0.5px;
    text-transform: uppercase;
}}

/* ═══════════════════════════════════════════════
   CAMPOS DE TEXTO (QLineEdit / QTextEdit)
═══════════════════════════════════════════════ */
QLineEdit {{
    background-color: {c['bg_input']};
    color: {c['text']};
    border: {BORDER_WIDTH} solid {c['border']};
    border-radius: {RADIUS_SM};
    padding: 4px 8px;
    selection-background-color: {c['accent']};
    selection-color: #ffffff;
    font-size: {FONT_SIZE_BASE}pt;
}}

QLineEdit:focus {{
    border: {BORDER_WIDTH} solid {c['border_focus']};
    background-color: {c['bg_input']};
}}

QLineEdit:disabled {{
    color: {c['text_disabled']};
    background-color: {c['bg']};
    border-color: {c['border']};
}}

QLineEdit:read-only {{
    color: {c['text_muted']};
    background-color: {c['bg']};
}}

QTextEdit {{
    background-color: {c['bg_input']};
    color: {c['text']};
    border: {BORDER_WIDTH} solid {c['border']};
    border-radius: {RADIUS_SM};
    padding: 4px;
    selection-background-color: {c['accent']};
    font-size: {FONT_SIZE_BASE}pt;
}}

QTextEdit:focus {{
    border: {BORDER_WIDTH} solid {c['border_focus']};
}}

/* Consola de estado: estilo terminal */
QTextEdit#status_console {{
    background-color: {c['console_bg']};
    color: {c['console_text']};
    border: {BORDER_WIDTH} solid {c['border']};
    border-top: 2px solid {c['border']};
    border-radius: 0px;
    font-family: "Consolas", "Courier New", monospace;
    font-size: {FONT_SIZE_SMALL}pt;
    padding: 4px 8px;
}}

/* ═══════════════════════════════════════════════
   BOTONES
═══════════════════════════════════════════════ */

/* --- Botón primario (run / ejecutar / cargar) --- */
QPushButton {{
    background-color: {c['bg_hover']};
    color: {c['text']};
    border: {BORDER_WIDTH} solid {c['border']};
    border-radius: {RADIUS_SM};
    padding: 5px 14px;
    font-size: {FONT_SIZE_BASE}pt;
    font-weight: normal;
    min-height: 22px;
}}

QPushButton:hover {{
    background-color: {c['bg_hover']};
    border-color: {c['accent']};
    color: {c['text']};
}}

QPushButton:pressed {{
    background-color: {c['accent_press']};
    border-color: {c['accent_press']};
    color: #ffffff;
}}

QPushButton:disabled {{
    background-color: {c['bg']};
    color: {c['text_disabled']};
    border-color: {c['border']};
}}

/* Botones de acción principal: Ejecutar / Cargar / Exportar */
QPushButton[class="primary"],
QPushButton#run_btn,
QPushButton#btn_run,
QPushButton#btn_export,
QPushButton#btn_create {{
    background-color: {c['accent']};
    color: #ffffff;
    border: none;
    border-radius: {RADIUS_SM};
    padding: 6px 18px;
    font-weight: bold;
    min-width: 90px;
}}

QPushButton[class="primary"]:hover,
QPushButton#run_btn:hover,
QPushButton#btn_run:hover,
QPushButton#btn_export:hover,
QPushButton#btn_create:hover {{
    background-color: {c['accent_hover']};
}}

QPushButton[class="primary"]:pressed,
QPushButton#run_btn:pressed,
QPushButton#btn_run:pressed,
QPushButton#btn_export:pressed,
QPushButton#btn_create:pressed {{
    background-color: {c['accent_press']};
}}

/* Botón Ayuda */
QPushButton#btn_help {{
    background-color: transparent;
    color: {c['text_muted']};
    border: {BORDER_WIDTH} solid {c['border']};
    border-radius: {RADIUS_SM};
    padding: 4px 12px;
    font-size: {FONT_SIZE_SMALL}pt;
}}

QPushButton#btn_help:hover {{
    color: {c['text']};
    border-color: {c['accent']};
    background-color: {c['bg_hover']};
}}

/* ═══════════════════════════════════════════════
   ETIQUETAS (QLabel)
═══════════════════════════════════════════════ */
QLabel {{
    color: {c['text_muted']};
    background-color: transparent;
    font-size: {FONT_SIZE_BASE}pt;
}}

QLabel[class="title"] {{
    color: {c['text']};
    font-size: {FONT_SIZE_TITLE}pt;
    font-weight: bold;
}}

QLabel[class="subtitle"] {{
    color: {c['text_muted']};
    font-size: {FONT_SIZE_SMALL}pt;
}}

/* ═══════════════════════════════════════════════
   CHECKBOXES
═══════════════════════════════════════════════ */
QCheckBox {{
    color: {c['text']};
    spacing: 6px;
    font-size: {FONT_SIZE_BASE}pt;
    background-color: transparent;
}}

QCheckBox::indicator {{
    width: 14px;
    height: 14px;
    border-radius: 3px;
    border: {BORDER_WIDTH} solid {c['border']};
    background-color: {c['bg_input']};
}}

QCheckBox::indicator:checked {{
    background-color: {c['accent']};
    border-color: {c['accent']};
    image: none;
}}

QCheckBox::indicator:hover {{
    border-color: {c['accent']};
}}

QCheckBox:disabled {{
    color: {c['text_disabled']};
}}

/* ═══════════════════════════════════════════════
   COMBOBOX
═══════════════════════════════════════════════ */
QComboBox {{
    background-color: {c['bg_input']};
    color: {c['text']};
    border: {BORDER_WIDTH} solid {c['border']};
    border-radius: {RADIUS_SM};
    padding: 4px 8px;
    min-height: 22px;
    font-size: {FONT_SIZE_BASE}pt;
}}

QComboBox:focus {{
    border-color: {c['border_focus']};
}}

QComboBox::drop-down {{
    border: none;
    width: 22px;
    background-color: {c['bg_hover']};
    border-left: {BORDER_WIDTH} solid {c['border']};
    border-radius: 0px {RADIUS_SM} {RADIUS_SM} 0px;
}}

QComboBox::down-arrow {{
    width: 10px;
    height: 10px;
}}

QComboBox QAbstractItemView {{
    background-color: {c['bg_surface']};
    color: {c['text']};
    border: {BORDER_WIDTH} solid {c['border']};
    selection-background-color: {c['bg_selected']};
    selection-color: {c['text']};
    outline: none;
}}

/* ═══════════════════════════════════════════════
   LISTAS (QListWidget / QTreeWidget)
═══════════════════════════════════════════════ */
QListWidget, QTreeWidget {{
    background-color: {c['bg_input']};
    color: {c['text']};
    border: {BORDER_WIDTH} solid {c['border']};
    border-radius: {RADIUS_SM};
    outline: none;
    font-size: {FONT_SIZE_BASE}pt;
    alternate-background-color: {c['bg_surface']};
}}

QListWidget::item, QTreeWidget::item {{
    padding: 4px 6px;
    border-radius: 2px;
    color: {c['text']};
}}

QListWidget::item:hover, QTreeWidget::item:hover {{
    background-color: {c['bg_hover']};
}}

QListWidget::item:selected, QTreeWidget::item:selected {{
    background-color: {c['bg_selected']};
    color: {c['text']};
    border-left: 2px solid {c['accent']};
}}

QTreeWidget::branch {{
    background-color: {c['bg_input']};
}}

/* ═══════════════════════════════════════════════
   BARRA DE PROGRESO
═══════════════════════════════════════════════ */
QProgressBar {{
    background-color: {c['bg_input']};
    color: {c['text']};
    border: {BORDER_WIDTH} solid {c['border']};
    border-radius: {RADIUS_SM};
    text-align: center;
    font-size: {FONT_SIZE_SMALL}pt;
}}

QProgressBar::chunk {{
    background-color: {c['accent']};
    border-radius: {RADIUS_SM};
}}

QHeaderView::section {{
    background-color: {c['bg_surface']};
    color: {c['text_muted']};
    border: none;
    border-bottom: {BORDER_WIDTH} solid {c['border']};
    padding: 4px 6px;
    font-weight: bold;
    font-size: {FONT_SIZE_SMALL}pt;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}}

/* ═══════════════════════════════════════════════
   SCROLL AREA
═══════════════════════════════════════════════ */
QScrollArea {{
    background-color: {c['bg_surface']};
    border: none;
}}

QScrollBar:vertical {{
    background-color: {c['bg']};
    width: 8px;
    border-radius: 4px;
    margin: 0;
}}

QScrollBar::handle:vertical {{
    background-color: {c['scrollbar']};
    border-radius: 4px;
    min-height: 30px;
}}

QScrollBar::handle:vertical:hover {{
    background-color: {c['scrollbar_h']};
}}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0px;
}}

QScrollBar:horizontal {{
    background-color: {c['bg']};
    height: 8px;
    border-radius: 4px;
    margin: 0;
}}

QScrollBar::handle:horizontal {{
    background-color: {c['scrollbar']};
    border-radius: 4px;
    min-width: 30px;
}}

QScrollBar::handle:horizontal:hover {{
    background-color: {c['scrollbar_h']};
}}

QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
    width: 0px;
}}

/* ═══════════════════════════════════════════════
   SPLITTER
═══════════════════════════════════════════════ */
QSplitter::handle {{
    background-color: {c['border']};
}}

/* ═══════════════════════════════════════════════
   DIÁLOGOS HIJOS (QMessageBox, etc.)
═══════════════════════════════════════════════ */
QMessageBox {{
    background-color: {c['bg_surface']};
    color: {c['text']};
}}

QMessageBox QLabel {{
    color: {c['text']};
}}

/* ═══════════════════════════════════════════════
   TOOLTIP
═══════════════════════════════════════════════ */
QToolTip {{
    background-color: {c['bg_surface']};
    color: {c['text']};
    border: {BORDER_WIDTH} solid {c['accent']};
    border-radius: {RADIUS_SM};
    padding: 4px 8px;
    font-size: {FONT_SIZE_SMALL}pt;
}}

/* ═══════════════════════════════════════════════
   DIALOG BUTTON BOX
═══════════════════════════════════════════════ */
QDialogButtonBox QPushButton {{
    min-width: 80px;
    padding: 5px 14px;
}}

"""

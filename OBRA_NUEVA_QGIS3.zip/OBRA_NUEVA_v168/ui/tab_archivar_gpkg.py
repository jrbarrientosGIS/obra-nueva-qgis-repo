# -*- coding: utf-8 -*-
import os

from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QFileDialog, QTextEdit, QMessageBox, QFrame, QProgressBar, QApplication,
)

from ..core.settings_manager import SettingsManager
from ..core.gpkg_archiver import archive_gpkg, GpkgArchiveError
from ..core.gpkg_utils import primary_loaded_gpkg_path


class ArchivarGpkgTab(QWidget):
    """Pestaña 'Archivar GPKG': copia un GeoPackage ya terminado a una
    carpeta de archivo/consulta (p. ej. una carpeta de "GPKG listos para
    consulta", separada de la carpeta de trabajo con cientos de obras),
    dejando sus documentos y fotos adjuntos (Ficha, Foto 1-4, Doc_Apertura,
    Doc_Cierre...) perfectamente accesibles desde la copia -- sin mover ni
    duplicar los ficheros originales: sus rutas se reescriben como
    absolutas apuntando a donde ya están."""

    def __init__(self, iface, status_callback, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.status_callback = status_callback
        self.settings = SettingsManager()
        self._src_gpkg_user_chosen = False  # True en cuanto el usuario elige/escribe uno a mano
        self._build_ui()
        self._restore_state()

    # ── UI ───────────────────────────────────────────────────────────────
    def _build_ui(self):
        layout = QVBoxLayout(self)

        intro = QLabel(
            "Copia un GeoPackage ya terminado a una carpeta de archivo, dejando sus documentos y "
            "fotos adjuntos (Ficha, Foto 1-4, Doc_Apertura, Doc_Cierre...) perfectamente accesibles "
            "desde la copia -- sin mover ni duplicar los ficheros originales, que se quedan donde ya "
            "estaban."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        src_row = QHBoxLayout()
        src_row.addWidget(QLabel("GeoPackage a archivar:"))
        self.src_edit = QLineEdit()
        self.src_edit.setPlaceholderText("Selecciona el GeoPackage terminado…")
        src_row.addWidget(self.src_edit)
        self.src_btn = QPushButton("…")
        self.src_btn.setFixedWidth(36)
        src_row.addWidget(self.src_btn)
        layout.addLayout(src_row)

        dest_row = QHBoxLayout()
        dest_row.addWidget(QLabel("Carpeta de destino:"))
        self.dest_edit = QLineEdit()
        self.dest_edit.setPlaceholderText("Selecciona la carpeta donde se archivará la copia…")
        dest_row.addWidget(self.dest_edit)
        self.dest_btn = QPushButton("…")
        self.dest_btn.setFixedWidth(36)
        dest_row.addWidget(self.dest_btn)
        layout.addLayout(dest_row)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Plain)
        layout.addWidget(line)

        layout.addWidget(QLabel("Registro:"))
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        layout.addWidget(self.log_box, 1)

        self.progress = QProgressBar()
        self.progress.setTextVisible(True)
        self._set_progress_idle("Sin archivar")
        layout.addWidget(self.progress)

        footer = QHBoxLayout()
        self.archive_btn = QPushButton("🗄  Archivar GPKG")
        self.archive_btn.setObjectName("run_btn")
        footer.addStretch(1)
        footer.addWidget(self.archive_btn)
        layout.addLayout(footer)

        self.src_btn.clicked.connect(self.choose_source)
        self.dest_btn.clicked.connect(self.choose_dest)
        self.src_edit.textEdited.connect(self._on_src_edit_user_edited)
        self.archive_btn.clicked.connect(self.run_archive)

    def _restore_state(self):
        self.src_edit.setText(self.settings.get('archivar/src_gpkg', '') or '')
        self.dest_edit.setText(self.settings.get('archivar/dest_folder', '') or '')
        self.refresh_project_default()

    def refresh_project_default(self):
        """Si hay algún GeoPackage cargado en el proyecto QGIS actual, lo
        propone por defecto en el campo del GeoPackage a archivar -- tiene
        prioridad sobre el último recordado de una sesión anterior, para
        que el campo muestre siempre, de entrada, el que ya está abierto
        en el lienzo. Deja de aplicarse en cuanto el usuario elige o
        escribe una ruta a mano; volver a vaciar el campo reactiva el
        relleno automático."""
        if self._src_gpkg_user_chosen:
            return
        default_path = primary_loaded_gpkg_path()
        if default_path:
            self.src_edit.setText(default_path)

    def _on_src_edit_user_edited(self, text):
        self._src_gpkg_user_chosen = bool(text.strip())

    # ── Utilidades ───────────────────────────────────────────────────────
    def _set_progress_idle(self, text=""):
        """Barra estática (sin animar), vacía: para cuando NO se está
        archivando (al abrir la pestaña, tras un error, tras cancelar)."""
        self.progress.setMinimum(0)
        self.progress.setMaximum(1)
        self.progress.setValue(0)
        self.progress.setFormat(text)

    def _set_progress_busy(self, text=""):
        """Modo "ocupado" de Qt (mínimo y máximo a 0): la barra se anima
        sola. Debe usarse SOLO mientras el archivado está realmente en
        curso, nunca en reposo."""
        self.progress.setMinimum(0)
        self.progress.setMaximum(0)
        self.progress.setValue(0)
        self.progress.setFormat(text)

    def _set_progress_done(self, text=""):
        self.progress.setMinimum(0)
        self.progress.setMaximum(1)
        self.progress.setValue(1)
        self.progress.setFormat(text)

    def log(self, message):
        self.log_box.append(str(message))
        try:
            self.status_callback(message)
        except Exception:
            pass

    def choose_source(self):
        last = self.settings.get('archivar/src_gpkg', '') or ''
        path, _ = QFileDialog.getOpenFileName(self, "Seleccionar GeoPackage a archivar", last, "GeoPackage (*.gpkg)")
        if path:
            self._src_gpkg_user_chosen = True
            self.src_edit.setText(path)
            self.settings.set('archivar/src_gpkg', path)

    def choose_dest(self):
        last = self.settings.get('archivar/dest_folder', '') or ''
        path = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta de destino", last)
        if path:
            self.dest_edit.setText(path)
            self.settings.set('archivar/dest_folder', path)

    # ── Archivar ─────────────────────────────────────────────────────────
    def run_archive(self):
        source_path = self.src_edit.text().strip()
        dest_folder = self.dest_edit.text().strip()

        if not source_path or not os.path.isfile(source_path):
            QMessageBox.warning(self, "Archivar GPKG", "Selecciona un GeoPackage válido.")
            return
        if not dest_folder or not os.path.isdir(dest_folder):
            QMessageBox.warning(self, "Archivar GPKG", "Selecciona una carpeta de destino válida.")
            return

        self.settings.set('archivar/src_gpkg', source_path)
        self.settings.set('archivar/dest_folder', dest_folder)

        dest_path = os.path.join(dest_folder, os.path.basename(source_path))
        overwrite = False
        if os.path.exists(dest_path):
            reply = QMessageBox.question(
                self, "Archivar GPKG",
                f"Ya existe un archivo con ese nombre en el destino:\n{dest_path}\n\n¿Sobrescribirlo?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
            )
            if reply != QMessageBox.Yes:
                return
            overwrite = True

        self.log_box.clear()
        self._set_progress_busy("Archivando…")
        self.archive_btn.setEnabled(False)

        def _progress(msg):
            self.log(msg)
            try:
                QApplication.processEvents()
            except Exception:
                pass

        try:
            result = archive_gpkg(source_path, dest_folder, overwrite=overwrite, progress_cb=_progress)
        except GpkgArchiveError as e:
            self._set_progress_idle("Error")
            self.log(f"✖ {e}")
            QMessageBox.critical(self, "Archivar GPKG", str(e))
            return
        except Exception as e:
            self._set_progress_idle("Error")
            self.log(f"✖ Error inesperado: {e}")
            QMessageBox.critical(self, "Archivar GPKG", str(e))
            return
        finally:
            self.archive_btn.setEnabled(True)

        self._set_progress_done("Archivado completado")

        if result['tables_processed']:
            summary = (
                f"GeoPackage archivado en:\n{result['dest_path']}\n\n"
                f"Tablas con documentos: {result['tables_processed']}\n"
                f"Campos reconfigurados: {result['fields_updated']}\n"
                f"Rutas reescritas: {result['values_rewritten']}"
            )
        else:
            summary = (
                f"GeoPackage archivado en:\n{result['dest_path']}\n\n"
                "No se ha encontrado ningún campo de documento/foto en este GeoPackage; "
                "se ha copiado tal cual."
            )

        if result['missing']:
            summary += f"\n\n⚠ {len(result['missing'])} adjunto(s) no se han encontrado en disco (ver registro)."
            for table, field, fid, path in result['missing'][:50]:
                self.log(f"⚠ No encontrado: {table}.{field} (id {fid}): {path}")
            if len(result['missing']) > 50:
                self.log(f"… y {len(result['missing']) - 50} más.")

        self.log(f"✔ Archivado completado: {result['dest_path']}")
        QMessageBox.information(self, "Archivar GPKG", summary)

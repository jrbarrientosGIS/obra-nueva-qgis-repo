# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QTextBrowser, QPushButton, QHBoxLayout
from qgis.PyQt.QtCore import QUrl


class HelpDialog(QDialog):
    def __init__(self, plugin_dir, parent=None):
        super().__init__(parent)
        self.setWindowTitle('OBRA_NUEVA - Ayuda')
        self.resize(1160, 800)

        layout = QVBoxLayout(self)

        self.browser = QTextBrowser()
        self.browser.setOpenExternalLinks(True)
        self.browser.setOpenLinks(True)
        self.browser.setStyleSheet(
            'QTextBrowser { background: #f7f8f7; border: 1px solid #d9dfdc; border-radius: 10px; }'
        )

        help_dir = os.path.join(plugin_dir, 'docs', 'help')
        self.browser.setSearchPaths([help_dir])
        index_path = os.path.join(help_dir, 'index.html')
        self.browser.setSource(QUrl.fromLocalFile(index_path))
        layout.addWidget(self.browser)

        btns = QHBoxLayout()
        btns.addStretch()
        close_btn = QPushButton('Cerrar')
        close_btn.clicked.connect(self.accept)
        btns.addWidget(close_btn)
        layout.addLayout(btns)

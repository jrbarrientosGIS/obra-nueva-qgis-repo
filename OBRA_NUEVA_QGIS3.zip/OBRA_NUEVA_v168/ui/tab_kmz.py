# -*- coding: utf-8 -*-
import os
import re
import sqlite3
import shutil
import tempfile
import zipfile
from xml.sax.saxutils import escape

from qgis.PyQt.QtCore import Qt, QSize, QRect
from qgis.PyQt.QtGui import QColor, QFont, QImage, QPainter, QPen, QPixmap
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QFileDialog, QListWidget, QListWidgetItem, QMessageBox, QAbstractItemView
)
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsWkbTypes, QgsFeatureRequest,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsSymbolLayerUtils, QgsCategorizedSymbolRenderer,
    QgsGraduatedSymbolRenderer
)

from ..core.settings_manager import SettingsManager


def qcolor_to_kml(color):
    if color is None:
        color = QColor(255, 255, 255, 255)
    return "{:02x}{:02x}{:02x}{:02x}".format(color.alpha(), color.blue(), color.green(), color.red())


class KmzTab(QWidget):
    def __init__(self, iface, status_callback, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.status_callback = status_callback
        self.settings = SettingsManager()
        self._build_ui()
        self._restore_state()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        gpkg_row = QHBoxLayout()
        gpkg_row.addWidget(QLabel("GeoPackage:"))
        self.gpkg_edit = QLineEdit()
        gpkg_row.addWidget(self.gpkg_edit)
        self.gpkg_btn = QPushButton("…")
        self.gpkg_btn.setFixedWidth(36)
        gpkg_row.addWidget(self.gpkg_btn)
        layout.addLayout(gpkg_row)

        layout.addWidget(QLabel("Capas a exportar:"))
        self.layer_list = QListWidget()
        self.layer_list.setSelectionMode(QAbstractItemView.NoSelection)
        layout.addWidget(self.layer_list)

        btns = QHBoxLayout()
        self.select_all_btn = QPushButton("Seleccionar todo")
        self.clear_selection_btn = QPushButton("Limpiar")
        btns.addWidget(self.select_all_btn)
        btns.addWidget(self.clear_selection_btn)
        btns.addStretch(1)
        layout.addLayout(btns)

        out_row = QHBoxLayout()
        out_row.addWidget(QLabel("Carpeta de salida:"))
        self.out_edit = QLineEdit()
        out_row.addWidget(self.out_edit)
        self.out_btn = QPushButton("…")
        self.out_btn.setFixedWidth(36)
        out_row.addWidget(self.out_btn)
        layout.addLayout(out_row)

        footer = QHBoxLayout()
        footer.addStretch(1)
        self.export_btn = QPushButton("1)  Exportar")
        self.export_btn.setObjectName("run_btn")
        self.reset_btn = QPushButton("Limpiar formulario")
        footer.addWidget(self.export_btn)
        footer.addWidget(self.reset_btn)
        layout.addLayout(footer)

        self.gpkg_btn.clicked.connect(self.choose_gpkg)
        self.out_btn.clicked.connect(self.choose_output)
        self.select_all_btn.clicked.connect(self.select_all)
        self.clear_selection_btn.clicked.connect(self.clear_all)
        self.gpkg_edit.textChanged.connect(self.load_layers)
        self.export_btn.clicked.connect(self._do_export)
        self.reset_btn.clicked.connect(self._reset_form)

    def choose_gpkg(self):
        last = self.settings.get('kmz/input_gpkg', '') or ''
        path, _ = QFileDialog.getOpenFileName(self, "Seleccionar GeoPackage", last, "GeoPackage (*.gpkg)")
        if path:
            self.gpkg_edit.setText(path)
            self.settings.set('kmz/input_gpkg', path)

    def choose_output(self):
        last = self.settings.get('kmz/output_dir', '') or ''
        path = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta de salida", last)
        if path:
            self.out_edit.setText(path)
            self.settings.set('kmz/output_dir', path)

    def select_all(self):
        for i in range(self.layer_list.count()):
            self.layer_list.item(i).setCheckState(Qt.Checked)

    def clear_all(self):
        for i in range(self.layer_list.count()):
            self.layer_list.item(i).setCheckState(Qt.Unchecked)

    def _reset_form(self):
        self.gpkg_edit.clear()
        self.layer_list.clear()

    def _restore_state(self):
        self.gpkg_edit.setText(self.settings.get('kmz/input_gpkg', '') or '')
        self.out_edit.setText(self.settings.get('kmz/output_dir', '') or '')
        if self.gpkg_edit.text().strip():
            self.load_layers()

    def _safe_text(self, value):
        if value is None:
            return ""
        try:
            return str(value)
        except Exception:
            return ""

    def _normalize(self, text):
        text = self._safe_text(text).lower()
        for k, v in {"á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u", "ñ": "n"}.items():
            text = text.replace(k, v)
        return re.sub(r'[^a-z0-9]+', '', text)

    def _log(self, message):
        if self.status_callback:
            self.status_callback(message)

    def load_layers(self):
        self.layer_list.clear()
        gpkg = self.gpkg_edit.text().strip()
        if not gpkg or not os.path.exists(gpkg):
            return
        try:
            con = sqlite3.connect(gpkg)
            cur = con.cursor()
            rows = cur.execute(
                """
                SELECT table_name
                FROM gpkg_contents
                WHERE data_type='features'
                ORDER BY table_name
                """
            ).fetchall()
            con.close()
            for row in rows:
                name = row[0]
                lname = self._safe_text(name).strip().lower()
                if lname == "leyenda":
                    continue
                item = QListWidgetItem(name)
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
                item.setCheckState(Qt.Checked if name.startswith("SDON_") else Qt.Unchecked)
                self.layer_list.addItem(item)
            self._log(f"✔ Capas KMZ leídas desde {os.path.basename(gpkg)}")
        except Exception as e:
            QMessageBox.warning(self, "Lectura de capas", f"No se pudieron leer las capas del GeoPackage.\n\n{self._safe_text(e)}")
            self._log(f"✖ Error leyendo capas KMZ: {self._safe_text(e)}")

    def _selected_layers(self):
        names = []
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            if item.checkState() == Qt.Checked:
                names.append(item.text())
        return names

    def _resolve_layer(self, gpkg, layer_name):
        try:
            for lyr in QgsProject.instance().mapLayers().values():
                if lyr and lyr.isValid() and lyr.name() == layer_name:
                    src = self._safe_text(lyr.source())
                    if os.path.normcase(os.path.abspath(gpkg)) in os.path.normcase(src):
                        return lyr
        except Exception:
            pass
        uri = f"{gpkg}|layername={layer_name}"
        layer = QgsVectorLayer(uri, layer_name, "ogr")
        return layer if layer and layer.isValid() else None

    def _read_clave_map(self, gpkg):
        mapping = {}
        try:
            con = sqlite3.connect(gpkg)
            cur = con.cursor()
            for row in cur.execute('SELECT "key", "TIPO" FROM "CLAVE"'):
                k = self._safe_text(row[0]).strip()
                v = self._safe_text(row[1]).strip()
                if k:
                    mapping[k] = v
                    if k.endswith('.0'):
                        mapping[k[:-2]] = v
            con.close()
        except Exception:
            pass
        return mapping

    def _field_name(self, layer, candidates):
        names = [f.name() for f in layer.fields()]
        normalized = {self._normalize(n): n for n in names}
        for c in candidates:
            if c in names:
                return c
            nc = self._normalize(c)
            if nc in normalized:
                return normalized[nc]
        return None

    def _resolve_name(self, feature, layer):
        f_ambito_txt = self._field_name(layer, ["ambito_txt"])
        f_ambito = self._field_name(layer, ["Ámbito", "Ambito"])
        for field_name in [f_ambito_txt, f_ambito]:
            if field_name:
                value = self._safe_text(feature[field_name]).strip()
                if value:
                    return value
        return f"Elemento {feature.id()}"

    def _resolve_tipo(self, feature, layer, clave_map):
        f_tipo_txt = self._field_name(layer, ["tipo_txt"])
        if f_tipo_txt:
            value = self._safe_text(feature[f_tipo_txt]).strip()
            if value:
                return value
        f_tipo = self._field_name(layer, ["Tipo"])
        if f_tipo:
            raw = self._safe_text(feature[f_tipo]).strip()
            if raw in clave_map:
                return clave_map[raw]
            try:
                raw2 = str(float(raw))
                if raw2 in clave_map:
                    return clave_map[raw2]
                if raw2.endswith('.0') and raw2[:-2] in clave_map:
                    return clave_map[raw2[:-2]]
            except Exception:
                pass
            return raw
        return ""

    def _get_feature_ambito(self, feature):
        fields = [f.name() for f in feature.fields()]
        for candidate in ('ambito_txt', 'Ámbito', 'Ambito', 'ambito'):
            if candidate in fields:
                value = feature[candidate]
                return self._safe_text(value) if value not in (None, '') else 'Sin ámbito'
        return 'Sin ámbito'

    def _get_category_symbol(self, layer):
        renderer = layer.renderer()
        mapping = {}
        try:
            if isinstance(renderer, QgsCategorizedSymbolRenderer):
                attr = self._safe_text(renderer.classAttribute()).strip().strip('"')
                for cat in renderer.categories():
                    try:
                        mapping[self._safe_text(cat.value())] = cat.symbol()
                    except Exception:
                        pass
                return attr, mapping
        except Exception:
            pass
        return None, {}

    def _pixmap_to_png_bytes(self, pixmap):
        image = pixmap.toImage()
        if image.size() != QSize(32, 32):
            image = image.scaled(32, 32, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        try:
            from qgis.PyQt.QtCore import QByteArray, QBuffer
            qba = QByteArray()
            buff = QBuffer(qba)
            buff.open(QBuffer.WriteOnly)
            image.save(buff, "PNG")
            data = bytes(qba)
            buff.close()
            return data
        except Exception:
            return b""

    def _fallback_point_style(self):
        pix = QPixmap(32, 32)
        pix.fill(Qt.transparent)
        p = QPainter(pix)
        p.setPen(QPen(QColor(20, 20, 20), 2))
        p.setBrush(QColor(230, 60, 60, 220))
        p.drawEllipse(6, 6, 20, 20)
        p.end()
        return {"kind": "point", "png_bytes": self._pixmap_to_png_bytes(pix), "key": "pt_fallback"}

    def _extract_symbol_info(self, layer, feature):
        geom_type = QgsWkbTypes.geometryType(layer.wkbType())
        attr, mapping = self._get_category_symbol(layer)

        if geom_type == QgsWkbTypes.PointGeometry:
            try:
                if attr and attr in [f.name() for f in layer.fields()]:
                    val = self._safe_text(feature[attr])
                    sym = mapping.get(val)
                    if sym:
                        pix = QgsSymbolLayerUtils.symbolPreviewPixmap(sym, QSize(32, 32), 1)
                        png_bytes = self._pixmap_to_png_bytes(pix)
                        if png_bytes:
                            return {"kind": "point", "png_bytes": png_bytes, "key": "pt_" + val}
            except Exception:
                pass
            return self._fallback_point_style()

        renderer = layer.renderer()
        sym = None
        try:
            if isinstance(renderer, QgsGraduatedSymbolRenderer):
                sym = renderer.sourceSymbol()
            elif hasattr(renderer, 'symbol'):
                sym = renderer.symbol()
        except Exception:
            sym = None

        if sym is None:
            return {"kind": "generic", "key": "generic"}

        if geom_type == QgsWkbTypes.LineGeometry:
            color = sym.color() if hasattr(sym, 'color') else QColor(0, 0, 0)
            return {"kind": "line", "color": color, "width": 1.5, "key": "line_" + qcolor_to_kml(color)}

        if geom_type == QgsWkbTypes.PolygonGeometry:
            fill = sym.color() if hasattr(sym, 'color') else QColor(200, 200, 200, 180)
            stroke = QColor(80, 80, 80, 255)
            return {
                "kind": "polygon",
                "fill": fill,
                "stroke": stroke,
                "width": 1.0,
                "key": "poly_" + qcolor_to_kml(fill)
            }

        return {"kind": "generic", "key": "generic"}

    def _build_style_xml(self, style_id, style_info, assets_dir):
        kind = style_info.get("kind")
        if kind == "point":
            icon_name = f"{style_id}.png"
            icon_path = os.path.join(assets_dir, icon_name)
            with open(icon_path, 'wb') as f:
                f.write(style_info.get('png_bytes', b''))
            return (
                f'<Style id="{escape(style_id)}"><IconStyle>'
                '<scale>1.0</scale>'
                f'<Icon><href>files/{escape(icon_name)}</href></Icon>'
                '<hotSpot x="0.5" y="0.5" xunits="fraction" yunits="fraction"/>'
                '</IconStyle></Style>'
            )

        if kind == "line":
            color = qcolor_to_kml(style_info.get("color"))
            width = style_info.get("width", 1.5)
            return f'<Style id="{escape(style_id)}"><LineStyle><color>{color}</color><width>{width}</width></LineStyle></Style>'

        if kind == "polygon":
            fill = qcolor_to_kml(style_info.get("fill"))
            stroke = qcolor_to_kml(style_info.get("stroke"))
            width = style_info.get("width", 1.0)
            return (
                f'<Style id="{escape(style_id)}">'
                f'<LineStyle><color>{stroke}</color><width>{width}</width></LineStyle>'
                f'<PolyStyle><color>{fill}</color><fill>1</fill><outline>1</outline></PolyStyle>'
                '</Style>'
            )

        return f'<Style id="{escape(style_id)}"></Style>'

    def _build_extended_data(self, feature, layer, tipo, name):
        parts = ['<ExtendedData>']
        for fld in layer.fields():
            fname = fld.name()
            if self._normalize(fname) in ('geom', 'geometry'):
                continue
            val = feature[fname]
            if self._normalize(fname) == self._normalize('Tipo'):
                val = tipo
            if self._normalize(fname) in (self._normalize('Ámbito'), self._normalize('Ambito')):
                val = name
            parts.append(f'<Data name="{escape(fname)}"><value>{escape(self._safe_text(val))}</value></Data>')
        parts.append(f'<Data name="Name"><value>{escape(name)}</value></Data>')
        parts.append('</ExtendedData>')
        return ''.join(parts)

    def _coords(self, pt):
        return f"{pt.x():.8f},{pt.y():.8f},0"

    def _polygon_to_kml(self, poly):
        if not poly:
            return ""
        outer = poly[0]
        if not outer:
            return ""
        outer_coords = ' '.join(self._coords(p) for p in outer)
        inners = []
        for ring in poly[1:]:
            if not ring:
                continue
            ring_coords = ' '.join(self._coords(p) for p in ring)
            inners.append(f'<innerBoundaryIs><LinearRing><coordinates>{ring_coords}</coordinates></LinearRing></innerBoundaryIs>')
        return (
            '<Polygon><tessellate>1</tessellate>'
            f'<outerBoundaryIs><LinearRing><coordinates>{outer_coords}</coordinates></LinearRing></outerBoundaryIs>'
            f"{''.join(inners)}</Polygon>"
        )

    def _geometry_to_kml(self, geom):
        geom_type = QgsWkbTypes.geometryType(geom.wkbType())
        multi = QgsWkbTypes.isMultiType(geom.wkbType())

        if geom_type == QgsWkbTypes.PointGeometry:
            if multi:
                pts = geom.asMultiPoint()
                if not pts:
                    return ""
                if len(pts) == 1:
                    return f'<Point><coordinates>{self._coords(pts[0])}</coordinates></Point>'
                inner = ''.join(f'<Point><coordinates>{self._coords(p)}</coordinates></Point>' for p in pts)
                return f'<MultiGeometry>{inner}</MultiGeometry>'
            pt = geom.asPoint()
            return f'<Point><coordinates>{self._coords(pt)}</coordinates></Point>'

        if geom_type == QgsWkbTypes.LineGeometry:
            if multi:
                lines = geom.asMultiPolyline()
                inner = []
                for line in lines:
                    if line:
                        coords = ' '.join(self._coords(p) for p in line)
                        inner.append(f'<LineString><tessellate>1</tessellate><coordinates>{coords}</coordinates></LineString>')
                return f"<MultiGeometry>{''.join(inner)}</MultiGeometry>" if inner else ""
            line = geom.asPolyline()
            if not line:
                return ""
            coords = ' '.join(self._coords(p) for p in line)
            return f'<LineString><tessellate>1</tessellate><coordinates>{coords}</coordinates></LineString>'

        if geom_type == QgsWkbTypes.PolygonGeometry:
            if multi:
                polys = geom.asMultiPolygon()
                inner = [self._polygon_to_kml(poly) for poly in polys if poly]
                inner = [x for x in inner if x]
                return f"<MultiGeometry>{''.join(inner)}</MultiGeometry>" if inner else ""
            poly = geom.asPolygon()
            return self._polygon_to_kml(poly)

        return ""

    def _create_legend_png(self, legend_items, assets_dir, layer_name):
        if not legend_items:
            return None
        ordered = list(legend_items.items())
        row_h = 36
        width = 420
        height = 50 + row_h * len(ordered)
        image = QImage(width, height, QImage.Format_ARGB32_Premultiplied)
        image.fill(QColor(255, 255, 255, 230))

        painter = QPainter(image)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(QPen(QColor(60, 60, 60)))
        painter.setFont(QFont("Arial", 11, QFont.Bold))
        painter.drawText(QRect(12, 8, width - 24, 24), Qt.AlignLeft | Qt.AlignVCenter, f"Leyenda - {layer_name}")
        painter.setFont(QFont("Arial", 9))

        y = 38
        for _, (style_info, label) in ordered:
            kind = style_info.get("kind")
            if kind == "point" and style_info.get("png_bytes"):
                pix = QPixmap()
                pix.loadFromData(style_info["png_bytes"], "PNG")
                painter.drawPixmap(12, y, 24, 24, pix)
            elif kind == "line":
                pen = QPen(style_info.get("color", QColor(0, 0, 0)))
                pen.setWidthF(max(1.0, style_info.get("width", 1.5)))
                painter.setPen(pen)
                painter.drawLine(12, y + 12, 36, y + 12)
                painter.setPen(QPen(QColor(60, 60, 60)))
            elif kind == "polygon":
                painter.fillRect(12, y + 4, 24, 16, style_info.get("fill", QColor(200, 200, 200, 180)))
                painter.setPen(QPen(style_info.get("stroke", QColor(80, 80, 80)), max(1, int(round(style_info.get("width", 1.0))))))
                painter.drawRect(12, y + 4, 24, 16)
                painter.setPen(QPen(QColor(60, 60, 60)))
            painter.drawText(QRect(46, y, width - 58, 24), Qt.AlignLeft | Qt.AlignVCenter, self._safe_text(label))
            y += row_h
        painter.end()

        path = os.path.join(assets_dir, 'legend.png')
        image.save(path, 'PNG')
        return path

    def _export_selected_layers_to_one_kmz(self, layers, gpkg, kmz_path, clave_map):
        tmpdir = tempfile.mkdtemp(prefix='sdon_kmz_')
        try:
            assets_dir = os.path.join(tmpdir, 'files')
            os.makedirs(assets_dir, exist_ok=True)
            style_defs = {}
            all_folder_xml = []

            for layer in layers:
                if self._safe_text(layer.name()).strip().lower() == 'leyenda':
                    continue

                transform = None
                dest_crs = QgsCoordinateReferenceSystem('EPSG:4326')
                try:
                    if layer.crs().isValid() and layer.crs() != dest_crs:
                        transform = QgsCoordinateTransform(layer.crs(), dest_crs, QgsProject.instance())
                except Exception:
                    transform = None

                by_ambito = {}
                for feature in layer.getFeatures(QgsFeatureRequest()):
                    geom = feature.geometry()
                    if geom is None or geom.isEmpty():
                        continue
                    if transform:
                        try:
                            geom.transform(transform)
                        except Exception:
                            pass

                    style_info = self._extract_symbol_info(layer, feature)
                    style_id = style_info.get('key', 'default')
                    name = self._resolve_name(feature, layer)
                    tipo = self._resolve_tipo(feature, layer, clave_map)
                    ambito = self._get_feature_ambito(feature) or name or 'Sin ámbito'

                    if style_id not in style_defs:
                        style_defs[style_id] = self._build_style_xml(style_id, style_info, assets_dir)

                    ext_data = self._build_extended_data(feature, layer, tipo, name)
                    geom_xml = self._geometry_to_kml(geom)
                    if not geom_xml:
                        continue

                    placemark = (
                        '<Placemark>'
                        f'<name>{escape(name)}</name>'
                        f'<styleUrl>#{escape(style_id)}</styleUrl>'
                        f'{ext_data}{geom_xml}'
                        '</Placemark>'
                    )
                    by_ambito.setdefault(ambito, []).append(placemark)

                legend_items = {}
                for feature in layer.getFeatures(QgsFeatureRequest()):
                    style_info = self._extract_symbol_info(layer, feature)
                    style_id = style_info.get('key', 'default')
                    tipo = self._resolve_tipo(feature, layer, clave_map)
                    label = tipo or self._resolve_name(feature, layer)
                    if style_id not in legend_items:
                        legend_items[style_id] = (style_info, label)

                overlay_block = ''
                legend_path = self._create_legend_png(legend_items, assets_dir, layer.name())
                if legend_path:
                    overlay_block = (
                        '<ScreenOverlay>'
                        '<name>Leyenda</name>'
                        f'<Icon><href>files/{os.path.basename(legend_path)}</href></Icon>'
                        '<overlayXY x="0" y="1" xunits="fraction" yunits="fraction"/>'
                        '<screenXY x="0.02" y="0.98" xunits="fraction" yunits="fraction"/>'
                        '<rotationXY x="0" y="0" xunits="fraction" yunits="fraction"/>'
                        '<size x="0" y="0" xunits="pixels" yunits="pixels"/>'
                        '</ScreenOverlay>'
                    )

                ambito_xml = []
                for ambito_name in sorted(by_ambito.keys()):
                    ambito_xml.append(f'<Folder><name>{escape(ambito_name)}</name>{"".join(by_ambito[ambito_name])}</Folder>')

                if ambito_xml:
                    all_folder_xml.append(
                        f'<Folder><name>{escape(layer.name())}</name>{overlay_block}{"".join(ambito_xml)}</Folder>'
                    )

            style_block = '\n'.join(style_defs.values())
            folder_block = '\n'.join(all_folder_xml)
            kml = (
                '<?xml version="1.0" encoding="UTF-8"?>\n'
                '<kml xmlns="http://www.opengis.net/kml/2.2">\n'
                '<Document>\n'
                f'<name>{escape(os.path.basename(kmz_path))}</name>\n'
                f'{style_block}\n'
                f'{folder_block}\n'
                '</Document>\n'
                '</kml>\n'
            )
            doc_kml = os.path.join(tmpdir, 'doc.kml')
            with open(doc_kml, 'w', encoding='utf-8') as f:
                f.write(kml)

            with zipfile.ZipFile(kmz_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                zf.write(doc_kml, 'doc.kml')
                for folder, _, files in os.walk(assets_dir):
                    for fn in files:
                        full = os.path.join(folder, fn)
                        rel = os.path.relpath(full, tmpdir)
                        zf.write(full, rel)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def _do_export(self):
        gpkg = self.gpkg_edit.text().strip()
        out_dir = self.out_edit.text().strip()
        selected_names = self._selected_layers()
        if not gpkg or not os.path.exists(gpkg):
            QMessageBox.warning(self, 'KMZ', 'Selecciona un GeoPackage válido.')
            return
        if not out_dir:
            QMessageBox.warning(self, 'KMZ', 'Selecciona un directorio de salida.')
            return
        if not selected_names:
            QMessageBox.warning(self, 'KMZ', 'Selecciona al menos una capa.')
            return

        os.makedirs(out_dir, exist_ok=True)
        self.settings.set('kmz/input_gpkg', gpkg)
        self.settings.set('kmz/output_dir', out_dir)

        clave_map = self._read_clave_map(gpkg)
        layers = []
        for layer_name in selected_names:
            layer = self._resolve_layer(gpkg, layer_name)
            if layer is None or not layer.isValid():
                QMessageBox.warning(self, 'KMZ', f'No se pudo cargar la capa: {layer_name}')
                continue
            if self._safe_text(layer.name()).strip().lower() != 'leyenda':
                layers.append(layer)

        if not layers:
            QMessageBox.warning(self, 'KMZ', 'No se pudo cargar ninguna capa seleccionada.')
            return

        gpkg_base = re.sub(r'[^A-Za-z0-9._-]+', '_', os.path.splitext(os.path.basename(gpkg))[0]).strip('._-') or 'export'
        kmz_path = os.path.join(out_dir, f'{gpkg_base}_export.kmz')
        try:
            self._export_selected_layers_to_one_kmz(layers, gpkg, kmz_path, clave_map)
            self._log(f'✔ KMZ generado: {kmz_path}')
            QMessageBox.information(self, 'KMZ', f'Exportación completada.\nKMZ generado:\n{kmz_path}')
        except Exception as e:
            self._log(f'✖ Error exportando KMZ: {self._safe_text(e)}')
            QMessageBox.critical(self, 'Error', self._safe_text(e))

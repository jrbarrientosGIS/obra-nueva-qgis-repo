# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTabWidget, QTextEdit, QScrollArea, QSizePolicy, QWidget, QFrame
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QFont

from ..core.settings_manager import SettingsManager
from .tab_nueva_obra import NuevaObraTab
from .tab_carga_obra import CargaObraTab
from .tab_kmz import KmzTab
from .tab_consulta import ConsultaTab
from .tab_fotos import FotosTab
from .tab_actualiza_gpkg import ActualizaGpkgTab
from .tab_archivar_gpkg import ArchivarGpkgTab
from .help_dialog import HelpDialog
from .styles import get_stylesheet


class ObraNuevaMainDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.settings = SettingsManager()
        self.setWindowTitle('OBRA_NUEVA')
        self.resize(1220, 790)
        self.setMinimumSize(900, 650)
        self.setSizeGripEnabled(True)
        self.setStyleSheet(get_stylesheet())
        self.setup_ui()
        self.restore_state()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Cabecera ──────────────────────────────────────────────────────────
        header_widget = QWidget()
        header_widget.setObjectName("header_widget")
        header_widget.setFixedHeight(52)
        header_layout = QHBoxLayout(header_widget)
        header_layout.setContentsMargins(16, 0, 12, 0)
        header_layout.setSpacing(8)

        # Punto de color decorativo
        dot = QLabel("●")
        dot.setStyleSheet("color: #4A90D9; font-size: 14pt; background: transparent;")
        dot.setFixedWidth(20)

        title = QLabel("OBRA_NUEVA")
        title.setObjectName("main_title")
        title.setProperty("class", "title")
        font_title = QFont()
        font_title.setBold(True)
        font_title.setPointSize(11)
        title.setFont(font_title)
        title.setStyleSheet("color: #E8EDF5; background: transparent; font-size: 11pt; font-weight: bold;")

        sep = QLabel("·")
        sep.setStyleSheet("color: #374461; font-size: 11pt; background: transparent;")

        subtitle = QLabel("Plataforma GeoPackage / KMZ / Multiobra")
        subtitle.setProperty("class", "subtitle")
        subtitle.setStyleSheet("color: #8A9BBE; background: transparent; font-size: 9pt;")

        self.btn_help = QPushButton("⚙  Ayuda")
        self.btn_help.setObjectName("btn_help")
        self.btn_help.setFixedHeight(28)
        self.btn_help.clicked.connect(self.open_help)

        header_layout.addWidget(dot)
        header_layout.addWidget(title)
        header_layout.addWidget(sep)
        header_layout.addWidget(subtitle)
        header_layout.addStretch()
        header_layout.addWidget(self.btn_help)

        layout.addWidget(header_widget)

        # ── Separador ────────────────────────────────────────────────────────
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Plain)
        line.setStyleSheet("color: #4A90D9; background-color: #4A90D9; max-height: 1px;")
        layout.addWidget(line)

        # ── Área de contenido con márgenes ───────────────────────────────────
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(10, 8, 10, 0)
        content_layout.setSpacing(6)

        # ── Pestañas ─────────────────────────────────────────────────────────
        self.tabs = QTabWidget()
        self.tabs.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        content_layout.addWidget(self.tabs, 1)

        # ── Consola de estado ────────────────────────────────────────────────
        self.status_console = QTextEdit()
        self.status_console.setObjectName("status_console")
        self.status_console.setReadOnly(True)
        self.status_console.setMaximumHeight(130)
        self.status_console.setPlaceholderText("▶  Consola de estado...")
        content_layout.addWidget(self.status_console)

        layout.addWidget(content_widget, 1)

        # ── Barra de estado inferior ─────────────────────────────────────────
        footer = QWidget()
        footer.setFixedHeight(22)
        footer.setStyleSheet(
            "background-color: #131926; border-top: 1px solid #374461;"
        )
        footer_layout = QHBoxLayout(footer)
        footer_layout.setContentsMargins(12, 0, 12, 0)
        footer_lbl = QLabel("GIS-OMICRON  ·  v1.7.3")
        footer_lbl.setStyleSheet("color: #4A5568; font-size: 8pt; background: transparent;")
        footer_layout.addStretch()
        footer_layout.addWidget(footer_lbl)
        layout.addWidget(footer)

        # ── Instanciar pestañas ───────────────────────────────────────────────
        self.tab_nueva = NuevaObraTab(self.iface, self.append_status)
        self.tab_carga = CargaObraTab(self.iface, self.append_status)
        self.tab_kmz = KmzTab(self.iface, self.append_status)
        self.tab_consulta = ConsultaTab(self.iface, self.append_status)
        self.tab_fotos = FotosTab(self.iface, self.append_status)
        self.tab_actualiza_gpkg = ActualizaGpkgTab(self.iface, self.append_status)
        self.tab_archivar_gpkg = ArchivarGpkgTab(self.iface, self.append_status)

        self.tab_fotos_scroll = QScrollArea()
        self.tab_fotos_scroll.setWidgetResizable(True)
        self.tab_fotos_scroll.setWidget(self.tab_fotos)

        # Iconos Unicode en las pestañas para reconocimiento visual rápido
        self.tabs.addTab(self.tab_nueva,        "🗂  Nueva Obra")
        self.tabs.addTab(self.tab_carga,        "📂  Carga Obra")
        self.tabs.addTab(self.tab_kmz,          "🗺  KMZ")
        self.tabs.addTab(self.tab_consulta,     "🔍  Consulta")
        self.tabs.addTab(self.tab_fotos_scroll, "📷  Fotos")
        self.tabs.addTab(self.tab_actualiza_gpkg, "🔄  Actualiza GPKG")
        self.tabs.addTab(self.tab_archivar_gpkg, "🗄  Archivar GPKG")

        self.tabs.currentChanged.connect(self._on_tab_changed)
        self._on_tab_changed(self.tabs.currentIndex())

    def _on_tab_changed(self, index):
        widget = self.tabs.widget(index)
        show_console = widget not in (self.tab_consulta, self.tab_archivar_gpkg)
        self.status_console.setVisible(show_console)
        if widget is self.tab_actualiza_gpkg:
            self.tab_actualiza_gpkg.refresh_project_default()
        elif widget is self.tab_archivar_gpkg:
            self.tab_archivar_gpkg.refresh_project_default()

    def open_help(self):
        plugin_dir = getattr(self.iface, 'plugin_dir', '')
        if not plugin_dir:
            plugin_dir = os.path.dirname(os.path.dirname(__file__))
        dlg = HelpDialog(plugin_dir, self)
        dlg.exec_()

    def append_status(self, message):
        if hasattr(self, 'status_console') and self.status_console is not None:
            self.status_console.append(str(message))

    def closeEvent(self, event):
        self.settings.set('last_tab', self.tabs.currentIndex())
        super().closeEvent(event)

    def restore_state(self):
        idx = int(self.settings.get('last_tab', 0) or 0)
        self.tabs.setCurrentIndex(idx)

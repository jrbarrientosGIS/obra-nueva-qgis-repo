# -*- coding: utf-8 -*-
import os
import re
import sqlite3

from qgis.PyQt.QtWidgets import (
    QWidget, QLabel, QLineEdit, QPushButton, QCheckBox,
    QFileDialog, QGridLayout, QVBoxLayout, QHBoxLayout, QMessageBox
)
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsVectorFileWriter,
    QgsCoordinateTransformContext,
    QgsWkbTypes,
    QgsMessageLog,
    QgsEditorWidgetSetup,
    Qgis,
)

from ..core.gpkg_utils import GpkgIntrospector
from ..core.settings_manager import SettingsManager
from ..core.form_customizer import IncidenciaFormCustomizer


class NuevaObraTab(QWidget):
    def __init__(self, iface, status_callback, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.status_callback = status_callback
        self.settings = SettingsManager()
        self.form_customizer = IncidenciaFormCustomizer()
        self.setup_ui()
        self.restore_state()

    def setup_ui(self):
        main_layout = QVBoxLayout(self)
        grid = QGridLayout()

        self.lbl_source = QLabel('GeoPackage de entrada')
        self.le_source = QLineEdit()
        self.btn_source = QPushButton('Examinar...')
        self.btn_source.clicked.connect(self.browse_source)
        grid.addWidget(self.lbl_source, 0, 0)
        grid.addWidget(self.le_source, 0, 1)
        grid.addWidget(self.btn_source, 0, 2)

        self.lbl_output_dir = QLabel('Directorio de salida')
        self.le_output_dir = QLineEdit()
        self.btn_output_dir = QPushButton('Examinar...')
        self.btn_output_dir.clicked.connect(self.browse_output_dir)
        grid.addWidget(self.lbl_output_dir, 1, 0)
        grid.addWidget(self.le_output_dir, 1, 1)
        grid.addWidget(self.btn_output_dir, 1, 2)

        self.lbl_output_name = QLabel('Nombre del nuevo GeoPackage')
        self.le_output_name = QLineEdit()
        grid.addWidget(self.lbl_output_name, 2, 0)
        grid.addWidget(self.le_output_name, 2, 1, 1, 2)

        main_layout.addLayout(grid)

        self.chk_group = QCheckBox('Cargar capas resultantes en QGIS dentro de un grupo')
        self.chk_group.setChecked(True)
        self.chk_lineas = QCheckBox('Cargar capa base Lineas_FFCC')
        self.chk_pk = QCheckBox('Cargar capa base pk')
        self.chk_estaciones = QCheckBox('Cargar capa base Estaciones')
        self.chk_overwrite = QCheckBox('Sobrescribir GeoPackage si ya existe')
        self.chk_skip_empty = QCheckBox('No cargar capas vacías')

        main_layout.addWidget(self.chk_group)
        main_layout.addWidget(self.chk_lineas)
        main_layout.addWidget(self.chk_pk)
        main_layout.addWidget(self.chk_estaciones)
        main_layout.addWidget(self.chk_overwrite)
        main_layout.addWidget(self.chk_skip_empty)

        button_layout = QHBoxLayout()
        button_layout.addStretch()
        self.run_btn = QPushButton('①  Ejecutar')
        self.run_btn.setObjectName('run_btn')
        self.run_btn.clicked.connect(self.create_new_work)
        self.cancel_btn = QPushButton('Cancelar')
        self.cancel_btn.clicked.connect(self.clear_form)
        button_layout.addWidget(self.run_btn)
        button_layout.addWidget(self.cancel_btn)
        main_layout.addLayout(button_layout)

    def browse_source(self):
        last = self.settings.get('new_work/source', '')
        path, _ = QFileDialog.getOpenFileName(self, 'Seleccionar GeoPackage origen', last, 'GeoPackage (*.gpkg)')
        if path:
            self.le_source.setText(path)
            base = os.path.splitext(os.path.basename(path))[0]
            if not self.le_output_name.text().strip():
                self.le_output_name.setText(base)
            self.settings.set('new_work/source', path)

    def browse_output_dir(self):
        last = self.settings.get('new_work/output_dir', '')
        path = QFileDialog.getExistingDirectory(self, 'Seleccionar directorio destino', last)
        if path:
            self.le_output_dir.setText(path)
            self.settings.set('new_work/output_dir', path)

    def clear_form(self):
        self.le_source.clear()
        self.le_output_dir.clear()
        self.le_output_name.clear()

    def restore_state(self):
        self.le_source.setText(self.settings.get('new_work/source', '') or '')
        self.le_output_dir.setText(self.settings.get('new_work/output_dir', '') or '')

    def create_new_work(self):
        source = self.le_source.text().strip()
        output_dir = self.le_output_dir.text().strip()
        obra_name = self._normalize_name(self.le_output_name.text().strip())

        if not source or not output_dir or not obra_name:
            QMessageBox.warning(self, 'Validación', 'Debes completar origen, destino y nombre de salida.')
            return

        if not os.path.exists(source):
            QMessageBox.warning(self, 'Validación', 'El GeoPackage de entrada no existe.')
            return

        if not os.path.isdir(output_dir):
            QMessageBox.warning(self, 'Validación', 'El directorio de salida no es válido.')
            return

        output_gpkg = os.path.join(output_dir, f'{obra_name}.gpkg')

        if os.path.exists(output_gpkg) and not self.chk_overwrite.isChecked():
            QMessageBox.warning(self, 'Validación', 'El GeoPackage de salida ya existe. Marca "Sobrescribir" o usa otro nombre.')
            return

        if os.path.exists(output_gpkg) and self.chk_overwrite.isChecked():
            try:
                os.remove(output_gpkg)
            except Exception as exc:
                QMessageBox.critical(self, 'Error', f'No se pudo sobrescribir el GeoPackage existente:\n{exc}')
                return

        try:
            created_layers = self._process_gpkg(
                input_gpkg=source,
                output_gpkg=output_gpkg,
                obra_name=obra_name,
                include_pk=self.chk_pk.isChecked(),
                include_estaciones=self.chk_estaciones.isChecked(),
                include_lineas_ffcc=self.chk_lineas.isChecked(),
            )

            self.status_callback(f'✔ GeoPackage creado: {output_gpkg}')
            self.status_callback(f'✔ Capas creadas: {", ".join(created_layers)}')

            if self.chk_group.isChecked():
                self._load_result_layers_to_qgis(
                    output_gpkg=output_gpkg,
                    obra_name=obra_name,
                    created_layers=created_layers,
                    skip_empty=self.chk_skip_empty.isChecked(),
                )
                self.status_callback('✔ Capas cargadas en QGIS con estructura controlada')

        except Exception as exc:
            QMessageBox.critical(self, 'Error', str(exc))
            self.status_callback(f'✖ Error en Nueva Obra: {exc}')

    def _process_gpkg(self, input_gpkg, output_gpkg, obra_name, include_pk=False, include_estaciones=False, include_lineas_ffcc=False):
        introspector = GpkgIntrospector(input_gpkg)
        layer_names = introspector.list_geometry_tables()
        if not layer_names:
            raise ValueError('No se encontraron capas geométricas en el GeoPackage de entrada.')

        src_puntos = self._find_operational_layer_strict(
            gpkg_path=input_gpkg,
            layer_names=layer_names,
            target_suffixes=['_Puntos', 'Puntos'],
            target_geom_type=QgsWkbTypes.PointGeometry,
        )
        src_lineas = self._find_operational_layer_strict(
            gpkg_path=input_gpkg,
            layer_names=layer_names,
            target_suffixes=['_Lineas', 'Lineas', 'Líneas'],
            target_geom_type=QgsWkbTypes.LineGeometry,
        )
        src_poligonos = self._find_operational_layer_strict(
            gpkg_path=input_gpkg,
            layer_names=layer_names,
            target_suffixes=['_Poligonos', 'Poligonos', 'Polígonos'],
            target_geom_type=QgsWkbTypes.PolygonGeometry,
        )

        if not src_puntos:
            raise ValueError('No se encontró la capa operativa de Puntos en el GeoPackage de entrada.')
        if not src_lineas:
            raise ValueError('No se encontró la capa operativa de Lineas en el GeoPackage de entrada.')
        if not src_poligonos:
            raise ValueError('No se encontró la capa operativa de Poligonos en el GeoPackage de entrada.')

        created_layers = []
        operational_targets = [
            (src_puntos, f'{obra_name}_Puntos'),
            (src_lineas, f'{obra_name}_Lineas'),
            (src_poligonos, f'{obra_name}_Poligonos'),
        ]

        for src_layer, target_name in operational_targets:
            self._copy_layer_to_gpkg(src_layer, output_gpkg, target_name)
            created_layers.append(target_name)

        if include_pk:
            src_pk = self._find_source_layer_by_name(input_gpkg, layer_names, ['pk'])
            if src_pk:
                self._copy_layer_to_gpkg(src_pk, output_gpkg, 'pk')
                created_layers.append('pk')
            else:
                self._log("No se encontró la capa base 'pk' en el GeoPackage de entrada.", Qgis.Warning)

        if include_estaciones:
            src_estaciones = self._find_source_layer_by_name(input_gpkg, layer_names, ['Estaciones', 'Estacion'])
            if src_estaciones:
                self._copy_layer_to_gpkg(src_estaciones, output_gpkg, 'Estaciones')
                created_layers.append('Estaciones')
            else:
                self._log("No se encontró la capa base 'Estaciones' en el GeoPackage de entrada.", Qgis.Warning)

        if include_lineas_ffcc:
            src_ffcc = self._find_source_layer_by_name(input_gpkg, layer_names, ['Lineas_FFCC', 'Líneas_FFCC', 'lineasffcc'])
            if src_ffcc:
                self._copy_layer_to_gpkg(src_ffcc, output_gpkg, 'Lineas_FFCC')
                created_layers.append('Lineas_FFCC')
            else:
                self._log("No se encontró la capa base 'Lineas_FFCC' en el GeoPackage de entrada.", Qgis.Warning)

        self._copy_attribute_table_sqlite(input_gpkg, output_gpkg, 'CLAVE')
        self._ensure_layer_styles_schema(input_gpkg, output_gpkg)

        for src_layer, target_name in operational_targets:
            self._clone_layer_styles_exact(input_gpkg, output_gpkg, src_layer.name(), target_name)
        if include_pk and 'pk' in created_layers:
            self._clone_layer_styles_exact(input_gpkg, output_gpkg, 'pk', 'pk')
        if include_estaciones and 'Estaciones' in created_layers:
            self._clone_layer_styles_exact(input_gpkg, output_gpkg, 'Estaciones', 'Estaciones')
        if include_lineas_ffcc and 'Lineas_FFCC' in created_layers:
            self._clone_layer_styles_exact(input_gpkg, output_gpkg, 'Lineas_FFCC', 'Lineas_FFCC')

        return created_layers

    def _find_source_layer_by_name(self, gpkg_path, layer_names, candidates):
        normalized_candidates = [self._normalize_text(x) for x in candidates]
        exact_matches = []
        contains_matches = []

        for layer_name in layer_names:
            lname = self._normalize_text(layer_name)
            lyr = QgsVectorLayer(f'{gpkg_path}|layername={layer_name}', layer_name, 'ogr')
            if not lyr.isValid():
                continue
            for candidate in normalized_candidates:
                if lname == candidate:
                    exact_matches.append((layer_name, lyr))
                elif candidate in lname:
                    contains_matches.append((layer_name, lyr))

        if exact_matches:
            exact_matches.sort(key=lambda x: x[0])
            return exact_matches[0][1]
        if contains_matches:
            contains_matches.sort(key=lambda x: x[0])
            return contains_matches[0][1]
        return None

    def _find_operational_layer_strict(self, gpkg_path, layer_names, target_suffixes, target_geom_type):
        normalized_suffixes = [self._normalize_text(x) for x in target_suffixes]
        excluded_names = {
            'pk', 'estaciones', 'estacion', 'lineas_ffcc', 'lineasffcc',
            'leyenda', 'clave', 'layer_groups', 'metadata'
        }

        strict_matches = []
        for layer_name in layer_names:
            lname = self._normalize_text(layer_name)
            if lname in excluded_names:
                continue
            lyr = QgsVectorLayer(f'{gpkg_path}|layername={layer_name}', layer_name, 'ogr')
            if not lyr.isValid():
                continue
            geom_type = QgsWkbTypes.geometryType(lyr.wkbType())
            if geom_type != target_geom_type:
                continue

            score = -1
            for suffix in normalized_suffixes:
                if lname == suffix:
                    score = max(score, 200)
                elif lname.endswith(suffix):
                    score = max(score, 150)
                elif suffix in lname:
                    score = max(score, 100)
            if score >= 0:
                strict_matches.append((score, layer_name, lyr))

        if strict_matches:
            strict_matches.sort(key=lambda x: (-x[0], x[1]))
            return strict_matches[0][2]
        return None

    def _copy_layer_to_gpkg(self, source_layer, output_gpkg, target_layer_name):
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = 'GPKG'
        options.layerName = target_layer_name
        options.fileEncoding = 'UTF-8'
        if os.path.exists(output_gpkg):
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        else:
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile

        err_code, err_msg, *_ = QgsVectorFileWriter.writeAsVectorFormatV3(
            source_layer,
            output_gpkg,
            QgsCoordinateTransformContext(),
            options,
        )
        if err_code != QgsVectorFileWriter.NoError:
            raise RuntimeError(f"No se pudo copiar la capa '{source_layer.name()}' a '{target_layer_name}': {err_msg}")

    def _copy_attribute_table_sqlite(self, input_gpkg, output_gpkg, table_name):
        src = sqlite3.connect(input_gpkg)
        dst = sqlite3.connect(output_gpkg)
        try:
            s = src.cursor()
            d = dst.cursor()

            s.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
            row = s.fetchone()
            if not row or not row[0]:
                raise RuntimeError(f"No se encontró la definición SQL de la tabla '{table_name}'.")

            d.execute(f'DROP TABLE IF EXISTS "{table_name}"')
            d.execute('DELETE FROM gpkg_contents WHERE table_name = ?', (table_name,))
            d.execute(row[0])

            s.execute(f'PRAGMA table_info("{table_name}")')
            cols = [r[1] for r in s.fetchall()]
            quoted_cols = ', '.join([f'"{c}"' for c in cols])
            placeholders = ', '.join(['?'] * len(cols))
            s.execute(f'SELECT {quoted_cols} FROM "{table_name}"')
            rows = s.fetchall()
            if rows:
                d.executemany(
                    f'INSERT INTO "{table_name}" ({quoted_cols}) VALUES ({placeholders})',
                    rows,
                )

            s.execute('SELECT table_name,data_type,identifier,description,last_change,min_x,min_y,max_x,max_y,srs_id FROM gpkg_contents WHERE table_name=?', (table_name,))
            gc = s.fetchone()
            if gc:
                d.execute(
                    'INSERT INTO gpkg_contents (table_name,data_type,identifier,description,last_change,min_x,min_y,max_x,max_y,srs_id) VALUES (?,?,?,?,?,?,?,?,?,?)',
                    gc,
                )
            dst.commit()
        finally:
            src.close()
            dst.close()

    def _ensure_layer_styles_schema(self, input_gpkg, output_gpkg):
        src = sqlite3.connect(input_gpkg)
        dst = sqlite3.connect(output_gpkg)
        try:
            s = src.cursor()
            d = dst.cursor()
            s.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='layer_styles'")
            row = s.fetchone()
            if row and row[0]:
                d.execute(row[0])
            s.execute("SELECT sql FROM sqlite_master WHERE type='index' AND tbl_name='layer_styles' AND sql IS NOT NULL")
            for (sql,) in s.fetchall():
                try:
                    d.execute(sql)
                except Exception:
                    pass
            s.execute("SELECT sql FROM sqlite_master WHERE type='trigger' AND tbl_name='layer_styles' AND sql IS NOT NULL")
            for (sql,) in s.fetchall():
                try:
                    d.execute(sql)
                except Exception:
                    pass
            d.execute("SELECT 1 FROM gpkg_contents WHERE table_name='layer_styles'")
            if not d.fetchone():
                d.execute(
                    "INSERT INTO gpkg_contents (table_name,data_type,identifier,description,last_change,srs_id) VALUES ('layer_styles','attributes','layer_styles','',strftime('%Y-%m-%dT%H:%M:%fZ','now'),0)"
                )
            dst.commit()
        finally:
            src.close()
            dst.close()

    def _rewrite_style_qml_for_output(self, style_qml, output_gpkg):
        if not style_qml:
            return style_qml
        qml = style_qml
        new_src = f'{output_gpkg}|layername=CLAVE'
        qml = re.sub(
            r'(<Option name="LayerSource" type="QString" value=")([^"]*\|layername=CLAVE)(")',
            lambda m: m.group(1) + new_src + m.group(3),
            qml,
        )
        qml = re.sub(
            r'(<Option name="Layer" type="QString" value=")([^"]*)(")',
            lambda m: m.group(1) + 'CLAVE' + m.group(3),
            qml,
            count=1,
        )
        return qml

    def _clone_layer_styles_exact(self, input_gpkg, output_gpkg, source_table_name, target_table_name):
        src = sqlite3.connect(input_gpkg)
        dst = sqlite3.connect(output_gpkg)
        try:
            s = src.cursor()
            d = dst.cursor()
            d.execute('DELETE FROM layer_styles WHERE f_table_name = ?', (target_table_name,))
            s.execute('PRAGMA table_info(layer_styles)')
            cols = [r[1] for r in s.fetchall()]
            s.execute('SELECT * FROM layer_styles WHERE f_table_name = ? ORDER BY useAsDefault DESC, id ASC', (source_table_name,))
            rows = s.fetchall()
            if not rows:
                self._log(f"No se encontró estilo persistido para '{source_table_name}' en layer_styles.", Qgis.Warning)
                dst.commit()
                return

            for idx, row in enumerate(rows):
                record = dict(zip(cols, row))
                record['id'] = None
                record['f_table_name'] = target_table_name
                record['styleQML'] = self._rewrite_style_qml_for_output(record.get('styleQML'), output_gpkg)
                record['useAsDefault'] = 1 if idx == 0 else 0
                record['update_time'] = None
                insert_cols = [c for c in cols if c != 'id']
                placeholders = ','.join(['?'] * len(insert_cols))
                d.execute(
                    f"INSERT INTO layer_styles ({','.join(insert_cols)}) VALUES ({placeholders})",
                    [record[c] for c in insert_cols],
                )
            dst.commit()
        finally:
            src.close()
            dst.close()

    def _load_result_layers_to_qgis(self, output_gpkg, obra_name, created_layers, skip_empty=False):
        project = QgsProject.instance()
        root = project.layerTreeRoot()

        layers_to_remove = list(created_layers) + ['CLAVE']
        self._remove_existing_layers_by_source(output_gpkg, layers_to_remove)

        group = root.findGroup(obra_name)
        if group is None:
            group = root.addGroup(obra_name)
        else:
            self._clear_group_layers(group)

        hidden_clave = self._load_hidden_support_table(output_gpkg, 'CLAVE')

        operational_layers = [
            name for name in [
                f'{obra_name}_Puntos',
                f'{obra_name}_Lineas',
                f'{obra_name}_Poligonos',
            ] if name in created_layers
        ]
        base_layers = [name for name in ['pk', 'Estaciones', 'Lineas_FFCC'] if name in created_layers]

        # Garantiza los campos de Apertura/Cierre en las capas operativas
        # recién creadas (por si el GeoPackage de entrada usado como fuente
        # todavía no los tuviera) y prepara el formulario de edición, igual
        # que se hace al cargar una obra ya existente desde "Carga Obra".
        try:
            self.form_customizer.ensure_fields_for_gpkg(output_gpkg, operational_layers)
        except Exception as e:
            self._log(f"No se pudieron preparar los campos de incidencias en {output_gpkg}: {e}", Qgis.Warning)

        for layer_name in operational_layers:
            uri = f'{output_gpkg}|layername={layer_name}'
            vlayer = QgsVectorLayer(uri, layer_name, 'ogr')
            if not vlayer.isValid():
                self._log(f"No se pudo cargar la capa operativa '{layer_name}'.", Qgis.Warning)
                continue
            self._load_persisted_style(vlayer)
            if hidden_clave is not None:
                self._repair_tipo_value_relation_runtime(vlayer, hidden_clave, output_gpkg)
            self.form_customizer.apply_form(vlayer)
            if skip_empty and vlayer.featureCount() == 0:
                continue
            project.addMapLayer(vlayer, False)
            group.addLayer(vlayer)

        group.setExpanded(True)

        for layer_name in base_layers:
            uri = f'{output_gpkg}|layername={layer_name}'
            vlayer = QgsVectorLayer(uri, layer_name, 'ogr')
            if not vlayer.isValid():
                self._log(f"No se pudo cargar la capa base '{layer_name}'.", Qgis.Warning)
                continue
            self._load_persisted_style(vlayer)
            if skip_empty and vlayer.featureCount() == 0:
                continue
            project.addMapLayer(vlayer, True)


    def _load_hidden_support_table(self, output_gpkg, table_name):
        uri = f'{output_gpkg}|layername={table_name}'
        layer = QgsVectorLayer(uri, table_name, 'ogr')
        if not layer.isValid():
            self._log(f"No se pudo cargar la tabla interna '{table_name}' para soporte del formulario.", Qgis.Warning)
            return None
        QgsProject.instance().addMapLayer(layer, False)
        return layer

    def _repair_tipo_value_relation_runtime(self, layer, clave_layer, output_gpkg):
        try:
            field_index = layer.fields().indexOf('Tipo')
            if field_index < 0:
                field_index = layer.fields().indexOf('TIPO')
            if field_index < 0:
                return

            setup = layer.editorWidgetSetup(field_index)
            config = dict(setup.config()) if setup and hasattr(setup, 'config') else {}
            config.update({
                'AllowMulti': False,
                'AllowNull': False,
                'CompleterMatchFlags': 2,
                'Description': None,
                'DisplayGroupName': False,
                'FilterExpression': "\"N_AMB\" = current_value('Ámbito')",
                'Group': None,
                'Key': 'key',
                'Layer': clave_layer.id(),
                'LayerName': 'CLAVE',
                'LayerProviderName': 'ogr',
                'LayerSource': f'{output_gpkg}|layername=CLAVE',
                'NofColumns': 1,
                'OrderByDescending': False,
                'OrderByField': False,
                'OrderByFieldName': 'fid',
                'OrderByKey': True,
                'OrderByValue': False,
                'UseCompleter': False,
                'Value': 'TIPO',
            })
            layer.setEditorWidgetSetup(field_index, QgsEditorWidgetSetup('ValueRelation', config))
            layer.triggerRepaint()
        except Exception as exc:
            self._log(f"No se pudo reparar en runtime el control 'Tipo' de {layer.name()}: {exc}", Qgis.Warning)

    def _load_persisted_style(self, layer):
        try:
            err = ''
            ok = layer.loadDefaultStyle(err)
            if not ok and err:
                self._log(f"Aviso al cargar estilo persistido de {layer.name()}: {err}", Qgis.Warning)
        except Exception as exc:
            self._log(f"Aviso al cargar estilo persistido de {layer.name()}: {exc}", Qgis.Warning)

    def _clear_group_layers(self, group):
        project = QgsProject.instance()
        layer_ids = []
        for child in group.children():
            if child.nodeType() == child.NodeLayer:
                layer_ids.append(child.layerId())
        for layer_id in layer_ids:
            if project.mapLayer(layer_id):
                project.removeMapLayer(layer_id)
        for child in list(group.children()):
            group.removeChildNode(child)

    def _remove_existing_layers_by_source(self, output_gpkg, created_layers):
        project = QgsProject.instance()
        target_sources = {f'{output_gpkg}|layername={layer_name}'.lower() for layer_name in created_layers}
        for lyr in list(project.mapLayers().values()):
            src = (lyr.source() or '').lower()
            if src in target_sources:
                project.removeMapLayer(lyr.id())

    def _normalize_name(self, name):
        return name.replace('.gpkg', '').strip().replace(' ', '_')

    def _normalize_text(self, text):
        return (
            str(text or '')
            .lower()
            .replace('á', 'a')
            .replace('é', 'e')
            .replace('í', 'i')
            .replace('ó', 'o')
            .replace('ú', 'u')
            .replace('ñ', 'n')
            .replace(' ', '_')
            .strip()
        )

    def _log(self, text, level=Qgis.Info):
        QgsMessageLog.logMessage(text, 'OBRA_NUEVA', level)

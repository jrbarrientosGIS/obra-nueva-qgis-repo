# -*- coding: utf-8 -*-

def classFactory(iface):
    from .main_plugin import ObraNuevaPlugin
    return ObraNuevaPlugin(iface)

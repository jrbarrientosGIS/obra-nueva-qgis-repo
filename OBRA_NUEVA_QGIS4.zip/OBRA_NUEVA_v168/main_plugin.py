# -*- coding: utf-8 -*-
import os
from qgis.core import Qgis
from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtGui import QIcon, QAction
from qgis.PyQt.QtWidgets import QPushButton

from .ui.main_dialog import ObraNuevaMainDialog


# V1.7.27: espera tras abrir el proyecto antes de comprobar las obras, para
# no frenar la apertura (las capas terminan de cargarse y se dibujan antes).
PROJECT_CHECK_DELAY_MS = 1500


class ObraNuevaPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dialog = None
        self._model_checker = None
        self._check_messages = {}   # {ruta normalizada: widget de la barra de mensajes}
        self._project_signal_connected = False

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.action = QAction(QIcon(icon_path), 'OBRA_NUEVA', self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu('OBRA_NUEVA', self.action)
        # V1.7.27: comprobación de las obras al abrir un proyecto.
        try:
            self.iface.projectRead.connect(self._on_project_read)
            self._project_signal_connected = True
        except Exception:
            self._project_signal_connected = False

    def unload(self):
        if self._project_signal_connected:
            try:
                self.iface.projectRead.disconnect(self._on_project_read)
            except Exception:
                pass
            self._project_signal_connected = False
        self._clear_check_messages()
        # V1.7.16: al descargar el plugin se cancela la herramienta de colocar
        # fotos (si estaba activa en el lienzo) y se cierra el diálogo.
        if self.dialog is not None:
            try:
                from .ui.tab_fotos import FotosTab
                for tab in self.dialog.findChildren(FotosTab):
                    tab.cancel_placement(silent=True)
            except Exception:
                pass
            try:
                self.dialog.close()
                self.dialog.deleteLater()
            except Exception:
                pass
            self.dialog = None
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu('OBRA_NUEVA', self.action)
            self.action = None

    def _ensure_dialog(self):
        if self.dialog is None:
            self.dialog = ObraNuevaMainDialog(self.iface)
            self.dialog.setWindowModality(Qt.WindowModality.NonModal)
            try:
                self.dialog.tab_actualiza_gpkg.on_gpkg_up_to_date = self._on_gpkg_up_to_date
            except Exception:
                pass
        return self.dialog

    def run(self):
        self._ensure_dialog()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()

    # ── V1.7.27: comprobación al abrir un proyecto ──────────────────────
    def _checker(self):
        if self._model_checker is None:
            from .core.model_check import ModelChecker
            self._model_checker = ModelChecker()
        return self._model_checker

    def _on_project_read(self, *args):
        self._clear_check_messages()
        try:
            if not self._checker().enabled():
                return
        except Exception:
            return
        QTimer.singleShot(PROJECT_CHECK_DELAY_MS, self._check_project_now)

    def _check_project_now(self):
        from .helpers.logging_utils import log_warning
        try:
            model_path, results = self._checker().check_project()
        except Exception as e:
            log_warning(f'Comprobación al abrir: error inesperado: {e}')
            return
        for res in results:
            if res.status == 'pending':
                self._push_pending_message(model_path, res)
            elif res.status == 'error':
                log_warning(f'Comprobación al abrir: no se pudo comprobar {res.gpkg_path}: {res.text}')

    def _push_pending_message(self, model_path, res):
        from .core.model_check import _norm_path
        bar = self.iface.messageBar()
        text = (
            f'«{res.name}» no está al día con el modelo '
            f'{os.path.basename(model_path)}: {res.text} pendiente(s).'
        )
        widget = bar.createMessage('OBRA_NUEVA', text)
        btn = QPushButton('Abrir Actualiza GPKG')
        btn.setToolTip(
            'Abre "Actualiza GPKG" con esta obra y el modelo, y muestra el informe de diferencias.\n'
            'No se modifica nada hasta que pulses «Actualizar GPKG».'
        )
        btn.clicked.connect(lambda _=False, m=model_path, g=res.gpkg_path: self._open_actualiza(m, g))
        widget.layout().addWidget(btn)
        btn_off = QPushButton('No comprobar al abrir')
        btn_off.setToolTip('Desactiva este aviso. Se puede volver a activar en "Actualiza GPKG".')
        btn_off.clicked.connect(self._disable_check_on_open)
        widget.layout().addWidget(btn_off)
        bar.pushWidget(widget, Qgis.MessageLevel.Warning, 0)
        self._check_messages[_norm_path(res.gpkg_path)] = widget

    def _open_actualiza(self, model_path, gpkg_path):
        dlg = self._ensure_dialog()
        tab = dlg.tab_actualiza_gpkg
        tool = dlg.dlg_actualiza_gpkg
        tool.show()
        tool.raise_()
        tool.activateWindow()
        tab.prepare_single_analysis(model_path, gpkg_path)

    def _on_gpkg_up_to_date(self, gpkg_path):
        """La pestaña Actualiza GPKG avisa de que una obra ha quedado al
        día: se quita su aviso de la barra de mensajes."""
        from .core.model_check import _norm_path
        widget = self._check_messages.pop(_norm_path(gpkg_path), None)
        if widget is not None:
            try:
                self.iface.messageBar().popWidget(widget)
            except Exception:
                pass

    def _disable_check_on_open(self):
        try:
            self._checker().set_enabled(False)
        except Exception:
            pass
        if self.dialog is not None:
            try:
                self.dialog.tab_actualiza_gpkg.sync_check_on_open_checkbox()
            except Exception:
                pass
        self._clear_check_messages()
        self.iface.messageBar().pushMessage(
            'OBRA_NUEVA',
            'Comprobación al abrir desactivada. Puedes volver a activarla en "Actualiza GPKG".',
            Qgis.MessageLevel.Info, 6,
        )

    def _clear_check_messages(self):
        bar = None
        try:
            bar = self.iface.messageBar()
        except Exception:
            pass
        for widget in list(self._check_messages.values()):
            try:
                if bar is not None:
                    bar.popWidget(widget)
            except Exception:
                pass
        self._check_messages = {}

# -*- coding: utf-8 -*-
import os

from qgis.core import (
    QgsEditorWidgetSetup, QgsProject, QgsVectorLayer, QgsWkbTypes,
)

from .gpkg_utils import GpkgIntrospector, normalize_text
from .ogr_layer_utils import project_layers_for_gpkg, split_ogr_source
from ..helpers.file_utils import normalize_base_name
from ..helpers.logging_utils import log_info, log_warning
from .legend_pruner import LegendPruner
from .form_customizer import IncidenciaFormCustomizer


# Propiedad que recuerda en cada capa si se cargó en modo "Visualización"
# (leyenda recortada) o "Edición" (leyenda completa), para respetarlo cuando
# la capa se refresca tras "Actualiza GPKG" sin volver a preguntar (V198).
PRUNED_LEGEND_PROP = 'obra_nueva/legend_pruned'


def _truthy(value):
    return value in (True, 1, '1', 'true', 'True', 'TRUE')


class GpkgLoader:
    def __init__(self):
        self.legend_pruner = LegendPruner()
        self.form_customizer = IncidenciaFormCustomizer()

    def list_sublayers(self, gpkg_path):
        return GpkgIntrospector(gpkg_path).list_feature_tables()

    def load_grouped_gpkg(self, gpkg_path, load_mode='all', no_duplicates=True, skip_empty=False, prune_legend=True):
        selected = self.find_operational_layers_strict(gpkg_path)
        return self.load_selected_layers(
            gpkg_path,
            selected_layer_names=selected,
            no_duplicates=no_duplicates,
            skip_empty=skip_empty,
            prune_legend=prune_legend,
        )

    def load_selected_layers(self, gpkg_path, selected_layer_names, no_duplicates=True, skip_empty=False, prune_legend=True):
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        group_name = normalize_base_name(gpkg_path)
        main_group = root.findGroup(group_name) or root.addGroup(group_name)
        self._clear_group_layers(main_group)

        ordered_names = self._sort_operational_layers(selected_layer_names)

        try:
            self.form_customizer.ensure_fields_for_gpkg(gpkg_path, ordered_names)
        except Exception as e:
            log_warning(f'No se pudieron preparar los campos de incidencias en {gpkg_path}: {e}')

        loaded_layers = []
        for layer_name in ordered_names:
            uri = f'{gpkg_path}|layername={layer_name}'
            existing_layers = (
                [l for l in project_layers_for_gpkg(gpkg_path, layer_name) if l.isValid()]
                if no_duplicates else []
            )
            if existing_layers:
                # La capa ya estaba cargada en el proyecto (p. ej. se acaba
                # de abrir un proyecto guardado que ya la traía, o se cargó
                # antes en esta misma sesión, o "Actualiza GPKG" acaba de
                # añadirle campos). V198: se localizan TODAS sus copias
                # comparando rutas normalizadas (antes se comparaba el
                # texto exacto de la ruta, y una copia con la ruta escrita
                # de otra forma -- "\\" frente a "/", mayúsculas -- no se
                # reconocía y se quedaba con el formulario viejo). Todas se
                # refrescan (estructura, estilo, formulario); la primera se
                # coloca en el grupo de la obra.
                existing = existing_layers[0]
                for lyr in existing_layers:
                    self._refresh_existing_layer(lyr, gpkg_path, layer_name, prune_legend)
                # Si la capa ya tenía un nodo en el árbol (en el propio
                # grupo de la obra o en cualquier otro sitio del panel
                # de capas, p. ej. porque el usuario la cargó a mano),
                # se quita de ahí antes de volver a añadirla al grupo de
                # la obra, para no dejarla duplicada visualmente.
                existing_node = project.layerTreeRoot().findLayer(existing.id())
                if existing_node is not None and existing_node.parent() is not None:
                    existing_node.parent().removeChildNode(existing_node)
                main_group.addLayer(existing)
                loaded_layers.append(existing)
                continue
            layer = QgsVectorLayer(uri, layer_name, 'ogr')
            if not layer.isValid():
                log_warning(f'No se pudo cargar la capa: {layer_name}')
                continue
            if skip_empty and layer.featureCount() == 0:
                continue
            layer.setName(layer_name)
            self._load_persisted_style(layer)
            self._repair_value_relation_layers(layer, gpkg_path)
            self.form_customizer.apply_form(layer)
            if prune_legend:
                self.legend_pruner.prune_layer_legend(layer)
            layer.setCustomProperty(PRUNED_LEGEND_PROP, bool(prune_legend))
            project.addMapLayer(layer, False)
            main_group.addLayer(layer)
            loaded_layers.append(layer)
        main_group.setExpanded(True)
        log_info(f'Cargadas {len(loaded_layers)} capas operativas desde {gpkg_path}')
        return loaded_layers

    def _refresh_existing_layer(self, layer, gpkg_path, table_name, prune_legend):
        """Pone al día una capa YA cargada en el proyecto: estructura
        (campos nuevos), estilo guardado en el GeoPackage, desplegables
        ValueRelation y formulario de la obra. V198: sin setDataSource()
        salvo como último recurso (ver _ensure_schema_current)."""
        self._ensure_schema_current(layer, gpkg_path, table_name)
        self._load_persisted_style(layer)
        self._repair_value_relation_layers(layer, gpkg_path)
        self.form_customizer.apply_form(layer)
        if prune_legend:
            self.legend_pruner.prune_layer_legend(layer)
        try:
            layer.setCustomProperty(PRUNED_LEGEND_PROP, bool(prune_legend))
            layer.triggerRepaint()
        except Exception:
            pass

    def _ensure_schema_current(self, layer, gpkg_path, table_name):
        """Comprueba si la capa ya "ve" todas las columnas que tiene ahora
        la tabla en el fichero. Desde V198 los campos se añaden por el propio
        proveedor OGR de QGIS, así que lo normal es que ya las vea y aquí no
        se haga nada. Si faltan (campos añadidos por otro programa o por una
        versión anterior del plugin), primero se intenta una recarga suave
        del proveedor y, solo si no basta, setDataSource() (V177), que
        reabre el origen de datos por completo."""
        try:
            intro = GpkgIntrospector(gpkg_path)
            file_cols = {normalize_text(c) for c in intro.table_columns(table_name)}
            # El nombre de tabla puede venir con otras mayúsculas que en
            # gpkg_geometry_columns (p. ej. desde el origen de la capa).
            geom_col = None
            for t in intro.list_geometry_tables():
                if t.lower() == (table_name or '').lower():
                    geom_col = intro.geometry_column_name(t)
                    break
            if geom_col:
                file_cols.discard(normalize_text(geom_col))
        except Exception as e:
            log_warning(f'No se pudo leer la estructura de "{table_name}" en {gpkg_path}: {e}')
            return

        def missing():
            return file_cols - {normalize_text(f.name()) for f in layer.fields()}

        if not missing():
            return
        try:
            layer.dataProvider().reloadData()
            layer.updateFields()
        except Exception as e:
            log_warning(f'No se pudieron recargar los campos de "{layer.name()}": {e}')
        if not missing():
            return
        try:
            layer.setDataSource(layer.source(), layer.name(), 'ogr', False)
        except Exception as e:
            log_warning(f'No se pudo reconectar la capa "{layer.name()}" al origen de datos actualizado: {e}')

    def _load_persisted_style(self, layer):
        """Carga sobre la capa el estilo guardado como predeterminado en el
        GeoPackage (tabla layer_styles, useAsDefault=1) -- exactamente el
        que sincroniza la pestaña "Actualiza GPKG": leyenda/simbología,
        anchos ValueMap/ValueRelation, formato de fecha, carpeta por defecto
        de los campos de documento, y el diseño de formulario (grupos,
        pestañas) diseñado en el modelo.

        QgsVectorLayer NO carga este estilo automáticamente: hay que pedirlo
        de forma explícita con loadDefaultStyle(), igual que ya hacen las
        pestañas "Nueva Obra" y "Consulta". Sin esta llamada, el formulario
        de edición nace con los valores por defecto de QGIS (sin listas
        desplegables, sin carpeta de documento, sin agrupaciones), aunque el
        GeoPackage tenga el estilo correcto guardado."""
        try:
            # loadDefaultStyle() no admite parámetros y devuelve (mensaje,
            # ok) -- no (ok) con un parámetro de salida por referencia. Con
            # la firma antigua, PyQGIS lanza TypeError ("too many
            # arguments") en las versiones de QGIS comprobadas.
            msg, ok = layer.loadDefaultStyle()
            if not ok and msg:
                log_warning(f'Aviso al cargar el estilo guardado de "{layer.name()}": {msg}')
        except Exception as e:
            log_warning(f'No se pudo cargar el estilo guardado de "{layer.name()}": {e}')

    # Tablas de apoyo (no espaciales) del GeoPackage cuyos ValueRelation
    # necesitan repararse igual que "CLAVE" (ver docstring de
    # _repair_value_relation_layers). V190 añade "ASPECTOS" (desplegable de
    # aspecto ambiental para Incidencias Ambientales, ver form_customizer.py)
    # sin tocar el comportamiento ya probado para "CLAVE".
    SUPPORT_TABLES = ('CLAVE', 'ASPECTOS')

    def _repair_value_relation_layers(self, layer, gpkg_path):
        """Repara los campos ValueRelation que apuntan a una tabla de apoyo
        del propio modelo -- "CLAVE" (p. ej. "Tipo", filtrado por Ámbito) o
        "ASPECTOS" (p. ej. "Aspecto Ambiental") -- ver SUPPORT_TABLES.

        El estilo persistido que se traslada tal cual desde el modelo (ver
        form_customizer.py V175) guarda, para esos campos, la ruta absoluta
        del GeoPackage donde el AUTOR del modelo tenía cargada su propia
        copia de esa tabla (p. ej. "E:/1_GPK/SDON_KKK.gpkg|layername=CLAVE")
        y el id interno que esa capa tenía en SU proyecto de QGIS. Ninguno
        de los dos existe en la máquina de quien abre otra obra: la ruta no
        suele existir en ese equipo, y aunque existiera, el id de capa no
        coincide con nada cargado en este proyecto. Sin poder resolver esa
        referencia, QGIS no encuentra la descripción del código
        seleccionado y el desplegable se ve, por ejemplo, "(8.1)" en vez de
        una descripción legible (comprobado con el propio SDON79).

        Todo GeoPackage de obra lleva su PROPIA copia de estas tablas (se
        sincronizan igual que el resto de tablas de referencia). Aquí se
        reapunta cada campo ValueRelation cuyo "LayerName" coincida con
        alguna de SUPPORT_TABLES a la tabla homónima de ESTE GeoPackage
        (cargada como capa oculta de apoyo, reutilizada si ya estaba
        cargada), conservando el resto de su configuración (columnas
        clave/valor, filtro, descripción...) tal cual la dejó el modelo --
        solo se corrige la referencia a la capa, no el diseño."""
        fields = layer.fields()
        tables_in_use = set()
        for i in range(fields.count()):
            setup = layer.editorWidgetSetup(i)
            if setup.type() != 'ValueRelation':
                continue
            config = setup.config() or {}
            layer_name_norm = normalize_text(str(config.get('LayerName') or ''))
            for table in self.SUPPORT_TABLES:
                if layer_name_norm == normalize_text(table):
                    tables_in_use.add(table)
        if not tables_in_use:
            return

        hidden_layers = {}
        for table in tables_in_use:
            hidden = self._get_hidden_support_layer(gpkg_path, table)
            if hidden is not None:
                hidden_layers[table] = hidden

        for i in range(fields.count()):
            setup = layer.editorWidgetSetup(i)
            if setup.type() != 'ValueRelation':
                continue
            config = dict(setup.config() or {})
            layer_name_norm = normalize_text(str(config.get('LayerName') or ''))
            matched_table = next(
                (t for t in self.SUPPORT_TABLES if normalize_text(t) == layer_name_norm),
                None,
            )
            if matched_table is None or matched_table not in hidden_layers:
                continue
            hidden = hidden_layers[matched_table]
            config['Layer'] = hidden.id()
            config['LayerName'] = matched_table
            config['LayerProviderName'] = 'ogr'
            config['LayerSource'] = f'{gpkg_path}|layername={matched_table}'
            layer.setEditorWidgetSetup(i, QgsEditorWidgetSetup('ValueRelation', config))

    def _get_hidden_support_layer(self, gpkg_path, table_name):
        """Carga (o reutiliza, si ya está cargada) una tabla de apoyo
        (CLAVE, ASPECTOS...) del GeoPackage indicado como capa oculta (no
        se añade a ningún grupo del panel de capas), para que los campos
        ValueRelation puedan resolverla por id de capa dentro de este
        proyecto de QGIS."""
        uri = f'{gpkg_path}|layername={table_name}'
        existing = [l for l in project_layers_for_gpkg(gpkg_path, table_name) if l.isValid()]
        if existing:
            return existing[0]
        layer = QgsVectorLayer(uri, table_name, 'ogr')
        if not layer.isValid():
            log_warning(f'No se pudo cargar la tabla "{table_name}" de {gpkg_path} para resolver los desplegables ValueRelation.')
            return None
        QgsProject.instance().addMapLayer(layer, False)
        return layer

    def find_operational_layers_strict(self, gpkg_path):
        layer_names = self.list_sublayers(gpkg_path)
        targets = [
            ('Puntos', QgsWkbTypes.PointGeometry, ['_puntos', 'puntos']),
            ('Lineas', QgsWkbTypes.LineGeometry, ['_lineas', '_líneas', 'lineas', 'líneas']),
            ('Poligonos', QgsWkbTypes.PolygonGeometry, ['_poligonos', '_polígonos', 'poligonos', 'polígonos']),
        ]

        found = []
        for _, geom_type, suffixes in targets:
            match = self._find_layer_by_suffix_and_geom(
                gpkg_path=gpkg_path,
                layer_names=layer_names,
                suffixes=suffixes,
                target_geom_type=geom_type,
            )
            if match:
                found.append(match)
        return self._sort_operational_layers(found)

    def _find_layer_by_suffix_and_geom(self, gpkg_path, layer_names, suffixes, target_geom_type):
        suffixes = [self._normalize_text(s) for s in suffixes]
        candidates = []
        geometry_map = GpkgIntrospector(gpkg_path).geometry_type_by_table()

        excluded = {
            'pk',
            'estaciones',
            'estacion',
            'lineas_ffcc',
            'lineasffcc',
            'leyenda',
            'clave',
            'layer_groups',
            'metadata',
        }

        def geom_family(geometry_type_name):
            g = self._normalize_text(geometry_type_name)
            if 'point' in g:
                return QgsWkbTypes.PointGeometry
            if 'line' in g or 'curve' in g:
                return QgsWkbTypes.LineGeometry
            if 'polygon' in g or 'surface' in g:
                return QgsWkbTypes.PolygonGeometry
            return QgsWkbTypes.UnknownGeometry

        for layer_name in layer_names:
            lname = self._normalize_text(layer_name)
            if lname in excluded:
                continue
            if any(bad in lname for bad in ['leyenda', 'clave', 'group', 'metadata']):
                continue

            if geom_family(geometry_map.get(layer_name, '')) != target_geom_type:
                continue

            score = -1
            for suffix in suffixes:
                if lname == suffix:
                    score = max(score, 200)
                elif lname.endswith(suffix):
                    score = max(score, 150)
                elif suffix in lname:
                    score = max(score, 100)

            if score >= 0:
                candidates.append((score, layer_name))

        if not candidates:
            return None
        candidates.sort(key=lambda x: (-x[0], x[1]))
        return candidates[0][1]

    def _sort_operational_layers(self, layer_names):
        def rank(name):
            n = self._normalize_text(name)
            if 'puntos' in n:
                return (0, n)
            if 'lineas' in n:
                return (1, n)
            if 'poligonos' in n:
                return (2, n)
            return (99, n)
        return sorted(layer_names, key=rank)

    def _clear_group_layers(self, group):
        project = QgsProject.instance()
        layer_ids = []
        for child in group.children():
            if child.nodeType() == child.NodeLayer:
                layer_ids.append(child.layerId())
        for layer_id in layer_ids:
            if project.mapLayer(layer_id):
                project.removeMapLayer(layer_id)
        for child in list(group.children()):
            group.removeChildNode(child)

    def detach_layers_for_path(self, gpkg_path):
        """Devuelve [(capa, origen), ...] de todas las capas del proyecto
        QGIS actual que provienen de gpkg_path, para refrescarlas con
        reattach_layers() cuando termine "Actualiza GPKG".

        V198: YA NO DESCONECTA NADA (se conserva el nombre para no tocar
        las llamadas de ui/tab_actualiza_gpkg.py). V194 desconectaba estas
        capas con setDataSource('') antes de escribir, para no tener dos
        conexiones abiertas sobre el mismo fichero; el usuario confirmó que
        QGIS 3 seguía cerrándose de golpe. La causa de fondo -- cambiar el
        esquema con ALTER TABLE desde una conexión sqlite3 propia, por
        debajo de GDAL -- se ha eliminado: los campos se añaden ahora por el
        proveedor OGR de QGIS (core/ogr_layer_utils.py), que es seguro con
        las capas conectadas. Desconectar una capa viva era además un riesgo
        en sí mismo (lienzo dibujándola, tabla o formulario abiertos,
        desplegables que la referencian)."""
        return [(layer, layer.source()) for layer in project_layers_for_gpkg(gpkg_path)]

    def reattach_layers(self, detached):
        """Tras "Actualiza GPKG" (modo un solo GeoPackage y modo carpeta),
        pone al día las capas de ese GeoPackage que ya estaban cargadas:
        campos nuevos, estilo sincronizado desde el modelo y formulario de
        la obra (grupos FICHAS-INFORMES/FOTOS/NC-INCIDENCIAS, ASPECTO-ZONA
        condicional, selectores de documento...). Antes (V194-V197) solo se
        reconectaba el origen de datos y el formulario se quedaba como
        estaba hasta volver a cargar la obra (posible origen del formulario
        "plano", sin grupos, visto en SDONO124). Respeta el modo de leyenda con el
        que se cargó cada capa (Edición/Visualización).

        El estilo y el formulario solo se reaplican a las capas operativas
        de la obra (con Ámbito, Tipo y Ficha); al resto (tablas de apoyo,
        capas base) solo se les refresca la estructura."""
        for layer, uri in detached:
            try:
                if not layer.isValid():
                    continue
                _, lname = split_ogr_source(uri or layer.source())
                gpkg_path = (uri or layer.source()).split('|')[0]
                table_name = lname or layer.name()
                if self._is_operational_layer(layer):
                    prune = _truthy(layer.customProperty(PRUNED_LEGEND_PROP, False))
                    self._refresh_existing_layer(layer, gpkg_path, table_name, prune)
                else:
                    self._ensure_schema_current(layer, gpkg_path, table_name)
            except Exception as e:
                log_warning(f'No se pudo refrescar la capa "{layer.name()}" tras la actualización: {e}')

    def _is_operational_layer(self, layer):
        names = {normalize_text(f.name()) for f in layer.fields()}
        return (
            ('ambito' in names)
            and ('tipo' in names)
            and ('ficha' in names)
        )

    def _is_layer_loaded(self, uri):
        return self._find_loaded_layer_by_uri(uri) is not None

    def _find_loaded_layer_by_uri(self, uri):
        path, lname = split_ogr_source(uri)
        gpkg_path = (uri or '').split('|')[0]
        found = project_layers_for_gpkg(gpkg_path, lname) if lname else []
        return found[0] if found else None

    def _normalize_text(self, text):
        return normalize_text(text).strip()

# -*- coding: utf-8 -*-
"""
OBRA_NUEVA - Escritura de estructura en un GeoPackage SIN salir del
proveedor OGR de QGIS (V198).

MOTIVO
------
Hasta V197, "Actualiza GPKG" (core/gpkg_updater.py) y la preparación de
campos de incidencias (core/form_customizer.py -> ensure_fields_for_gpkg)
añadían columnas con "ALTER TABLE ... ADD COLUMN" desde una conexión
sqlite3 propia de Python, abierta en paralelo a la conexión GDAL/OGR que
QGIS mantiene sobre el mismo fichero para las capas cargadas. Cambiar el
esquema de una tabla por debajo de GDAL deja a su proveedor con una
estructura en caché que ya no coincide con el fichero, y es una causa
conocida de cierres NATIVOS de QGIS (no capturables desde Python).

V194 intentó evitarlo desconectando las capas (setDataSource a un origen
vacío) antes de escribir y reconectándolas después. El usuario ha
confirmado que QGIS 3 sigue cerrándose de golpe: además de que QGIS
mantiene su propio "pool" de conexiones OGR abiertas aunque la capa se
desconecte, el propio setDataSource('') sobre una capa viva (con el lienzo
dibujándola, su tabla o formulario abiertos, o widgets ValueRelation que
la referencian) es en sí mismo arriesgado.

SOLUCIÓN
--------
Añadir los campos con el MISMO mecanismo que usa QGIS cuando el usuario
añade un campo desde la tabla de atributos: QgsVectorDataProvider.
addAttributes() del proveedor OGR. Ese proveedor comparte el dataset GDAL
con el resto de capas del mismo fichero e invalida él mismo su pool de
conexiones, así que QGIS nunca ve un esquema distinto del real. Si la
tabla ya está cargada en el proyecto, se usa el proveedor de ESA capa; si
no, una capa OGR temporal que no se añade al proyecto.

Ya no hace falta desconectar ni reconectar ninguna capa.
"""
import os

from qgis.core import QgsField, QgsProject, QgsVectorLayer

from .gpkg_utils import normalize_text


# ── Localizar capas del proyecto que apuntan a un fichero/tabla ─────────
def _norm_path(path):
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(path or '')))
    except Exception:
        return os.path.normcase(path or '')


def split_ogr_source(source):
    """'C:/x/obra.gpkg|layername=Tabla|subset=...' -> (ruta_normalizada,
    'Tabla' tal cual viene escrita, o None). Tolera '\\' frente a '/', mayúsculas y
    parámetros adicionales -- la comparación de texto exacto que se usaba
    antes no reconocía una misma capa cuando la ruta venía escrita de otra
    forma, y dejaba una copia antigua sin refrescar en el proyecto."""
    parts = (source or '').split('|')
    file_part = parts[0]
    layer_name = None
    for p in parts[1:]:
        key, sep, value = p.partition('=')
        if sep and key.strip().lower() == 'layername':
            layer_name = value.strip()
    return _norm_path(file_part), layer_name


def project_layers_for_gpkg(gpkg_path, table_name=None):
    """Todas las capas vectoriales del proyecto QGIS actual que provienen
    de gpkg_path (y, si se indica, de su tabla table_name). Devuelve TODAS
    las coincidencias, no solo la primera."""
    target = _norm_path(gpkg_path)
    wanted = table_name.lower() if table_name else None
    found = []
    for layer in list(QgsProject.instance().mapLayers().values()):
        try:
            # isinstance en vez de layer.type() == QgsMapLayer.VectorLayer:
            # funciona igual con el enum antiguo (QGIS 3) y el nuevo (QGIS 4).
            if not isinstance(layer, QgsVectorLayer):
                continue
            path, lname = split_ogr_source(layer.source())
            if not path.endswith('.gpkg') or path != target:
                continue
            if wanted is not None and (lname or '').lower() != wanted:
                continue
            found.append(layer)
        except Exception:
            continue
    return found


def editing_layers_for_gpkg(gpkg_path):
    """Capas de ese GeoPackage que están ahora mismo en modo edición."""
    result = []
    for layer in project_layers_for_gpkg(gpkg_path):
        try:
            if layer.isEditable():
                result.append(layer)
        except Exception:
            continue
    return result


def assert_no_layer_in_edit_mode(gpkg_path):
    """Lanza RuntimeError si alguna capa de ese GeoPackage está en modo
    edición. Añadir columnas por el proveedor con un búfer de edición
    abierto desincronizaría ese búfer (índices de campo desplazados), así
    que se pide al usuario que guarde o descarte antes."""
    editing = editing_layers_for_gpkg(gpkg_path)
    if editing:
        names = ', '.join(sorted({l.name() for l in editing}))
        raise RuntimeError(
            'Hay capas de este GeoPackage en modo edición (' + names + '). '
            'Guarda o descarta sus cambios y sal del modo edición antes de '
            'actualizar el GeoPackage.'
        )


# ── Crear campos ─────────────────────────────────────────────────────────
def nullable_copy(field):
    """Copia de un QgsField (tipo, nombre de tipo, longitud, precisión,
    subtipo) SIN sus restricciones: los campos se añaden siempre como
    opcionales para no invalidar registros existentes (mismo criterio que
    antes con ALTER TABLE)."""
    try:
        return QgsField(
            field.name(), field.type(), field.typeName(),
            field.length(), field.precision(), '', field.subType(),
        )
    except TypeError:
        return QgsField(field.name(), field.type(), field.typeName(), field.length(), field.precision())


def simple_field(name, kind):
    """QgsField para los tipos básicos que necesita el plugin sin modelo
    del que copiar ('TEXT', 'DATE', 'INTEGER', 'REAL'). Usa QMetaType
    (QGIS 3.38+ y QGIS 4) y, si no está disponible, QVariant."""
    kind = (kind or 'TEXT').upper()
    try:
        from qgis.PyQt.QtCore import QMetaType
        t = {
            'TEXT': QMetaType.Type.QString,
            'DATE': QMetaType.Type.QDate,
            'INTEGER': QMetaType.Type.LongLong,
            'REAL': QMetaType.Type.Double,
        }.get(kind, QMetaType.Type.QString)
        return QgsField(name, t)
    except Exception:
        from qgis.PyQt.QtCore import QVariant
        t = {
            'TEXT': QVariant.String,
            'DATE': QVariant.Date,
            'INTEGER': QVariant.LongLong,
            'REAL': QVariant.Double,
        }.get(kind, QVariant.String)
        return QgsField(name, t)


def add_fields_via_provider(gpkg_path, table_name, qgs_fields):
    """Añade qgs_fields a gpkg_path|table_name mediante el proveedor OGR
    de QGIS. Omite los que ya existan (comparación normalizada). Devuelve
    la lista de nombres realmente añadidos. Lanza RuntimeError si el
    proveedor rechaza la operación.

    Si la tabla ya está cargada en el proyecto, se usa el proveedor de la
    primera capa encontrada y después se refrescan los campos de TODAS las
    capas de esa tabla; si no está cargada, se usa una capa temporal que
    nunca se añade al proyecto."""
    uri = f'{gpkg_path}|layername={table_name}'
    loaded = project_layers_for_gpkg(gpkg_path, table_name)
    loaded = [l for l in loaded if l.isValid()]
    temp = None
    if loaded:
        target = loaded[0]
    else:
        temp = QgsVectorLayer(uri, table_name, 'ogr')
        if not temp.isValid():
            raise RuntimeError(f'No se pudo abrir la tabla "{table_name}" de {gpkg_path}.')
        target = temp

    try:
        prov = target.dataProvider()
        existing = {normalize_text(f.name()) for f in prov.fields()}
        to_add = []
        for f in qgs_fields:
            key = normalize_text(f.name())
            if key in existing:
                continue
            existing.add(key)
            to_add.append(f)
        if not to_add:
            return []

        ok = prov.addAttributes(to_add)
        if not ok:
            detail = ''
            try:
                errs = prov.errors()
                if errs:
                    detail = ': ' + ' / '.join(str(e) for e in errs[-3:])
            except Exception:
                pass
            raise RuntimeError(f'QGIS no pudo añadir campos a "{table_name}"{detail}')

        target.updateFields()
        # Otras copias de la misma tabla en el proyecto (poco habitual, p.
        # ej. el usuario la arrastró dos veces al lienzo): recargan su
        # proveedor para ver las columnas nuevas.
        for other in loaded[1:]:
            try:
                other.dataProvider().reloadData()
                other.updateFields()
            except Exception:
                pass
        return [f.name() for f in to_add]
    finally:
        if temp is not None:
            del temp

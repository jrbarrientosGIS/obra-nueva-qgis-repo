# -*- coding: utf-8 -*-
"""
OBRA_NUEVA - Personalización automática del formulario de edición.

Cuando una capa operativa (Puntos/Líneas/Polígonos) sigue el esquema estándar
de obra (campos Ámbito, Tipo, Ficha, Foto 1, Foto 2), este módulo:

  1. Garantiza que existan cuatro campos adicionales en la tabla del
     GeoPackage: "Apertura", "Doc_Apertura", "Cierre" y "Doc_Cierre"
     (se añaden si faltan, mediante el proveedor OGR de QGIS desde V198;
     nunca se eliminan ni modifican columnas existentes, ni se toca
     ninguna entidad gráfica).
  2. Reconfigura el formulario de edición (en memoria, sobre la capa ya
     cargada en QGIS). Desde V175 el criterio es: TRASLADAR EXACTAMENTE el
     formulario que el propio modelo trae diseñado a mano en QGIS, en vez
     de reconstruir una aproximación en Python.

     Antes de llegar aquí, GpkgLoader ya ha cargado sobre la capa el
     estilo persistido del GeoPackage (ver GpkgLoader._load_persisted_style)
     -- el mismo que la pestaña "Actualiza GPKG" sincroniza copiando tal
     cual (fila completa de layer_styles) desde el modelo. Ese estilo ya
     incluye el formulario diseñado en el modelo: grupos "FICHAS-INFORMES"
     (Ficha + Poyecto/Proyecto), "FOTOS" (Foto 1-4) y "NC-INCIDENCIAS"
     (Apertura/Cierre/Doc_Apertura/Doc_Cierre), con sus nombres exactos.
     Si ese formulario diseñado ya está presente (la capa trae al menos un
     grupo), este módulo NO LO TOCA -- lo deja exactamente como lo dejó el
     modelo. Solo reconstruye el formulario desde cero (con esos mismos
     tres grupos, como red de seguridad) cuando la capa no tiene ningún
     grupo propio (obra muy antigua, o "Actualiza GPKG" se ejecutó con la
     sincronización de estilos desactivada).

     En ambos casos (formulario del modelo intacto, o reconstruido aquí),
     se aplica un último ajuste de colapso a los tres grupos conocidos,
     replicando la configuración de "Formulario de atributos" que el
     usuario diseñó en QGIS (ver capturas): plegados por defecto y,
     además, con "Control Collapsed by Expression" activado para que el
     grupo se despliegue solo él cuando ya hay datos que mostrar:
       - "FICHAS-INFORMES" se despliega cuando "Ficha" no está vacío.
       - "FOTOS" se despliega cuando "Foto 1" no está vacío.
       - "NC-INCIDENCIAS" se despliega cuando "Apertura" no está vacío.
     (El campo `setCollapsedExpression` de QgsAttributeEditorContainer es
     una API de QGIS 3.44+ -- la versión mínima que ya declara este plugin
     --; en una versión de QGIS más antigua sin esa API, el grupo se queda
     simplemente plegado por defecto, sin el despliegue automático.)

     El widget de Doc_Apertura/Doc_Cierre (ExternalResource) solo se
     sustituye por la configuración genérica de aquí abajo si el campo
     todavía no tiene ningún widget de documento asignado (obras antiguas
     sin estilo guardado); si ya viene de un estilo persistido (con su
     propia carpeta por defecto), no se toca.

Este módulo no depende de que el GeoPackage tenga un estilo (QML) previo:
si no lo tiene, construye un formulario de repuesto directamente sobre la
capa cargada, por lo que funciona igual con obras antiguas y nuevas.
"""
import sqlite3

from qgis.core import (
    QgsAttributeEditorContainer,
    QgsAttributeEditorField,
    QgsEditFormConfig,
    QgsEditorWidgetSetup,
    QgsExpression,
    QgsOptionalExpression,
)

from .gpkg_utils import normalize_text
from .ogr_layer_utils import add_fields_via_provider, simple_field
from ..helpers.logging_utils import log_info, log_warning

# (nombre_campo, tipo_sql, es_documento)
NEW_FIELDS = [
    ('Apertura', 'DATE', False),
    ('Doc_Apertura', 'TEXT', True),
    ('Cierre', 'DATE', False),
    ('Doc_Cierre', 'TEXT', True),
    # V190: campo para Incidencias Ambientales (ver _ensure_aspecto_zona_group).
    ('Aspecto Ambiental', 'TEXT', False),
]

DOCUMENT_WIDGET_CONFIG = {
    'DefaultRoot': '',
    'DocumentViewer': 1,
    'DocumentViewerHeight': 0,
    'DocumentViewerWidth': 0,
    'FileWidget': True,
    'FileWidgetButton': True,
    'RelativeStorage': 1,
    'StorageMode': 0,
    'UseLink': True,
}

# V190: desplegable de "Aspecto Ambiental" (codigo de checklist, p. ej.
# "SUE-01.1") para Incidencias Ambientales, resuelto contra la tabla
# ASPECTOS del propio GeoPackage -- mismo mecanismo que "Tipo" contra
# CLAVE. "LayerName"/"Layer"/"LayerSource" aqui son solo un valor de
# partida: gpkg_loader.GpkgLoader._repair_value_relation_layers (ver
# SUPPORT_TABLES) los reapunta a la tabla ASPECTOS de CADA GeoPackage al
# cargar la capa, igual que ya hace con CLAVE.
ASPECTO_VALUE_RELATION_CONFIG = {
    'AllowMulti': False,
    'AllowNull': True,
    'CompleterMatchFlags': 2,
    'Description': '',
    'DisplayGroupName': False,
    'FilterExpression': '',
    'Group': None,
    'Key': 'CODIGO',
    'LayerName': 'ASPECTOS',
    'LayerProviderName': 'ogr',
    'LayerSource': '',
    'NofColumns': 1,
    'OrderByDescending': False,
    'OrderByField': True,
    'OrderByFieldName': 'ORDEN',
    'OrderByKey': False,
    'OrderByValue': False,
    'UseCompleter': False,
    'Value': 'ETIQUETA',
}


# Grupos estándar del formulario de obra (nombres exactos del modelo).
STANDARD_GROUPS = ('FICHAS-INFORMES', 'FOTOS', 'NC-INCIDENCIAS')


def _quoted_field(name):
    return '"' + name.replace('"', '""') + '"'


class IncidenciaFormCustomizer:

    # ── 1. Estructura: garantizar los campos nuevos en el GeoPackage ──────
    def ensure_fields_for_gpkg(self, gpkg_path, table_names):
        """Añade (si faltan) los campos de NEW_FIELDS (Apertura/Doc_Apertura/
        Cierre/Doc_Cierre/Aspecto Ambiental) a cada tabla de table_names que
        ya siga el esquema estándar de obra (tiene Ámbito, Tipo y Ficha). No
        toca las tablas que no encajen con ese esquema (p. ej. CLAVE,
        Estaciones, Lineas_FFCC, pk).

        V198: la estructura se LEE con sqlite3 (solo lectura, PRAGMA), pero
        los campos que falten se AÑADEN mediante el proveedor OGR de QGIS
        (ver core/ogr_layer_utils.py), nunca con ALTER TABLE desde una
        conexión propia: este método se ejecuta justo antes de refrescar
        capas que pueden estar ya cargadas en el lienzo, y cambiar su
        esquema por debajo de GDAL puede cerrar QGIS de golpe."""
        pending = {}
        try:
            conn = sqlite3.connect(gpkg_path)
        except Exception as e:
            log_warning(f'No se pudo abrir el GeoPackage para preparar campos de incidencias: {e}')
            return []
        try:
            cur = conn.cursor()
            for table_name in table_names:
                try:
                    missing = self._missing_fields_for_table(cur, table_name)
                    if missing:
                        pending[table_name] = missing
                except Exception as e:
                    log_warning(f'No se pudieron revisar los campos de incidencias en "{table_name}": {e}')
        finally:
            conn.close()

        changed = []
        for table_name, missing in pending.items():
            try:
                fields = [simple_field(name, sql_type) for name, sql_type in missing]
                if add_fields_via_provider(gpkg_path, table_name, fields):
                    changed.append(table_name)
            except Exception as e:
                log_warning(f'No se pudieron preparar los campos de incidencias en "{table_name}": {e}')

        if changed:
            log_info(f'Campos de Apertura/Cierre preparados en: {", ".join(changed)}')
        return changed

    def _missing_fields_for_table(self, cur, table_name):
        """[(nombre, tipo_sql), ...] de NEW_FIELDS que faltan en la tabla,
        o [] si la tabla no sigue el esquema estándar de obra."""
        table_sql = table_name.replace("'", "''")
        cur.execute("PRAGMA table_info('{}')".format(table_sql))
        cols = cur.fetchall()
        if not cols:
            return []
        existing_by_norm = {normalize_text(c[1]): c[1] for c in cols}

        has_ambito = self._find(existing_by_norm, ['Ámbito', 'Ambito'])
        has_tipo = self._find(existing_by_norm, ['Tipo'])
        has_ficha = self._find(existing_by_norm, ['Ficha'])
        if not (has_ambito and has_tipo and has_ficha):
            return []

        return [
            (field_name, sql_type)
            for field_name, sql_type, _ in NEW_FIELDS
            if normalize_text(field_name) not in existing_by_norm
        ]

    def _find(self, existing_by_norm, candidates):
        for c in candidates:
            n = normalize_text(c)
            if n in existing_by_norm:
                return existing_by_norm[n]
        return None

    # ── 2. Formulario: reorganizar en memoria sobre la capa cargada ───────
    def apply_form(self, layer):
        """Reconfigura el formulario de edición de la capa. Devuelve True si
        se aplicó (la capa sigue el esquema estándar de obra), False si no."""
        try:
            return self._apply_form(layer)
        except Exception as e:
            log_warning(f'No se pudo personalizar el formulario de "{layer.name() if layer else "?"}": {e}')
            return False

    def _apply_form(self, layer):
        if layer is None or not layer.isValid():
            return False

        fields = layer.fields()
        by_norm = {normalize_text(f.name()): f.name() for f in fields}

        def real(*candidates):
            for c in candidates:
                n = normalize_text(c)
                if n in by_norm:
                    return by_norm[n]
            return None

        f_ambito = real('Ámbito', 'Ambito')
        f_tipo = real('Tipo')
        f_ficha = real('Ficha')
        f_poyecto = real('Poyecto', 'Proyecto')
        f_foto1 = real('Foto 1', 'Foto1')
        f_foto2 = real('Foto 2', 'Foto2')
        f_foto3 = real('Foto 3', 'Foto3')
        f_foto4 = real('Foto 4', 'Foto4')
        f_apertura = real('Apertura')
        f_doc_apertura = real('Doc_Apertura', 'Doc Apertura')
        f_cierre = real('Cierre')
        f_doc_cierre = real('Doc_Cierre', 'Doc Cierre')
        f_aspecto = real('Aspecto Ambiental', 'Aspecto ambiental')
        f_zona = real('Zona')

        if not (f_ambito and f_tipo and f_ficha):
            # Esta capa no sigue el esquema estándar de obra (p. ej. CLAVE,
            # Estaciones, Lineas_FFCC, pk): no se toca su formulario.
            return False

        # Condición (expresión QGIS) que identifica una incidencia de tipo
        # "no conformidad". Se construye con los nombres REALES de los
        # campos de esta capa (no hardcodeados), por si algún GeoPackage
        # los nombra con una variante de acentuación distinta.
        condition_expression = (
            "lower({amb}) LIKE '%incidencias%' "
            "AND lower(represent_value({tipo})) LIKE '%no conformidad%'"
        ).format(amb=_quoted_field(f_ambito), tipo=_quoted_field(f_tipo))

        # Widget de documento para los nuevos campos, si existen en la capa.
        # OJO: si "Actualiza GPKG" ya cargó un estilo persistido con este
        # campo configurado como ExternalResource (p. ej. con una carpeta
        # por defecto ya establecida en el modelo), NO lo pisamos con la
        # configuración genérica de aquí abajo (que no tiene carpeta) --
        # solo rellenamos el hueco cuando el campo aún no tiene ningún
        # widget de documento asignado (obras antiguas sin estilo guardado).
        for doc_field in (f_doc_apertura, f_doc_cierre):
            if doc_field:
                idx = fields.indexOf(doc_field)
                if idx >= 0:
                    current_type = layer.editorWidgetSetup(idx).type()
                    if current_type != 'ExternalResource':
                        layer.setEditorWidgetSetup(idx, QgsEditorWidgetSetup('ExternalResource', dict(DOCUMENT_WIDGET_CONFIG)))

        # V199: Ficha y Foto 1-4 también reciben su selector de documento /
        # foto si el estilo no lo trae (visto en SDONO124: Foto 3 y Foto 4
        # como simples cajas de texto). Las fotos copian la configuración
        # de otra foto que ya la tenga (misma carpeta por defecto y visor
        # de imagen); si ninguna la tiene, se usa la genérica.
        self._backfill_attachment_widgets(
            layer, fields, f_ficha, [f_foto1, f_foto2, f_foto3, f_foto4],
        )

        if f_aspecto:
            idx = fields.indexOf(f_aspecto)
            if idx >= 0:
                current_type = layer.editorWidgetSetup(idx).type()
                if current_type != 'ValueRelation':
                    layer.setEditorWidgetSetup(idx, QgsEditorWidgetSetup('ValueRelation', dict(ASPECTO_VALUE_RELATION_CONFIG)))

        efc = layer.editFormConfig()
        root = efc.invisibleRootContainer()

        # ¿La capa ya trae un formulario diseñado con grupos (el que
        # "Actualiza GPKG" acaba de sincronizar tal cual desde el modelo,
        # vía GpkgLoader._load_persisted_style)? Si es así, NO SE TOCA: es
        # el formulario EXACTO que el usuario diseñó a mano en QGIS, y
        # cualquier reconstrucción nuestra solo puede aproximarlo peor.
        # Solo reconstruimos desde cero cuando no hay ningún grupo (obra
        # sin estilo persistido, o "Actualiza GPKG" con la sincronización
        # de estilos desactivada).
        # V199: solo cuenta como "formulario diseñado" si trae alguno de los
        # grupos estándar de la obra. Un contenedor suelto (p. ej. solo el
        # grupo ASPECTO-ZONA que una versión anterior del plugin añadió
        # sobre un formulario automático) no es un diseño: en ese caso se
        # reconstruye.
        has_designed_form = any(
            child.__class__.__name__ == 'QgsAttributeEditorContainer'
            and child.name() in STANDARD_GROUPS
            for child in root.children()
        )

        if not has_designed_form:
            self._rebuild_form_from_scratch(
                root, fields, f_ficha, f_poyecto, f_foto1, f_foto2, f_foto3,
                f_foto4, f_apertura, f_cierre, f_doc_apertura, f_doc_cierre,
                condition_expression,
            )
        else:
            # V199: si al diseño del modelo le falta alguno de los grupos
            # estándar, se añade al final sin tocar los que ya tiene.
            self._ensure_standard_groups(
                root, fields, f_ficha, f_poyecto, f_foto1, f_foto2, f_foto3,
                f_foto4, f_apertura, f_cierre, f_doc_apertura, f_doc_cierre,
                condition_expression,
            )
        # V199: SIEMPRE modo "arrastrar y soltar". Si el estilo guardado
        # trae los grupos pero con el formulario en modo automático, QGIS
        # los ignora y enseña todos los campos seguidos ("plano"); antes
        # solo se fijaba este modo al reconstruir el formulario desde cero.
        efc.setLayout(QgsEditFormConfig.EditorLayout.TabLayout)

        # V190: garantiza el grupo "ASPECTO-ZONA" (Aspecto Ambiental +
        # Zona), visible solo para Incidencias Ambientales. Se ejecuta
        # SIEMPRE (formulario diseñado o reconstruido aquí) y ANTES de
        # _dedupe_root_fields(), para que la copia suelta de "Zona" que ya
        # existiera en la raíz del formulario se retire a continuación
        # igual que ocurre con Apertura/Doc_Apertura/Doc_Cierre.
        self._ensure_aspecto_zona_group(root, fields, f_ambito, f_tipo, f_aspecto, f_zona)

        # V179: algunos formularios diseñados a mano en el propio modelo
        # traen, por descuido del autor, un campo repetido: suelto en la
        # raíz del formulario Y TAMBIÉN dentro de uno de sus grupos (visto
        # en capturas reales del usuario: "Apertura"/"Doc_Apertura"/
        # "Doc_Cierre" duplicados fuera de "NC-INCIDENCIAS"). Como V175
        # traslada el formulario del modelo tal cual, ese defecto se
        # propagaba a cada obra actualizada. Se limpia aquí, conservando
        # solo la copia agrupada, sin tocar nada más del formulario.
        self._dedupe_root_fields(root)

        # Se haya dejado intacto el formulario del modelo o se haya
        # reconstruido aquí como red de seguridad, en ambos casos se aplica
        # el mismo ajuste final de colapso a los tres grupos conocidos
        # (igual que el usuario configuró en QGIS: plegados por defecto,
        # desplegados automáticamente en cuanto ya hay datos).
        group_key_fields = {
            'FICHAS-INFORMES': f_ficha,
            'FOTOS': f_foto1,
            'NC-INCIDENCIAS': f_apertura,
        }
        for child in root.children():
            if child.__class__.__name__ != 'QgsAttributeEditorContainer':
                continue
            key_field = group_key_fields.get(child.name())
            if key_field:
                self._configure_group_collapse(child, key_field)

        layer.setEditFormConfig(efc)
        return True

    # ── V199: comprobación del formulario ─────────────────────────────
    def _resolve_fields(self, layer):
        fields = layer.fields()
        by_norm = {normalize_text(f.name()): f.name() for f in fields}

        def real(*candidates):
            for c in candidates:
                n = normalize_text(c)
                if n in by_norm:
                    return by_norm[n]
            return None

        return {
            'ambito': real('Ámbito', 'Ambito'),
            'tipo': real('Tipo'),
            'ficha': real('Ficha'),
            'foto1': real('Foto 1', 'Foto1'),
            'foto2': real('Foto 2', 'Foto2'),
            'foto3': real('Foto 3', 'Foto3'),
            'foto4': real('Foto 4', 'Foto4'),
            'apertura': real('Apertura'),
            'cierre': real('Cierre'),
            'doc_apertura': real('Doc_Apertura', 'Doc Apertura'),
            'doc_cierre': real('Doc_Cierre', 'Doc Cierre'),
            'aspecto': real('Aspecto Ambiental', 'Aspecto ambiental'),
            'zona': real('Zona'),
        }

    @staticmethod
    def _is_drag_and_drop(efc):
        lay = efc.layout()
        try:
            if lay == QgsEditFormConfig.EditorLayout.TabLayout:
                return True
        except Exception:
            pass
        return (getattr(lay, 'name', '') or '') in ('TabLayout', 'DragAndDrop')

    def form_problems(self, layer, include_plugin_groups=True):
        """Revisa el formulario de atributos de una capa TAL COMO ESTÁ (sin
        tocarlo) y devuelve la lista de problemas encontrados, en texto
        para el usuario; [] si está bien; None si la capa no sigue el
        esquema estándar de obra (no se revisa)."""
        if layer is None or not layer.isValid():
            return None
        f = self._resolve_fields(layer)
        if not (f['ambito'] and f['tipo'] and f['ficha']):
            return None
        fields = layer.fields()
        efc = layer.editFormConfig()
        problems = []

        if not self._is_drag_and_drop(efc):
            problems.append('formulario automático: todos los campos seguidos, sin grupos')

        root = efc.invisibleRootContainer()
        groups = {
            child.name() for child in root.children()
            if child.__class__.__name__ == 'QgsAttributeEditorContainer'
        }
        expected = []
        if f['ficha']:
            expected.append('FICHAS-INFORMES')
        if f['foto1']:
            expected.append('FOTOS')
        if f['apertura'] and f['cierre']:
            expected.append('NC-INCIDENCIAS')
        if include_plugin_groups and f['aspecto'] and f['zona']:
            # Grupo que añade el propio plugin (V190), no el modelo.
            expected.append('ASPECTO-ZONA')
        missing = [g for g in expected if g not in groups]
        if missing:
            problems.append('faltan grupos: ' + ', '.join(missing))

        no_widget = []
        for key in ('ficha', 'foto1', 'foto2', 'foto3', 'foto4', 'doc_apertura', 'doc_cierre'):
            name = f[key]
            if not name:
                continue
            idx = fields.indexOf(name)
            if idx >= 0 and layer.editorWidgetSetup(idx).type() != 'ExternalResource':
                no_widget.append(name)
        if no_widget:
            problems.append('sin selector de documento/foto: ' + ', '.join(no_widget))

        if include_plugin_groups and f['aspecto']:
            idx = fields.indexOf(f['aspecto'])
            if idx >= 0 and layer.editorWidgetSetup(idx).type() != 'ValueRelation':
                problems.append(f'"{f["aspecto"]}" sin desplegable')
        return problems

    def _backfill_attachment_widgets(self, layer, fields, f_ficha, photo_fields):
        photos = [p for p in photo_fields if p]
        template = None
        for name in photos:
            idx = fields.indexOf(name)
            if idx < 0:
                continue
            setup = layer.editorWidgetSetup(idx)
            if setup.type() == 'ExternalResource':
                template = dict(setup.config() or {})
                break
        if template is None:
            template = dict(DOCUMENT_WIDGET_CONFIG)
        for name in photos:
            idx = fields.indexOf(name)
            if idx >= 0 and layer.editorWidgetSetup(idx).type() != 'ExternalResource':
                layer.setEditorWidgetSetup(idx, QgsEditorWidgetSetup('ExternalResource', dict(template)))
        if f_ficha:
            idx = fields.indexOf(f_ficha)
            if idx >= 0 and layer.editorWidgetSetup(idx).type() != 'ExternalResource':
                cfg = dict(DOCUMENT_WIDGET_CONFIG)
                cfg['DocumentViewer'] = 0
                layer.setEditorWidgetSetup(idx, QgsEditorWidgetSetup('ExternalResource', cfg))

    def _ensure_standard_groups(self, root, fields, f_ficha, f_poyecto,
                                f_foto1, f_foto2, f_foto3, f_foto4,
                                f_apertura, f_cierre, f_doc_apertura,
                                f_doc_cierre, condition_expression):
        """Con un formulario ya diseñado, añade al final los grupos
        estándar que le falten (sin tocar los que ya tiene), con los mismos
        campos y opciones que _rebuild_form_from_scratch()."""
        present = {
            child.name() for child in root.children()
            if child.__class__.__name__ == 'QgsAttributeEditorContainer'
        }

        def add_field(container, field_name):
            if not field_name:
                return
            idx = fields.indexOf(field_name)
            if idx >= 0:
                container.addChildElement(QgsAttributeEditorField(field_name, idx, container))

        def new_group(name):
            g = QgsAttributeEditorContainer(name, root)
            g.setColumnCount(2)
            g.setIsGroupBox(True)
            g.setCollapsed(True)
            return g

        if f_ficha and 'FICHAS-INFORMES' not in present:
            g = new_group('FICHAS-INFORMES')
            add_field(g, f_ficha)
            add_field(g, f_poyecto)
            root.addChildElement(g)
        if f_foto1 and 'FOTOS' not in present:
            g = new_group('FOTOS')
            for name in (f_foto1, f_foto2, f_foto3, f_foto4):
                add_field(g, name)
            root.addChildElement(g)
        if f_apertura and f_cierre and 'NC-INCIDENCIAS' not in present:
            g = new_group('NC-INCIDENCIAS')
            g.setVisibilityExpression(QgsOptionalExpression(QgsExpression(condition_expression), True))
            for name in (f_apertura, f_cierre, f_doc_apertura, f_doc_cierre):
                add_field(g, name)
            root.addChildElement(g)

    def _ensure_aspecto_zona_group(self, root, fields, f_ambito, f_tipo, f_aspecto, f_zona):
        """V190: garantiza que exista un grupo "ASPECTO-ZONA" con los
        campos "Aspecto Ambiental" y "Zona", visible (sin colapsar, para
        que se note que hay que rellenarlo) solo cuando la entidad es una
        Incidencia Ambiental (Ámbito "Incidencias" + Tipo "Incidencias
        Ambientales", ver CLAVE). Se ejecuta siempre -- con formulario
        diseñado en el modelo o reconstruido aquí -- y es idempotente: si
        el grupo ya existe (capa recargada, u obra ya procesada antes), no
        se vuelve a crear.

        Como con NC-INCIDENCIAS/Apertura-Cierre, el campo "Zona" puede
        seguir existiendo suelto en la raíz del formulario (siempre
        estuvo ahí, para cualquier Ámbito/Tipo): _dedupe_root_fields(),
        llamado justo después de este método en _apply_form(), retira esa
        copia suelta y deja solo la agrupada aquí -- por eso este método
        se llama ANTES de _dedupe_root_fields()."""
        if not (f_ambito and f_tipo and f_aspecto and f_zona):
            return

        group_name = 'ASPECTO-ZONA'
        if any(
            child.__class__.__name__ == 'QgsAttributeEditorContainer' and child.name() == group_name
            for child in root.children()
        ):
            return

        idx_aspecto = fields.indexOf(f_aspecto)
        idx_zona = fields.indexOf(f_zona)
        if idx_aspecto < 0 or idx_zona < 0:
            return

        condition_expression = (
            "lower({amb}) LIKE '%incidencias%' "
            "AND lower(represent_value({tipo})) LIKE '%incidencias ambientales%'"
        ).format(amb=_quoted_field(f_ambito), tipo=_quoted_field(f_tipo))

        group = QgsAttributeEditorContainer(group_name, root)
        group.setColumnCount(2)
        group.setIsGroupBox(True)
        # A diferencia de FICHAS-INFORMES/FOTOS/NC-INCIDENCIAS (colapsados
        # por defecto), este grupo se deja DESPLEGADO cuando es visible:
        # su función es precisamente pedir estos dos datos en cuanto se
        # detecta una Incidencia Ambiental, no esconderlos plegados.
        group.setCollapsed(False)
        group.setVisibilityExpression(QgsOptionalExpression(QgsExpression(condition_expression), True))
        group.addChildElement(QgsAttributeEditorField(f_aspecto, idx_aspecto, group))
        group.addChildElement(QgsAttributeEditorField(f_zona, idx_zona, group))
        root.addChildElement(group)

    def _configure_group_collapse(self, container, key_field):
        """Pliega el grupo por defecto y, si esta versión de PyQGIS lo
        soporta (QGIS 3.44+, la versión mínima que declara el plugin), lo
        despliega automáticamente en cuanto `key_field` ya tenga un valor
        -- igual que "Control Collapsed by Expression" configurado a mano
        en QGIS. En versiones de QGIS sin esta API, el grupo se queda
        simplemente plegado por defecto."""
        container.setCollapsed(True)
        if not hasattr(container, 'setCollapsedExpression'):
            return
        expr_text = _quoted_field(key_field) + ' IS NULL'
        try:
            container.setCollapsedExpression(QgsOptionalExpression(QgsExpression(expr_text), True))
            return
        except TypeError:
            pass
        try:
            container.setCollapsedExpression(expr_text)
            if hasattr(container, 'setCollapsedExpressionEnabled'):
                container.setCollapsedExpressionEnabled(True)
        except Exception as e:
            log_warning(f'No se pudo aplicar el plegado condicional al grupo "{container.name()}": {e}')

    def _dedupe_root_fields(self, root):
        """Elimina de la raíz del formulario cualquier campo que aparezca
        SUELTO ahí Y TAMBIÉN dentro de algún grupo (contenedor) del mismo
        formulario, conservando únicamente la copia agrupada. No es un
        fallo de este plugin: es un defecto que puede venir ya arrastrado
        del propio formulario diseñado a mano en el modelo (comprobado en
        el QML real del modelo del usuario: "Apertura", "Doc_Apertura" y
        "Doc_Cierre" duplicados fuera de "NC-INCIDENCIAS") y que, al
        trasladar el formulario tal cual (V175), se propagaba a cada obra
        actualizada.

        OJO: QgsAttributeEditorContainer no tiene ningún método para
        eliminar UN solo hijo -- solo clear(), que los elimina TODOS (y
        además invalida cualquier referencia Python a los hijos
        originales). Por eso el único patrón seguro es: clonar (clone())
        los hijos que SÍ se quieren conservar ANTES de tocar nada, vaciar
        el contenedor con clear() y volver a añadir esos clones en su
        orden original con addChildElement()."""
        def collect_nested_field_names(container):
            names = set()
            for child in container.children():
                cls = child.__class__.__name__
                if cls == 'QgsAttributeEditorField':
                    names.add(child.name())
                elif cls == 'QgsAttributeEditorContainer':
                    names |= collect_nested_field_names(child)
            return names

        nested_names = set()
        for child in root.children():
            if child.__class__.__name__ == 'QgsAttributeEditorContainer':
                nested_names |= collect_nested_field_names(child)

        if not nested_names:
            return

        to_remove = [
            child for child in root.children()
            if child.__class__.__name__ == 'QgsAttributeEditorField'
            and child.name() in nested_names
        ]
        if not to_remove:
            return

        remove_ids = {id(c) for c in to_remove}
        kept_clones = []
        for child in root.children():
            if id(child) in remove_ids:
                continue
            clone = child.clone(root)
            if clone is not None:
                kept_clones.append(clone)

        root.clear()
        for clone in kept_clones:
            root.addChildElement(clone)

        removed_names = sorted({c.name() for c in to_remove})
        log_info(
            'Campos duplicados eliminados de la raíz del formulario (ya '
            'están dentro de un grupo): ' + ', '.join(removed_names)
        )

    def _rebuild_form_from_scratch(self, root, fields, f_ficha, f_poyecto,
                                    f_foto1, f_foto2, f_foto3, f_foto4,
                                    f_apertura, f_cierre, f_doc_apertura,
                                    f_doc_cierre, condition_expression):
        """Reconstruye el formulario desde cero, replicando el mismo
        diseño de grupos que el modelo (nombres exactos "FICHAS-INFORMES"
        /"FOTOS"/"NC-INCIDENCIAS"). Solo se usa cuando la capa no trae
        ningún formulario diseñado propio (ver _apply_form)."""
        # OJO: QgsAttributeEditorContainer no tiene un método
        # "removeChildElement" (nunca lo tuvo en ninguna versión de PyQGIS
        # comprobada) -- el método real para vaciar el contenedor es
        # clear(). Con el nombre erróneo, esta línea lanzaba
        # AttributeError, que el try/except de apply_form() capturaba en
        # silencio: TODA la reorganización de más abajo (agrupar
        # Fotos, ocultar Ficha y mostrar Apertura/Cierre en incidencias de
        # "no conformidad") no se aplicaba nunca, sin ningún aviso visible
        # para el usuario más allá del panel de registro de QGIS.
        root.clear()

        def add_field(container, field_name):
            idx = fields.indexOf(field_name)
            if idx < 0:
                return None
            elem = QgsAttributeEditorField(field_name, idx, container)
            container.addChildElement(elem)
            return elem

        skip = {f_foto2}
        if f_foto3:
            skip.add(f_foto3)
        if f_foto4:
            skip.add(f_foto4)
        if f_poyecto:
            skip.add(f_poyecto)
        if f_apertura:
            skip.add(f_apertura)
        if f_cierre:
            skip.add(f_cierre)
        if f_doc_apertura:
            skip.add(f_doc_apertura)
        if f_doc_cierre:
            skip.add(f_doc_cierre)
        skip.discard(None)

        show_group_expr = QgsOptionalExpression(QgsExpression(condition_expression), True)
        hide_ficha_expr = QgsOptionalExpression(QgsExpression('NOT (' + condition_expression + ')'), True)

        for field in fields:
            fname = field.name()
            if fname in skip:
                continue

            if fname == f_ficha:
                # Nombre y estado de colapso EXACTOS al del modelo (QML real
                # comprobado): "FICHAS-INFORMES", 2 columnas, colapsado por
                # defecto (collapsed="1"). Agrupa "Ficha" y "Poyecto".
                fichas_group = QgsAttributeEditorContainer('FICHAS-INFORMES', root)
                fichas_group.setColumnCount(2)
                fichas_group.setIsGroupBox(True)
                fichas_group.setCollapsed(True)

                # QgsAttributeEditorField no tiene setVisibilityExpression
                # (ese método solo existe en QgsAttributeEditorContainer):
                # para ocultar un único campo según una condición hay que
                # envolverlo en un contenedor sin caja de grupo (patrón
                # estándar de QGIS para visibilidad condicional de un
                # campo suelto), anidado dentro del grupo "FICHAS-INFORMES".
                ficha_wrap = QgsAttributeEditorContainer('', fichas_group)
                ficha_wrap.setIsGroupBox(False)
                ficha_wrap.setShowLabel(False)
                ficha_wrap.setVisibilityExpression(hide_ficha_expr)
                add_field(ficha_wrap, f_ficha)
                fichas_group.addChildElement(ficha_wrap)

                if f_poyecto:
                    add_field(fichas_group, f_poyecto)

                root.addChildElement(fichas_group)

                if f_apertura and f_cierre:
                    # Nombre y estado de colapso EXACTOS al del modelo:
                    # "NC-INCIDENCIAS", 2 columnas, colapsado por defecto.
                    group = QgsAttributeEditorContainer('NC-INCIDENCIAS', root)
                    group.setColumnCount(2)
                    group.setIsGroupBox(True)
                    group.setCollapsed(True)
                    group.setVisibilityExpression(show_group_expr)
                    add_field(group, f_apertura)
                    add_field(group, f_cierre)
                    if f_doc_apertura:
                        add_field(group, f_doc_apertura)
                    if f_doc_cierre:
                        add_field(group, f_doc_cierre)
                    root.addChildElement(group)
                continue

            if fname == f_foto1:
                # Nombre y estado de colapso EXACTOS al del modelo: "FOTOS"
                # (todo en mayúsculas), 2 columnas, colapsado por defecto.
                fotos = QgsAttributeEditorContainer('FOTOS', root)
                fotos.setColumnCount(2)
                fotos.setIsGroupBox(True)
                fotos.setCollapsed(True)
                add_field(fotos, f_foto1)
                if f_foto2:
                    add_field(fotos, f_foto2)
                if f_foto3:
                    add_field(fotos, f_foto3)
                if f_foto4:
                    add_field(fotos, f_foto4)
                root.addChildElement(fotos)
                continue

            add_field(root, fname)
        # El layout (TabLayout) y el ajuste de colapso de los tres grupos
        # los aplica _apply_form() al volver de aquí, igual que si el
        # formulario ya viniera diseñado desde el modelo.

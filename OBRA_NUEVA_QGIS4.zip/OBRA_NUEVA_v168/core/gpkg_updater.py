# -*- coding: utf-8 -*-
"""
OBRA_NUEVA - Actualizador de estructura de GeoPackage.

Sincroniza la estructura (campos y, opcionalmente, tablas) de un GeoPackage
"antiguo" con la de un GeoPackage "modelo" más reciente, sin tocar ni perder
en ningún momento las entidades gráficas ni los datos ya existentes:

  * Los campos que existan en el modelo y falten en el antiguo se añaden
    siempre como opcionales (nullable), para no invalidar registros ya
    cargados. Desde V198 se añaden mediante el proveedor OGR de QGIS
    (QgsVectorDataProvider.addAttributes, ver core/ogr_layer_utils.py) y ya
    no con ALTER TABLE desde una conexión sqlite3 propia: esa segunda
    conexión, cambiando el esquema por debajo de las capas ya cargadas,
    es la causa más probable de los cierres repentinos de QGIS al pulsar
    "Actualizar GPKG".
  * Los campos que existan en el antiguo y no en el modelo NUNCA se tocan ni
    se eliminan: se conservan tal cual (se informa de ellos como "extra").
  * Las tablas del modelo que no tengan equivalente en el antiguo pueden
    crearse vacías (misma estructura de campos, geometría y CRS) si el
    usuario lo solicita.
  * La correspondencia entre tablas operativas (Puntos/Líneas/Polígonos) se
    hace por rol, no por nombre exacto, ya que cada obra nombra sus tablas
    con un prefijo distinto (p.ej. "SDON_78_Puntos" frente a
    "SDONO120_Puntos"): así nunca se renombra ni se toca la tabla original.
"""
import hashlib
import os
import re
import shutil
import sqlite3
from datetime import datetime

from qgis.core import (
    QgsEditorWidgetSetup,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
    QgsCoordinateTransformContext,
)
from qgis.PyQt.QtXml import QDomDocument

from .form_customizer import IncidenciaFormCustomizer

from .gpkg_utils import GpkgIntrospector, normalize_text
from .ogr_layer_utils import (
    add_fields_via_provider,
    assert_no_layer_in_edit_mode,
    nullable_copy,
    simple_field,
)
from ..helpers.logging_utils import log_info, log_warning

ROLES = ('Puntos', 'Lineas', 'Poligonos')
IGNORED_COLUMN_KEYS = ('fid', 'geom', 'geometry')
NON_STYLED_TABLES = ('clave', 'layer_styles')

# Sufijo que _make_backup() añade a las copias de seguridad, p.ej.
# "..._backup_20260901_101638.gpkg". Se usa para no volver a tratar una
# copia de seguridad como si fuera un GeoPackage de obra más al buscar en
# una carpeta de forma recursiva.
_BACKUP_SUFFIX_RE = re.compile(r'_backup_\d{8}_\d{6}$')


def scan_gpkg_files_recursive(folder_path, exclude_paths=None, progress_cb=None):
    """Busca de forma recursiva (incluidas todas las subcarpetas) todos los
    archivos .gpkg dentro de folder_path.

    Excluye:
      * las rutas indicadas en exclude_paths (comparación por ruta absoluta
        normalizada; se usa típicamente para no incluir el propio GPKG
        modelo si está dentro de la misma carpeta),
      * las copias de seguridad que crea este mismo módulo
        (sufijo "_backup_AAAAMMDD_HHMMSS"), para que una ejecución posterior
        no las trate como obras a actualizar.

    Si se pasa `progress_cb`, se llama tras revisar cada subcarpeta como
    `progress_cb(current_dir, dirs_visited, found_count)` -- para que un
    llamador con interfaz gráfica pueda mostrar avance real (p. ej. una
    barra de progreso) mientras dura el recorrido de una carpeta grande,
    en vez de quedarse congelado hasta que termina. Cualquier excepción
    del callback se ignora (nunca debe interrumpir la búsqueda).

    Devuelve una lista de rutas absolutas, ordenada alfabéticamente.
    """
    exclude_norm = {
        os.path.normcase(os.path.abspath(p)) for p in (exclude_paths or []) if p
    }
    found = []
    dirs_visited = 0
    for root, _dirs, files in os.walk(folder_path):
        dirs_visited += 1
        for name in files:
            if not name.lower().endswith('.gpkg'):
                continue
            full_path = os.path.join(root, name)
            if os.path.normcase(os.path.abspath(full_path)) in exclude_norm:
                continue
            stem = os.path.splitext(name)[0]
            if _BACKUP_SUFFIX_RE.search(stem):
                continue
            found.append(full_path)
        if progress_cb is not None:
            try:
                progress_cb(root, dirs_visited, len(found))
            except Exception:
                pass
    found.sort(key=lambda p: os.path.normcase(p))
    return found


def _style_marker(model_qml):
    """Marca (comentario XML) que se añade al estilo de una obra cuando el
    plugin corrige el formulario partiendo del estilo del modelo (V199)."""
    digest = hashlib.sha1((model_qml or '').encode('utf-8')).hexdigest()[:16]
    return f'[OBRA_NUEVA modelo:{digest}]'


def _type_base(type_str):
    """'TEXT(254)' -> 'TEXT' — compara solo la afinidad de tipo, no la anchura."""
    t = (type_str or '').strip().upper()
    idx = t.find('(')
    if idx >= 0:
        t = t[:idx]
    return t.strip() or 'TEXT'


class TableDiff:
    """Diferencias de estructura entre una tabla del GPKG antiguo y su
    equivalente en el GPKG modelo."""

    def __init__(self, role, old_table, model_table):
        self.role = role                # 'Puntos' / 'Lineas' / 'Poligonos' / None
        self.old_table = old_table
        self.model_table = model_table
        self.add_columns = []           # [{'name','type','notnull',...}, ...] a añadir al antiguo
        self.extra_in_old = []          # nombres de columnas del antiguo que no están en el modelo
        self.type_mismatch = []         # [(nombre, tipo_antiguo, tipo_modelo), ...]
        self.geom_mismatch = None       # (tipo_antiguo, tipo_modelo) si difiere el tipo de geometría
        self.style_status = 'skip'      # 'match' | 'missing' | 'different' | 'skip'
        # V199: problemas del formulario de atributos guardado en el GPKG
        # antiguo (None = tabla no operativa / no revisada; [] = correcto).
        self.form_problems = None

    @property
    def has_changes(self):
        return bool(self.add_columns)

    @property
    def needs_style_sync(self):
        return self.style_status in ('missing', 'different')

    @property
    def needs_form_fix(self):
        return bool(self.form_problems)


class GpkgUpdatePlan:
    def __init__(self, model_path, old_path):
        self.model_path = model_path
        self.old_path = old_path
        self.pairs = []           # [TableDiff, ...]
        self.new_tables = []      # tablas del modelo sin equivalente en el antiguo
        self.unmatched_old_roles = []  # roles presentes en el antiguo que el modelo no define
        self.model_form_problems = {}  # V199: {tabla_modelo: [problemas]} del formulario del modelo

    def has_changes(self):
        return bool(self.new_tables) or any(p.has_changes for p in self.pairs)

    def total_new_fields(self):
        return sum(len(p.add_columns) for p in self.pairs)

    def total_style_updates(self):
        return sum(1 for p in self.pairs if p.needs_style_sync)

    def total_form_fixes(self):
        return sum(1 for p in self.pairs if p.needs_form_fix)


class GpkgStructureUpdater:

    # Tablas de apoyo a las que apuntan los desplegables ValueRelation (ver
    # GpkgLoader.SUPPORT_TABLES).
    SUPPORT_TABLES = ('CLAVE', 'ASPECTOS')

    def __init__(self):
        self.form_customizer = IncidenciaFormCustomizer()

    # ── Análisis ─────────────────────────────────────────────────────────
    def analyze(self, model_path, old_path):
        plan = GpkgUpdatePlan(model_path, old_path)

        model_intro = GpkgIntrospector(model_path)
        old_intro = GpkgIntrospector(old_path)

        model_roles = model_intro.detect_operational_tables()
        old_roles = old_intro.detect_operational_tables()

        matched_model_tables = set()

        for role in ROLES:
            model_table = model_roles.get(role)
            old_table = old_roles.get(role)
            if model_table:
                matched_model_tables.add(model_table)
            if old_table and model_table:
                plan.pairs.append(
                    self._diff_tables(role, old_table, old_intro, model_table, model_intro)
                )
            elif old_table and not model_table:
                plan.unmatched_old_roles.append(role)
                log_warning(
                    f'El GPKG modelo no define capa de rol "{role}"; '
                    f'se conserva "{old_table}" sin cambios.'
                )

        # Tablas "con nombre propio" (no operativas): CLAVE, layer_styles,
        # y cualquier otra capa base/de referencia del modelo (Estaciones,
        # Lineas_FFCC, pk, ...).
        model_named = [t for t in model_intro.list_feature_tables() if t not in matched_model_tables]
        old_role_tables = {v for v in old_roles.values() if v}
        old_named = [t for t in old_intro.list_feature_tables() if t not in old_role_tables]

        old_named_by_norm = {normalize_text(t): t for t in old_named}
        for model_table in model_named:
            old_table = old_named_by_norm.get(normalize_text(model_table))
            if old_table:
                plan.pairs.append(
                    self._diff_tables(None, old_table, old_intro, model_table, model_intro)
                )
            else:
                plan.new_tables.append(model_table)

        # V199: revisión del formulario de atributos de las capas
        # operativas, tal como está guardado en cada GeoPackage (es el que
        # verá cualquiera que abra el fichero en QGIS).
        for diff in plan.pairs:
            if not diff.role:
                continue
            diff.form_problems = self._check_form(old_path, diff.old_table)
            model_problems = self._check_form(model_path, diff.model_table, include_plugin_groups=False)
            if model_problems:
                plan.model_form_problems[diff.model_table] = model_problems

        return plan

    def _check_form(self, gpkg_path, table_name, include_plugin_groups=True):
        try:
            lyr = QgsVectorLayer(f'{gpkg_path}|layername={table_name}', table_name, 'ogr')
            if not lyr.isValid():
                return None
            lyr.loadDefaultStyle()
            return self.form_customizer.form_problems(lyr, include_plugin_groups)
        except Exception as e:
            log_warning(f'No se pudo revisar el formulario de "{table_name}" en {gpkg_path}: {e}')
            return None

    def _diff_tables(self, role, old_table, old_intro, model_table, model_intro):
        diff = TableDiff(role, old_table, model_table)

        old_cols = old_intro.table_columns_full(old_table)
        model_cols = model_intro.table_columns_full(model_table)

        old_by_norm = {normalize_text(c['name']): c for c in old_cols if normalize_text(c['name']) not in IGNORED_COLUMN_KEYS}
        model_by_norm = {normalize_text(c['name']): c for c in model_cols if normalize_text(c['name']) not in IGNORED_COLUMN_KEYS}

        for key, col in model_by_norm.items():
            if key not in old_by_norm:
                diff.add_columns.append(col)
            else:
                old_col = old_by_norm[key]
                if _type_base(old_col['type']) != _type_base(col['type']):
                    diff.type_mismatch.append((col['name'], old_col['type'], col['type']))

        for key, col in old_by_norm.items():
            if key not in model_by_norm:
                diff.extra_in_old.append(col['name'])

        try:
            old_geom = old_intro.geometry_type_by_table().get(old_table)
            model_geom = model_intro.geometry_type_by_table().get(model_table)
            if old_geom and model_geom and old_geom.upper() != model_geom.upper():
                diff.geom_mismatch = (old_geom, model_geom)
        except Exception:
            pass

        diff.style_status = self._compare_styles(old_table, old_intro, model_table, model_intro)

        return diff

    def _compare_styles(self, old_table, old_intro, model_table, model_intro):
        """Compara la leyenda/simbología (tabla layer_styles) de old_table
        frente a model_table. Solo mira metadatos de estilo, nunca datos ni
        geometrías. Devuelve 'skip' si la tabla no es susceptible de tener
        estilo propio (CLAVE, layer_styles, o si el modelo no define uno)."""
        if normalize_text(model_table) in NON_STYLED_TABLES or normalize_text(old_table) in NON_STYLED_TABLES:
            return 'skip'
        try:
            model_qml = model_intro.default_style_qml(model_table)
        except Exception:
            model_qml = None
        if not model_qml:
            return 'skip'
        try:
            old_qml = old_intro.default_style_qml(old_table)
        except Exception:
            old_qml = None
        if not old_qml:
            return 'missing'
        if old_qml == model_qml:
            return 'match'
        # V199: si el estilo del antiguo es el del modelo con el formulario
        # ya corregido por el plugin (ver _fix_form_in_gpkg), no es una
        # diferencia real: sin esto, cada análisis volvería a proponer
        # "sincronizar leyenda" y se entraría en un bucle.
        if _style_marker(model_qml) in old_qml:
            return 'match'
        return 'different'

    # ── Aplicación ───────────────────────────────────────────────────────
    def apply(self, plan, backup=True, create_missing_tables=True, sync_styles=True, progress_cb=None):
        def log(msg):
            if progress_cb:
                progress_cb(msg)
            log_info(msg)

        result = {'backup_path': None, 'fields_added': 0, 'tables_created': [], 'styles_synced': 0, 'forms_fixed': 0}

        # V198: antes de escribir nada (ni siquiera la copia de seguridad),
        # ninguna capa de este GeoPackage puede estar en modo edición.
        assert_no_layer_in_edit_mode(plan.old_path)

        if backup:
            backup_path = self._make_backup(plan.old_path)
            result['backup_path'] = backup_path
            log(f'🗄  Copia de seguridad creada: {backup_path}')

        # V198: campos nuevos a través del proveedor OGR de QGIS (misma
        # conexión GDAL que usan las capas cargadas), copiando la
        # definición exacta del campo desde la tabla del modelo.
        for diff in plan.pairs:
            if not diff.add_columns:
                continue
            model_fields = self._model_fields(plan.model_path, diff.model_table)
            pending = []
            for col in diff.add_columns:
                src = model_fields.get(normalize_text(col['name']))
                if src is not None:
                    field = nullable_copy(src)
                else:
                    field = simple_field(col['name'], _type_base(col.get('type')))
                pending.append((col, field))
            added = set(add_fields_via_provider(
                plan.old_path, diff.old_table, [f for _, f in pending],
            ))
            for col, field in pending:
                if field.name() not in added:
                    continue
                col_type = col.get('type') or 'TEXT'
                result['fields_added'] += 1
                log(f'＋ {diff.old_table}: campo "{col["name"]}" ({col_type}) añadido.')
                if col.get('notnull'):
                    log(
                        f'   ⚠ "{col["name"]}" es obligatorio en el modelo; '
                        f'se crea como opcional para no afectar registros existentes.'
                    )

        if sync_styles:
            for diff in plan.pairs:
                if not diff.needs_style_sync:
                    continue
                try:
                    n = self._copy_layer_styles(plan.model_path, plan.old_path, diff.model_table, diff.old_table)
                    if n:
                        result['styles_synced'] += 1
                        log(f'🎨 {diff.old_table}: leyenda y simbología actualizada desde el modelo.')
                except Exception as e:
                    log(f'✖ No se pudo sincronizar la leyenda de "{diff.old_table}": {e}')

        if create_missing_tables:
            for table_name in plan.new_tables:
                try:
                    self._create_empty_table_from_model(plan.model_path, plan.old_path, table_name)
                    result['tables_created'].append(table_name)
                    log(f'✚ Tabla nueva "{table_name}" creada (vacía) a partir del modelo.')
                    if sync_styles:
                        try:
                            n = self._copy_layer_styles(plan.model_path, plan.old_path, table_name, table_name)
                            if n:
                                result['styles_synced'] += 1
                                log(f'🎨 {table_name}: leyenda y simbología copiada desde el modelo.')
                        except Exception as e:
                            log(f'✖ No se pudo copiar la leyenda de "{table_name}": {e}')
                except Exception as e:
                    log(f'✖ No se pudo crear la tabla "{table_name}": {e}')

        # V199: con la estructura y el estilo ya al día, se revisa el
        # formulario de atributos de cada capa operativa TAL COMO QUEDA
        # GUARDADO en el GeoPackage y, si está incompleto, se corrige y se
        # guarda como estilo predeterminado -- así sale bien lo abra quien
        # lo abra (con el plugin, arrastrándolo desde el explorador, o en
        # otro equipo), no solo al cargarlo con "Carga Obra".
        for diff in plan.pairs:
            if not diff.role:
                continue
            try:
                fixed, remaining = self._fix_form_in_gpkg(
                    plan.old_path, diff.old_table, plan.model_path, diff.model_table,
                )
                if fixed:
                    result['forms_fixed'] += 1
                    log(f'📝 {diff.old_table}: formulario de atributos corregido y guardado en el GeoPackage.')
                if remaining:
                    log(f'   ⚠ {diff.old_table}: el formulario sigue con problemas: {"; ".join(remaining)}')
            except Exception as e:
                log(f'✖ No se pudo corregir el formulario de "{diff.old_table}": {e}')

        return result

    # ── V199: formulario de atributos guardado en el GeoPackage ─────────
    def _fix_form_in_gpkg(self, gpkg_path, table_name, model_path=None, model_table=None):
        """Devuelve (corregido, problemas_restantes)."""
        marker = ''
        if model_path and model_table:
            try:
                old_qml = GpkgIntrospector(gpkg_path).default_style_qml(table_name)
                model_qml = GpkgIntrospector(model_path).default_style_qml(model_table)
                # Solo se marca como "derivado del modelo" si el estilo que
                # se va a corregir ES el del modelo (recién sincronizado).
                if model_qml and old_qml == model_qml:
                    marker = _style_marker(model_qml)
            except Exception:
                marker = ''
        uri = f'{gpkg_path}|layername={table_name}'
        lyr = QgsVectorLayer(uri, table_name, 'ogr')
        if not lyr.isValid():
            raise RuntimeError(f'no se pudo abrir "{table_name}"')
        lyr.loadDefaultStyle()
        before = self.form_customizer.form_problems(lyr)
        if not before:
            return False, []
        self.form_customizer.apply_form(lyr)
        self._retarget_value_relations(lyr, gpkg_path)

        doc = QDomDocument('qgis')
        err = lyr.exportNamedStyle(doc)
        if isinstance(err, tuple):
            err = err[-1]
        if err:
            raise RuntimeError(f'no se pudo exportar el estilo: {err}')
        qml = doc.toString()
        if not qml:
            raise RuntimeError('estilo exportado vacío')
        if marker:
            # Comentario XML al final del QML (QGIS lo ignora al leerlo):
            # permite reconocer después que este estilo ES el del modelo
            # con el formulario revisado (ver _compare_styles).
            qml = qml.rstrip() + '\n<!-- ' + marker + ' -->\n'
        if not self._write_default_style_qml(gpkg_path, table_name, qml, marker):
            # Sin tabla layer_styles en el fichero: que la cree QGIS.
            lyr.saveStyleToDatabase(table_name, 'OBRA_NUEVA', True, '')

        check = QgsVectorLayer(uri, table_name, 'ogr')
        check.loadDefaultStyle()
        remaining = self.form_customizer.form_problems(check) or []
        return True, remaining

    def _retarget_value_relations(self, layer, gpkg_path):
        """Hace que los desplegables ValueRelation del estilo que se va a
        guardar apunten a las tablas CLAVE/ASPECTOS de ESTE GeoPackage (y
        no a la ruta del equipo del autor del modelo)."""
        fields = layer.fields()
        support = {normalize_text(t): t for t in self.SUPPORT_TABLES}
        for i in range(fields.count()):
            setup = layer.editorWidgetSetup(i)
            if setup.type() != 'ValueRelation':
                continue
            config = dict(setup.config() or {})
            table = support.get(normalize_text(str(config.get('LayerName') or '')))
            if not table:
                continue
            config['LayerName'] = table
            config['LayerProviderName'] = 'ogr'
            config['LayerSource'] = f'{gpkg_path}|layername={table}'
            layer.setEditorWidgetSetup(i, QgsEditorWidgetSetup('ValueRelation', config))

    def _write_default_style_qml(self, gpkg_path, table_name, qml, marker=''):
        """Guarda qml como estilo predeterminado de table_name en la tabla
        layer_styles (sustituye el predeterminado actual o crea uno). Solo
        escribe filas de layer_styles: no cambia la estructura de ninguna
        tabla de datos. False si el GeoPackage no tiene layer_styles."""
        try:
            geom_col = GpkgIntrospector(gpkg_path).geometry_column_name(table_name) or ''
        except Exception:
            geom_col = ''
        conn = sqlite3.connect(gpkg_path)
        try:
            cur = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='layer_styles'")
            if not cur.fetchone():
                return False
            cols = {r[1] for r in cur.execute("PRAGMA table_info('layer_styles')").fetchall()}
            row = cur.execute(
                'SELECT id FROM layer_styles WHERE f_table_name=? ORDER BY useAsDefault DESC, id ASC LIMIT 1',
                (table_name,),
            ).fetchone()
            if row:
                sets = ['styleQML=?', 'useAsDefault=1']
                params = [qml]
                if 'description' in cols:
                    sets.append('description=?')
                    params.append(('Estilo del modelo con formulario revisado por OBRA_NUEVA ' + marker).strip())
                if 'f_geometry_column' in cols and geom_col:
                    sets.append('f_geometry_column=?')
                    params.append(geom_col)
                if 'update_time' in cols:
                    sets.append("update_time=strftime('%Y-%m-%dT%H:%M:%fZ','now')")
                params.append(row[0])
                cur.execute('UPDATE layer_styles SET ' + ', '.join(sets) + ' WHERE id=?', params)
                cur.execute(
                    'UPDATE layer_styles SET useAsDefault=0 WHERE f_table_name=? AND id<>?',
                    (table_name, row[0]),
                )
            else:
                values = {
                    'f_table_catalog': '', 'f_table_schema': '', 'f_table_name': table_name,
                    'f_geometry_column': geom_col, 'styleName': table_name, 'styleQML': qml,
                    'styleSLD': '', 'useAsDefault': 1,
                    'description': ('Formulario revisado por OBRA_NUEVA ' + marker).strip(),
                    'owner': '', 'ui': '',
                }
                use = [k for k in values if k in cols]
                cur.execute(
                    'INSERT INTO layer_styles ({}) VALUES ({})'.format(
                        ', '.join('"' + k + '"' for k in use), ', '.join('?' for _ in use)),
                    [values[k] for k in use],
                )
            conn.commit()
            return True
        finally:
            conn.close()

    def _make_backup(self, path):
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        base, ext = os.path.splitext(path)
        backup_path = f'{base}_backup_{stamp}{ext}'
        # V198: copia con la API de copia de seguridad de SQLite (solo
        # lectura sobre el original) en vez de copiar el fichero a pelo: si
        # QGIS tiene el GeoPackage abierto en modo WAL, parte de los últimos
        # cambios pueden estar aún en el fichero "-wal" y una copia directa
        # del .gpkg saldría incompleta. Si falla, se recurre a la copia
        # directa de siempre.
        try:
            src = sqlite3.connect(path)
            try:
                dst = sqlite3.connect(backup_path)
                try:
                    src.backup(dst)
                finally:
                    dst.close()
            finally:
                src.close()
        except Exception as e:
            log_warning(f'Copia de seguridad SQLite no disponible ({e}); se copia el fichero directamente.')
            try:
                if os.path.exists(backup_path):
                    os.remove(backup_path)
            except Exception:
                pass
            shutil.copy2(path, backup_path)
        return backup_path

    def _model_fields(self, model_path, model_table):
        """{nombre_normalizado: QgsField} de una tabla del modelo, leída
        con OGR (solo lectura), para copiar la definición exacta de cada
        campo nuevo. Vacío si la tabla no se puede abrir (se usa entonces
        el tipo SQL de PRAGMA table_info como respaldo)."""
        try:
            lyr = QgsVectorLayer(f'{model_path}|layername={model_table}', model_table, 'ogr')
            if not lyr.isValid():
                return {}
            return {normalize_text(f.name()): f for f in lyr.fields()}
        except Exception as e:
            log_warning(f'No se pudieron leer los campos del modelo "{model_table}": {e}')
            return {}

    def _create_empty_table_from_model(self, model_path, target_path, table_name):
        src_layer = QgsVectorLayer(f'{model_path}|layername={table_name}', table_name, 'ogr')
        if not src_layer.isValid():
            raise RuntimeError(f'No se pudo leer la tabla "{table_name}" del GPKG modelo.')

        wkb_type = src_layer.wkbType()
        if wkb_type in (QgsWkbTypes.NoGeometry, QgsWkbTypes.Unknown):
            uri = 'None'
        else:
            uri = f'{QgsWkbTypes.displayString(wkb_type)}?crs={src_layer.crs().authid()}'

        mem = QgsVectorLayer(uri, table_name, 'memory')
        if not mem.isValid():
            raise RuntimeError(f'No se pudo preparar la estructura en memoria para "{table_name}".')

        prov = mem.dataProvider()
        prov.addAttributes(src_layer.fields())
        mem.updateFields()

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = 'GPKG'
        options.layerName = table_name
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

        write_result = QgsVectorFileWriter.writeAsVectorFormatV3(
            mem, target_path, QgsCoordinateTransformContext(), options,
        )
        err_code, err_msg = write_result[0], write_result[1]
        if err_code != QgsVectorFileWriter.NoError:
            raise RuntimeError(err_msg or f'Error desconocido creando "{table_name}".')

    def _copy_layer_styles(self, model_path, target_path, model_table, target_table):
        """Copia (sustituyendo) las filas de layer_styles del modelo para
        model_table al GeoPackage de destino bajo target_table. Solo toca
        metadatos de leyenda/simbología (tabla layer_styles); nunca modifica
        datos ni geometrías de las capas. Devuelve el número de filas de
        estilo copiadas."""
        try:
            mconn = sqlite3.connect(model_path)
            try:
                mcur = mconn.cursor()
                mcur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='layer_styles'")
                if not mcur.fetchone():
                    return 0
                cur_cols = [r[1] for r in mcur.execute("PRAGMA table_info('layer_styles')").fetchall()]
                cols = [c for c in cur_cols if c != 'id']
                col_list_sql = ', '.join('"' + c + '"' for c in cols)
                rows = mcur.execute(
                    'SELECT {} FROM layer_styles WHERE f_table_name=?'.format(col_list_sql),
                    (model_table,),
                ).fetchall()
            finally:
                mconn.close()
        except Exception as e:
            log_warning(f'No se pudo leer el estilo del modelo para "{model_table}": {e}')
            return 0
        if not rows:
            return 0
        name_idx = cols.index('f_table_name')
        # V198: QGIS solo reconoce como estilo de una capa la fila de
        # layer_styles cuyo f_geometry_column coincide con el nombre REAL
        # de la columna de geometría de esa tabla. Si el modelo la llama,
        # p. ej., "geom" y la obra "geometry" (obras creadas con versiones
        # distintas), la fila copiada tal cual existe pero QGIS la ignora y
        # la capa se queda sin el estilo/formulario del modelo. Se ajusta
        # al nombre de la tabla de destino.
        geom_idx = cols.index('f_geometry_column') if 'f_geometry_column' in cols else None
        target_geom_col = None
        if geom_idx is not None:
            try:
                target_geom_col = GpkgIntrospector(target_path).geometry_column_name(target_table)
            except Exception:
                target_geom_col = None
        tconn = sqlite3.connect(target_path)
        try:
            tcur = tconn.cursor()
            tcur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='layer_styles'")
            if not tcur.fetchone():
                return 0
            tcur.execute('DELETE FROM layer_styles WHERE f_table_name=?', (target_table,))
            placeholders = ', '.join('?' for _ in cols)
            insert_sql = 'INSERT INTO layer_styles ({}) VALUES ({})'.format(col_list_sql, placeholders)
            count = 0
            for row in rows:
                row = list(row)
                row[name_idx] = target_table
                if geom_idx is not None and target_geom_col:
                    row[geom_idx] = target_geom_col
                tcur.execute(insert_sql, row)
                count += 1
            tconn.commit()
            return count
        finally:
            tconn.close()

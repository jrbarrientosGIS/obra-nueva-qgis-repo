V197 - FIX: NUMERACIÓN DE BOTONES A TEXTO PLANO (SIN SÍMBOLOS ESPECIALES)
============================================================================

PROBLEMA REPORTADO
-------------------
La V196 sustituyó los círculos Unicode ①②③④ (poco legibles, ver
README_V196) por el emoji "keycap" 1️⃣2️⃣3️⃣4️⃣, asumiendo que se
renderizaría bien porque el plugin ya usa otros emojis (🔍, 🗄, ⬆, ⇄) sin
problema. El usuario mandó una nueva captura real (pestaña Consulta) y
mostró que el emoji "keycap" tampoco se renderizaba correctamente: en vez
de un recuadro de color con el dígito, aparecía un icono genérico (una
especie de engranaje/ajustes), IGUAL para los botones "① Escanear
carpeta", "② Ejecutar consulta", "③ Exportar a GeoPackage" y "④ Exportar
a CSV" -- es decir, ni siquiera se distinguía un número de otro.

CAUSA
-----
El emoji "keycap" no es un carácter simple, sino una SECUENCIA de tres
puntos de código (dígito + U+FE0F "variation selector-16" + U+20E3
"combining enclosing keycap"). Para que se vea como el recuadro de color
esperado hace falta que el motor de texto combine correctamente esos tres
puntos de código y que exista una fuente de emoji a color instalada y
accesible desde el control `QPushButton` de Qt. A diferencia de los
emojis simples de un solo carácter que ya usaba el plugin (🔍, 🗄, ⬆, ⇄,
que sí se ven bien porque son un único glifo con su propia entrada en la
fuente), la combinación de tres puntos de código para el "keycap" no se
resuelve igual en todos los equipos/fuentes: aquí el sistema no compone
el recuadro y cae a un glifo de repuesto genérico (aparentemente el mismo
para cualquier dígito), perdiendo toda la información del número.
Esto confirma que CUALQUIER numeración basada en un carácter o secuencia
Unicode poco común es frágil entre equipos distintos (ya fue el caso con
los círculos ①②③④ en la V196), porque depende de qué fuentes tenga
instaladas cada máquina y de cómo las resuelva Qt para ese control
concreto.

CORRECCIÓN
----------
Se abandona cualquier símbolo especial para la numeración. Ahora el
número va en TEXTO PLANO, con el mismo tipo de carácter que el resto del
texto del botón: `"1)  Ejecutar"`, `"2)  Actualizar GPKG"`, etc. -- solo
dígitos ASCII y un paréntesis de cierre, sin ningún carácter fuera del
alfabeto básico. Esto no puede fallar por fuente ni por composición de
glifos: se renderiza exactamente igual que cualquier otra palabra del
botón, en cualquier equipo Windows/Linux/Mac con QGIS.
Aplicado en los mismos 7 ficheros que la V195/V196 (sustituyendo
`1️⃣/2️⃣/3️⃣/4️⃣` por `1)/2)/3)/4)`), en ambas copias qgis3/qgis4, sin tocar
ninguna otra cosa (ni el orden de filas corregido en la V196, ni ninguna
conexión de señal, ni ningún objectName).

CÓMO SE COMPROBÓ
-----------------
  - `python3 -m py_compile` sobre los 7 ficheros, en ambas copias: sin
    errores.
  - `diff` entre las copias qgis3/qgis4: cero líneas `QPushButton(...)`
    en los diffs -- el texto de los botones queda idéntico en ambas
    copias, solo persisten los enums PyQt5/PyQt6 de siempre.
  - Listado completo de todos los `QPushButton(...)` de las 7 pestañas
    para confirmar que ya no queda ningún círculo Unicode ni emoji
    "keycap" en ningún botón.
No se puede garantizar al 100% desde este entorno (sin QGIS real
disponible) que el texto plano se vea "bien" en un sentido estético --
pero al ser texto ASCII corriente, no puede aparecer como icono genérico
ni como glifo roto: es la opción con menos margen de fallo posible. Se
recomienda que el usuario confirme con una nueva captura antes de
reempaquetar y publicar.

COMPATIBILIDAD
---------------
Cambio de interfaz (solo el símbolo de numeración) en:
ui/tab_nueva_obra.py, ui/tab_carga_obra.py, ui/tab_archivar_gpkg.py,
ui/tab_kmz.py, ui/tab_actualiza_gpkg.py, ui/tab_consulta.py y
ui/tab_fotos.py, en ambas copias qgis3/qgis4. No cambia el orden de
filas ya corregido en la V196, ni ningún objectName, conexión de señal
ni comportamiento.

V194 - FIX: "ACTUALIZA GPKG" PODÍA CERRAR QGIS EN ALGUNOS ORDENADORES
========================================================================

PROBLEMA
--------
El usuario reportó: "la pestaña Actualizar GPKG, en algunos ordenadores,
cierra el programa QGIS". El cierre es del propio proceso de QGIS (no un
mensaje de error del plugin), y solo pasa en algunos equipos.

CAUSA (por revisión de código; NO reproducido con QGIS real en este
entorno, que no dispone de una instalación de QGIS de escritorio)
--------------------------------------------------------------------
`GpkgStructureUpdater.apply()` (core/gpkg_updater.py) modifica el
GeoPackage "antiguo" en el disco por TRES vías, todas ajenas al proveedor
OGR de QGIS:
  1. `ALTER TABLE ... ADD COLUMN` por una conexión `sqlite3.connect()`
     propia, para los campos nuevos.
  2. Otra conexión `sqlite3.connect()` propia para copiar filas de
     `layer_styles` (leyenda/simbología).
  3. `QgsVectorFileWriter.writeAsVectorFormatV3()` (un handle GDAL
     independiente) para crear las tablas nuevas del modelo.

Nada de esto comprueba antes si ese mismo GeoPackage tiene ya capas
cargadas en el lienzo de QGIS -- y es MUY probable que las tenga, porque
esta misma pestaña, desde la V187, propone por defecto como "GPKG a
actualizar (antiguo)" precisamente el GeoPackage que el usuario ya tiene
abierto en el proyecto. Es decir: el flujo normal y fomentado por el
propio plugin es "GPKG abierto en el lienzo -> Actualiza GPKG -> Actualizar",
justo el caso más expuesto al problema.

Si esas capas siguen conectadas mientras se escribe, coexisten -- dentro
del MISMO proceso de QGIS -- dos conexiones SQLite/GDAL independientes
abiertas sobre el mismo fichero: la del proveedor OGR de la capa ya
cargada (con la estructura antigua en caché: campos, definiciones de
entidad, sentencias preparadas) y la que abre la actualización para
escribir. Que una de ellas cambie el esquema del fichero mientras la otra
sigue con referencias a la estructura anterior es una causa conocida de
cierres NATIVOS de QGIS: no es un error Python que este plugin pueda
capturar con `try/except` (todos los puntos de escritura ya estaban bien
protegidos), sino un fallo a nivel de GDAL/Qt que puede terminar el
proceso entero sin ningún aviso ni traza. Encaja con "en algunos
ordenadores": depende de la versión de QGIS/GDAL instalada, del modo de
journal de SQLite, de si hay antivirus o sincronización de carpeta
(OneDrive, etc.) interfiriendo con los bloqueos de fichero, y del instante
exacto en que el proveedor de la capa cargada sea tocado (redibujado,
tabla de atributos abierta...) -- nada de esto está controlado y varía de
un equipo a otro, e incluso de una ejecución a otra en el mismo equipo.

De hecho, `core/gpkg_loader.py` ya documentaba el mismo conflicto en un
comentario (rama de "capa ya cargada" en `load_selected_layers()`, V177):
"el GeoPackage puede haberse modificado desde entonces ('Actualiza GPKG'
añade campos con ALTER TABLE por una conexión sqlite3 aparte de la del
proveedor OGR de esta capa)". Pero esa mitigación solo actúa DESPUÉS de
escribir, al ofrecer recargar el GeoPackage en el lienzo -- nunca antes,
durante la propia escritura, que es cuando el proveedor original todavía
tiene el fichero abierto con la conexión de la capa que ya estaba
cargada.

CORRECCIÓN
----------
core/gpkg_loader.py:
  - Nuevo método `GpkgLoader.detach_layers_for_path(gpkg_path)`: busca en
    el proyecto QGIS actual todas las capas vectoriales cuyo origen
    (ignorando "|layername=...") apunte a ese mismo fichero, y las
    desconecta con `setDataSource('', ...)` -- igual mecanismo
    (`setDataSource`) que ya usaba `load_selected_layers()` desde V177
    para forzar una relectura, pero aquí usado ANTES de escribir, para
    soltar la conexión, no para refrescarla. Devuelve la lista de
    (capa, uri_original) desconectadas.
  - Nuevo método `GpkgLoader.reattach_layers(detached)`: reconecta cada
    capa a su uri original con `setDataSource()`, forzando una relectura
    completa del esquema ya actualizado (misma lógica que V177).
ui/tab_actualiza_gpkg.py:
  - `_do_update_single()`: antes de llamar a `self.updater.apply(...)` se
    llama a `self.loader.detach_layers_for_path(self._plan.old_path)`;
    se reconectan las capas con `reattach_layers()` tanto si `apply()`
    termina bien como si lanza una excepción (rama `except`), para no
    dejar nunca una capa sin origen de datos.
  - `_do_update_batch()`: mismo tratamiento, pero por cada GeoPackage
    de la carpeta dentro del bucle de actualización masiva (con
    `try/finally`, ya que el bucle continúa con el resto de ficheros
    aunque uno falle).

Con este cambio, mientras dura la escritura externa del GeoPackage solo
queda abierta la conexión de la propia actualización -- ninguna capa del
proyecto mantiene una conexión propia al mismo fichero en ese momento.

CÓMO SE COMPROBÓ
-----------------
NO ha sido posible reproducir el cierre original ni verificar la
corrección con QGIS real en este entorno (no hay una instalación de QGIS
de escritorio disponible aquí, solo análisis de código). Se ha verificado:
  - `python3 -m py_compile` sobre `core/gpkg_loader.py` y
    `ui/tab_actualiza_gpkg.py` en ambas copias (qgis3/qgis4): sin errores.
  - `diff` entre las copias qgis3/qgis4 de `core/gpkg_loader.py`: CERO
    diferencias (código añadido idéntico byte a byte, no usa ningún enum
    que difiera entre PyQt5/PyQt6).
  - `diff` entre las copias qgis3/qgis4 de `ui/tab_actualiza_gpkg.py`:
    únicamente las diferencias de sintaxis de enums PyQt5/PyQt6 que ya
    existían antes de este cambio (QMessageBox.Yes vs
    QMessageBox.StandardButton.Yes, etc.) -- el código añadido no
    introduce ninguna diferencia nueva entre ambas copias.
PENDIENTE (importante): confirmar en un equipo real, sobre todo en uno de
los que ya haya sufrido el cierre, que:
  1. Al actualizar un GeoPackage que SÍ está cargado en el lienzo, QGIS ya
     no se cierra, y la actualización se aplica correctamente.
  2. Tras actualizar, las capas afectadas siguen mostrando los datos
     correctos (mismo id de capa, mismo estilo/formulario, campos nuevos
     visibles) -- `reattach_layers()` debería dejarlas exactamente como
     las deja hoy la recarga manual ("¿Cargar el GeoPackage actualizado en
     el lienzo?"), pero sin haber llegado a desaparecer del panel de capas
     en ningún momento.
  3. El modo "Carpeta completa" también se comporta bien cuando alguno de
     los GeoPackage encontrados está cargado en el lienzo.

COMPATIBILIDAD
---------------
Afecta a core/gpkg_loader.py y ui/tab_actualiza_gpkg.py, en ambas copias
qgis3/qgis4 (cambio idéntico salvo, como siempre, la sintaxis de enums
Qt). No afecta a "Archivar GPKG", "Carga Obra", "Consulta", "Nueva Obra",
KMZ ni Fotos: ninguna de esas pestañas escribe en el GeoPackage por una
conexión sqlite3/GDAL aparte de la del proveedor OGR de sus propias capas.

V198 - "ACTUALIZA GPKG": ADIÓS AL CIERRE DE QGIS 3 Y REFRESCO DEL FORMULARIO
=============================================================================

PROBLEMAS DE PARTIDA
--------------------
1. El usuario confirmó que, con la versión 1.7.10 (que ya incluía V194),
   QGIS 3 SEGUÍA cerrándose de golpe al pulsar "Actualizar GPKG".
2. Tras actualizar SDONO124 (modo un solo GeoPackage, respondiendo
   "Edición" a cargar en el lienzo), el formulario de SDONO124_Poligonos
   aparecía "plano": sin los grupos FICHAS-INFORMES / FOTOS /
   NC-INCIDENCIAS, con Doc_Apertura, Doc_Cierre y Aspecto Ambiental como
   simples cajas de texto (sin selector de documento ni desplegable) y
   con Aspecto Ambiental visible aunque el Ámbito no era "Incidencias".
   Esos tres campos los reconfigura SIEMPRE el código del formulario del
   plugin (form_customizer.apply_form), así que esa capa no había pasado
   por ese código después de actualizarse.

CAUSA (1): CIERRE DE QGIS
-------------------------
Los campos nuevos se añadían con "ALTER TABLE ... ADD COLUMN" desde una
conexión sqlite3 propia de Python, en paralelo a la conexión GDAL/OGR que
QGIS mantiene sobre el mismo fichero para las capas cargadas. Cambiar el
esquema de una tabla por debajo de GDAL deja a su proveedor con una
estructura en caché que ya no coincide con el fichero: causa conocida de
cierres nativos de QGIS (no capturables desde Python).
V194 intentó evitarlo desconectando las capas (setDataSource a un origen
vacío) antes de escribir. No bastaba: QGIS mantiene su propio "pool" de
conexiones OGR aunque la capa se desconecte, y desconectar una capa viva
(lienzo dibujándola, tabla/formulario abiertos, desplegables que la
referencian) es en sí mismo otro riesgo.
Lo mismo ocurría en form_customizer.ensure_fields_for_gpkg (campos
Apertura/Doc_Apertura/Cierre/Doc_Cierre/Aspecto Ambiental), que se ejecuta
al cargar una obra justo cuando sus capas pueden estar ya en el lienzo.

CAUSA (2): FORMULARIO PLANO
---------------------------
a) Después de actualizar, las capas ya cargadas solo se reconectaban
   (reattach_layers): nunca se les volvía a aplicar el estilo del modelo
   ni el formulario de la obra. En modo "Carpeta completa" no había
   ningún otro paso que lo hiciera.
b) Para reconocer una capa ya cargada se comparaba el TEXTO EXACTO de la
   ruta. Si la misma capa estaba cargada con la ruta escrita de otra forma
   ("\" frente a "/", mayúsculas...), no se reconocía: se cargaba una
   copia nueva bien configurada y la vieja se quedaba en el proyecto con
   su formulario antiguo; al pinchar en el mapa podía abrirse la vieja.
c) Además, QGIS solo reconoce como estilo de una capa la fila de
   layer_styles cuyo f_geometry_column coincide con el nombre real de su
   columna de geometría. La fila se copiaba del modelo tal cual; si el
   modelo y la obra llaman distinto a esa columna ("geom" / "geometry"),
   QGIS ignoraba el estilo copiado.

CAMBIOS
-------
Nuevo core/ogr_layer_utils.py:
  - add_fields_via_provider(): añade campos con QgsVectorDataProvider.
    addAttributes() del proveedor OGR de QGIS -- el mismo mecanismo que usa
    QGIS al añadir un campo desde la tabla de atributos. Usa el proveedor
    de la capa si ya está cargada (y refresca todas sus copias) o una capa
    temporal que no se añade al proyecto. Campos siempre opcionales.
  - project_layers_for_gpkg(): localiza TODAS las capas del proyecto de un
    GeoPackage/tabla comparando rutas normalizadas.
  - assert_no_layer_in_edit_mode(): si alguna capa del GeoPackage está en
    modo edición, se avisa y no se escribe nada (añadir campos con un
    búfer de edición abierto lo desincronizaría).
core/gpkg_updater.py:
  - apply(): campos nuevos vía add_fields_via_provider(), copiando la
    definición exacta del campo desde la tabla del modelo (sin sus
    restricciones NOT NULL). Ya no hay ALTER TABLE por sqlite3.
  - _make_backup(): copia con la API de copia de seguridad de SQLite
    (coherente aunque QGIS tenga el fichero en modo WAL); si falla, copia
    directa como antes.
  - _copy_layer_styles(): ajusta f_geometry_column al nombre real de la
    columna de geometría de la tabla de destino.
core/form_customizer.py:
  - ensure_fields_for_gpkg(): lee la estructura con sqlite3 (solo lectura)
    y añade lo que falte vía add_fields_via_provider().
core/gpkg_loader.py:
  - detach_layers_for_path(): ya NO desconecta nada; solo devuelve las
    capas de ese GeoPackage (se mantiene el nombre para no tocar la
    pestaña).
  - reattach_layers(): pone al día esas capas -- estructura, estilo del
    GeoPackage, desplegables ValueRelation y formulario de la obra --
    respetando el modo de leyenda con que se cargaron (Edición /
    Visualización, recordado en la propiedad "obra_nueva/legend_pruned").
    Sirve igual para modo un solo GeoPackage y modo "Carpeta completa".
  - load_selected_layers(): refresca todas las copias ya cargadas de cada
    tabla (comparación de rutas normalizada) en vez de solo la primera
    con ruta idéntica.
  - _ensure_schema_current(): solo usa setDataSource() como último recurso,
    si la capa no ve alguna columna del fichero tras una recarga suave.

CÓMO SE COMPROBÓ
----------------
  - python3 -m py_compile de los 4 ficheros de core/.
  - Prueba de lógica con GeoPackage SQLite reales y una simulación de la API
    de QGIS (no hay QGIS de escritorio en este entorno): detección de capas
    con rutas escritas de forma distinta, bloqueo con capa en edición,
    campos añadidos por el proveedor y vistos por todas las copias, copia de
    seguridad íntegra, estilo copiado con la columna de geometría de la obra,
    refresco de estilo+formulario respetando "Visualización", y ningún
    setDataSource() en el flujo normal.
  - NO verificado con QGIS real: pendiente de que el usuario pruebe en
    QGIS 3 que "Actualizar GPKG" ya no cierra QGIS y que el formulario sale
    agrupado sin recargar la obra.

COMPATIBILIDAD
--------------
Sin cambios de interfaz. core/ es idéntico en qgis3 y qgis4: no se usan
enums de Qt/QGIS que difieran entre versiones (isinstance en vez de
QgsMapLayer.VectorLayer; los tipos de campo se copian del modelo, o
QMetaType con respaldo a QVariant).

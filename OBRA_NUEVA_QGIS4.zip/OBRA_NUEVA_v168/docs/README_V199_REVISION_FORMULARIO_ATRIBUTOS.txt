V199 - "ACTUALIZA GPKG" REVISA Y CORRIGE EL FORMULARIO DE ATRIBUTOS
====================================================================

PROBLEMA
--------
El usuario indica que "Actualiza GPKG" sigue sin dejar bien el GeoPackage,
"sobre todo no chequea el formulario de atributos". Hasta ahora la pestaña
solo comparaba campos, tablas y la leyenda (el texto del estilo guardado).
Del formulario no se revisaba nada: el formulario correcto (grupos
FICHAS-INFORMES / FOTOS / NC-INCIDENCIAS, selectores de documento y foto,
desplegable de Aspecto Ambiental) solo se montaba EN MEMORIA al cargar la
obra con el plugin. El GeoPackage seguía guardando un formulario incompleto:
bastaba abrirlo de otra forma (arrastrándolo desde el explorador, en un
proyecto guardado, en otro equipo) para ver el formulario "plano" de
SDONO124.

Dos defectos más en form_customizer.apply_form() podían dejarlo plano
incluso cargando con el plugin:
  - Si el estilo guardado traía los grupos pero con el formulario en modo
    "automático" (no "arrastrar y soltar"), QGIS ignora los grupos y
    enseña todos los campos seguidos. El modo "arrastrar y soltar" solo se
    fijaba al reconstruir el formulario desde cero.
  - Bastaba cualquier contenedor para considerar que el formulario ya
    estaba "diseñado", incluido un grupo ASPECTO-ZONA suelto que el propio
    plugin añadía sobre un formulario automático. En ese caso no se
    reconstruía nada.

CAMBIOS
-------
core/form_customizer.py
  - form_problems(layer): revisa el formulario tal como está y devuelve los
    problemas en texto: modo automático sin grupos, grupos que faltan,
    Ficha / Foto 1-4 / Doc_Apertura / Doc_Cierre sin selector de documento
    o foto, Aspecto Ambiental sin desplegable.
  - apply_form(): siempre deja el formulario en modo "arrastrar y soltar".
    Solo considera "diseñado" un formulario con alguno de los grupos
    estándar. Si a un formulario diseñado le falta algún grupo estándar, lo
    añade al final. Además completa el selector de Ficha y de Foto 1-4
    cuando falta (las fotos copian la configuración de otra foto que ya lo
    tenga).
core/gpkg_updater.py
  - analyze(): revisa el formulario guardado de cada capa operativa de la
    obra, y también el del modelo (sin contar los grupos que añade el
    plugin). Un formulario incompleto cuenta como cambio pendiente.
  - apply(): al final, para cada capa operativa, abre el estilo guardado,
    corrige el formulario, apunta los desplegables a las tablas CLAVE y
    ASPECTOS de ese mismo GeoPackage y lo guarda como estilo predeterminado
    en layer_styles, con la columna de geometría correcta. Después lo
    vuelve a leer para comprobar que ha quedado bien. Se hace aunque la
    sincronización de leyenda esté desactivada.
  - El estilo guardado lleva una marca (comentario XML) que lo identifica
    como el del modelo con el formulario revisado. Así el siguiente
    análisis no lo da por distinto del modelo, y no entra en un bucle de
    volver a sincronizarlo.
ui/tab_actualiza_gpkg.py
  - El informe muestra, por capa, si el formulario es correcto o qué le
    falta. Avisa si el formulario del propio MODELO está incompleto. El
    resumen, la confirmación y el mensaje final cuentan los formularios
    corregidos, en modo un solo GeoPackage y en modo carpeta.

CÓMO SE COMPROBÓ
----------------
  - py_compile y pyflakes sobre los ficheros tocados, en ambas copias.
  - Prueba de lógica con GeoPackage SQLite reales y una simulación de la API
    de QGIS (no hay QGIS de escritorio en este entorno). Obra con formulario
    automático, solo un grupo ASPECTO-ZONA suelto y Foto 3/4 y Doc_* sin
    selector: el análisis detecta los cuatro problemas. La actualización
    deja guardado en el GeoPackage un formulario con los 4 grupos y todos
    los selectores, y el nuevo análisis sale limpio (sin bucle). Con la
    sincronización de leyenda desactivada, el formulario también se corrige.
  - NO verificado con QGIS real.

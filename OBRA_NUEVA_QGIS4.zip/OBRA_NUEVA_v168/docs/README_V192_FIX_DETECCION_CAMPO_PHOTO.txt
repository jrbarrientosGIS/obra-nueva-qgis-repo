V192 - FIX: DETECCION DE FOTOS EN CAPAS CREADAS POR "IMPORTAR FOTOS GEOETIQUETADAS"
====================================================================================

SINTOMA
-------
Al usar "Importar fotos desde seleccion en el lienzo" (bloque 3, V191) sobre una
entidad de una capa shp temporal creada con la herramienta nativa de QGIS
"Importar fotos geoetiquetadas" (Processing: native:importphotos, la que se usa
para crear puntos directamente desde una carpeta de fotos), el resultado era
"Fotos importadas a puntos_informe: 0 / Entidades seleccionadas sin foto
detectada: 1" aunque la foto SI estaba en la capa.

CAUSA
-----
El detector generico de campos de foto (_photo_paths(), usado tambien por el
bloque 1 de ambitos) buscaba nombres de campo en PHOTO_FIELDS (foto, foto_1,
imagen, image...) y, como respaldo, cualquier campo cuyo nombre contuviera
"foto", "image" o "imagen". La herramienta nativa de QGIS "Importar fotos
geoetiquetadas" (src/analysis/processing/qgsalgorithmimportphotos.cpp) crea el
campo con la ruta completa de la foto llamado literalmente "photo" (ingles, sin
"foto" como subcadena: "photo" no contiene "foto" -- le falta la "f"). Ese
campo no coincidia con ningun candidato ni con el respaldo por subcadena, asi
que se ignoraba silenciosamente.

CORRECCION
----------
ui/tab_fotos.py:
  - PHOTO_FIELDS: anadidos "photo", "Photo", "PHOTO" como candidatos exactos.
  - Respaldo por subcadena en _photo_paths(): anadidas las subcadenas "photo"
    y "picture" (antes solo "foto"/"image"/"imagen"), asi que ahora tambien
    detecta variantes como "photo_path", "PhotoPath", "picture_url", etc.
Cambiado en AMBAS copias qgis3/ y qgis4/ (identico, no usa ninguno de los
enums que difieren entre ambas).

Esto beneficia tambien al bloque 1 ("Fotos asociadas a ambitos del GeoPackage
cargado"), que usa el mismo detector generico -- cualquier capa con un campo
"photo" (ingles) empieza a detectarse correctamente ahi tambien.

Version publicada: 1.7.5-fix-deteccion-campo-photo (qgis3) /
1.7.5-fix-deteccion-campo-photo-qgis4 (qgis4).

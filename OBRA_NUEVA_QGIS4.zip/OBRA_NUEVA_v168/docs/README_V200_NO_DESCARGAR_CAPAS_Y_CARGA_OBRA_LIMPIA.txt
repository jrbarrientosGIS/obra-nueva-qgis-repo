V200 - LAS CAPAS YA NO SE DESCARGAN DEL LIENZO AL ACTUALIZAR / CARGAR, Y
"CARGA OBRA" EMPIEZA CON EL CAMPO VACÍO
=========================================================================

PROBLEMAS
---------
1. Al actualizar un GeoPackage con "Actualiza GPKG", sus capas desaparecían
   del lienzo.
2. En "Carga Obra", el campo "GeoPackage a cargar" aparecía relleno con la
   última obra cargada.

CAUSA (1)
---------
core/gpkg_loader.py, load_selected_layers(): para colocar en el grupo de la
obra una capa que ya estaba cargada, se quitaba su nodo del árbol de capas
(removeChildNode) y después se añadía al grupo (addLayer). En QGIS, al
quitar del árbol el ÚLTIMO nodo de una capa, el proyecto elimina también
la propia capa. addLayer() recibía entonces una capa ya borrada: la capa
desaparecía del lienzo, y en algunos casos podía llegar a cerrar QGIS.
Desde V198 las capas ya cargadas se reconocen mucho mejor (rutas
normalizadas), así que este camino se recorría más a menudo que antes.
Además, al terminar la actualización se preguntaba si cargar el GeoPackage
en el lienzo aunque ya estuviera cargado, lo que quitaba y volvía a crear
esas mismas capas.

CAMBIOS
-------
core/gpkg_loader.py
  - _move_layer_to_group(): coloca la capa en el grupo con el patrón que
    recomienda QGIS. Primero inserta en el grupo una copia del nodo y
    después quita el original, así la capa nunca se queda sin nodo ni sale
    del proyecto.
  - load_selected_layers() / _clear_group_layers(): las capas de la obra
    que ya están en su grupo y se van a recargar se conservan y se
    refrescan en su sitio (campos, estilo, formulario), en vez de
    eliminarlas y crearlas de nuevo.
  - has_operational_layers(): indica si el GeoPackage tiene capas
    operativas visibles en el panel de capas.
ui/tab_actualiza_gpkg.py
  - Si el GeoPackage ya estaba cargado en el lienzo, al terminar ya no se
    pregunta si cargarlo: sus capas se han actualizado en su sitio y se
    avisa en el registro. Si no estaba cargado, se sigue ofreciendo
    cargarlo.
ui/tab_carga_obra.py
  - El campo "GeoPackage a cargar" empieza siempre vacío. La última ruta
    se sigue recordando, solo como carpeta de partida de "Examinar...".
  - Tras cargar una obra, y con "Limpiar", el campo, la lista de capas y
    el texto del modo de carga quedan limpios.

CÓMO SE COMPROBÓ
----------------
  - py_compile y pyflakes, en ambas copias qgis3/qgis4.
  - Prueba de lógica con una simulación del árbol de capas de QGIS que
    reproduce la regla anterior (si una capa se queda sin nodo, sale del
    proyecto). Se probaron tres casos y en todos la capa sigue en el
    proyecto, es el mismo objeto y queda en el grupo de la obra: capa
    cargada fuera del grupo de la obra, recarga con la capa ya en su
    grupo, y flujo de actualización.
  - NO verificado con QGIS real.

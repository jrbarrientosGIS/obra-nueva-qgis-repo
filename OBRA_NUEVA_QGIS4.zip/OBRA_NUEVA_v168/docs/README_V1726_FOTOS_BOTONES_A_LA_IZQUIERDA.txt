OBRA_NUEVA 1.7.26 - Fotos: botones alineados a la izquierda
==================================================

- Bloque 2: el boton «2) Iniciar / continuar colocacion» va a continuacion de «Cancelar», alineado a la izquierda.
- Bloque 3: la fila «2) Agrupar IF...», «3) Exportar fotos a carpeta» y «4) Exportar tabla DOCX» se alinea a la izquierda.
- La 1.7.25 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.25.zip y OBRA_NUEVA_QGIS4_v1.7.25.zip.

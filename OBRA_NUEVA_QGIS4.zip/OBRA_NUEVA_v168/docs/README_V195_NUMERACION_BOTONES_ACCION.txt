V195 - NUMERACIÓN DE LOS BOTONES DE ACCIÓN EN CADA PESTAÑA
=============================================================

PETICIÓN
--------
El usuario pidió: "quiero que numeres en cada pestaña los botones de
acción, por orden de uso, empezando en cada pestaña por el 1". Se aclaró
con el usuario, antes de tocar código, en tres puntos:
  1. Formato de la numeración: círculos Unicode (①②③...), no "1. " ni "[1]".
  2. Qué botones cuentan como "de acción": solo los pasos principales del
     flujo de cada pestaña. Los botones de apoyo (examinar/seleccionar
     fichero o carpeta, seleccionar todo/deseleccionar todo, cancelar,
     limpiar formulario) NO se numeran.
  3. La pestaña "Fotos" tiene tres bloques independientes entre sí
     (fotos de ámbitos, georreferenciación manual, anejo fotográfico):
     cada uno empieza su propia numeración en ①, en vez de una única
     secuencia para toda la pestaña.

CAMBIO
------
Se ha prefijado el texto de cada botón de acción principal con su número
en círculo Unicode seguido de dos espacios (p. ej. "①  Ejecutar", o
"①  🔍  Analizar diferencias" cuando el botón ya llevaba un icono emoji,
en cuyo caso el número va delante del icono). Es un cambio puramente de
texto en `QPushButton(...)`: no se ha tocado ninguna conexión de señal,
ningún `objectName` ni ninguna lógica interna.

Numeración aplicada, pestaña por pestaña:
  - Nueva Obra: ① Ejecutar.
  - Carga Obra: ① Cargar.
  - Archivar GPKG: ① Archivar GPKG.
  - KMZ: ① Exportar.
  - Actualiza GPKG: ① Analizar diferencias, ② Actualizar GPKG.
  - Consulta: ① Escanear carpeta, ② Ejecutar consulta,
    ③ Exportar resultados a GeoPackage, ④ Exportar resumen a CSV.
    (El botón "Aceptar" de la ventana emergente de selección de
    GeoPackage encontrados, y "Cancelar"/"Seleccionar todo"/"Ninguno" en
    esa misma ventana, no se numeran: es una ventana de confirmación
    transitoria, no una pestaña con flujo propio.)
  - Fotos (tres bloques independientes, cada uno reinicia en ①):
      · Bloque "1 · Fotos asociadas a ámbitos": ① Georref fotos ámbitos
        (único botón de acción del bloque).
      · Bloque "2 · Georreferenciación manual avanzada": ① Seleccionar
        foto individual / ① Seleccionar carpeta (formas alternativas de
        elegir el origen de fotos -- comparten el mismo número porque son
        dos maneras de dar el mismo paso, no pasos distintos), ② Iniciar
        / continuar colocación, ③ Exportar imágenes georref.
      · Bloque "3 · Anejo fotográfico / puntos_informe": ① Seleccionar
        fotos desde carpeta / ① Seleccionar foto individual / ① Importar
        fotos desde selección en el lienzo (tres alternativas para el
        mismo paso de origen de fotos), ② Agrupar IF por ubicación y
        renumerar, ③ Exportar fotos a carpeta, ④ Exportar tabla DOCX.
    Los botones "Cancelar", "Eliminar seleccionadas de la cola",
    "Actualizar lista" y "Seleccionar todos"/"Deseleccionar todos" de
    esta pestaña no se numeran (apoyo). Tampoco se numeran los botones de
    las ventanas emergentes de vista previa de foto ("Pinchar en lienzo",
    "Siguiente imagen", "Insertar por coordenadas EXIF", "Cancelar"): son
    alternativas de una misma decisión puntual sobre una foto, no pasos
    de la pestaña.
  - El botón "⚙ Ayuda" del diálogo principal (fuera de cualquier pestaña,
    visible siempre) tampoco se numera: no pertenece al flujo de ninguna
    pestaña en concreto.

Fuera de esto, no se han numerado en ninguna pestaña los botones de
examinar fichero/carpeta ("…", "Examinar..."), "Cambiar modo...",
"Actualizar" (refresco de vista), "Seleccionar todo(s)"/"Deseleccionar
todo(s)"/"Ninguno", "Cancelar" ni "Limpiar"/"Limpiar formulario", tal y
como se acordó con el usuario.

CÓMO SE COMPROBÓ
-----------------
  - `python3 -m py_compile` sobre los 7 ficheros de `ui/` modificados,
    en ambas copias (qgis3/qgis4): sin errores.
  - `diff` entre las copias qgis3/qgis4 de cada fichero modificado:
    únicamente las diferencias de sintaxis de enums PyQt5/PyQt6 que ya
    existían antes de este cambio; ninguna línea `QPushButton(...)`
    aparece en esos diffs, es decir, el texto de los botones (incluida
    la numeración añadida) es idéntico en ambas copias.
  - Revisión manual del listado final de todos los `QPushButton(...)` de
    las 7 pestañas para confirmar que la numeración no se solapa dentro
    de cada pestaña/bloque y que ningún botón de apoyo quedó numerado por
    error.
No ha sido posible verificar el aspecto visual en QGIS real en este
entorno (no hay una instalación de QGIS de escritorio disponible aquí).
Al ser un cambio limitado al texto de los botones, sin tocar layouts ni
tamaños, el riesgo visual esperado es bajo (algún botón con texto largo
podría necesitar más ancho, a revisar de un vistazo al abrir el plugin).

COMPATIBILIDAD
---------------
Cambio de interfaz (texto de botones) en: ui/tab_nueva_obra.py,
ui/tab_carga_obra.py, ui/tab_archivar_gpkg.py, ui/tab_kmz.py,
ui/tab_actualiza_gpkg.py, ui/tab_consulta.py y ui/tab_fotos.py, en ambas
copias qgis3/qgis4. No afecta a ui/main_dialog.py (revisado: solo tiene
el botón "Ayuda", fuera de las pestañas, que no se numera) ni a ninguna
lógica de core/. No cambia ningún `objectName`, conexión de señal ni
comportamiento -- solo el texto visible de los botones.

V196 - FIX: NUMEROS DE BOTONES POCO LEGIBLES Y ORDEN VISUAL INCORRECTO
========================================================================

PROBLEMA REPORTADO
-------------------
Tras publicar la V195 (numeración de botones de acción por pestaña), el
usuario reportó dos problemas al ver capturas reales del plugin:
  1. Los círculos Unicode ①②③④ se veían diminutos y apenas legibles con
     la fuente de QGIS en Windows -- casi como iconos borrosos (una especie
     de "ⓘ" o engranaje) en vez de números reconocibles.
  2. En algunos bloques, el orden visual de los botones (de arriba a abajo)
     no coincidía con su numeración: un botón ② o ③ podía aparecer POR
     ENCIMA de un botón ① o ② en la pantalla, aunque lógicamente debería
     ir después.

CAUSA
-----
1. Los caracteres del bloque Unicode "Enclosed Alphanumerics" (①②③... U+2460
   en adelante) tienen mal soporte en la fuente de interfaz que usa QGIS en
   Windows: se dibujan con un trazo muy fino y a un tamaño reducido,
   resultando casi ilegibles junto al resto del texto del botón.
2. En `ui/tab_consulta.py` y en dos bloques de `ui/tab_fotos.py`
   ("2 · Georreferenciación manual avanzada" y "3 · Anejo fotográfico"),
   los distintos QHBoxLayout/QGroupBox de cada sección se habían añadido
   al layout principal en el mismo orden en que aparecían en el código
   fuente original (anterior a la numeración de la V195), sin tener en
   cuenta que la V195 les había asignado números que exigían un orden de
   lectura distinto. Por ejemplo, en "Anejo fotográfico" los botones de
   exportación (③④) se añadían al layout antes que "Agrupar IF... " (②).

CORRECCIÓN
----------
1. Numeración: sustituidos los círculos Unicode ①②③④ por la secuencia
   emoji "keycap" 1️⃣2️⃣3️⃣4️⃣ (dígito + selector de variación + "combining
   enclosing keycap") en el texto de los `QPushButton(...)` ya numerados
   por la V195. Es el mismo tipo de carácter emoji que ya usan con buen
   resultado otros botones del plugin (🔍 Analizar diferencias, 🗄 Archivar
   GPKG, ⬆ Actualizar GPKG, ⇄ Agrupar IF...), por lo que se apoya en la
   misma fuente/mecanismo de emoji que QGIS ya renderiza bien en este
   plugin, en vez de un bloque Unicode de símbolos poco habitual.
2. Orden visual:
   - `ui/tab_consulta.py`: el grupo "Exportación" (③④) se añadía al
     layout principal justo después del grupo de filtros, antes de la
     fila con el botón "② Ejecutar consulta". Se ha movido la llamada
     `layout.addWidget(export_group)` para que ocurra DESPUÉS de añadir
     la fila del botón de consulta, de modo que el orden visual pase a
     ser: ① Escanear carpeta, filtros, ② Ejecutar consulta, ③④ Exportar.
   - `ui/tab_fotos.py`, bloque "Georreferenciación manual avanzada": la
     fila con "② Iniciar/continuar colocación" se añadía ANTES que la
     fila con los botones "① Seleccionar foto individual/carpeta", y el
     botón "③ Exportar imágenes georref" compartía fila con los ①. Se ha
     reorganizado en tres filas añadidas en este orden: ①① (seleccionar
     individual/carpeta + Cancelar), ② (eliminar de la cola + iniciar/
     continuar colocación), ③ (exportar imágenes georref), cada una en
     su propia fila.
   - `ui/tab_fotos.py`, bloque "Anejo fotográfico / puntos_informe": la
     fila con los botones de exportación (③④) se añadía ANTES que la
     fila de "② Agrupar IF por ubicación y renumerar". Se ha invertido
     el orden en que ambas filas se añaden al layout, sin tocar su
     contenido, para que ② aparezca antes que ③④.
   En ningún caso se ha cambiado qué botón hace qué, ninguna conexión de
   señal, ni ningún objectName -- solo el texto de la numeración y el
   ORDEN en que las filas/grupos ya existentes se añaden al layout.

CÓMO SE COMPROBÓ
-----------------
  - `python3 -m py_compile` sobre `ui/tab_consulta.py` y `ui/tab_fotos.py`
    (los únicos con reordenación de layout) y sobre los 7 ficheros con
    numeración (cambio de símbolo), en ambas copias: sin errores.
  - `diff` entre las copias qgis3/qgis4 de los 7 ficheros modificados:
    cero líneas `QPushButton(...)` en los diffs -- el texto de los
    botones y el orden de las filas quedan idénticos en ambas copias;
    solo persisten las diferencias de enums PyQt5/PyQt6 ya existentes.
  - Revisión manual, pestaña por pestaña y bloque por bloque, del orden
    en que cada fila/grupo numerado se añade a su layout padre
    (`grep` de las líneas `QPushButton(...)` y `addLayout`/`addWidget`
    de cada sección), confirmando que ahora coincide con la numeración.
No ha sido posible comprobar visualmente el resultado en QGIS real en
este entorno (no hay instalación de QGIS de escritorio disponible aquí).
El propio usuario fue quien detectó el problema a partir de una captura
real del plugin -- se recomienda que confirme visualmente esta corrección
del mismo modo antes de darla por buena.

COMPATIBILIDAD
---------------
Cambio de interfaz en: ui/tab_nueva_obra.py, ui/tab_carga_obra.py,
ui/tab_archivar_gpkg.py, ui/tab_kmz.py, ui/tab_actualiza_gpkg.py (solo
cambio de símbolo de numeración) y ui/tab_consulta.py, ui/tab_fotos.py
(cambio de símbolo + reordenación de filas), en ambas copias qgis3/qgis4.
No cambia ningún objectName, conexión de señal ni comportamiento -- solo
el texto de los botones y el orden visual de filas ya existentes.

V193 - PLANO GENERAL DEL ANEJO FOTOGRÁFICO: EL FONDO DE TESELAS VECTORIALES
SALÍA EN BLANCO
================================================================================

PETICIÓN / INCIDENCIA REPORTADA
--------------------------------
Con un fondo de teselas vectoriales cargado en el proyecto (p. ej. la capa
"ESRI OSM Standard", tipo Vector Tile, apuntando a un servicio
VectorTileServer de Esri), el plano general que el Anejo fotográfico inserta
en el DOCX (bloque "3 · Anejo fotográfico / puntos_informe") salía siempre en
blanco: solo se veían las capas propias del proyecto (trazado, puntos) y las
llamadas "Foto: Nº", pero ningún relieve, carretera, núcleo de población ni
relleno del fondo. En el lienzo de QGIS, con ese mismo fondo activado, se veía
perfectamente -- el problema era exclusivo del plano generado por el plugin.

DIAGNÓSTICO
-----------
Se comprobó primero (descartándose) que no era:
  - Un problema de sprites del estilo (había un 404 real en
    tiles.versatiles.org para los iconos del estilo, pero esos sprites solo
    afectan a símbolos de punto/POI, no a los rellenos de uso de suelo que
    faltaban).
  - Un problema de carga asíncrona de teselas / condición de carrera con el
    render (el renderizador de teselas vectoriales de QGIS
    (QgsVectorTileLoader::downloadBlocking) bloquea hasta que todas las
    peticiones de red terminan, sea con éxito o con fallo).
  - Un problema de escala/zoom demasiado alejado (el propio código ya limita
    el plano general a un denominador de escala máximo de 1:300.000,
    dividiendo en una rejilla de varias imágenes si hace falta).

Causa real (confirmada leyendo el código): en `ui/tab_fotos.py`, el método
`_situation_canvas_layers()` -- que decide qué capas del lienzo se incluyen al
renderizar el plano general -- filtraba explícitamente las capas por tipo:

    if lyr and lyr.isValid() and lyr.type() in (QgsMapLayer.VectorLayer, QgsMapLayer.RasterLayer):

Una capa de teselas vectoriales (Vector Tile Layer) en QGIS NO es ni
`QgsMapLayer.VectorLayer` ni `QgsMapLayer.RasterLayer`: es su propio tipo,
`QgsMapLayer.VectorTileLayer` (añadido en QGIS 3.14; ver
`Qgis::LayerType::VectorTile` / alias `QgsMapLayer.VectorTileLayer` en el
código fuente de QGIS, `src/core/qgis.h`). Como ese tipo no estaba en la
lista permitida, la capa de fondo se excluía siempre de
`settings.setLayers(...)` antes de renderizar el PNG del plano general --
por eso salía en blanco de forma sistemática, con independencia del zoom, la
escala o la extensión, mientras que en el lienzo normal de QGIS sí se veía
(el lienzo no aplica ese filtro).

El mismo filtro, con el mismo fallo, se repetía en la rama de respaldo de la
función (cuando no hay ninguna capa visible en el lienzo, se usan todas las
del proyecto):

    layers = [lyr for lyr in QgsProject.instance().mapLayers().values() if lyr.type() in (QgsMapLayer.VectorLayer, QgsMapLayer.RasterLayer)]

CORRECCIÓN
----------
En `ui/tab_fotos.py`, en ambas ramas de `_situation_canvas_layers()`, se
añadió `QgsMapLayer.VectorTileLayer` a la tupla de tipos permitidos:

    lyr.type() in (QgsMapLayer.VectorLayer, QgsMapLayer.RasterLayer, QgsMapLayer.VectorTileLayer)

`QgsMapLayer.VectorTileLayer` es un alias plano mantenido por QGIS para
compatibilidad hacia atrás (mecanismo SIP_MONKEYPATCH_COMPAT_NAME), disponible
igual en QGIS 3.x (PyQt5) y QGIS 4.x (PyQt6) -- por eso el cambio es idéntico
byte a byte en ambas copias del plugin, sin necesidad de sintaxis distinta.

Cambiado en `ui/tab_fotos.py`, en AMBAS copias qgis3/ y qgis4/. Verificado
`python3 -m py_compile` en ambas y `diff` (se mantienen las mismas 126
diferencias de sintaxis de enums de siempre, ninguna nueva).

PENDIENTE
---------
Verificar contra QGIS real que, con un fondo de teselas vectoriales activado
en el lienzo, el plano general del Anejo fotográfico ya lo incluye
correctamente. Si en el proyecto también se usan capas de tipo Malla (Mesh),
Nube de puntos (PointCloud) o Anotaciones (Annotation) y se quisiera que
también aparecieran en el plano general, habría que añadir esos tipos a la
misma tupla -- no se ha hecho porque no se ha pedido y no son habituales como
capa de fondo.

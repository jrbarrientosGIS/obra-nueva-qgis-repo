# -*- coding: utf-8 -*-
"""
Pestaña Fotos - OBRA_NUEVA

Reestructuración completa en tres bloques verticales:
1) Georref fotos ámbitos: exporta/copias JPG asociados a elementos de capas GPKG cargadas,
   usando el centroide del elemento asociado como punto de referencia.
2) Georref Fotos: permite insertar fotos una a una pinchando en el lienzo, sin solicitar descripción, y exportarlas.
3) Anejo fotográfico: flujo inspirado en el plugin anejo_fotografico, con capa puntos_informe,
   selección desde carpeta, simbología QML y exportación DOCX.
"""

import csv
import os
import shutil
import tempfile
import zipfile
from collections import OrderedDict
from datetime import datetime
from xml.sax.saxutils import escape as xml_escape

from qgis.PyQt.QtCore import Qt, QVariant, QSize, QRectF, QPointF, QSizeF
from qgis.PyQt.QtGui import QImage, QPainter, QPixmap, QColor, QFont, QPen
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QGroupBox, QTreeWidget, QTreeWidgetItem, QMessageBox, QCheckBox,
    QLineEdit, QTextEdit, QFileDialog, QListWidget, QDialog, QDialogButtonBox, QInputDialog,
    QAbstractItemView, QSizePolicy
)
from qgis.core import (
    Qgis, QgsProject, QgsMapLayer, QgsVectorLayer, QgsWkbTypes, QgsFields, QgsField,
    QgsFeature, QgsGeometry, QgsPointXY, QgsVectorFileWriter, QgsCoordinateReferenceSystem,
    QgsCoordinateTransform, QgsCoordinateTransformContext, QgsEditorWidgetSetup,
    QgsMarkerSymbol, QgsPalLayerSettings, QgsTextFormat, QgsVectorLayerSimpleLabeling,
    QgsMapSettings, QgsMapRendererCustomPainterJob, QgsRectangle, QgsMessageLog, QgsTextBackgroundSettings
)
from qgis.gui import QgsMapToolEmitPoint


PLUGIN_DIR = os.path.dirname(os.path.dirname(__file__))
STYLE_PATH = os.path.join(PLUGIN_DIR, "styles", "puntos.qml")

LAYER_AMBITOS = "Fotos"
LAYER_MANUAL = "fotos_georref"
LAYER_ANEJO = "puntos_informe"
LAYER_ANEJO_PRE = "puntos_informes_pre"
FIELD_NUM = "Nº"
FIELD_DESC = "Descripción"
FIELD_PATH = "foto_path"
FIELD_REPORT = "informe_final"
FIELD_DATE = "fecha_foto"
FIELD_STAMP_DATE = "estampar_fecha"

CODE_FIELDS = ["codigo", "código", "CODIGO", "CÓDIGO", "code", "Code"]
AMBITO_FIELDS = ["ambito", "ámbito", "Ambito", "Ámbito", "AMBITO", "ÁMBITO"]
TIPO_FIELDS = ["tipo", "Tipo", "TIPO", "N_AMB", "n_amb"]
DESC_FIELDS = ["descripcion", "descripción", "Descripcion", "Descripción", "DESCRIPCION", "comentario", "Comentario", FIELD_DESC]
PHOTO_FIELDS = [
    "photo", "Photo", "PHOTO",
    "foto_path", "Foto_path", "FOTO_PATH", "foto", "Foto", "FOTO",
    "foto_1", "Foto_1", "FOTO_1", "Foto1", "foto1", "foto_2", "Foto_2", "FOTO_2", "Foto2", "foto2",
    "foto_3", "Foto_3", "FOTO_3", "Foto3", "foto3", "imagen", "Imagen", "IMAGEN", "image", "Image", "IMAGE"
]
OP_SUFFIXES = (
    "_puntos", "_punto", "puntos", "punto", "_lineas", "_líneas", "lineas", "líneas", "linea", "línea",
    "_poligonos", "_polígonos", "poligonos", "polígonos", "poligono", "polígono",
)


class PhotoPointMapTool(QgsMapToolEmitPoint):
    """Herramienta de captura estable para insertar una fotografía con un clic en el canvas."""
    def __init__(self, canvas, callback):
        super().__init__(canvas)
        self.canvas = canvas
        self.callback = callback

    def canvasReleaseEvent(self, event):
        if event.button() != Qt.MouseButton.LeftButton:
            return
        point = self.toMapCoordinates(event.pos())
        self.callback(point, Qt.MouseButton.LeftButton)

    def keyReleaseEvent(self, event):
        if event.key() == Qt.Key.Key_Escape and hasattr(self.callback, "__self__"):
            try:
                self.callback.__self__.cancel_placement(silent=False)
            except Exception:
                pass


class PhotoPreviewDialog(QDialog):
    """Vista previa escalable de fotografía con decisión de informe final."""
    PLACE = 1
    NEXT = 2
    CANCEL = 0

    def __init__(self, photo_path, allow_next=False, parent=None, detected_date=""):
        super().__init__(parent)
        self.photo_path = photo_path
        self.allow_next = allow_next
        self.detected_date = detected_date or ""
        self.action = self.CANCEL
        self._preview_pixmap = QPixmap(photo_path)
        self.setWindowTitle("Vista previa de fotografía")
        self.setModal(True)
        self.setSizeGripEnabled(True)
        self.setMinimumSize(520, 430)
        self.resize(760, 620)

        layout = QVBoxLayout(self)

        title = QLabel(os.path.basename(photo_path))
        title.setWordWrap(True)
        layout.addWidget(title)

        self.preview = QLabel()
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumSize(360, 220)
        self.preview.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        if self._preview_pixmap.isNull():
            self.preview.setText("No se pudo cargar la vista previa de la imagen.")
        layout.addWidget(self.preview, 1)
        self._update_preview_pixmap()

        self.chk_report = QCheckBox("Seleccionar para informe final")
        self.chk_report.setChecked(False)
        layout.addWidget(self.chk_report)

        date_text = self.detected_date if self.detected_date else "No detectada"
        self.lbl_date = QLabel(f"Fecha detectada: {date_text}")
        self.lbl_date.setWordWrap(True)
        layout.addWidget(self.lbl_date)
        self.chk_stamp_date = QCheckBox("La foto no tiene fecha visible: estampar fecha al exportar")
        self.chk_stamp_date.setChecked(not bool(self.detected_date))
        layout.addWidget(self.chk_stamp_date)

        row = QHBoxLayout()
        self.btn_place = QPushButton("Pinchar en lienzo")
        self.btn_place.clicked.connect(self._place)
        row.addWidget(self.btn_place)
        if allow_next:
            self.btn_next = QPushButton("Siguiente imagen")
            self.btn_next.clicked.connect(self._next)
            row.addWidget(self.btn_next)
        self.btn_cancel = QPushButton("Cancelar")
        self.btn_cancel.clicked.connect(self.reject)
        row.addWidget(self.btn_cancel)
        layout.addLayout(row)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_preview_pixmap()

    def _update_preview_pixmap(self):
        if self._preview_pixmap.isNull():
            return
        target = self.preview.contentsRect().size()
        if target.width() < 20 or target.height() < 20:
            return
        scaled = self._preview_pixmap.scaled(target, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        self.preview.setPixmap(scaled)

    def _place(self):
        self.action = self.PLACE
        self.accept()

    def _next(self):
        self.action = self.NEXT
        self.accept()

    def reject(self):
        self.action = self.CANCEL
        super().reject()


class AnejoPhotoPreviewDialog(QDialog):
    """Vista previa escalable de foto individual para puntos_informe con control opcional de fecha."""
    PLACE = 1
    GPS = 2
    CANCEL = 0

    def __init__(self, photo_path, parent=None, detected_date=""):
        super().__init__(parent)
        self.photo_path = photo_path
        self.detected_date = detected_date or ""
        self.action = self.CANCEL
        self._preview_pixmap = QPixmap(photo_path)
        self.setWindowTitle("Vista previa · foto para informe final")
        self.setModal(True)
        self.setSizeGripEnabled(True)
        self.setMinimumSize(560, 520)
        self.resize(820, 700)

        layout = QVBoxLayout(self)

        title = QLabel(os.path.basename(photo_path))
        title.setWordWrap(True)
        layout.addWidget(title)

        self.preview = QLabel()
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumSize(380, 240)
        self.preview.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        if self._preview_pixmap.isNull():
            self.preview.setText("No se pudo cargar la vista previa de la imagen.")
        layout.addWidget(self.preview, 1)
        self._update_preview_pixmap()

        date_text = self.detected_date if self.detected_date else "No detectada"
        self.lbl_date = QLabel(f"Fecha detectada: {date_text}")
        self.lbl_date.setWordWrap(True)
        layout.addWidget(self.lbl_date)

        self.chk_stamp_date = QCheckBox("Estampar fecha en la fotografía exportada")
        self.chk_stamp_date.setChecked(False)
        layout.addWidget(self.chk_stamp_date)

        self.txt_date = QLineEdit()
        self.txt_date.setPlaceholderText("DD/MM/AAAA HH:MM")
        self.txt_date.setText(self.detected_date)
        self.txt_date.setEnabled(False)
        layout.addWidget(self.txt_date)
        self.chk_stamp_date.toggled.connect(self.txt_date.setEnabled)

        note = QLabel("Activa la casilla solo si quieres que la fecha se imprima visualmente sobre la foto exportada. Si la foto no tiene fecha, puedes escribirla aquí.")
        note.setWordWrap(True)
        layout.addWidget(note)

        self.chk_add_desc = QCheckBox("Añadir descripción de la fotografía")
        self.chk_add_desc.setChecked(False)
        layout.addWidget(self.chk_add_desc)

        lbl_desc = QLabel("Descripción de la fotografía para el anejo:")
        layout.addWidget(lbl_desc)
        self.txt_desc = QTextEdit()
        self.txt_desc.setPlaceholderText("Descripción que aparecerá bajo la foto en el anejo fotográfico")
        self.txt_desc.setMinimumHeight(70)
        self.txt_desc.setEnabled(False)
        layout.addWidget(self.txt_desc)
        self.chk_add_desc.toggled.connect(self.txt_desc.setEnabled)

        row = QHBoxLayout()
        self.btn_place = QPushButton("Pinchar en lienzo")
        self.btn_place.clicked.connect(self._place)
        row.addWidget(self.btn_place)
        self.btn_gps = QPushButton("Insertar por coordenadas EXIF")
        self.btn_gps.clicked.connect(self._gps)
        row.addWidget(self.btn_gps)
        self.btn_cancel = QPushButton("Cancelar")
        self.btn_cancel.clicked.connect(self.reject)
        row.addWidget(self.btn_cancel)
        layout.addLayout(row)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_preview_pixmap()

    def _update_preview_pixmap(self):
        if self._preview_pixmap.isNull():
            return
        target = self.preview.contentsRect().size()
        if target.width() < 20 or target.height() < 20:
            return
        scaled = self._preview_pixmap.scaled(target, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        self.preview.setPixmap(scaled)

    def selected_date(self):
        return " ".join(str(self.txt_date.text() or "").strip().split())

    def selected_desc(self):
        if not bool(self.chk_add_desc.isChecked()):
            return ""
        return str(self.txt_desc.toPlainText() or "").strip()

    def stamp_date(self):
        return bool(self.chk_stamp_date.isChecked())

    def _place(self):
        self.action = self.PLACE
        self.accept()

    def _gps(self):
        self.action = self.GPS
        self.accept()

    def reject(self):
        self.action = self.CANCEL
        super().reject()


class FotosTab(QWidget):
    def __init__(self, iface, status_callback=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.status_callback = status_callback or (lambda text: None)
        self.gpkgs = OrderedDict()
        self.pending_manual = []
        self.manual_index = 0
        self.manual_folder_mode = False
        self.current_manual_meta = None
        self.current_anejo_meta = None
        self.pending_anejo = []
        self.anejo_index = 0
        self.map_tool = None
        self.previous_tool = None
        self.placement_mode = None
        self._layer_counters = {}
        self._build_ui()
        self.refresh_loaded_gpkgs()
        self._apply_anejo_style_if_exists()
        self._apply_anejo_pre_style_if_exists()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        layout = QVBoxLayout(self)

        intro = QLabel(
            "Pestaña Fotos reestructurada: exportación de fotos asociadas a ámbitos, "
            "georreferenciación manual de fotografías y generación de anejo fotográfico."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        # 1. Exportación de fotos asociadas a capas del GeoPackage cargado
        g1 = QGroupBox("1 · Fotos asociadas a ámbitos del GeoPackage cargado")
        l1 = QVBoxLayout(g1)
        help1 = QLabel(
            "Detecta GeoPackage cargados en el lienzo, lee campos de imagen en capas Puntos/Líneas/Polígonos "
            "y exporta copias JPG con coordenadas del centroide del elemento asociado."
        )
        help1.setWordWrap(True)
        l1.addWidget(help1)

        row_refresh = QHBoxLayout()
        self.btn_refresh = QPushButton("Actualizar lista")
        self.btn_refresh.clicked.connect(self.refresh_loaded_gpkgs)
        self.btn_select_all = QPushButton("Seleccionar todos")
        self.btn_select_all.clicked.connect(lambda: self._set_all_checked(Qt.CheckState.Checked))
        self.btn_unselect_all = QPushButton("Deseleccionar todos")
        self.btn_unselect_all.clicked.connect(lambda: self._set_all_checked(Qt.CheckState.Unchecked))
        row_refresh.addWidget(self.btn_refresh)
        row_refresh.addWidget(self.btn_select_all)
        row_refresh.addWidget(self.btn_unselect_all)
        row_refresh.addStretch()
        l1.addLayout(row_refresh)

        self.tree = QTreeWidget()
        self.tree.setColumnCount(4)
        self.tree.setHeaderLabels(["Usar", "GeoPackage", "Capas origen", "Estado"])
        self.tree.setRootIsDecorated(False)
        l1.addWidget(self.tree)

        cfg1 = QHBoxLayout()
        self.chk_selected_only = QCheckBox("Solo entidades seleccionadas")
        self.chk_selected_only.setChecked(True)
        self.chk_write_exif = QCheckBox("Intentar escribir coordenadas GPS EXIF en JPG")
        self.chk_write_exif.setChecked(True)
        cfg1.addWidget(self.chk_selected_only)
        cfg1.addWidget(self.chk_write_exif)
        cfg1.addStretch()
        l1.addLayout(cfg1)

        row_export_amb = QHBoxLayout()
        self.btn_export_ambitos = QPushButton("Georref fotos ámbitos")
        self.btn_export_ambitos.setObjectName("run_btn")
        self.btn_export_ambitos.clicked.connect(self.export_ambito_photos)
        row_export_amb.addStretch()
        row_export_amb.addWidget(self.btn_export_ambitos)
        l1.addLayout(row_export_amb)
        layout.addWidget(g1)

        # 2. Georreferenciación manual avanzada
        g2 = QGroupBox("2 · Georreferenciación manual avanzada")
        l2 = QVBoxLayout(g2)
        help2 = QLabel(
            "Permite georreferenciar fotografías con vista previa escalable y redimensionable. "
            "Puedes seleccionar una foto individual o una carpeta completa. Para cada imagen se decide si se coloca, "
            "si se pasa a la siguiente y si debe entrar en el informe final. Si se marca para informe final, además de fotos_georref se añade a puntos_informes_pre para revisión previa. Si la foto no tiene fecha visible, se pide la fecha para estamparla al exportar. Solo en informe final se solicita descripción."
        )
        help2.setWordWrap(True)
        l2.addWidget(help2)
        self.list_manual = QListWidget()
        self.list_manual.setMaximumHeight(100)
        self.list_manual.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        l2.addWidget(self.list_manual)

        row2list = QHBoxLayout()
        self.btn_manual_remove = QPushButton("Eliminar seleccionadas de la cola")
        self.btn_manual_remove.clicked.connect(self.remove_selected_manual_photos)
        self.btn_manual_start = QPushButton("Iniciar / continuar colocación")
        self.btn_manual_start.clicked.connect(self.start_manual_folder_preview)
        row2list.addWidget(self.btn_manual_remove)
        row2list.addWidget(self.btn_manual_start)
        row2list.addStretch()
        l2.addLayout(row2list)

        row2a = QHBoxLayout()
        self.btn_manual_single = QPushButton("Seleccionar foto individual")
        self.btn_manual_single.clicked.connect(self.select_manual_single_with_preview)
        self.btn_manual_folder = QPushButton("Seleccionar carpeta")
        self.btn_manual_folder.clicked.connect(self.select_manual_folder_with_preview)
        self.btn_manual_cancel = QPushButton("Cancelar")
        self.btn_manual_cancel.clicked.connect(self.cancel_placement)
        self.btn_manual_export = QPushButton("Exportar imágenes georref")
        self.btn_manual_export.clicked.connect(lambda: self.export_layer_photos(self._find_layer(LAYER_MANUAL), "fotos_georref"))
        row2a.addWidget(self.btn_manual_single)
        row2a.addWidget(self.btn_manual_folder)
        row2a.addWidget(self.btn_manual_cancel)
        row2a.addStretch()
        row2a.addWidget(self.btn_manual_export)
        l2.addLayout(row2a)
        self.lbl_manual_status = QLabel("Estado: capa fotos_georref no creada.")
        l2.addWidget(self.lbl_manual_status)
        self.lbl_pre_status = QLabel("Estado: capa puntos_informes_pre no creada.")
        l2.addWidget(self.lbl_pre_status)
        layout.addWidget(g2)

        # 3. Anejo fotográfico
        g3 = QGroupBox("3 · Anejo fotográfico / puntos_informe")
        l3 = QVBoxLayout(g3)
        help3 = QLabel(
            "Flujo de Anejo Fotográfico: selecciona fotos IF desde carpeta de forma recursiva o una foto individual, "
            "crea automáticamente la capa puntos_informe al seleccionar fotos, mantiene la simbología corporativa "
            "tipo etiqueta Foto: Nº y exporta DOCX con plano(s) general(es) de ubicación "
            "antes de las fotografías individuales. Los planos vacíos se descartan. También puedes importar "
            "fotos ya cargadas como atributo en una capa del proyecto (p. ej. un shapefile) a partir de las "
            "entidades que selecciones directamente en el lienzo."
        )
        help3.setWordWrap(True)
        l3.addWidget(help3)
        self.list_anejo = QListWidget()
        self.list_anejo.setMaximumHeight(100)
        l3.addWidget(self.list_anejo)
        row3a = QHBoxLayout()
        self.btn_anejo_folder = QPushButton("Seleccionar fotos desde carpeta")
        self.btn_anejo_folder.clicked.connect(lambda: self.select_anejo_photos_from_folder())
        self.btn_anejo_single = QPushButton("Seleccionar foto individual")
        self.btn_anejo_single.clicked.connect(self.select_anejo_single_photo)
        self.btn_anejo_cancel = QPushButton("Cancelar")
        self.btn_anejo_cancel.clicked.connect(self.cancel_placement)
        row3a.addWidget(self.btn_anejo_folder)
        row3a.addWidget(self.btn_anejo_single)
        row3a.addWidget(self.btn_anejo_cancel)
        l3.addLayout(row3a)
        row3a2 = QHBoxLayout()
        self.btn_anejo_from_selection = QPushButton("Importar fotos desde selección en el lienzo")
        self.btn_anejo_from_selection.setToolTip(
            "Usa como origen la capa activa en el lienzo (p. ej. un shapefile ya cargado con un campo de "
            "foto): selecciona antes en esa capa las entidades con fotos a incorporar y pulsa este botón "
            "para añadirlas a puntos_informe en la ubicación de cada entidad, sin pinchar en el lienzo."
        )
        self.btn_anejo_from_selection.clicked.connect(self.import_anejo_photos_from_selection)
        row3a2.addWidget(self.btn_anejo_from_selection)
        row3a2.addStretch()
        l3.addLayout(row3a2)
        row3b = QHBoxLayout()
        self.btn_anejo_docx = QPushButton("Exportar tabla DOCX")
        self.btn_anejo_docx.setObjectName("run_btn")
        self.btn_anejo_docx.clicked.connect(self.export_docx)
        self.btn_anejo_folder_export = QPushButton("Exportar fotos a carpeta")
        self.btn_anejo_folder_export.clicked.connect(lambda: self.export_layer_photos(self._find_layer(LAYER_ANEJO), "puntos_informe"))
        row3b.addStretch()
        row3b.addWidget(self.btn_anejo_folder_export)
        row3b.addWidget(self.btn_anejo_docx)
        l3.addLayout(row3b)

        row3c = QHBoxLayout()
        self.btn_pair_renumber = QPushButton("⇄  Agrupar IF por ubicación y renumerar")
        self.btn_pair_renumber.setToolTip(
            "Agrupa las fotos marcadas como Informe Final en parejas por proximidad geográfica "
            "y las renumera correlativamente. Dentro de cada pareja, el número impar corresponde "
            "siempre a la foto más antigua."
        )
        self.btn_pair_renumber.clicked.connect(self._pair_and_renumber_informe_final)
        row3c.addStretch()
        row3c.addWidget(self.btn_pair_renumber)
        l3.addLayout(row3c)
        self.lbl_anejo_status = QLabel("Estado: capa puntos_informe no creada.")
        l3.addWidget(self.lbl_anejo_status)
        layout.addWidget(g3)
        layout.addStretch()

    # ------------------------------------------------------------------ GeoPackage discovery
    def refresh_loaded_gpkgs(self):
        self.tree.clear()
        self.gpkgs = self._find_loaded_gpkgs()
        if not self.gpkgs:
            self.status_callback("⚠ Fotos: no hay GeoPackage cargados en el lienzo.")
            self._refresh_status_labels()
            return
        for gpkg_path, info in self.gpkgs.items():
            op_layers = info.get("operational_layers", [])
            state = "OK" if op_layers else "Sin capas Puntos/Líneas/Polígonos"
            item = QTreeWidgetItem(["", os.path.basename(gpkg_path), str(len(op_layers)), state])
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(0, Qt.CheckState.Checked if op_layers else Qt.CheckState.Unchecked)
            item.setData(0, Qt.ItemDataRole.UserRole, gpkg_path)
            self.tree.addTopLevelItem(item)
        for i in range(self.tree.columnCount()):
            self.tree.resizeColumnToContents(i)
        self.status_callback(f"ℹ Fotos: {len(self.gpkgs)} GeoPackage cargados detectados.")
        self._refresh_status_labels()

    def _find_loaded_gpkgs(self):
        gpkgs = OrderedDict()
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() != QgsMapLayer.VectorLayer or not layer.isValid():
                continue
            source = layer.source() or ""
            if ".gpkg" not in source.lower():
                continue
            gpkg_path = source.split("|")[0]
            if not gpkg_path.lower().endswith(".gpkg"):
                continue
            if gpkg_path not in gpkgs:
                gpkgs[gpkg_path] = {"layers": [], "operational_layers": []}
            gpkgs[gpkg_path]["layers"].append(layer)
            if self._is_operational_layer(layer):
                gpkgs[gpkg_path]["operational_layers"].append(layer)
        return gpkgs

    def _is_operational_layer(self, layer):
        name = layer.name().lower().replace("í", "i")
        return any(name.endswith(s.replace("í", "i")) or name == s.replace("_", "") for s in OP_SUFFIXES)

    def _selected_gpkg_paths(self):
        paths = []
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if item.checkState(0) == Qt.CheckState.Checked:
                paths.append(item.data(0, Qt.ItemDataRole.UserRole))
        return paths

    def _set_all_checked(self, state):
        for i in range(self.tree.topLevelItemCount()):
            self.tree.topLevelItem(i).setCheckState(0, state)

    def _primary_gpkg_path(self):
        paths = self._selected_gpkg_paths() or list(self.gpkgs.keys())
        return paths[0] if paths else None

    # ------------------------------------------------------------------ Block 1: export ambitos photos
    def export_ambito_photos(self):
        paths = self._selected_gpkg_paths()
        if not paths:
            QMessageBox.warning(self, "Fotos", "Selecciona al menos un GeoPackage cargado.")
            return
        out_dir = QFileDialog.getExistingDirectory(self, "Carpeta para guardar fotos georreferenciadas", "")
        if not out_dir:
            return
        only_selected = self.chk_selected_only.isChecked()
        rows, errors = [], []
        for gpkg_path in paths:
            for layer in self.gpkgs.get(gpkg_path, {}).get("operational_layers", []):
                iterator = layer.getSelectedFeatures() if only_selected else layer.getFeatures()
                if only_selected and not layer.selectedFeatureIds():
                    continue
                for src_feat in iterator:
                    geom = src_feat.geometry()
                    centroid = self._safe_centroid(geom) if geom else None
                    if centroid is None:
                        continue
                    pt = centroid.asPoint()
                    lon, lat = self._to_lonlat(layer.crs(), pt.x(), pt.y())
                    photos = self._photo_paths(src_feat, layer, gpkg_path)
                    for photo in photos:
                        if not os.path.exists(photo):
                            errors.append(f"No existe imagen: {photo}")
                            continue
                        # Nombre de exportación corto: solo prefijo FR + nombre original.
                        out_name = self._prefixed_original_name(photo, "FR", out_dir)
                        dst = os.path.join(out_dir, out_name)
                        shutil.copy2(photo, dst)
                        exif_ok = self._write_gps_exif_optional(dst, lon, lat) if self.chk_write_exif.isChecked() else False
                        rows.append({
                            "archivo": out_name, "origen": photo, "gpkg": gpkg_path, "capa": layer.name(), "fid": src_feat.id(),
                            "codigo": self._attr(src_feat, layer, CODE_FIELDS), "ambito": self._attr(src_feat, layer, AMBITO_FIELDS),
                            "tipo": self._attr(src_feat, layer, TIPO_FIELDS), "descripcion": self._attr(src_feat, layer, DESC_FIELDS),
                            "x": pt.x(), "y": pt.y(), "lon": lon, "lat": lat, "exif_gps": "SI" if exif_ok else "NO"
                        })
        self._write_manifest(out_dir, rows)
        msg = f"Fotos exportadas: {len(rows)}\nCarpeta: {out_dir}\nSe ha creado manifest_fotos.csv."
        if errors:
            msg += "\n\nAvisos:\n" + "\n".join(errors[:15])
        QMessageBox.information(self, "Georref fotos ámbitos", msg)
        self.status_callback(f"✔ Georref fotos ámbitos: {len(rows)} fotos exportadas.")

    # ------------------------------------------------------------------ Blocks 2/3: placement
    def insert_manual_photo_direct(self):
        """Compatibilidad: redirige al nuevo flujo de foto individual con vista previa."""
        self.select_manual_single_with_preview()

    def select_manual_single_with_preview(self):
        """Sección 2: selecciona una imagen, muestra vista previa y prepara el clic en canvas."""
        photo = self._select_single_image_file()
        if not photo:
            return
        self.pending_manual = [photo]
        self.manual_index = 0
        self.manual_folder_mode = False
        self._fill_list(self.list_manual, self.pending_manual, 0)
        self._preview_current_manual_photo(allow_next=False)

    def select_manual_folder_with_preview(self):
        """Sección 2: selecciona carpeta y recorre imágenes con vista previa, colocar o siguiente."""
        files = self._select_image_files_from_folder()
        if not files:
            return
        self.pending_manual = files
        self.manual_index = 0
        self.manual_folder_mode = True
        self._fill_list(self.list_manual, self.pending_manual, 0)
        self.status_callback(f"ℹ Georref Fotos: {len(files)} fotografía(s) detectada(s) en la carpeta. Revisa la lista y elimina las descartadas antes de iniciar.")
        self.iface.messageBar().pushMessage(
            "Georref Fotos",
            "Carpeta cargada. Selecciona en la lista las imágenes que quieras descartar y pulsa 'Eliminar seleccionadas de la cola'. Después inicia la colocación.",
            level=Qgis.MessageLevel.Info,
            duration=7,
        )


    def start_manual_folder_preview(self):
        """Inicia o continúa el recorrido de la cola manual tras revisar/eliminar fotos."""
        if not self.pending_manual:
            QMessageBox.warning(self, "Georref Fotos", "No hay fotografías cargadas en la cola.")
            return
        if self.manual_index >= len(self.pending_manual):
            QMessageBox.information(self, "Georref Fotos", "No quedan más fotografías pendientes en la cola.")
            return
        self._preview_current_manual_photo(allow_next=self.manual_folder_mode)

    def remove_selected_manual_photos(self):
        """Elimina de la cola las imágenes seleccionadas antes de su inserción en el lienzo."""
        if not self.pending_manual:
            QMessageBox.information(self, "Georref Fotos", "No hay fotografías cargadas en la cola.")
            return

        selected_rows = sorted({idx.row() for idx in self.list_manual.selectedIndexes()}, reverse=True)
        if not selected_rows:
            row = self.list_manual.currentRow()
            if row >= 0:
                selected_rows = [row]

        if not selected_rows:
            QMessageBox.information(self, "Georref Fotos", "Selecciona una o varias fotografías de la lista para eliminarlas de la cola.")
            return

        locked_rows = [r for r in selected_rows if r < self.manual_index]
        rows_to_remove = [r for r in selected_rows if r >= self.manual_index and r < len(self.pending_manual)]

        if locked_rows and not rows_to_remove:
            QMessageBox.warning(
                self,
                "Georref Fotos",
                "Las fotografías ya colocadas no se eliminan desde la cola. Si necesitas quitarlas de la exportación, elimina su punto de la capa fotos_georref.",
            )
            return

        if not rows_to_remove:
            return

        names = [os.path.basename(self.pending_manual[r]) for r in sorted(rows_to_remove)]
        reply = QMessageBox.question(
            self,
            "Eliminar fotografías de la cola",
            "Se eliminarán de la cola y no se georreferenciarán/exportarán estas fotografías:\n\n"
            + "\n".join(names[:20])
            + ("\n..." if len(names) > 20 else ""),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        removing_current = self.manual_index in rows_to_remove
        for r in rows_to_remove:
            del self.pending_manual[r]

        if self.manual_index > len(self.pending_manual):
            self.manual_index = len(self.pending_manual)
        if removing_current:
            self.current_manual_meta = None
            self.cancel_placement(silent=True)

        self._fill_list(self.list_manual, self.pending_manual, self.manual_index)
        remaining = max(0, len(self.pending_manual) - self.manual_index)
        self.status_callback(f"ℹ Georref Fotos: {len(rows_to_remove)} fotografía(s) eliminada(s) de la cola. Pendientes: {remaining}.")
        if locked_rows:
            QMessageBox.information(
                self,
                "Georref Fotos",
                "Se han eliminado solo las fotografías pendientes. Las ya colocadas se mantienen en la capa fotos_georref.",
            )

    def select_manual_photos(self, from_folder=False):
        """Compatibilidad con llamadas antiguas."""
        if from_folder:
            self.select_manual_folder_with_preview()
        else:
            self.select_manual_single_with_preview()

    def select_anejo_photos_from_folder(self):
        files = self._select_image_files_from_folder(if_prefix_only=True, recursive=True)
        if files:
            self.pending_anejo = files
            self.anejo_index = 0
            self._fill_list(self.list_anejo, files, 0)
            self.status_callback(f"ℹ Anejo fotográfico: {len(files)} fotografía(s) IF detectada(s) recursivamente.")
            self.start_placement("anejo")

    def select_anejo_single_photo(self):
        photo = self._select_single_image_file()
        if not photo:
            return
        self.pending_anejo = [photo]
        self.anejo_index = 0
        self._fill_list(self.list_anejo, self.pending_anejo, 0)

        detected_date = self._photo_date_for_display(photo)
        dlg = AnejoPhotoPreviewDialog(photo, parent=self, detected_date=detected_date)
        dlg.exec()
        if dlg.action == AnejoPhotoPreviewDialog.CANCEL:
            return

        estampar_fecha = bool(dlg.stamp_date())
        fecha_foto = ""
        if estampar_fecha:
            fecha_foto = self._normalize_photo_date(dlg.selected_date())
            if not fecha_foto:
                QMessageBox.warning(
                    self,
                    "Fecha no válida",
                    "Para estampar la fecha debes indicar un valor con formato DD/MM/AAAA HH:MM. Ejemplo: 10/12/2025 11:10",
                )
                return
        elif detected_date:
            # Se conserva la fecha como metadato, pero no se estampa visualmente si no se marca la casilla.
            fecha_foto = detected_date

        self.current_anejo_meta = {
            "photo": photo,
            "fecha_foto": fecha_foto,
            "estampar_fecha": estampar_fecha,
            "descripcion": dlg.selected_desc(),
        }
        if dlg.action == AnejoPhotoPreviewDialog.PLACE:
            self.start_placement("anejo")
            return
        if dlg.action == AnejoPhotoPreviewDialog.GPS:
            self._insert_anejo_photo_at_own_coordinates(photo)

    def import_anejo_photos_from_selection(self):
        """Anejo fotográfico: importa fotos ya cargadas como atributo en una capa vectorial
        (p. ej. un shapefile) usando las entidades que el usuario ha seleccionado directamente
        en el lienzo sobre la capa activa. Cada foto encontrada se añade a puntos_informe en la
        ubicación (centroide) de la entidad de origen, sin necesidad de pinchar en el lienzo."""
        src_layer = self.iface.activeLayer()
        if src_layer is None or src_layer.type() != QgsMapLayer.VectorLayer or not src_layer.isValid():
            QMessageBox.warning(
                self,
                "Anejo fotográfico",
                "Activa en el lienzo la capa (shapefile, GeoPackage, etc.) que contiene las fotos "
                "y selecciona en ella las entidades a importar.",
            )
            return
        if src_layer.name() in (LAYER_ANEJO, LAYER_ANEJO_PRE, LAYER_MANUAL):
            QMessageBox.warning(
                self,
                "Anejo fotográfico",
                "Selecciona como capa activa la capa origen de las fotos, no puntos_informe.",
            )
            return
        feats = list(src_layer.getSelectedFeatures())
        if not feats:
            QMessageBox.warning(
                self,
                "Anejo fotográfico",
                "No hay entidades seleccionadas en el lienzo. Selecciona en la capa activa las "
                "entidades que tengan fotos a importar.",
            )
            return

        anejo_layer = self.ensure_point_layer(LAYER_ANEJO, save_to_gpkg=False)
        if anejo_layer is None or not anejo_layer.isValid():
            QMessageBox.critical(self, "Anejo fotográfico", "No se pudo crear/activar la capa puntos_informe.")
            return

        src_path = (src_layer.source() or "").split("|")[0]
        transform = None
        if src_layer.crs() != anejo_layer.crs():
            try:
                transform = QgsCoordinateTransform(src_layer.crs(), anejo_layer.crs(), QgsProject.instance())
            except Exception:
                transform = None

        added = 0
        skipped_no_photo = 0
        missing = []
        for feat in feats:
            geom = feat.geometry()
            centroid = self._safe_centroid(geom) if geom else None
            if centroid is None:
                continue
            pt = centroid.asPoint()
            if transform is not None:
                try:
                    pt = transform.transform(QgsPointXY(pt))
                except Exception:
                    pass
            photos = self._photo_paths(feat, src_layer, src_path)
            if not photos:
                skipped_no_photo += 1
                continue
            for photo in photos:
                if not os.path.exists(photo):
                    missing.append(photo)
                    continue
                date_meta = self._ensure_anejo_photo_date(photo)
                if date_meta is None:
                    continue
                fecha_foto, estampar_fecha = date_meta
                anejo_layer, _num = self._add_photo_feature_to_layer(
                    anejo_layer, photo, QgsPointXY(pt), report=True, desc="",
                    fecha_foto=fecha_foto, estampar_fecha=estampar_fecha,
                )
                if anejo_layer is None:
                    return
                added += 1

        self._refresh_status_labels()
        msg = f"Fotos importadas a puntos_informe: {added}."
        if skipped_no_photo:
            msg += f"\nEntidades seleccionadas sin foto detectada: {skipped_no_photo}."
        if missing:
            msg += "\n\nAvisos (ruta de imagen no encontrada):\n" + "\n".join(missing[:15])
        QMessageBox.information(self, "Anejo fotográfico", msg)
        self.status_callback(f"✔ Anejo fotográfico: {added} foto(s) importadas desde selección del lienzo.")

    def _ensure_anejo_photo_date(self, photo_path):
        """Devuelve ``(fecha_foto, estampar_fecha)`` o ``None`` si se cancela.

        Contrato único para los puntos del anejo: si hay fecha legible en EXIF,
        nombre de fichero u OCR visible se conserva como metadato y no se
        reestampa; si no hay fecha, se pide al usuario y se marca para
        estamparla al exportar.
        """
        detected_date = self._photo_date_for_display(photo_path)
        if detected_date:
            return (detected_date, False)
        fecha_foto = self._normalize_photo_date(self._ask_photo_date(photo_path, default_value=""))
        if not fecha_foto:
            return None
        return (fecha_foto, True)

    def _preview_current_manual_photo(self, allow_next=False):
        """Muestra la imagen actual. Si se acepta, pide clic; si se pasa, avanza."""
        if self.manual_index >= len(self.pending_manual):
            self.cancel_placement(silent=True)
            self.iface.messageBar().pushMessage("Fotos", "No quedan más imágenes pendientes.", level=Qgis.MessageLevel.Info, duration=4)
            return
        photo = self.pending_manual[self.manual_index]
        detected_date = self._photo_date_for_display(photo)
        dlg = PhotoPreviewDialog(photo, allow_next=allow_next, parent=self, detected_date=detected_date)
        dlg.exec()
        if dlg.action == PhotoPreviewDialog.CANCEL:
            self.cancel_placement(silent=False)
            return
        if dlg.action == PhotoPreviewDialog.NEXT:
            self.manual_index += 1
            self._fill_list(self.list_manual, self.pending_manual, self.manual_index)
            self._preview_current_manual_photo(allow_next=allow_next)
            return

        needs_stamp_date = bool(dlg.chk_stamp_date.isChecked())
        fecha_foto = detected_date or ""
        if needs_stamp_date:
            fecha_foto = self._ask_photo_date(photo, default_value=fecha_foto)
            if not fecha_foto:
                return
        report = bool(dlg.chk_report.isChecked())
        desc = ""
        if report:
            desc, ok = QInputDialog.getMultiLineText(
                self,
                "Descripción para informe final",
                "Descripción de la fotografía:",
                ""
            )
            if not ok:
                return
            desc = (desc or "").strip()
        self.current_manual_meta = {
            "photo": photo,
            "informe_final": report,
            "descripcion": desc,
            "fecha_foto": fecha_foto,
            "estampar_fecha": needs_stamp_date,
        }
        # No se guarda todavía en GeoPackage: la vista previa solo prepara la imagen.
        # La capa se crea/valida de forma ligera y se persiste al insertar el primer punto.
        layer = self.ensure_point_layer(LAYER_MANUAL, save_to_gpkg=False)
        if layer is None or not layer.isValid():
            QMessageBox.critical(self, "Georref Fotos", f"No se pudo crear/activar la capa {LAYER_MANUAL}.")
            return
        self.status_callback("ℹ Georref Fotos: imagen validada. Pendiente de pinchar punto en el lienzo.")
        self.start_placement("manual")

    def _select_single_image_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Seleccionar fotografía", "", "Imágenes (*.jpg *.jpeg *.png *.JPG *.JPEG *.PNG)"
        )
        return file_path or ""

    def _select_image_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Seleccionar fotografías", "", "Imágenes (*.jpg *.jpeg *.png *.JPG *.JPEG *.PNG)"
        )
        return list(files or [])

    def _select_image_files_from_folder(self, if_prefix_only=False, recursive=False):
        folder = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta de fotografías", "")
        if not folder:
            return []
        exts = (".jpg", ".jpeg", ".png")
        files = []
        if recursive:
            iterator = []
            for root, _dirs, names in os.walk(folder):
                for name in names:
                    iterator.append(os.path.join(root, name))
        else:
            iterator = [os.path.join(folder, f) for f in os.listdir(folder)]
        for path in sorted(iterator, key=lambda p: os.path.normcase(p)):
            name = os.path.basename(path)
            if not name.lower().endswith(exts):
                continue
            if if_prefix_only and not name.upper().startswith("IF"):
                continue
            files.append(path)
        if if_prefix_only and not files:
            QMessageBox.warning(
                self,
                "Anejo fotográfico",
                "No se han encontrado imágenes cuyo nombre empiece por IF en la carpeta ni en sus subcarpetas.",
            )
        return files

    def _insert_anejo_photo_at_own_coordinates(self, photo_path):
        lonlat = self._read_photo_gps_lonlat(photo_path)
        if lonlat is None:
            QMessageBox.warning(
                self,
                "Anejo fotográfico",
                "La fotografía no contiene coordenadas GPS EXIF válidas. Usa la opción de pinchar en el lienzo.",
            )
            return
        lon, lat = lonlat
        layer = self.ensure_point_layer(LAYER_ANEJO, save_to_gpkg=False)
        if layer is None or not layer.isValid():
            QMessageBox.critical(self, "Anejo fotográfico", "No se pudo crear/activar la capa puntos_informe.")
            return
        try:
            src = QgsCoordinateReferenceSystem("EPSG:4326")
            tr = QgsCoordinateTransform(src, layer.crs(), QgsProject.instance())
            pt = tr.transform(QgsPointXY(float(lon), float(lat)))
        except Exception:
            pt = QgsPointXY(float(lon), float(lat))
        desc = ""
        if self.current_anejo_meta and self.current_anejo_meta.get("photo") == photo_path:
            fecha_foto = self.current_anejo_meta.get("fecha_foto", "") or ""
            estampar_fecha = bool(self.current_anejo_meta.get("estampar_fecha", False))
            desc = self.current_anejo_meta.get("descripcion", "") or ""
        else:
            date_meta = self._ensure_anejo_photo_date(photo_path)
            if date_meta is None:
                return
            fecha_foto, estampar_fecha = date_meta
        layer, _num = self._add_photo_feature_to_layer(layer, photo_path, pt, report=True, desc=desc, fecha_foto=fecha_foto, estampar_fecha=estampar_fecha)
        if layer is None:
            return
        self.current_anejo_meta = None
        self.pending_anejo = []
        self.anejo_index = 0
        self._fill_list(self.list_anejo, [], 0)
        self._refresh_status_labels()
        self.iface.messageBar().pushMessage("Fotos", "Fotografía insertada en puntos_informe usando coordenadas GPS EXIF.", level=Qgis.MessageLevel.Success, duration=5)

    def _add_photo_feature_to_layer(self, layer, photo_path, point, report=False, desc="", fecha_foto="", estampar_fecha=False):
        num = self._next_number(layer)
        feat = QgsFeature(layer.fields())
        feat.setGeometry(QgsGeometry.fromPointXY(point))
        feat[FIELD_NUM] = num
        feat[FIELD_DESC] = desc or ""
        feat[FIELD_PATH] = photo_path
        field_names = [f.name() for f in layer.fields()]
        if FIELD_REPORT in field_names:
            feat[FIELD_REPORT] = 1 if report else 0
        if FIELD_DATE in field_names:
            feat[FIELD_DATE] = fecha_foto or ""
        if FIELD_STAMP_DATE in field_names:
            feat[FIELD_STAMP_DATE] = 1 if estampar_fecha else 0
        feat["x"] = float(point.x())
        feat["y"] = float(point.y())
        lon, lat = self._to_lonlat(layer.crs(), point.x(), point.y())
        feat["lon"] = lon
        feat["lat"] = lat
        was_editing = layer.isEditable()
        if not was_editing and not layer.startEditing():
            QMessageBox.critical(self, "Fotos", "No se pudo iniciar la edición de la capa de fotografías.")
            return None, None

        ok = layer.addFeature(feat)
        if not ok:
            # No hacer rollback si la capa ya estaba en edición: podríamos descartar
            # cambios previos del usuario o de otra herramienta.
            if not was_editing:
                layer.rollBack()
            QMessageBox.critical(self, "Fotos", "No se pudo añadir la fotografía a la capa.")
            return None, None

        if not was_editing:
            if not layer.commitChanges():
                errors = "; ".join(layer.commitErrors()) if hasattr(layer, "commitErrors") else ""
                try:
                    layer.rollBack()
                except Exception:
                    pass
                QMessageBox.critical(self, "Fotos", "No se pudieron guardar los cambios en la capa.\n" + errors)
                return None, None

        layer.updateExtents()
        layer.triggerRepaint()
        if layer.providerType() == "memory":
            saved_layer = self._try_save_layer_to_project_gpkg(layer, layer.name())
            if saved_layer is not None and saved_layer.isValid():
                layer = saved_layer
        self.iface.setActiveLayer(layer)
        return layer, num

    def _add_manual_report_pre_feature(self, photo_path, point, desc="", fecha_foto="", estampar_fecha=False):
        """Añade a puntos_informes_pre la foto marcada como informe final desde la georreferenciación avanzada."""
        pre_layer = self.ensure_point_layer(LAYER_ANEJO_PRE, save_to_gpkg=False)
        if pre_layer is None or not pre_layer.isValid():
            QMessageBox.warning(self, "Informe final preliminar", "No se pudo crear/activar la capa puntos_informes_pre.")
            return None
        saved_layer, num = self._add_photo_feature_to_layer(
            pre_layer,
            photo_path,
            QgsPointXY(point.x(), point.y()),
            report=True,
            desc=desc,
            fecha_foto=fecha_foto,
            estampar_fecha=estampar_fecha,
        )
        return saved_layer

    def start_placement(self, mode):
        pending = self.pending_manual if mode == "manual" else self.pending_anejo
        layer_name = LAYER_MANUAL if mode == "manual" else LAYER_ANEJO
        if not pending:
            QMessageBox.warning(self, "Fotos", "Primero selecciona fotografías.")
            return
        # Evitamos escribir en disco antes del clic: así no bloquea la previsualización
        # ni falla si OGR/QGIS tiene el GeoPackage abierto en modo actualización.
        layer = self.ensure_point_layer(layer_name, save_to_gpkg=False)
        if layer is None or not layer.isValid():
            QMessageBox.critical(self, "Fotos", f"No se pudo crear/activar la capa {layer_name}.")
            return
        self.cancel_placement(silent=True)
        self.previous_tool = self.canvas.mapTool()
        self.map_tool = PhotoPointMapTool(self.canvas, self._add_photo_point)
        self.placement_mode = mode
        self.canvas.setMapTool(self.map_tool)
        self.iface.messageBar().pushMessage("Fotos", "Haz clic en el lienzo para colocar la fotografía actual. ESC cancela.", level=Qgis.MessageLevel.Info, duration=5)

    def cancel_placement(self, silent=False):
        if self.map_tool:
            try:
                self.map_tool.canvasClicked.disconnect(self._add_photo_point)
            except Exception:
                pass
        if self.previous_tool:
            self.canvas.setMapTool(self.previous_tool)
        self.map_tool = None
        self.previous_tool = None
        self.placement_mode = None
        if not silent:
            self.iface.messageBar().pushMessage("Fotos", "Colocación cancelada.", level=Qgis.MessageLevel.Warning, duration=3)

    def _add_photo_point(self, point, button):
        if button != Qt.MouseButton.LeftButton or self.placement_mode not in ("manual", "anejo"):
            return
        if self.placement_mode == "manual":
            pending, idx, layer_name = self.pending_manual, self.manual_index, LAYER_MANUAL
        else:
            pending, idx, layer_name = self.pending_anejo, self.anejo_index, LAYER_ANEJO
        if idx >= len(pending):
            self.cancel_placement(silent=True)
            return
        layer = self.ensure_point_layer(layer_name, save_to_gpkg=False)
        photo_path = pending[idx]
        report = self.placement_mode == "anejo"
        desc = ""
        fecha_foto = ""
        estampar_fecha = False
        if self.placement_mode == "manual" and self.current_manual_meta:
            photo_path = self.current_manual_meta.get("photo", photo_path)
            report = bool(self.current_manual_meta.get("informe_final", False))
            desc = self.current_manual_meta.get("descripcion", "") or ""
            fecha_foto = self.current_manual_meta.get("fecha_foto", "") or ""
            estampar_fecha = bool(self.current_manual_meta.get("estampar_fecha", False))
        elif self.placement_mode == "anejo":
            if self.current_anejo_meta and self.current_anejo_meta.get("photo") == photo_path:
                fecha_foto = self.current_anejo_meta.get("fecha_foto", "") or ""
                estampar_fecha = bool(self.current_anejo_meta.get("estampar_fecha", False))
                desc = self.current_anejo_meta.get("descripcion", "") or ""
            else:
                date_meta = self._ensure_anejo_photo_date(photo_path)
                if date_meta is None:
                    return
                fecha_foto, estampar_fecha = date_meta
        layer, num = self._add_photo_feature_to_layer(layer, photo_path, point, report=report, desc=desc, fecha_foto=fecha_foto, estampar_fecha=estampar_fecha)
        if layer is None:
            return
        if self.placement_mode == "manual" and report:
            self._add_manual_report_pre_feature(photo_path, point, desc=desc, fecha_foto=fecha_foto, estampar_fecha=estampar_fecha)
        if self.placement_mode == "manual":
            self.manual_index += 1
            self.current_manual_meta = None
            self._fill_list(self.list_manual, self.pending_manual, self.manual_index)
            remaining = len(self.pending_manual) - self.manual_index
            self._refresh_status_labels()
            self.cancel_placement(silent=True)
            if remaining <= 0:
                self.iface.messageBar().pushMessage("Fotos", f"Todas las fotografías colocadas en {layer_name}.", level=Qgis.MessageLevel.Success, duration=5)
            else:
                self.iface.messageBar().pushMessage("Fotos", f"Foto {num} insertada. Quedan {remaining}.", level=Qgis.MessageLevel.Success, duration=3)
                if self.manual_folder_mode:
                    self._preview_current_manual_photo(allow_next=True)
            return
        self.anejo_index += 1
        self.current_anejo_meta = None
        self._fill_list(self.list_anejo, self.pending_anejo, self.anejo_index)
        remaining = len(self.pending_anejo) - self.anejo_index
        self._refresh_status_labels()
        if remaining <= 0:
            self.cancel_placement(silent=True)
            self.iface.messageBar().pushMessage("Fotos", f"Todas las fotografías se han colocado en {layer_name}.", level=Qgis.MessageLevel.Success, duration=5)
        else:
            self.iface.messageBar().pushMessage("Fotos", f"Foto {num} insertada. Quedan {remaining}.", level=Qgis.MessageLevel.Success, duration=3)

    def ensure_point_layer(self, layer_name, save_to_gpkg=False):
        layer = self._find_layer(layer_name)
        if layer is not None:
            self._ensure_photo_fields(layer)
            self._configure_photo_layer(layer)
            self._refresh_status_labels()
            return layer
        gpkg_path = self._project_photo_gpkg_path(layer_name) if save_to_gpkg else None
        crs = QgsProject.instance().crs() if QgsProject.instance().crs().isValid() else QgsCoordinateReferenceSystem("EPSG:25830")
        uri = f"Point?crs={crs.authid()}"
        layer = QgsVectorLayer(uri, layer_name, "memory")
        self._ensure_photo_fields(layer)
        self._configure_photo_layer(layer)
        QgsProject.instance().addMapLayer(layer)
        if gpkg_path:
            saved = self._try_save_layer_to_project_gpkg(layer, layer_name)
            if saved is not None and saved.isValid():
                layer = saved
        self.iface.setActiveLayer(layer)
        self._refresh_status_labels()
        return layer

    def _ensure_photo_fields(self, layer):
        existing = [f.name() for f in layer.fields()]
        to_add = []
        for name, qtype, length in [
            (FIELD_NUM, QVariant.Int, 0), (FIELD_DESC, QVariant.String, 254), (FIELD_PATH, QVariant.String, 1024),
            (FIELD_REPORT, QVariant.Int, 0),
            (FIELD_DATE, QVariant.String, 32), (FIELD_STAMP_DATE, QVariant.Int, 0),
            ("x", QVariant.Double, 0), ("y", QVariant.Double, 0), ("lon", QVariant.Double, 0), ("lat", QVariant.Double, 0),
        ]:
            if name not in existing:
                if length and qtype == QVariant.String:
                    field = QgsField(name, qtype, "", length)
                else:
                    field = QgsField(name, qtype)
                to_add.append(field)
        if to_add:
            layer.dataProvider().addAttributes(to_add)
            layer.updateFields()

    def _configure_photo_layer(self, layer):
        if layer.name() == LAYER_ANEJO:
            # puntos_informe debe conservar exactamente la simbología corporativa
            # proporcionada por el usuario. No se fuerza ningún etiquetado por código
            # después de cargar el QML para no sobrescribir el estilo.
            self._apply_anejo_style(layer)
        elif layer.name() == LAYER_ANEJO_PRE:
            # Capa previa de revisión: misma base que puntos_informe, pero con
            # etiqueta diferenciada mediante fondo amarillo.
            self._apply_anejo_pre_style(layer)
        else:
            try:
                symbol = QgsMarkerSymbol.createSimple({"name": "circle", "size": "4.5", "outline_width": "0.5"})
                layer.renderer().setSymbol(symbol)
            except Exception:
                pass
        try:
            idx = layer.fields().indexFromName(FIELD_PATH)
            if idx >= 0:
                layer.setEditorWidgetSetup(idx, QgsEditorWidgetSetup("ExternalResource", {
                    "DocumentViewer": 1, "DocumentViewerHeight": 260, "DocumentViewerWidth": 420,
                    "FileWidget": True, "RelativeStorage": 0, "StorageMode": 0,
                }))
        except Exception:
            pass
        layer.triggerRepaint()

    def _apply_anejo_style(self, layer):
        """Aplica el QML oficial de puntos_informe sin modificarlo después."""
        if layer is None or not layer.isValid() or layer.name() != LAYER_ANEJO:
            return False
        if not os.path.exists(STYLE_PATH):
            QgsMessageLog.logMessage(f"No se encontró el estilo puntos.qml en: {STYLE_PATH}", "OBRA_NUEVA", Qgis.MessageLevel.Warning)
            # Fallback mínimo solo si falta el QML empaquetado.
            try:
                symbol = QgsMarkerSymbol.createSimple({"name": "circle", "size": "2", "color": "231,113,72", "outline_width": "0"})
                layer.renderer().setSymbol(symbol)
            except Exception:
                pass
            return False
        try:
            result = layer.loadNamedStyle(STYLE_PATH)
            ok = result[0] if isinstance(result, tuple) else bool(result)
            msg = result[1] if isinstance(result, tuple) and len(result) > 1 else ""
            if not ok:
                QgsMessageLog.logMessage(f"No se pudo cargar puntos.qml: {msg}", "OBRA_NUEVA", Qgis.MessageLevel.Warning)
                return False
            layer.setLabelsEnabled(True)
            layer.triggerRepaint()
            try:
                self.iface.layerTreeView().refreshLayerSymbology(layer.id())
            except Exception:
                pass
            return True
        except Exception as exc:
            QgsMessageLog.logMessage(f"Error cargando puntos.qml: {exc}", "OBRA_NUEVA", Qgis.MessageLevel.Warning)
            return False

    def _apply_anejo_style_if_exists(self):
        layer = self._find_layer(LAYER_ANEJO)
        if layer is not None:
            self._ensure_photo_fields(layer)
            self._apply_anejo_style(layer)

    def _apply_anejo_pre_style_if_exists(self):
        layer = self._find_layer(LAYER_ANEJO_PRE)
        if layer is not None:
            self._ensure_photo_fields(layer)
            self._apply_anejo_pre_style(layer)

    def _apply_anejo_pre_style(self, layer):
        """Aplica estilo de revisión previa: base puntos.qml y etiqueta con fondo amarillo."""
        if layer is None or not layer.isValid() or layer.name() != LAYER_ANEJO_PRE:
            return False
        if os.path.exists(STYLE_PATH):
            try:
                layer.loadNamedStyle(STYLE_PATH)
            except Exception as exc:
                QgsMessageLog.logMessage(f"No se pudo cargar puntos.qml en {LAYER_ANEJO_PRE}: {exc}", "OBRA_NUEVA", Qgis.MessageLevel.Warning)
        else:
            try:
                symbol = QgsMarkerSymbol.createSimple({"name": "circle", "size": "2", "color": "231,113,72", "outline_width": "0"})
                layer.renderer().setSymbol(symbol)
            except Exception:
                pass
        try:
            labeling = layer.labeling()
            settings = labeling.settings() if labeling is not None and hasattr(labeling, "settings") else QgsPalLayerSettings()
        except Exception:
            settings = QgsPalLayerSettings()
        try:
            settings.fieldName = "concat('Foto: ', \"Nº\")"
            settings.isExpression = True
        except Exception:
            settings.fieldName = FIELD_NUM
        try:
            fmt = settings.format() if hasattr(settings, "format") else QgsTextFormat()
        except Exception:
            fmt = QgsTextFormat()
        try:
            if fmt.font().family() == "":
                fmt.setFont(QFont("Arial"))
            if fmt.size() <= 0:
                fmt.setSize(10)
            bg = QgsTextBackgroundSettings()
            bg.setEnabled(True)
            bg.setFillColor(QColor(255, 255, 0))
            try:
                bg.setStrokeColor(QColor(0, 0, 0))
            except Exception:
                pass
            try:
                bg.setSize(QSizeF(1.2, 0.8))
            except Exception:
                pass
            fmt.setBackground(bg)
            settings.setFormat(fmt)
            layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
            layer.setLabelsEnabled(True)
        except Exception as exc:
            QgsMessageLog.logMessage(f"No se pudo configurar etiqueta amarilla en {LAYER_ANEJO_PRE}: {exc}", "OBRA_NUEVA", Qgis.MessageLevel.Warning)
        layer.triggerRepaint()
        try:
            self.iface.layerTreeView().refreshLayerSymbology(layer.id())
        except Exception:
            pass
        return True

    def _try_save_layer_to_project_gpkg(self, layer, layer_name):
        """Guarda la capa en GPKG sin romper el flujo si OGR bloquea el archivo."""
        try:
            return self._save_layer_to_project_gpkg(layer, layer_name)
        except Exception as exc:
            QgsMessageLog.logMessage(
                f"No se pudo guardar {layer_name} en GeoPackage; se mantiene en memoria: {exc}",
                "OBRA_NUEVA",
                Qgis.MessageLevel.Warning,
            )
            self.iface.messageBar().pushMessage(
                "Fotos",
                f"La capa {layer_name} se ha creado en memoria, pero no se pudo guardar aún en GeoPackage. "
                "Guarda/exporta al finalizar o revisa que el GPKG no esté bloqueado.",
                level=Qgis.MessageLevel.Warning,
                duration=7,
            )
            return None

    def _save_layer_to_project_gpkg(self, layer, layer_name):
        gpkg = self._project_photo_gpkg_path(layer_name)
        if not gpkg:
            return None
        folder = os.path.dirname(gpkg)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder, exist_ok=True)

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = layer_name
        options.fileEncoding = "UTF-8"
        # Si el archivo no existe hay que crear el GeoPackage completo; si existe,
        # solo se sobrescribe/actualiza la capa. Usar siempre CreateOrOverwriteLayer
        # sobre un fichero inexistente provoca el error OGR de apertura en modo actualizar.
        if os.path.exists(gpkg):
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        else:
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile

        err = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer,
            gpkg,
            QgsProject.instance().transformContext(),
            options,
        )
        err_code = err[0] if isinstance(err, tuple) else err
        err_msg = err[1] if isinstance(err, tuple) and len(err) > 1 else ""
        if err_code != QgsVectorFileWriter.NoError:
            raise RuntimeError(err_msg or f"Error guardando {layer_name}: {err_code}")

        uri = f"{gpkg}|layername={layer_name}"
        if layer.providerType() == "memory":
            lyr_id = layer.id()
            new_layer = QgsVectorLayer(uri, layer_name, "ogr")
            if new_layer.isValid():
                self._ensure_photo_fields(new_layer)
                self._configure_photo_layer(new_layer)
                QgsProject.instance().removeMapLayer(lyr_id)
                QgsProject.instance().addMapLayer(new_layer)
                return new_layer
        return layer

    def _project_photo_gpkg_path(self, layer_name):
        base = self._primary_gpkg_path()
        if base:
            return os.path.join(os.path.dirname(base), f"{layer_name}.gpkg")
        proj_path = QgsProject.instance().fileName()
        folder = os.path.dirname(proj_path) if proj_path else os.path.expanduser("~")
        return os.path.join(folder, f"{layer_name}.gpkg")

    def _find_layer(self, name):
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == name and lyr.type() == QgsMapLayer.VectorLayer:
                return lyr
        return None

    # ------------------------------------------------------------------ Exports
    def export_layer_photos(self, layer, prefix=None):
        # prefix se conserva por compatibilidad con llamadas antiguas; el prefijo
        # real de fichero se decide por semántica de capa/campo: IF o FR.
        if layer is None or not layer.isValid():
            QMessageBox.warning(self, "Fotos", "No se ha localizado la capa de fotografías.")
            return
        out_dir = QFileDialog.getExistingDirectory(self, "Carpeta para exportar fotografías georreferenciadas", "")
        if not out_dir:
            return
        rows, errors = [], []
        for feat in layer.getFeatures():
            photo = str(feat[FIELD_PATH] or "").strip() if FIELD_PATH in [f.name() for f in layer.fields()] else ""
            if not photo or not os.path.exists(photo):
                errors.append(f"Foto no encontrada en FID {feat.id()}: {photo}")
                continue
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue
            pt = geom.asPoint()
            lon, lat = self._to_lonlat(layer.crs(), pt.x(), pt.y())
            names = [f.name() for f in layer.fields()]
            num = feat[FIELD_NUM] if FIELD_NUM in names else len(rows) + 1
            desc = str(feat[FIELD_DESC] or "").strip() if FIELD_DESC in names else ""
            report_val = feat[FIELD_REPORT] if FIELD_REPORT in names else 0
            try:
                is_report = bool(int(report_val))
            except Exception:
                is_report = str(report_val).strip().lower() in ("si", "sí", "true", "1", "yes")
            if desc:
                is_report = True
            fecha_foto = str(feat[FIELD_DATE] or "").strip() if FIELD_DATE in names else ""
            stamp_val = feat[FIELD_STAMP_DATE] if FIELD_STAMP_DATE in names else 0
            try:
                stamp_date = bool(int(stamp_val))
            except Exception:
                stamp_date = str(stamp_val).strip().lower() in ("si", "sí", "true", "1", "yes")
            # Nombre de exportación corto: solo prefijo IF/FR + nombre original.
            # La capa puntos_informe siempre representa informe final, incluso si
            # procede de capas antiguas sin campo informe_final/descripción.
            if layer.name() == LAYER_ANEJO:
                is_report = True
                base_prefix = "IF"
            elif layer.name() == LAYER_ANEJO_PRE:
                is_report = True
                base_prefix = "IF"
            else:
                base_prefix = "IF" if is_report else "FR"
            dst_name = self._prefixed_original_name(photo, base_prefix, out_dir)
            dst = os.path.join(out_dir, dst_name)
            shutil.copy2(photo, dst)
            fecha_estampada = "NO"
            if stamp_date and fecha_foto:
                fecha_estampada = "SI" if self._stamp_visible_date(dst, fecha_foto) else "NO"
            exif_ok = self._write_gps_exif_optional(dst, lon, lat)
            rows.append({"archivo": dst_name, "origen": photo, "descripcion": desc, "informe_final": "SI" if is_report else "NO", "fecha_foto": fecha_foto, "fecha_estampada": fecha_estampada, "x": pt.x(), "y": pt.y(), "lon": lon, "lat": lat, "exif_gps": "SI" if exif_ok else "NO"})
        self._write_manifest(out_dir, rows)
        msg = f"Fotografías exportadas: {len(rows)}\nCarpeta: {out_dir}\nSe ha creado manifest_fotos.csv."
        if errors:
            msg += "\n\nAvisos:\n" + "\n".join(errors[:10])
        QMessageBox.information(self, "Exportar a carpeta", msg)

    def export_docx(self):
        layer = self._find_layer(LAYER_ANEJO)
        if layer is None or layer.featureCount() == 0:
            QMessageBox.warning(self, "Anejo fotográfico", "La capa puntos_informe no existe o no contiene fotografías.")
            return
        out_dir = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta de descarga del DOCX", "")
        if not out_dir:
            return
        out_path = self._unique_docx_path(out_dir, "anejo_fotografico.docx")

        layout_box = QMessageBox(self)
        layout_box.setWindowTitle("Formato de fotografías")
        layout_box.setText("Elige la disposición de las fotografías en el DOCX.")
        btn_parallel = layout_box.addButton("Dos fotos en paralelo (8 cm)", QMessageBox.ButtonRole.AcceptRole)
        btn_vertical = layout_box.addButton("Disposición vertical (12 cm)", QMessageBox.ButtonRole.AcceptRole)
        layout_box.addButton(QMessageBox.StandardButton.Cancel)
        layout_box.exec()
        clicked = layout_box.clickedButton()
        if clicked is None or layout_box.standardButton(clicked) == QMessageBox.StandardButton.Cancel:
            return
        photo_layout = "vertical" if clicked == btn_vertical else "parallel"

        rows = []
        names = [f.name() for f in layer.fields()]
        for feat in layer.getFeatures():
            photo = str(feat[FIELD_PATH] or "") if FIELD_PATH in names else ""
            if not photo or not os.path.exists(photo):
                continue
            try:
                num = int(feat[FIELD_NUM]) if FIELD_NUM in names and feat[FIELD_NUM] not in (None, "") else len(rows) + 1
            except Exception:
                num = len(rows) + 1
            stamp_date = False
            fecha_foto = ""
            try:
                stamp_date = bool(int(feat[FIELD_STAMP_DATE] or 0)) if FIELD_STAMP_DATE in names else False
            except Exception:
                stamp_date = False
            if FIELD_DATE in names:
                fecha_foto = str(feat[FIELD_DATE] or "").strip()
            rows.append({
                "num": num,
                "desc": str(feat[FIELD_DESC] or "") if FIELD_DESC in names else "",
                "path": photo,
                "fecha_foto": fecha_foto,
                "estampar_fecha": stamp_date,
            })
        rows.sort(key=lambda r: r.get("num", 0))
        if not rows:
            QMessageBox.warning(self, "Anejo fotográfico", "No hay rutas de imagen válidas en puntos_informe.")
            return

        if len(rows) % 2 != 0:
            resp = QMessageBox.question(
                self,
                "Número impar de fotografías",
                "El informe contiene un número impar de fotografías. El anejo está configurado para trabajar por parejas.\n\n¿Quieres continuar igualmente?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if resp != QMessageBox.StandardButton.Yes:
                return

        include_summary = QMessageBox.question(
            self,
            "Resumen de fotografías",
            "¿Deseas insertar un resumen de fotografías debajo del último plano general?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        ) == QMessageBox.StandardButton.Yes
        summary_lines = []
        if include_summary:
            default_summary = self._default_photo_pair_summary(rows)
            text, ok = QInputDialog.getMultiLineText(
                self,
                "Resumen de fotografías",
                "Revisa o edita el resumen por parejas que se insertará bajo el último plano general:",
                default_summary,
            )
            if not ok:
                return
            summary_lines = [ln.strip().lstrip("•").strip() for ln in str(text or "").splitlines() if ln.strip()]

        tmp = tempfile.mkdtemp(prefix="obra_nueva_fotos_")
        try:
            for row in rows:
                src = row["path"]
                dst = os.path.join(tmp, "foto_%04d%s" % (int(row.get("num", 0) or 0), os.path.splitext(src)[1].lower() or ".jpg"))
                try:
                    shutil.copy2(src, dst)
                except Exception:
                    dst = src
                if row.get("estampar_fecha") and row.get("fecha_foto") and dst != src:
                    self._stamp_visible_date(dst, row.get("fecha_foto"))
                row["path"] = dst
            situation_maps = self._capture_situation_maps(layer, tmp)
            SimpleDocxReport(out_path).build(situation_maps, rows, photo_layout=photo_layout, summary_lines=summary_lines)
            QMessageBox.information(self, "Anejo fotográfico", f"DOCX generado:\n{out_path}")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def _unique_docx_path(self, out_dir, filename):
        base, ext = os.path.splitext(filename)
        if not ext:
            ext = ".docx"
        candidate = os.path.join(out_dir, base + ext)
        i = 2
        while os.path.exists(candidate):
            candidate = os.path.join(out_dir, f"{base}_{i}{ext}")
            i += 1
        return candidate

    def _default_photo_pair_summary(self, rows):
        lines = []
        ordered = sorted(rows, key=lambda r: r.get("num", 0))
        for i in range(0, len(ordered), 2):
            first = ordered[i]
            second = ordered[i + 1] if i + 1 < len(ordered) else None
            n1 = first.get("num", i + 1)
            d1 = str(first.get("desc", "") or "").strip()
            if second:
                n2 = second.get("num", i + 2)
                d2 = str(second.get("desc", "") or "").strip()
                if d1 and d2 and d1 != d2:
                    desc = f"{d1} y {d2}"
                else:
                    desc = d1 or d2
                lines.append(f"Fotos {n1} y {n2}, {desc}.")
            else:
                lines.append(f"Foto {n1}, {d1}.")
        return "\n".join(lines)

    def _capture_situation_maps(self, layer, tmp_dir):
        """Genera uno o varios planos generales ceñidos a puntos_informe.

        Si la escala calculada para toda la extensión supera 1:300000
        (denominador mayor de 300000), divide la extensión en teselas hasta
        cubrirla completa con planos a escala máxima aproximada 1:300000.

        Ajuste v154: cuando el plano general contiene una única pareja de
        fotografías, el encuadre se centra expresamente en esa pareja. Esto
        evita que, por extensiones degeneradas o por usar la extensión actual
        del lienzo como respaldo, la pareja aparezca desplazada hacia un borde
        del plano.
        """
        out_size = self._situation_output_size()
        extent = self._initial_situation_extent(layer, out_size)

        photo_points_all = self._situation_photo_points(layer)
        if len(photo_points_all) == 2:
            pair_extent = self._centered_extent_for_photo_points(photo_points_all, out_size, base_extent=extent)
            if pair_extent is not None and not pair_extent.isEmpty():
                extent = pair_extent

        denom = self._scale_denominator_for_extent(extent, out_size)
        max_denom = 300000.0
        cols = rows = 1
        if denom > max_denom:
            import math
            factor = max(1.0, denom / max_denom)
            width = max(extent.width(), 1.0)
            height = max(extent.height(), 1.0)
            aspect = float(out_size.width()) / float(max(out_size.height(), 1))
            cols = max(1, int(math.ceil(math.sqrt(factor * width / max(height * aspect, 1e-9)))))
            rows = max(1, int(math.ceil(factor / cols)))
            while self._scale_denominator_for_extent(self._tile_extent(extent, 0, 0, cols, rows), out_size) > max_denom:
                if (extent.width() / cols) >= (extent.height() / rows) * aspect:
                    cols += 1
                else:
                    rows += 1

        map_items = []
        for r in range(rows):
            for c in range(cols):
                tile = self._tile_extent(extent, c, r, cols, rows)
                # Solo se insertan en el informe los planos que contienen al menos
                # una fotografía/punto de puntos_informe dentro de su encuadre.
                min_num = self._min_photo_num_in_extent(layer, tile)
                if min_num is None:
                    continue
                out_png = os.path.join(tmp_dir, f"situacion_{r + 1}_{c + 1}.png")
                self._capture_situation_extent(tile, out_png, out_size)
                map_items.append((min_num, r, c, out_png))
        map_items.sort(key=lambda item: (item[0], item[1], item[2]))
        return [item[3] for item in map_items]

    def _initial_situation_extent(self, layer, out_size):
        """Devuelve una extensión inicial estable para el plano general.

        Si la extensión de puntos_informe es válida, se usa con margen. Si es
        degenerada por coincidir los puntos en una misma ubicación, se construye
        una extensión centrada en los puntos, manteniendo la relación de aspecto
        del PNG de salida.
        """
        try:
            extent = QgsRectangle(layer.extent())
        except Exception:
            extent = QgsRectangle(self.canvas.extent())

        if extent is None or extent.isEmpty() or extent.width() <= 0 or extent.height() <= 0:
            pts = self._situation_photo_points(layer)
            centered = self._centered_extent_for_photo_points(pts, out_size, base_extent=QgsRectangle(self.canvas.extent()))
            if centered is not None and not centered.isEmpty():
                return centered
            return QgsRectangle(self.canvas.extent())

        extent.scale(1.10)
        return self._fit_extent_to_output_aspect(extent, out_size)

    def _situation_photo_points(self, layer, extent=None):
        """Lista de puntos de puntos_informe en CRS del proyecto: [{'num', 'pt'}]."""
        items = []
        if layer is None or not layer.isValid():
            return items
        names = [f.name() for f in layer.fields()]
        project_crs = QgsProject.instance().crs()
        transform = None
        try:
            if layer.crs().isValid() and project_crs.isValid() and layer.crs() != project_crs:
                transform = QgsCoordinateTransform(layer.crs(), project_crs, QgsProject.instance())
        except Exception:
            transform = None

        for feat in layer.getFeatures():
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue
            try:
                pt = geom.asPoint() if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.PointGeometry else geom.centroid().asPoint()
            except Exception:
                try:
                    pt = geom.centroid().asPoint()
                except Exception:
                    continue
            try:
                if transform is not None:
                    pt = transform.transform(QgsPointXY(pt))
            except Exception:
                pass
            ptxy = QgsPointXY(pt)
            if extent is not None and not extent.contains(ptxy):
                continue
            try:
                num = int(feat[FIELD_NUM]) if FIELD_NUM in names and feat[FIELD_NUM] not in (None, "") else len(items) + 1
            except Exception:
                num = len(items) + 1
            items.append({"num": num, "pt": ptxy})
        items.sort(key=lambda x: x["num"])
        return items

    def _centered_extent_for_photo_points(self, photo_points, out_size, base_extent=None):
        """Crea un encuadre centrado en una pareja o grupo de fotos.

        Para una sola pareja en el plano general, el centro del PNG coincide con
        el centro geométrico de la pareja. La anchura/altura se dimensiona con
        margen suficiente para que las llamadas Foto: Nº entren dentro del plano
        y con un mínimo razonable tomado del lienzo actual cuando sea posible.
        """
        if not photo_points:
            return None
        xs = [float(item["pt"].x()) for item in photo_points]
        ys = [float(item["pt"].y()) for item in photo_points]
        cx = (min(xs) + max(xs)) / 2.0
        cy = (min(ys) + max(ys)) / 2.0
        raw_w = max(max(xs) - min(xs), 0.0)
        raw_h = max(max(ys) - min(ys), 0.0)

        aspect = float(max(out_size.width(), 1)) / float(max(out_size.height(), 1))

        min_w = 20.0
        min_h = min_w / max(aspect, 1e-9)
        try:
            canvas_extent = QgsRectangle(self.canvas.extent())
            if canvas_extent and not canvas_extent.isEmpty():
                # Se usa como mínimo una fracción moderada del encuadre actual:
                # da contexto cartográfico sin desplazar la pareja del centro.
                min_w = max(min_w, canvas_extent.width() * 0.25)
                min_h = max(min_h, canvas_extent.height() * 0.25)
        except Exception:
            pass
        if base_extent is not None and not base_extent.isEmpty():
            min_w = max(min_w, base_extent.width() * 0.05)
            min_h = max(min_h, base_extent.height() * 0.05)

        width = max(raw_w * 3.0, min_w)
        height = max(raw_h * 3.0, min_h)
        if width / max(height, 1e-9) > aspect:
            height = width / max(aspect, 1e-9)
        else:
            width = height * aspect

        rect = QgsRectangle(cx - width / 2.0, cy - height / 2.0, cx + width / 2.0, cy + height / 2.0)
        return self._fit_extent_to_output_aspect(rect, out_size)

    def _fit_extent_to_output_aspect(self, extent, out_size):
        """Amplía la extensión para que coincida con la relación de aspecto de salida."""
        if extent is None or extent.isEmpty():
            return extent
        aspect = float(max(out_size.width(), 1)) / float(max(out_size.height(), 1))
        width = max(extent.width(), 1e-9)
        height = max(extent.height(), 1e-9)
        cx = (extent.xMinimum() + extent.xMaximum()) / 2.0
        cy = (extent.yMinimum() + extent.yMaximum()) / 2.0
        if width / height > aspect:
            height = width / max(aspect, 1e-9)
        else:
            width = height * aspect
        return QgsRectangle(cx - width / 2.0, cy - height / 2.0, cx + width / 2.0, cy + height / 2.0)

    def _min_photo_num_in_extent(self, layer, extent):
        nums = []
        names = [f.name() for f in layer.fields()]
        try:
            for feat in layer.getFeatures():
                geom = feat.geometry()
                if not geom or geom.isEmpty() or not geom.boundingBox().intersects(extent):
                    continue
                try:
                    num = int(feat[FIELD_NUM]) if FIELD_NUM in names and feat[FIELD_NUM] not in (None, "") else None
                except Exception:
                    num = None
                if num is not None:
                    nums.append(num)
        except Exception:
            return 0
        return min(nums) if nums else None

    def _extent_contains_layer_features(self, layer, extent):
        try:
            for feat in layer.getFeatures():
                geom = feat.geometry()
                if geom and not geom.isEmpty() and geom.boundingBox().intersects(extent):
                    return True
        except Exception:
            return True
        return False

    def _situation_output_size(self):
        size = self.canvas.size()
        if size.width() < 400 or size.height() < 300:
            return QSize(1400, 900)
        return QSize(max(size.width(), 1200), max(size.height(), 800))

    def _scale_denominator_for_extent(self, extent, out_size):
        # QGIS usa 0,28 mm/píxel como tamaño de píxel de referencia para escala.
        map_units_per_pixel = max(extent.width() / float(max(out_size.width(), 1)), extent.height() / float(max(out_size.height(), 1)))
        return map_units_per_pixel / 0.00028

    def _tile_extent(self, extent, col, row, cols, rows):
        xmin = extent.xMinimum() + extent.width() * col / cols
        xmax = extent.xMinimum() + extent.width() * (col + 1) / cols
        # Generación de arriba a abajo para que el orden del informe sea natural.
        ymax = extent.yMaximum() - extent.height() * row / rows
        ymin = extent.yMaximum() - extent.height() * (row + 1) / rows
        tile = QgsRectangle(xmin, ymin, xmax, ymax)
        tile.scale(1.02)
        return tile

    def _capture_situation_extent(self, extent, out_png, out_size):
        """Renderiza el plano y dibuja después las llamadas Foto: Nº.

        Las etiquetas del plano de situación no se dejan en manos del motor PAL
        de QGIS, porque a escalas grandes o pequeñas puede ocultar etiquetas por
        conflicto. Se renderiza la cartografía con la simbología del QML y, a
        continuación, se dibujan todas las llamadas de puntos_informe en píxeles,
        con tamaño constante y reposicionamiento automático. Así se ven siempre
        todas las etiquetas, independientemente de la escala del plano.
        """
        render_extent = extent if isinstance(extent, QgsRectangle) else self.canvas.extent()
        anejo_layer = self._find_layer(LAYER_ANEJO)
        old_labels_enabled = None
        try:
            if anejo_layer is not None and anejo_layer.isValid():
                old_labels_enabled = anejo_layer.labelsEnabled()
                # Evita duplicados: el símbolo del QML se mantiene, pero las
                # etiquetas del plano se pintan manualmente y sin descarte.
                anejo_layer.setLabelsEnabled(False)

            settings = QgsMapSettings()
            settings.setLayers(self._situation_canvas_layers(anejo_layer))
            settings.setDestinationCrs(self.canvas.mapSettings().destinationCrs())
            settings.setExtent(render_extent)
            settings.setOutputSize(out_size)
            image = QImage(out_size, QImage.Format.Format_ARGB32_Premultiplied)
            image.fill(Qt.GlobalColor.white)
            painter = QPainter(image)
            job = QgsMapRendererCustomPainterJob(settings, painter)
            job.start()
            job.waitForFinished()
            painter.end()
        finally:
            if anejo_layer is not None and anejo_layer.isValid() and old_labels_enabled is not None:
                anejo_layer.setLabelsEnabled(old_labels_enabled)

        self._draw_situation_photo_labels(image, render_extent, anejo_layer)
        image.save(out_png, "PNG")

    def _situation_canvas_layers(self, anejo_layer=None):
        """Devuelve las capas visibles del lienzo para el plano de situación.

        El plano general del anejo debe respetar exactamente la composición que
        el usuario tiene activada en el canvas antes de exportar. Por eso no se
        usan todas las capas del proyecto, sino las capas actualmente visibles
        en el lienzo. Si por algún motivo puntos_informe no figura en esa lista,
        se añade al final para que el plano del informe conserve la referencia
        fotográfica mínima.
        """
        layers = []
        try:
            canvas_layers = list(self.canvas.layers())
        except Exception:
            canvas_layers = []

        for lyr in canvas_layers:
            try:
                if lyr and lyr.isValid() and lyr.type() in (QgsMapLayer.VectorLayer, QgsMapLayer.RasterLayer, QgsMapLayer.VectorTileLayer):
                    if lyr not in layers:
                        layers.append(lyr)
            except Exception:
                continue

        if anejo_layer is not None:
            try:
                if anejo_layer.isValid() and anejo_layer not in layers:
                    layers.append(anejo_layer)
            except Exception:
                pass

        if not layers:
            layers = [lyr for lyr in QgsProject.instance().mapLayers().values() if lyr.type() in (QgsMapLayer.VectorLayer, QgsMapLayer.RasterLayer, QgsMapLayer.VectorTileLayer)]
        return layers

    def _draw_situation_photo_labels(self, image, extent, layer):
        """Dibuja todas las etiquetas Foto: Nº sobre el PNG de situación.

        Usa coordenadas de imagen, no unidades de mapa. Por eso el tamaño de la
        etiqueta y la separación visual se mantienen constantes a 1:300, 1:20.000
        o cualquier otra escala.
        """
        if layer is None or not layer.isValid() or extent is None or extent.isEmpty():
            return
        labels = self._situation_label_items(layer, extent, image.size())
        if not labels:
            return

        painter = QPainter(image)
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            # En el PNG del plano general las llamadas deben leerse dentro
            # del DOCX. Se duplica el tamaño respecto a las versiones previas
            # y se escalan también separaciones, márgenes y líneas guía para
            # mantener la misma composición visual.
            label_scale = 2.0
            font = QFont("Arial", 20)
            font.setBold(True)
            painter.setFont(font)
            fm = painter.fontMetrics()
            placed = []

            base_offsets = [
                (18, -38), (18, 10), (-96, -38), (-96, 10),
                (18, -70), (18, 42), (-96, -70), (-96, 42),
                (42, -20), (-120, -20), (42, 24), (-120, 24),
                (18, -102), (18, 74), (-96, -102), (-96, 74),
            ]
            offsets = [(int(dx * label_scale), int(dy * label_scale)) for dx, dy in base_offsets]

            for item in labels:
                text = f"Foto: {item['num']}"
                text_w = fm.horizontalAdvance(text)
                text_h = fm.height()
                pad_x, pad_y = int(7 * label_scale), int(4 * label_scale)
                box_w = text_w + 2 * pad_x
                box_h = text_h + 2 * pad_y
                ax, ay = item["px"], item["py"]

                rect = None
                for dx, dy in offsets:
                    candidate = QRectF(ax + dx, ay + dy, box_w, box_h)
                    candidate = self._clamp_label_rect(candidate, image.width(), image.height())
                    sep = int(4 * label_scale)
                    grown = QRectF(candidate.x() - sep, candidate.y() - sep, candidate.width() + 2 * sep, candidate.height() + 2 * sep)
                    if not any(grown.intersects(prev) for prev in placed):
                        rect = candidate
                        break
                if rect is None:
                    # Último recurso: apilar hacia abajo. Sigue mostrando la etiqueta.
                    margin = int(18 * label_scale)
                    rect = QRectF(margin, margin + len(placed) * (box_h + int(6 * label_scale)), box_w, box_h)
                    rect = self._clamp_label_rect(rect, image.width(), image.height())

                callout_end = self._nearest_rect_point(rect, ax, ay)
                painter.setPen(QPen(QColor(0, 0, 0), int(2 * label_scale)))
                painter.drawLine(QPointF(ax, ay), callout_end)
                painter.fillRect(rect, QColor(0, 0, 0))
                painter.setPen(QPen(QColor(255, 255, 255), 1))
                painter.drawText(rect.adjusted(pad_x, pad_y, -pad_x, -pad_y), Qt.AlignmentFlag.AlignCenter, text)
                sep = int(4 * label_scale)
                placed.append(QRectF(rect.x() - sep, rect.y() - sep, rect.width() + 2 * sep, rect.height() + 2 * sep))
        finally:
            painter.end()

    def _situation_label_items(self, layer, extent, out_size):
        items = []
        names = [f.name() for f in layer.fields()]
        project_crs = QgsProject.instance().crs()
        transform = None
        try:
            if layer.crs().isValid() and project_crs.isValid() and layer.crs() != project_crs:
                transform = QgsCoordinateTransform(layer.crs(), project_crs, QgsProject.instance())
        except Exception:
            transform = None

        for feat in layer.getFeatures():
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue
            try:
                pt = geom.asPoint() if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.PointGeometry else geom.centroid().asPoint()
            except Exception:
                try:
                    pt = geom.centroid().asPoint()
                except Exception:
                    continue
            try:
                if transform is not None:
                    pt = transform.transform(QgsPointXY(pt))
            except Exception:
                pass
            if not extent.contains(QgsPointXY(pt)):
                continue
            try:
                num = int(feat[FIELD_NUM]) if FIELD_NUM in names and feat[FIELD_NUM] not in (None, "") else len(items) + 1
            except Exception:
                num = len(items) + 1
            px = (float(pt.x()) - extent.xMinimum()) / max(extent.width(), 1e-9) * out_size.width()
            py = (extent.yMaximum() - float(pt.y())) / max(extent.height(), 1e-9) * out_size.height()
            items.append({"num": num, "px": px, "py": py})
        items.sort(key=lambda x: x["num"])
        return items

    def _clamp_label_rect(self, rect, image_w, image_h):
        x = min(max(rect.x(), 4), max(4, image_w - rect.width() - 4))
        y = min(max(rect.y(), 4), max(4, image_h - rect.height() - 4))
        return QRectF(x, y, rect.width(), rect.height())

    def _nearest_rect_point(self, rect, ax, ay):
        x = min(max(ax, rect.left()), rect.right())
        y = min(max(ay, rect.top()), rect.bottom())
        return QPointF(x, y)

    # ------------------------------------------------------------------ Shared helpers
    def _photo_paths(self, feat, layer, gpkg_path):
        names = [field.name() for field in layer.fields()]
        lower_map = {n.lower(): n for n in names}
        candidates = []
        for cand in PHOTO_FIELDS:
            real = cand if cand in names else lower_map.get(cand.lower())
            if real and real not in candidates:
                candidates.append(real)
        for name in names:
            low = name.lower()
            if ("foto" in low or "photo" in low or "image" in low or "imagen" in low or "picture" in low) and name not in candidates:
                candidates.append(name)
        base_dir = os.path.dirname(gpkg_path)
        project_dir = os.path.dirname(QgsProject.instance().fileName()) if QgsProject.instance().fileName() else base_dir
        img_exts = (".jpg", ".jpeg", ".png", ".tif", ".tiff")
        null_tokens = {"", "null", "none", "nan", "<null>", "sin foto", "s/f"}

        paths, seen = [], set()
        for field_name in candidates:
            val = feat[field_name]
            if val is None:
                continue
            for chunk in str(val).replace("\r", ";").replace("\n", ";").replace("|", ";").split(";"):
                raw = chunk.strip().strip('"').strip("'")
                if raw.lower() in null_tokens:
                    continue
                # Evita interpretar valores alfanuméricos, códigos o NULL de campos no fotográficos como rutas.
                if not raw.lower().endswith(img_exts):
                    continue

                alternatives = []
                if os.path.isabs(raw):
                    alternatives.append(os.path.normpath(raw))
                else:
                    alternatives.extend([
                        os.path.normpath(os.path.join(base_dir, raw)),
                        os.path.normpath(os.path.join(project_dir, raw)),
                        os.path.normpath(os.path.join(base_dir, "fotos", raw)),
                        os.path.normpath(os.path.join(base_dir, "Fotos", raw)),
                        os.path.normpath(os.path.join(base_dir, "FOTOS", raw)),
                        os.path.normpath(os.path.join(base_dir, "imagenes", raw)),
                        os.path.normpath(os.path.join(base_dir, "Imágenes", raw)),
                    ])

                # Prioriza la alternativa existente; si ninguna existe, conserva la primera para informar del aviso real.
                path = next((a for a in alternatives if os.path.exists(a)), alternatives[0])
                key = os.path.normcase(path)
                if key not in seen:
                    seen.add(key)
                    paths.append(path)
        return paths

    def _safe_centroid(self, geom):
        try:
            if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.PointGeometry:
                return geom
            c = geom.centroid()
            if c and not c.isEmpty():
                return c
            p = geom.pointOnSurface()
            if p and not p.isEmpty():
                return p
        except Exception:
            return None
        return None

    def _attr(self, feat, layer, candidates):
        names = [field.name() for field in layer.fields()]
        lower_map = {n.lower(): n for n in names}
        for cand in candidates:
            real = cand if cand in names else lower_map.get(cand.lower())
            if real:
                val = feat[real]
                return "" if val is None else str(val)
        return ""

    def _to_lonlat(self, crs, x, y):
        try:
            dest = QgsCoordinateReferenceSystem("EPSG:4326")
            tr = QgsCoordinateTransform(crs, dest, QgsProject.instance())
            p = tr.transform(QgsPointXY(x, y))
            return float(p.x()), float(p.y())
        except Exception:
            return float(x), float(y)

    def _photo_date_for_display(self, photo_path):
        """Devuelve fecha en formato DD/MM/AAAA HH:MM.

        Orden de búsqueda:
        1) EXIF de la cámara.
        2) Nombre de archivo.
        3) Fecha estampada visualmente en la fotografía mediante OCR opcional.

        La lectura visual requiere que el entorno de QGIS tenga Tesseract disponible
        como ejecutable del sistema o como módulo pytesseract. Si no está disponible,
        el flujo continúa sin romperse y se pide la fecha manualmente.
        """
        # 1) EXIF DateTimeOriginal / DateTimeDigitized / DateTime
        try:
            from PIL import Image, ExifTags
            img = Image.open(photo_path)
            exif = img.getexif()
            tag_map = {v: k for k, v in ExifTags.TAGS.items()}
            for tag_name in ("DateTimeOriginal", "DateTimeDigitized", "DateTime"):
                value = exif.get(tag_map.get(tag_name)) if tag_map.get(tag_name) else None
                formatted = self._normalize_photo_date(value)
                if formatted:
                    return formatted
        except Exception as exc:
            QgsMessageLog.logMessage(f"No se pudo leer fecha EXIF de {photo_path}: {exc}", "OBRA_NUEVA", Qgis.MessageLevel.Info)

        # 2) Nombre típico IMG_20251210_111007.jpg / 20251210-111007
        try:
            name_date = self._photo_date_from_filename(photo_path)
            if name_date:
                return name_date
        except Exception as exc:
            QgsMessageLog.logMessage(f"No se pudo leer fecha desde nombre de archivo {photo_path}: {exc}", "OBRA_NUEVA", Qgis.MessageLevel.Info)

        # 3) Fecha visible estampada dentro de la imagen.
        try:
            visible_date = self._photo_date_from_visible_stamp(photo_path)
            if visible_date:
                return visible_date
        except Exception as exc:
            QgsMessageLog.logMessage(f"No se pudo leer fecha visible estampada de {photo_path}: {exc}", "OBRA_NUEVA", Qgis.MessageLevel.Info)

        return ""

    def _photo_date_from_filename(self, photo_path):
        """Detecta fechas habituales embebidas en el nombre de archivo."""
        import re
        name = os.path.basename(photo_path)
        patterns = (
            r"(20\d{2})(\d{2})(\d{2})[_\- ]?(\d{2})(\d{2})(\d{2})?",
            r"(\d{2})[\-_/\.](\d{2})[\-_/\.](20\d{2})[_\- ]+(\d{2})[\.:hH](\d{2})",
        )
        for pattern in patterns:
            m = re.search(pattern, name)
            if not m:
                continue
            groups = tuple(g or "" for g in m.groups())
            if pattern.startswith("(20"):
                y, mo, d, h, mi, _sec = groups
            else:
                d, mo, y, h, mi = groups
            normalized = self._normalize_photo_date(f"{d}/{mo}/{y} {h}:{mi}")
            if normalized:
                return normalized
        return ""

    def _photo_date_from_visible_stamp(self, photo_path):
        """Intenta leer una fecha ya estampada visualmente en la foto.

        Usa OCR opcional con Tesseract. Para hacerlo más fiable, analiza primero
        franjas inferiores y laterales, que es donde suelen aparecer las fechas
        impresas por cámara/app, y aplica varios preprocesados simples.
        """
        try:
            from PIL import Image, ImageOps, ImageEnhance, ImageFilter
        except Exception:
            return ""

        img = Image.open(photo_path).convert("RGB")
        w, h = img.size
        if w < 80 or h < 80:
            return ""

        crops = []
        # Franja inferior completa y esquinas inferiores: ubicaciones más habituales.
        crops.append(img.crop((0, int(h * 0.55), w, h)))
        crops.append(img.crop((0, int(h * 0.65), int(w * 0.70), h)))
        crops.append(img.crop((int(w * 0.30), int(h * 0.65), w, h)))
        # Imagen completa como último recurso por si la fecha está arriba.
        crops.append(img)

        for crop in crops:
            for prepared in self._ocr_prepared_images(crop):
                text = self._run_ocr_on_image(prepared)
                detected = self._extract_photo_date_from_text(text)
                if detected:
                    return detected
        return ""

    def _ocr_prepared_images(self, image):
        """Genera variantes sencillas para mejorar lectura OCR de texto blanco/negro."""
        try:
            from PIL import ImageOps, ImageEnhance, ImageFilter
        except Exception as exc:
            QgsMessageLog.logMessage(f"PIL no disponible para preparar OCR: {exc}", "OBRA_NUEVA", Qgis.MessageLevel.Info)
            return []
        variants = []
        gray = ImageOps.grayscale(image)
        # Ampliación: mejora textos pequeños de fecha en fotos de móvil.
        scale = 3 if max(gray.size) < 1800 else 2
        resized = gray.resize((gray.width * scale, gray.height * scale))
        variants.append(ImageOps.autocontrast(resized))
        variants.append(ImageOps.invert(ImageOps.autocontrast(resized)))

        sharp = ImageEnhance.Sharpness(resized).enhance(2.2).filter(ImageFilter.SHARPEN)
        contrast = ImageEnhance.Contrast(sharp).enhance(2.0)
        variants.append(ImageOps.autocontrast(contrast))
        variants.append(ImageOps.invert(ImageOps.autocontrast(contrast)))

        # Umbrales para texto claro sobre fondo oscuro y al contrario.
        for threshold in (120, 155, 190):
            bw = contrast.point(lambda p, t=threshold: 255 if p > t else 0)
            variants.append(bw)
            variants.append(ImageOps.invert(bw))
        return variants

    def _candidate_tesseract_commands(self):
        """Rutas habituales de Tesseract en Windows/QGIS y PATH del sistema."""
        import os as _os
        candidates = []
        env_cmd = _os.environ.get("TESSERACT_CMD") or _os.environ.get("TESSERACT_PATH")
        if env_cmd:
            candidates.append(env_cmd)
        candidates.extend([
            "tesseract",
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        ])
        seen = set()
        result = []
        for cmd in candidates:
            if cmd and cmd not in seen:
                seen.add(cmd)
                result.append(cmd)
        return result

    def _run_ocr_on_image(self, image):
        """Ejecuta OCR mediante pytesseract o ejecutable tesseract si existen."""
        # psm 7 funciona mejor para una única línea de fecha; psm 6/11 quedan como respaldo.
        configs = [
            "--psm 7 -c tessedit_char_whitelist=0123456789/:.- hH",
            "--psm 6 -c tessedit_char_whitelist=0123456789/:.- hH",
            "--psm 11 -c tessedit_char_whitelist=0123456789/:.- hH",
        ]
        try:
            import pytesseract
            for cmd in self._candidate_tesseract_commands():
                if cmd != "tesseract" and os.path.exists(cmd):
                    try:
                        pytesseract.pytesseract.tesseract_cmd = cmd
                    except Exception:
                        pass
                    break
            chunks = []
            for config in configs:
                try:
                    chunks.append(pytesseract.image_to_string(image, config=config) or "")
                except Exception:
                    continue
            if chunks:
                return "\n".join(chunks)
        except Exception:
            pass

        try:
            import subprocess, tempfile, os as _os
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                tmp_path = tmp.name
            try:
                image.save(tmp_path)
                for cmd in self._candidate_tesseract_commands():
                    if cmd != "tesseract" and not _os.path.exists(cmd):
                        continue
                    for psm in ("7", "6", "11"):
                        try:
                            proc = subprocess.run(
                                [cmd, tmp_path, "stdout", "--psm", psm, "-c", "tessedit_char_whitelist=0123456789/:.- hH"],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.DEVNULL,
                                timeout=5,
                                text=True,
                            )
                        except Exception:
                            continue
                        if proc.stdout:
                            return proc.stdout
                return ""
            finally:
                try:
                    _os.remove(tmp_path)
                except Exception:
                    pass
        except Exception:
            return ""

    def _extract_photo_date_from_text(self, text):
        """Extrae y normaliza fecha/hora desde texto OCR ruidoso."""
        if not text:
            return ""
        import re
        cleaned = str(text)
        cleaned = cleaned.replace("I", "1").replace("l", "1").replace("O", "0").replace("o", "0")
        cleaned = re.sub(r"\s+", " ", cleaned)

        patterns = (
            # 10/12/2025 11:10, 10-12-2025 11.10, 10.12.2025 11h10
            r"(?<!\d)(\d{1,2})[\s/\-.](\d{1,2})[\s/\-.](20\d{2})\s+(\d{1,2})[\s:.hH](\d{2})(?!\d)",
            # 2025/12/10 11:10
            r"(?<!\d)(20\d{2})[\s/\-.](\d{1,2})[\s/\-.](\d{1,2})\s+(\d{1,2})[\s:.hH](\d{2})(?!\d)",
            # 10122025 1110 o 20251210 1110, por si OCR elimina separadores
            r"(?<!\d)(\d{2})(\d{2})(20\d{2})\s*(\d{2})(\d{2})(?!\d)",
            r"(?<!\d)(20\d{2})(\d{2})(\d{2})\s*(\d{2})(\d{2})(?!\d)",
        )
        for i, pattern in enumerate(patterns):
            m = re.search(pattern, cleaned)
            if not m:
                continue
            g = m.groups()
            if i == 0:
                d, mo, y, h, mi = g
            elif i == 1:
                y, mo, d, h, mi = g
            elif i == 2:
                d, mo, y, h, mi = g
            else:
                y, mo, d, h, mi = g
            normalized = self._normalize_photo_date(f"{int(d):02d}/{int(mo):02d}/{y} {int(h):02d}:{mi}")
            if normalized:
                return normalized
        return ""

    def _normalize_photo_date(self, value):
        if not value:
            return ""
        text = str(value).strip()
        for fmt in (
            "%Y:%m:%d %H:%M:%S",
            "%Y-%m-%d %H:%M:%S",
            "%Y/%m/%d %H:%M:%S",
            "%Y%m%d_%H%M%S",
            "%d/%m/%Y %H:%M",
            "%d-%m-%Y %H:%M",
            "%d.%m.%Y %H:%M",
        ):
            try:
                dt = datetime.strptime(text, fmt)
                if 2000 <= dt.year <= 2099:
                    return dt.strftime("%d/%m/%Y %H:%M")
            except Exception:
                pass
        return ""

    def _ask_photo_date(self, photo_path, default_value=""):
        """Pregunta fecha visible para fotos sin fecha y valida DD/MM/AAAA HH:MM."""
        default_value = default_value or datetime.now().strftime("%d/%m/%Y %H:%M")
        while True:
            text, ok = QInputDialog.getText(
                self,
                "Fecha de la fotografía",
                "La fotografía no tiene fecha visible. Indica la fecha que se estampará al exportar\nFormato: DD/MM/AAAA HH:MM",
                text=default_value,
            )
            if not ok:
                return ""
            text = " ".join(str(text or "").strip().split())
            try:
                return datetime.strptime(text, "%d/%m/%Y %H:%M").strftime("%d/%m/%Y %H:%M")
            except Exception:
                QMessageBox.warning(self, "Fecha no válida", "Introduce la fecha con formato DD/MM/AAAA HH:MM. Ejemplo: 10/12/2025 11:10")

    def _stamp_visible_date(self, image_path, date_text):
        """Estampa la fecha en la esquina inferior derecha manteniendo formato DD/MM/AAAA HH:MM."""
        try:
            from PIL import Image, ImageDraw, ImageFont
            img = Image.open(image_path).convert("RGB")
            draw = ImageDraw.Draw(img)
            w, h = img.size
            font_size = max(24, int(w * 0.026))
            font = None
            for candidate in (
                "C:/Windows/Fonts/arial.ttf",
                "C:/Windows/Fonts/segoeui.ttf",
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            ):
                try:
                    font = ImageFont.truetype(candidate, font_size)
                    break
                except Exception:
                    pass
            if font is None:
                font = ImageFont.load_default()
            bbox = draw.textbbox((0, 0), date_text, font=font)
            tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
            margin_x = max(30, int(w * 0.035))
            margin_y = max(24, int(h * 0.045))
            x = w - tw - margin_x
            y = h - th - margin_y
            # sombra suave/contorno para lectura sobre fondo variable
            for dx, dy in ((-2, -2), (-2, 2), (2, -2), (2, 2), (0, 2), (2, 0)):
                draw.text((x + dx, y + dy), date_text, font=font, fill=(0, 0, 0))
            draw.text((x, y), date_text, font=font, fill=(255, 255, 255))
            img.save(image_path, quality=95)
            return True
        except Exception as exc:
            QgsMessageLog.logMessage(f"No se pudo estampar fecha en {image_path}: {exc}", "OBRA_NUEVA", Qgis.MessageLevel.Warning)
            return False

    def _read_photo_gps_lonlat(self, photo_path):
        """Lee coordenadas GPS EXIF y devuelve (lon, lat) en EPSG:4326."""
        try:
            from PIL import Image, ExifTags
            img = Image.open(photo_path)
            exif = img.getexif()
            if not exif:
                return None
            gps_tag = None
            for key, value in ExifTags.TAGS.items():
                if value == "GPSInfo":
                    gps_tag = key
                    break
            gps_raw = exif.get(gps_tag) if gps_tag else None
            if not gps_raw:
                return None
            gps = {}
            for key, value in gps_raw.items():
                gps[ExifTags.GPSTAGS.get(key, key)] = value

            def rational_to_float(v):
                try:
                    return float(v[0]) / float(v[1])
                except Exception:
                    return float(v)

            def dms_to_deg(values, ref):
                d = rational_to_float(values[0])
                m = rational_to_float(values[1])
                sec = rational_to_float(values[2])
                deg = d + (m / 60.0) + (sec / 3600.0)
                if str(ref).upper() in ("S", "W"):
                    deg *= -1.0
                return deg

            lat_values = gps.get("GPSLatitude")
            lat_ref = gps.get("GPSLatitudeRef")
            lon_values = gps.get("GPSLongitude")
            lon_ref = gps.get("GPSLongitudeRef")
            if not lat_values or not lon_values or not lat_ref or not lon_ref:
                return None
            lat = dms_to_deg(lat_values, lat_ref)
            lon = dms_to_deg(lon_values, lon_ref)
            return (lon, lat)
        except Exception as exc:
            QgsMessageLog.logMessage(f"No se pudieron leer coordenadas GPS EXIF de {photo_path}: {exc}", "OBRA_NUEVA", Qgis.MessageLevel.Warning)
            return None

    def _layer_counter_key(self, layer):
        """Clave estable para numeración incremental por capa durante la sesión."""
        try:
            source = layer.source() or ""
        except Exception:
            source = ""
        try:
            layer_id = layer.id() or ""
        except Exception:
            layer_id = ""
        return f"{layer.name()}::{source or layer_id}"

    def _next_number(self, layer):
        """Devuelve el siguiente Nº sin depender de refrescos del proveedor tras cada inserción."""
        key = self._layer_counter_key(layer)
        if key not in self._layer_counters:
            max_num = 0
            if FIELD_NUM in [f.name() for f in layer.fields()]:
                for feat in layer.getFeatures():
                    try:
                        max_num = max(max_num, int(feat[FIELD_NUM] or 0))
                    except Exception:
                        pass
            self._layer_counters[key] = max_num
        self._layer_counters[key] += 1
        return self._layer_counters[key]

    def _fill_list(self, widget, files, current_index):
        widget.clear()
        for i, path in enumerate(files):
            prefix = "▶ " if i == current_index else "   "
            widget.addItem(prefix + os.path.basename(path))
        if 0 <= current_index < widget.count():
            widget.setCurrentRow(current_index)

    def _refresh_status_labels(self):
        manual = self._find_layer(LAYER_MANUAL)
        anejo = self._find_layer(LAYER_ANEJO)
        pre = self._find_layer(LAYER_ANEJO_PRE)
        self.lbl_manual_status.setText("Estado: capa fotos_georref no creada." if manual is None else f"Estado: fotos_georref · {manual.featureCount()} elemento(s).")
        if hasattr(self, "lbl_pre_status"):
            self.lbl_pre_status.setText("Estado: capa puntos_informes_pre no creada." if pre is None else f"Estado: puntos_informes_pre · {pre.featureCount()} elemento(s).")
        self.lbl_anejo_status.setText("Estado: capa puntos_informe no creada." if anejo is None else f"Estado: puntos_informe · {anejo.featureCount()} elemento(s).")

    def _prefixed_original_name(self, photo_path, prefix, out_dir=None):
        """Devuelve nombre corto y consistente: FR_/IF_ + nombre original.

        Si el archivo de origen ya venía prefijado con FR_ o IF_, se elimina ese
        prefijo previo y se aplica siempre el prefijo del flujo actual. Así una
        foto de puntos_informe no puede salir accidentalmente como FR_ por traer
        ese prefijo en origen, ni una foto normal puede heredar IF_.
        """
        prefix = "IF" if str(prefix).upper().startswith("IF") else "FR"
        original = self._safe_filename(os.path.basename(photo_path))
        upper = original.upper()
        if upper.startswith(("FR_", "IF_")):
            original = original[3:] or "foto.jpg"
        candidate = f"{prefix}_{original}"

        if not out_dir:
            return candidate

        base, ext = os.path.splitext(candidate)
        final_name = candidate
        i = 2
        while os.path.exists(os.path.join(out_dir, final_name)):
            final_name = f"{base}_{i}{ext}"
            i += 1
        return final_name

    def _safe_filename(self, text):
        valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_ .áéíóúÁÉÍÓÚñÑ"
        out = "".join(c if c in valid else "_" for c in str(text))
        return out.strip().replace(" ", "_")[:120] or "foto"

    def _write_manifest(self, out_dir, rows):
        path = os.path.join(out_dir, "manifest_fotos.csv")
        keys = []
        for row in rows:
            for k in row.keys():
                if k not in keys:
                    keys.append(k)
        if not keys:
            keys = ["archivo", "x", "y", "lon", "lat", "exif_gps"]
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=keys, delimiter=";")
            writer.writeheader()
            for row in rows:
                writer.writerow(row)

    def _write_gps_exif_optional(self, jpg_path, lon, lat):
        """Intenta escribir GPS EXIF si piexif está disponible en el Python de QGIS.
        Si no lo está, devuelve False y el CSV mantiene las coordenadas.
        """
        if os.path.splitext(jpg_path)[1].lower() not in (".jpg", ".jpeg"):
            return False
        try:
            import piexif  # type: ignore
            def deg_to_dms_rational(deg):
                deg_abs = abs(float(deg))
                d = int(deg_abs)
                m_float = (deg_abs - d) * 60
                m = int(m_float)
                s = round((m_float - m) * 60 * 10000)
                return ((d, 1), (m, 1), (s, 10000))
            exif_dict = piexif.load(jpg_path)
            gps = exif_dict.get("GPS", {})
            gps[piexif.GPSIFD.GPSLatitudeRef] = "N" if lat >= 0 else "S"
            gps[piexif.GPSIFD.GPSLatitude] = deg_to_dms_rational(lat)
            gps[piexif.GPSIFD.GPSLongitudeRef] = "E" if lon >= 0 else "W"
            gps[piexif.GPSIFD.GPSLongitude] = deg_to_dms_rational(lon)
            exif_dict["GPS"] = gps
            piexif.insert(piexif.dump(exif_dict), jpg_path)
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------ Agrupación IF por ubicación
    def _pair_and_renumber_informe_final(self):
        """Agrupa las fotos de informe final en parejas por proximidad geográfica
        y renumera toda la capa puntos_informe correlativamente.

        Regla de numeración:
        - Las fotos IF se agrupan en parejas por cercanía espacial (clustering greedy
          por distancia mínima entre puntos no emparejados).
        - Dentro de cada pareja, el número IMPAR va a la foto más antigua y el número
          PAR a la más reciente.
        - Las fotos no marcadas como IF conservan su orden relativo al final de la
          numeración, sin alterar su contenido.

        Algoritmo de emparejamiento:
        - Se parte de la foto IF más al noroeste (mayor latitud, menor longitud)
          como ancla inicial.
        - Se le asigna como compañera la foto IF más cercana que aún no esté emparejada.
        - Se repite hasta agotar las fotos IF.
        - Si el número de fotos IF es impar, la última queda sola en su pareja.
        """
        layer = self._find_layer(LAYER_ANEJO)
        if layer is None or not layer.isValid():
            QMessageBox.warning(self, "Renumeración IF",
                                "La capa puntos_informe no existe o no es válida.")
            return

        names = [f.name() for f in layer.fields()]
        if FIELD_NUM not in names or FIELD_REPORT not in names:
            QMessageBox.warning(self, "Renumeración IF",
                                "La capa no tiene los campos esperados (Nº, informe_final).")
            return

        # ── 1. Recoger features ───────────────────────────────────────────────
        if_feats  = []   # marcadas informe_final = 1
        nif_feats = []   # resto

        for feat in layer.getFeatures():
            try:
                is_if = bool(int(feat[FIELD_REPORT] or 0))
            except Exception:
                is_if = False

            geom = feat.geometry()
            if geom and not geom.isEmpty():
                pt = (geom.asPoint()
                      if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.PointGeometry
                      else geom.centroid().asPoint())
            else:
                pt = None

            fecha_raw = str(feat[FIELD_DATE] or "").strip() if FIELD_DATE in names else ""

            record = {
                "fid":   feat.id(),
                "pt":    pt,
                "fecha": fecha_raw,
            }
            if is_if:
                if_feats.append(record)
            else:
                nif_feats.append(record)

        if not if_feats:
            QMessageBox.information(self, "Renumeración IF",
                                    "No hay fotografías marcadas como Informe Final en puntos_informe.")
            return

        n_if = len(if_feats)
        if n_if % 2 != 0:
            resp = QMessageBox.question(
                self,
                "Número impar de fotos IF",
                f"Hay {n_if} fotos de Informe Final (número impar).\n"
                "La última pareja quedará incompleta.\n\n¿Continuar igualmente?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if resp != QMessageBox.StandardButton.Yes:
                return

        # ── 2. Parsear fecha a datetime para comparar antigüedad ──────────────
        from datetime import datetime as _dt

        def _parse_fecha(s):
            for fmt in ("%d/%m/%Y %H:%M", "%d/%m/%Y", "%Y-%m-%d %H:%M:%S",
                        "%Y:%m:%d %H:%M:%S", "%Y/%m/%d %H:%M:%S"):
                try:
                    return _dt.strptime(s.strip(), fmt)
                except Exception:
                    pass
            return None  # sin fecha → se tratará como la más reciente

        for r in if_feats:
            r["dt"] = _parse_fecha(r["fecha"])

        # ── 3. Emparejamiento greedy por distancia mínima ─────────────────────
        import math

        def _dist(a, b):
            """Distancia euclidiana en unidades de mapa (suficiente para ordenar)."""
            if a is None or b is None:
                return float("inf")
            return math.hypot(a.x() - b.x(), a.y() - b.y())

        # Ancla inicial: foto más al noroeste (mayor y, menor x como desempate)
        remaining = sorted(
            if_feats,
            key=lambda r: (-(r["pt"].y() if r["pt"] else 0),
                            r["pt"].x() if r["pt"] else 0)
        )

        pairs = []   # lista de [rec_a, rec_b | None]
        used = set()

        while remaining:
            anchor = remaining.pop(0)
            used.add(anchor["fid"])

            best = None
            best_d = float("inf")
            for cand in remaining:
                d = _dist(anchor["pt"], cand["pt"])
                if d < best_d:
                    best_d = d
                    best = cand

            if best is not None:
                remaining.remove(best)
                used.add(best["fid"])
                pairs.append([anchor, best])
            else:
                pairs.append([anchor, None])  # pareja incompleta

        # ── 4. Asignar números: impar → más antigua, par → más reciente ───────
        fid_to_new_num = {}
        counter = 1

        for pair in pairs:
            a, b = pair
            if b is None:
                # Solo una foto en esta pareja: recibe el número impar
                fid_to_new_num[a["fid"]] = counter
                counter += 2  # dejamos hueco par vacío para mantener la lógica
                continue

            dt_a = a["dt"]
            dt_b = b["dt"]

            if dt_a is None and dt_b is None:
                older, newer = a, b   # sin fechas: ancla recibe impar
            elif dt_a is None:
                older, newer = b, a   # b tiene fecha y puede ser más antigua
            elif dt_b is None:
                older, newer = a, b
            else:
                if dt_a <= dt_b:
                    older, newer = a, b
                else:
                    older, newer = b, a

            fid_to_new_num[older["fid"]] = counter       # impar
            fid_to_new_num[newer["fid"]] = counter + 1   # par
            counter += 2

        # ── 5. Números para fotos NO informe final (tras las IF) ─────────────
        nif_by_fid = {r["fid"]: r for r in nif_feats}

        nif_original = []
        for feat in layer.getFeatures():
            fid = feat.id()
            if fid in nif_by_fid:
                try:
                    n = int(feat[FIELD_NUM] or 0)
                except Exception:
                    n = 0
                nif_original.append((n, fid))
        nif_original.sort()

        for _, fid in nif_original:
            fid_to_new_num[fid] = counter
            counter += 1

        # ── 6. Aplicar los nuevos Nº a la capa ───────────────────────────────
        layer.startEditing()
        try:
            num_idx = layer.fields().indexFromName(FIELD_NUM)
            if num_idx < 0:
                raise ValueError(f"Campo {FIELD_NUM!r} no encontrado en la capa.")

            for fid, new_num in fid_to_new_num.items():
                layer.changeAttributeValue(fid, num_idx, new_num)

            if not layer.commitChanges():
                errors = layer.commitErrors()
                raise RuntimeError("\n".join(errors))
        except Exception as exc:
            layer.rollBack()
            QMessageBox.critical(self, "Renumeración IF",
                                  f"Error al guardar los cambios:\n{exc}")
            return

        # ── 7. Refrescar simbología y avisar ─────────────────────────────────
        layer.triggerRepaint()
        n_pairs_complete   = sum(1 for p in pairs if p[1] is not None)
        n_pairs_incomplete = sum(1 for p in pairs if p[1] is None)
        msg = (
            f"Renumeración completada.\n"
            f"· {n_if} fotos IF en {len(pairs)} parejas "
            f"({n_pairs_complete} completas, {n_pairs_incomplete} incompletas).\n"
            f"· {len(nif_feats)} fotos no-IF renumeradas al final."
        )
        QMessageBox.information(self, "Renumeración IF", msg)
        self.status_callback(
            f"[IF] Renumeración por parejas aplicada: {n_if} fotos IF → {len(pairs)} parejas."
        )



class SimpleDocxReport:
    """Generador DOCX mínimo sin dependencia externa python-docx."""
    def __init__(self, out_path):
        self.out_path = out_path
        self.media = []
        self.rels = []
        self.next_rid = 1
        self.next_docpr_id = 1

    def build(self, situation_paths, photo_rows, photo_layout="parallel", summary_lines=None):
        self.media = []
        self.rels = []
        self.next_rid = 1
        self.next_docpr_id = 1
        if isinstance(situation_paths, str):
            situation_paths = [situation_paths]
        summary_lines = summary_lines or []
        body = []
        body.append(self._p("ANEJO FOTOGRÁFICO", bold=True, size=26, align="center"))
        total_maps = len(situation_paths or [])
        for idx, situation_path in enumerate(situation_paths or [], start=1):
            # v158: los planos generales no llevan título superior. Solo se
            # mantiene el pie bajo el plano y se intenta colocar dos planos por
            # página cuando la altura real del documento lo permita.
            body.append(self._image_paragraph(situation_path, width_cm=16.2, align="center"))
            body.append(self._p(f"Localización de las fotos de los emplazamientos {idx}/{total_maps}", size=18, align="center"))
            if idx == total_maps and summary_lines:
                body.append(self._p("Resumen de fotografías", bold=True, size=20, align="left"))
                for line in summary_lines:
                    body.append(self._bullet_p(line, size=18))
            if total_maps and (idx % 2 == 0 or idx == total_maps):
                body.append(self._page_break())
        if not situation_paths and summary_lines:
            body.append(self._p("Resumen de fotografías", bold=True, size=20, align="left"))
            for line in summary_lines:
                body.append(self._bullet_p(line, size=18))
            body.append(self._page_break())
        if photo_layout == "vertical":
            # v162: en disposición vertical se evita anidar tablas dentro de
            # celdas, porque Word puede reparar el DOCX. Se usa una tabla
            # global plana y se aplica keepNext/cantSplit para mantener la
            # pareja junta siempre que sea posible.
            body.append(self._photo_vertical_pairs_global_table(photo_rows, max_width_cm=12.0, min_width_cm=7.0))
        else:
            # v158: una única tabla global con parejas horizontales. Cada pareja
            # ocupa dos filas: imágenes y pies de foto. Se intenta colocar hasta
            # tres parejas por página manteniendo el ancho de 8 cm por foto.
            body.append(self._photo_pairs_global_table(photo_rows, width_cm=8.0, pairs_per_page=3))
        self._write_zip(self._document_xml("".join(body)))

    def _write_zip(self, document_xml):
        with zipfile.ZipFile(self.out_path, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml", self._content_types())
            z.writestr("_rels/.rels", self._root_rels())
            z.writestr("word/document.xml", document_xml)
            z.writestr("word/_rels/document.xml.rels", self._document_rels())
            z.writestr("docProps/core.xml", self._core_props())
            z.writestr("docProps/app.xml", self._app_props())
            for item in self.media:
                z.write(item["src"], "word/media/" + item["name"])

    def _add_image(self, path):
        ext = os.path.splitext(path)[1].lower().lstrip(".") or "png"
        if ext == "jpeg":
            ext = "jpg"
        media_name = "image%d.%s" % (len(self.media) + 1, ext)
        rid = "rId%d" % self.next_rid
        self.next_rid += 1
        self.media.append({"src": path, "name": media_name, "ext": ext})
        self.rels.append((rid, "media/" + media_name))
        return rid

    def _image_paragraph(self, path, width_cm=7.4, align="center", keep_next=False):
        rid = self._add_image(path)
        width_emu = int(width_cm / 2.54 * 914400)
        img = QImage(path)
        width_px, height_px = img.width(), img.height()
        height_emu = int(width_emu * height_px / width_px) if width_px > 0 and height_px > 0 else int(width_emu * 0.66)
        docpr_id = self.next_docpr_id
        self.next_docpr_id += 1
        return self._p_raw(self._drawing(rid, width_emu, height_emu, docpr_id), align=align, keep_next=keep_next)

    def _photo_pairs_global_table(self, rows, width_cm=8.0, pairs_per_page=3):
        """Tabla global de parejas en horizontal.

        v157: todas las parejas pertenecen a una única tabla. Cada pareja usa
        una fila para imágenes y otra fila independiente para pies de foto. Las
        imágenes se alinean abajo dentro de la celda y los pies quedan centrados
        con altura automática.
        """
        trs = []
        pair_index = 0
        total_pairs = (len(rows) + 1) // 2
        for start in range(0, len(rows), 2):
            pair_index += 1
            left = rows[start] if start < len(rows) else None
            right = rows[start + 1] if start + 1 < len(rows) else None
            left_img = self._photo_image_content(left, width_cm=width_cm) if left else self._p("", size=16)
            right_img = self._photo_image_content(right, width_cm=width_cm) if right else self._p("", size=16)
            left_cap = self._photo_caption_content(left) if left else self._p("", size=16, align="center")
            right_cap = self._photo_caption_content(right) if right else self._p("", size=16, align="center")
            trs.append(self._tr_cells([left_img, right_img], valign="bottom"))
            trs.append(self._tr_cells([left_cap, right_cap], valign="center"))
            if pairs_per_page and pair_index % pairs_per_page == 0 and pair_index < total_pairs:
                # Page break inside the global table: keeps one continuous table
                # while starting the next group of up to three pairs on a new page.
                trs.append(self._tr_page_break(columns=2))
        return self._table_xml(trs, columns=2)

    def _photo_vertical_global_table(self, rows, width_cm=12.0):
        """Compatibilidad interna: tabla global de fotografías en vertical."""
        trs = []
        for row in rows:
            trs.append(self._tr_single(self._photo_image_content(row, width_cm=width_cm), width_dxa="9000", valign="center", cant_split=True))
            trs.append(self._tr_single(self._photo_caption_content(row), width_dxa="9000", valign="center", cant_split=True))
        return self._table_xml(trs, columns=1)

    def _photo_vertical_pairs_global_table(self, rows, max_width_cm=12.0, min_width_cm=7.0):
        """Tabla global vertical manteniendo cada pareja junta sin corromper DOCX.

        v162: se elimina la tabla anidada de v161. Word puede considerar no
        legible un DOCX cuando una tabla completa se inserta directamente dentro
        de una celda generada a mano. Esta versión usa una única tabla plana:
        foto, pie, foto, pie. Para cada pareja se aplica cantSplit a las filas y
        keepNext a los párrafos internos, de modo que Word intente mantener las
        cuatro filas de la pareja en la misma página. El ancho se calcula por
        pareja y puede reducirse hasta min_width_cm si hace falta.
        """
        trs = []
        total_pairs = (len(rows) + 1) // 2
        pair_index = 0
        for start in range(0, len(rows), 2):
            pair_index += 1
            pair = [r for r in rows[start:start + 2] if r]
            width_cm = self._best_vertical_pair_width(pair, max_width_cm=max_width_cm, min_width_cm=min_width_cm)
            for idx, row in enumerate(pair):
                # keepNext en todas las filas salvo el último pie de la pareja.
                # cantSplit evita que Word parta una fila con imagen/pie.
                keep_next = not (idx == len(pair) - 1)
                trs.append(self._tr_single(
                    self._photo_image_content(row, width_cm=width_cm, keep_next=True),
                    width_dxa="9000", valign="center", cant_split=True
                ))
                trs.append(self._tr_single(
                    self._photo_caption_content(row, keep_next=keep_next),
                    width_dxa="9000", valign="center", cant_split=True
                ))
            if pair_index < total_pairs:
                # Separación ligera entre parejas sin forzar salto de página.
                trs.append(self._tr_single(self._p("", size=4), width_dxa="9000", valign="center"))
        return self._table_xml(trs, columns=1)

    def _best_vertical_pair_width(self, pair, max_width_cm=12.0, min_width_cm=7.0):
        """Devuelve el mayor ancho que permite conservar la pareja en página."""
        ratios = []
        for row in pair or []:
            path = row.get("path") if isinstance(row, dict) else None
            img = QImage(path) if path else QImage()
            if img.width() > 0 and img.height() > 0:
                ratios.append(float(img.height()) / float(img.width()))
            else:
                ratios.append(0.75)
        if not ratios:
            return max_width_cm
        # A4 vertical con márgenes del documento: se reserva espacio para los
        # pies, márgenes de tabla y tolerancia de Word.
        available_image_height_cm = 22.2
        required_width = available_image_height_cm / max(0.1, sum(ratios))
        return max(float(min_width_cm), min(float(max_width_cm), required_width))

    def _photo_image_content(self, row, width_cm, keep_next=False):
        return self._image_paragraph(row["path"], width_cm=width_cm, align="center", keep_next=keep_next)

    def _photo_caption_content(self, row, keep_next=False):
        cap_text = "Foto %s.    %s" % (row["num"], row["desc"]) if row.get("num") else row.get("desc", "")
        return self._p(cap_text, bold_num=True, size=16, align="center", keep_next=keep_next)

    def _table_xml(self, rows_xml, columns=2):
        grid = '<w:tblGrid>' + ''.join('<w:gridCol w:w="4500"/>' for _ in range(max(1, columns))) + '</w:tblGrid>'
        props = (
            '<w:tblPr>'
            '<w:tblW w:w="0" w:type="auto"/>'
            '<w:jc w:val="center"/>'
            '<w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/><w:insideH w:val="nil"/><w:insideV w:val="nil"/></w:tblBorders>'
            '<w:tblCellMar><w:left w:w="120" w:type="dxa"/><w:right w:w="120" w:type="dxa"/><w:top w:w="80" w:type="dxa"/><w:bottom w:w="80" w:type="dxa"/></w:tblCellMar>'
            '</w:tblPr>'
        )
        return '<w:tbl>' + props + grid + ''.join(rows_xml) + '</w:tbl>'

    def _tr(self, left, right):
        return self._tr_cells([left, right], valign="bottom")

    def _tr_cells(self, cells, valign="bottom", width_dxa="4500", cant_split=False):
        tr_pr = '<w:trPr><w:cantSplit/></w:trPr>' if cant_split else ''
        return '<w:tr>' + tr_pr + ''.join(self._tc(cell, width_dxa=width_dxa, valign=valign) for cell in cells) + '</w:tr>'

    def _tr_single(self, content, width_dxa="9000", valign="center", cant_split=False):
        tr_pr = '<w:trPr><w:cantSplit/></w:trPr>' if cant_split else ''
        return '<w:tr>' + tr_pr + self._tc(content, width_dxa=width_dxa, valign=valign) + '</w:tr>'

    def _tr_page_break(self, columns=2):
        span = max(1, int(columns or 1))
        tc_pr = '<w:tcPr><w:gridSpan w:val="%s"/><w:vAlign w:val="center"/></w:tcPr>' % span
        return '<w:tr><w:tc>' + tc_pr + self._page_break() + '</w:tc></w:tr>'

    def _tc(self, content, width_dxa="4500", valign="bottom"):
        # v156: w:vAlign controla la alineación vertical de la celda. En las
        # parejas en paralelo se usa bottom para que, si una foto es más baja
        # que la otra, ambas apoyen visualmente en la parte inferior.
        return '<w:tc><w:tcPr><w:tcW w:w="%s" w:type="dxa"/><w:vAlign w:val="%s"/></w:tcPr>' % (width_dxa, valign) + content + '</w:tc>'

    def _bullet_p(self, text, size=18):
        return self._p("•  " + str(text), size=size, align=None)

    def _p(self, text, bold=False, bold_num=False, size=20, align=None, keep_next=False):
        text = xml_escape(str(text))
        if bold_num and text.startswith("Foto ") and "." in text:
            prefix, rest = text.split(".", 1)
            return self._p_raw(self._run(prefix + ".", bold=True, size=size) + self._run(rest, bold=False, size=size), align=align, keep_next=keep_next)
        return self._p_raw(self._run(text, bold=bold, size=size), align=align, keep_next=keep_next)

    def _p_raw(self, raw_runs, align=None, keep_next=False):
        ppr_items = []
        if keep_next:
            ppr_items.append('<w:keepNext/>')
        if align:
            ppr_items.append('<w:jc w:val="%s"/>' % align)
        ppr = '<w:pPr>' + ''.join(ppr_items) + '</w:pPr>' if ppr_items else ''
        return '<w:p>' + ppr + raw_runs + '</w:p>' 

    def _run(self, text, bold=False, size=20):
        b = '<w:b/>' if bold else ''
        return '<w:r><w:rPr>%s<w:sz w:val="%s"/><w:szCs w:val="%s"/></w:rPr><w:t xml:space="preserve">%s</w:t></w:r>' % (b, size, size, text)

    def _page_break(self):
        return '<w:p><w:r><w:br w:type="page"/></w:r></w:p>'

    def _drawing(self, rid, cx, cy, docpr_id):
        name = "Imagen %s" % int(docpr_id)
        return '<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="%s" cy="%s"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:docPr id="%s" name="%s"/><wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/></wp:cNvGraphicFramePr><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="%s" name="%s"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%s" cy="%s"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>' % (cx, cy, docpr_id, name, docpr_id, name, rid, cx, cy)

    def _document_xml(self, body):
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>' + body + '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="900" w:right="900" w:bottom="900" w:left="900" w:header="450" w:footer="450" w:gutter="0"/></w:sectPr></w:body></w:document>'

    def _content_types(self):
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Default Extension="jpg" ContentType="image/jpeg"/><Default Extension="jpeg" ContentType="image/jpeg"/><Default Extension="tif" ContentType="image/tiff"/><Default Extension="tiff" ContentType="image/tiff"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>'

    def _root_rels(self):
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>'

    def _document_rels(self):
        items = ['<Relationship Id="%s" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="%s"/>' % (rid, target) for rid, target in self.rels]
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + ''.join(items) + '</Relationships>'

    def _core_props(self):
        now = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>Anejo Fotográfico</dc:title><dc:creator>OBRA_NUEVA</dc:creator><cp:lastModifiedBy>OBRA_NUEVA</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">' + now + '</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">' + now + '</dcterms:modified></cp:coreProperties>'

    def _app_props(self):
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>OBRA_NUEVA</Application></Properties>'

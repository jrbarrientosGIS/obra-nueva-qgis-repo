# -*- coding: utf-8 -*-
import os

from qgis.PyQt.QtWidgets import (
    QWidget, QLabel, QLineEdit, QPushButton,
    QFileDialog, QGridLayout, QVBoxLayout, QHBoxLayout,
    QMessageBox, QGroupBox, QTreeWidget, QTreeWidgetItem,
    QRadioButton, QButtonGroup
)
from qgis.PyQt.QtCore import Qt

from ..core.gpkg_loader import GpkgLoader
from ..core.settings_manager import SettingsManager


class CargaObraTab(QWidget):
    def __init__(self, iface, status_callback, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.status_callback = status_callback
        self.settings = SettingsManager()
        self.loader = GpkgLoader()
        self._last_asked_path = None
        self.setup_ui()
        self.restore_state()
        self._refresh_preview()

    def setup_ui(self):
        main_layout = QVBoxLayout(self)

        grid = QGridLayout()
        self.gpkg_label = QLabel('GeoPackage a cargar')
        self.gpkg_edit = QLineEdit()
        self.gpkg_btn = QPushButton('Examinar...')
        self.gpkg_btn.clicked.connect(self._select_gpkg)
        self.gpkg_edit.editingFinished.connect(self._on_gpkg_path_edited)
        grid.addWidget(self.gpkg_label, 0, 0)
        grid.addWidget(self.gpkg_edit, 0, 1)
        grid.addWidget(self.gpkg_btn, 0, 2)
        main_layout.addLayout(grid)

        mode_group = QGroupBox('Modo de carga')
        mode_layout = QVBoxLayout(mode_group)
        self.mode_status_label = QLabel('Selecciona un GeoPackage para elegir el modo de carga.')
        self.mode_status_label.setWordWrap(True)
        self.mode_visualizacion_radio = QRadioButton('Visualización (leyenda filtrada a los elementos presentes en cada capa)')
        self.mode_edicion_radio = QRadioButton('Edición (leyenda completa, permite añadir nuevos elementos a las capas)')
        self.mode_visualizacion_radio.setChecked(True)
        self.mode_button_group = QButtonGroup(self)
        self.mode_button_group.addButton(self.mode_visualizacion_radio)
        self.mode_button_group.addButton(self.mode_edicion_radio)
        self.mode_visualizacion_radio.toggled.connect(self._save_mode_state)
        mode_layout.addWidget(self.mode_status_label)
        mode_layout.addWidget(self.mode_visualizacion_radio)
        mode_layout.addWidget(self.mode_edicion_radio)
        change_mode_layout = QHBoxLayout()
        self.change_mode_btn = QPushButton('Cambiar modo...')
        self.change_mode_btn.clicked.connect(lambda: self._ask_load_mode(force=True))
        change_mode_layout.addWidget(self.change_mode_btn)
        change_mode_layout.addStretch()
        mode_layout.addLayout(change_mode_layout)
        main_layout.addWidget(mode_group)

        preview_group = QGroupBox('Capas operativas que se cargarán')
        preview_layout = QVBoxLayout(preview_group)

        tools_layout = QHBoxLayout()
        self.refresh_btn = QPushButton('Actualizar')
        self.refresh_btn.clicked.connect(self._refresh_preview)
        tools_layout.addWidget(self.refresh_btn)
        tools_layout.addStretch()
        preview_layout.addLayout(tools_layout)

        tree_actions = QHBoxLayout()
        self.select_all_btn = QPushButton('Seleccionar todas')
        self.select_all_btn.clicked.connect(self._select_all_layers)
        self.deselect_all_btn = QPushButton('Deseleccionar todas')
        self.deselect_all_btn.clicked.connect(self._deselect_all_layers)
        tree_actions.addWidget(self.select_all_btn)
        tree_actions.addWidget(self.deselect_all_btn)
        tree_actions.addStretch()
        preview_layout.addLayout(tree_actions)

        self.preview_tree = QTreeWidget()
        self.preview_tree.setHeaderHidden(True)
        preview_layout.addWidget(self.preview_tree)
        main_layout.addWidget(preview_group)

        options_group = QGroupBox('Opciones de carga')
        options_layout = QVBoxLayout(options_group)
        self.options_info = QLabel(
            'Solo se cargarán las capas *_Puntos, *_Lineas/*_Líneas y *_Poligonos/*_Polígonos.\n'
            'Se insertarán en un grupo con el mismo nombre que el GeoPackage seleccionado.'
        )
        self.options_info.setWordWrap(True)
        options_layout.addWidget(self.options_info)
        main_layout.addWidget(options_group)

        button_layout = QHBoxLayout()
        button_layout.addStretch()
        self.run_btn = QPushButton('①  Cargar')
        self.run_btn.setObjectName('run_btn')
        self.run_btn.clicked.connect(self._run)
        self.clear_btn = QPushButton('Limpiar')
        self.clear_btn.clicked.connect(self._clear_form)
        button_layout.addWidget(self.run_btn)
        button_layout.addWidget(self.clear_btn)
        main_layout.addLayout(button_layout)

    def _select_gpkg(self):
        last = self.settings.get('load/gpkg', '')
        file_path, _ = QFileDialog.getOpenFileName(self, 'Seleccionar GeoPackage', last, 'GeoPackage (*.gpkg)')
        if file_path:
            self.gpkg_edit.setText(file_path)
            self.settings.set('load/gpkg', file_path)
            self._last_asked_path = None
            self._ask_load_mode()
            self._refresh_preview()

    def _on_gpkg_path_edited(self):
        gpkg_path = self.gpkg_edit.text().strip()
        if gpkg_path and os.path.exists(gpkg_path) and gpkg_path != self._last_asked_path:
            self.settings.set('load/gpkg', gpkg_path)
            self._ask_load_mode()
        self._refresh_preview()

    def _ask_load_mode(self, force=False):
        gpkg_path = self.gpkg_edit.text().strip()
        if not gpkg_path or not os.path.exists(gpkg_path):
            if force:
                QMessageBox.information(self, 'Modo de carga', 'Selecciona primero un GeoPackage válido.')
            return

        self._last_asked_path = gpkg_path

        box = QMessageBox(self)
        box.setWindowTitle('Modo de carga')
        box.setIcon(QMessageBox.Icon.Question)
        box.setText(f'¿Cómo quieres cargar "{os.path.basename(gpkg_path)}"?')
        box.setInformativeText(
            'Edición: leyenda completa, permite añadir nuevos elementos a las capas.\n'
            'Visualización: leyenda filtrada a los elementos ya presentes en cada capa.'
        )
        edicion_btn = box.addButton('Edición', QMessageBox.ButtonRole.AcceptRole)
        visualizacion_btn = box.addButton('Visualización', QMessageBox.ButtonRole.AcceptRole)
        box.setDefaultButton(
            edicion_btn if self.mode_edicion_radio.isChecked() else visualizacion_btn
        )
        box.exec()

        if box.clickedButton() == edicion_btn:
            self.mode_edicion_radio.setChecked(True)
        else:
            self.mode_visualizacion_radio.setChecked(True)

    def _refresh_preview(self):
        self.preview_tree.clear()
        gpkg_path = self.gpkg_edit.text().strip()
        if not gpkg_path or not os.path.exists(gpkg_path):
            return
        try:
            selected = self.loader.find_operational_layers_strict(gpkg_path)
            obra_name = os.path.splitext(os.path.basename(gpkg_path))[0]
            if selected:
                root_item = QTreeWidgetItem([obra_name])
                root_item.setFlags(root_item.flags() & ~Qt.ItemFlag.ItemIsUserCheckable)
                self.preview_tree.addTopLevelItem(root_item)
                for layer_name in selected:
                    child = QTreeWidgetItem([layer_name])
                    child.setFlags(child.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    child.setCheckState(0, Qt.CheckState.Checked)
                    root_item.addChild(child)
                root_item.setExpanded(True)
                self.status_callback(f'ℹ {len(selected)} capas operativas detectadas en {os.path.basename(gpkg_path)}')
            else:
                self.preview_tree.clear()
                self.status_callback(f'⚠ No se detectaron capas operativas en {os.path.basename(gpkg_path)}')
        except Exception as exc:
            QMessageBox.warning(self, 'Lectura de capas', f'No se pudieron leer las capas del GeoPackage.\n\n{exc}')
            self.status_callback(f'✖ Error leyendo capas de {os.path.basename(gpkg_path)}: {exc}')

    def _clear_form(self):
        self.gpkg_edit.clear()
        self.preview_tree.clear()

    def _run(self):
        gpkg_path = self.gpkg_edit.text().strip()
        if not gpkg_path or not os.path.exists(gpkg_path):
            QMessageBox.warning(self, 'Validación', 'Selecciona un GeoPackage válido.')
            return

        try:
            detected_layers = self.loader.find_operational_layers_strict(gpkg_path)
            if not detected_layers:
                QMessageBox.warning(
                    self,
                    'Validación',
                    'No se encontraron capas operativas válidas (*_Puntos, *_Lineas, *_Poligonos).'
                )
                return

            selected_layers = self._selected_layer_names()
            if not selected_layers:
                QMessageBox.warning(
                    self,
                    'Validación',
                    'Selecciona al menos una capa para cargar.'
                )
                return

            prune_legend = not self.mode_edicion_radio.isChecked()
            layers = self.loader.load_selected_layers(
                gpkg_path,
                selected_layer_names=selected_layers,
                # no_duplicates=True: si el GeoPackage ya tiene estas capas
                # cargadas en el proyecto (p. ej. se acaba de abrir un
                # proyecto guardado que ya las traía), se REFRESCAN esas
                # mismas capas (campos nuevos, estilo, formulario) en vez
                # de crear copias nuevas y dejar las viejas sin actualizar
                # -- con no_duplicates=False, la capa que el usuario ya
                # tiene abierta en el lienzo nunca se toca.
                no_duplicates=True,
                skip_empty=False,
                prune_legend=prune_legend,
            )
            modo_txt = 'Edición (leyenda completa)' if not prune_legend else 'Visualización (leyenda filtrada)'
            self.status_callback(
                f'✔ Carga Obra: {len(layers)} capas operativas cargadas desde {os.path.basename(gpkg_path)} '
                f'[{modo_txt}]'
            )
        except Exception as exc:
            QMessageBox.critical(self, 'Error', str(exc))
            self.status_callback(f'✖ Error en Carga Obra: {exc}')


    def _selected_layer_names(self):
        selected = []
        root_item = self.preview_tree.topLevelItem(0)
        if root_item is None:
            return selected
        for i in range(root_item.childCount()):
            child = root_item.child(i)
            if child.checkState(0) == Qt.CheckState.Checked:
                selected.append(child.text(0))
        return selected

    def _select_all_layers(self):
        root_item = self.preview_tree.topLevelItem(0)
        if root_item is None:
            return
        for i in range(root_item.childCount()):
            root_item.child(i).setCheckState(0, Qt.CheckState.Checked)

    def _deselect_all_layers(self):
        root_item = self.preview_tree.topLevelItem(0)
        if root_item is None:
            return
        for i in range(root_item.childCount()):
            root_item.child(i).setCheckState(0, Qt.CheckState.Unchecked)

    def restore_state(self):
        self.gpkg_edit.setText(self.settings.get('load/gpkg', '') or '')
        saved_mode = self.settings.get('load/mode', 'visualizacion')
        if str(saved_mode) == 'edicion':
            self.mode_edicion_radio.setChecked(True)
        else:
            self.mode_visualizacion_radio.setChecked(True)

    def _save_mode_state(self):
        mode = 'visualizacion' if self.mode_visualizacion_radio.isChecked() else 'edicion'
        self.settings.set('load/mode', mode)
        gpkg_path = self.gpkg_edit.text().strip()
        nombre = os.path.basename(gpkg_path) if gpkg_path else None
        if mode == 'edicion':
            texto = 'Edición (leyenda completa)'
        else:
            texto = 'Visualización (leyenda filtrada)'
        if nombre:
            self.mode_status_label.setText(f'Modo seleccionado para "{nombre}": {texto}')
        else:
            self.mode_status_label.setText(f'Modo seleccionado: {texto}')

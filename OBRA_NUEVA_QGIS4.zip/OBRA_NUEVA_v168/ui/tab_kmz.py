# -*- coding: utf-8 -*-
import os
import re
import sqlite3
import shutil
import tempfile
import zipfile
from xml.sax.saxutils import escape

from qgis.PyQt.QtCore import Qt, QSize, QRect
from qgis.PyQt.QtGui import QColor, QFont, QFontMetrics, QImage, QPainter, QPen, QPixmap
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QFileDialog, QListWidget, QListWidgetItem, QMessageBox, QAbstractItemView,
    QCheckBox
)
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsWkbTypes, QgsFeatureRequest,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsSymbolLayerUtils, QgsRenderContext, QgsExpressionContext,
    QgsExpressionContextUtils, QgsUnitTypes
)

from ..core.settings_manager import SettingsManager


def qcolor_to_kml(color):
    if color is None:
        color = QColor(255, 255, 255, 255)
    return "{:02x}{:02x}{:02x}{:02x}".format(color.alpha(), color.blue(), color.green(), color.red())


class KmzTab(QWidget):
    def __init__(self, iface, status_callback, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.status_callback = status_callback
        self.settings = SettingsManager()
        self._build_ui()
        self._restore_state()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        gpkg_row = QHBoxLayout()
        gpkg_row.addWidget(QLabel("GeoPackage:"))
        self.gpkg_edit = QLineEdit()
        gpkg_row.addWidget(self.gpkg_edit)
        self.gpkg_btn = QPushButton("…")
        self.gpkg_btn.setFixedWidth(36)
        gpkg_row.addWidget(self.gpkg_btn)
        layout.addLayout(gpkg_row)

        layout.addWidget(QLabel("Capas a exportar:"))
        self.layer_list = QListWidget()
        self.layer_list.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        layout.addWidget(self.layer_list)

        btns = QHBoxLayout()
        self.select_all_btn = QPushButton("Seleccionar todo")
        self.clear_selection_btn = QPushButton("Limpiar")
        btns.addWidget(self.select_all_btn)
        btns.addWidget(self.clear_selection_btn)
        btns.addStretch(1)
        layout.addLayout(btns)

        out_row = QHBoxLayout()
        out_row.addWidget(QLabel("Carpeta de salida:"))
        self.out_edit = QLineEdit()
        out_row.addWidget(self.out_edit)
        self.out_btn = QPushButton("…")
        self.out_btn.setFixedWidth(36)
        out_row.addWidget(self.out_btn)
        layout.addLayout(out_row)

        # V202: la leyenda del KMZ es la del GeoPackage (mismos símbolos,
        # textos y orden). Por defecto solo con las categorías que tienen
        # elementos en lo exportado; marcado, con todas las del GeoPackage.
        self.full_legend_chk = QCheckBox("Leyenda completa del GeoPackage (incluir también categorías sin elementos)")
        layout.addWidget(self.full_legend_chk)

        footer = QHBoxLayout()
        footer.addStretch(1)
        self.export_btn = QPushButton("1)  Exportar")
        self.export_btn.setObjectName("run_btn")
        self.reset_btn = QPushButton("Limpiar formulario")
        footer.addWidget(self.export_btn)
        footer.addWidget(self.reset_btn)
        layout.addLayout(footer)

        self.gpkg_btn.clicked.connect(self.choose_gpkg)
        self.out_btn.clicked.connect(self.choose_output)
        self.select_all_btn.clicked.connect(self.select_all)
        self.clear_selection_btn.clicked.connect(self.clear_all)
        self.gpkg_edit.textChanged.connect(self.load_layers)
        self.export_btn.clicked.connect(self._do_export)
        self.reset_btn.clicked.connect(self._reset_form)

    def choose_gpkg(self):
        last = self.settings.get('kmz/input_gpkg', '') or ''
        path, _ = QFileDialog.getOpenFileName(self, "Seleccionar GeoPackage", last, "GeoPackage (*.gpkg)")
        if path:
            self.gpkg_edit.setText(path)
            self.settings.set('kmz/input_gpkg', path)

    def choose_output(self):
        last = self.settings.get('kmz/output_dir', '') or ''
        path = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta de salida", last)
        if path:
            self.out_edit.setText(path)
            self.settings.set('kmz/output_dir', path)

    def select_all(self):
        for i in range(self.layer_list.count()):
            self.layer_list.item(i).setCheckState(Qt.CheckState.Checked)

    def clear_all(self):
        for i in range(self.layer_list.count()):
            self.layer_list.item(i).setCheckState(Qt.CheckState.Unchecked)

    def _reset_form(self):
        self.gpkg_edit.clear()
        self.layer_list.clear()

    def _restore_state(self):
        self.gpkg_edit.setText(self.settings.get('kmz/input_gpkg', '') or '')
        self.out_edit.setText(self.settings.get('kmz/output_dir', '') or '')
        full = self.settings.get('kmz/full_legend', False)
        self.full_legend_chk.setChecked(str(full).lower() in ('true', '1'))
        if self.gpkg_edit.text().strip():
            self.load_layers()

    def _safe_text(self, value):
        if value is None:
            return ""
        # V201: fechas en formato legible (antes salía "PyQt5.QtCore.QDate(...)")
        # y valores nulos de QGIS como texto vacío (antes salía "NULL").
        try:
            from qgis.PyQt.QtCore import QDate, QDateTime, QTime
            if isinstance(value, QDateTime):
                return value.toString('dd/MM/yyyy HH:mm') if value.isValid() else ""
            if isinstance(value, QDate):
                return value.toString('dd/MM/yyyy') if value.isValid() else ""
            if isinstance(value, QTime):
                return value.toString('HH:mm') if value.isValid() else ""
        except Exception:
            pass
        try:
            if not isinstance(value, str) and hasattr(value, 'isNull') and value.isNull():
                return ""
        except Exception:
            pass
        try:
            return str(value)
        except Exception:
            return ""

    def _normalize(self, text):
        text = self._safe_text(text).lower()
        for k, v in {"á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u", "ñ": "n"}.items():
            text = text.replace(k, v)
        return re.sub(r'[^a-z0-9]+', '', text)

    def _log(self, message):
        if self.status_callback:
            self.status_callback(message)

    def load_layers(self):
        self.layer_list.clear()
        gpkg = self.gpkg_edit.text().strip()
        if not gpkg or not os.path.exists(gpkg):
            return
        try:
            con = sqlite3.connect(gpkg)
            cur = con.cursor()
            rows = cur.execute(
                """
                SELECT table_name
                FROM gpkg_contents
                WHERE data_type='features'
                ORDER BY table_name
                """
            ).fetchall()
            con.close()
            for row in rows:
                name = row[0]
                lname = self._safe_text(name).strip().lower()
                if lname == "leyenda":
                    continue
                item = QListWidgetItem(name)
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(Qt.CheckState.Checked if name.startswith("SDON_") else Qt.CheckState.Unchecked)
                self.layer_list.addItem(item)
            self._log(f"✔ Capas KMZ leídas desde {os.path.basename(gpkg)}")
        except Exception as e:
            QMessageBox.warning(self, "Lectura de capas", f"No se pudieron leer las capas del GeoPackage.\n\n{self._safe_text(e)}")
            self._log(f"✖ Error leyendo capas KMZ: {self._safe_text(e)}")

    def _selected_layers(self):
        names = []
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            if item.checkState() == Qt.CheckState.Checked:
                names.append(item.text())
        return names

    def _resolve_layer(self, gpkg, layer_name):
        """V202: la simbología sale del estilo guardado en el GeoPackage
        (tabla layer_styles), que es su leyenda "oficial", aunque la capa
        esté cargada en el lienzo con otra simbología (p. ej. recortada en
        modo Visualización). Solo si el GeoPackage no guarda estilo para esa
        tabla se usa la capa del lienzo, si está cargada."""
        uri = f"{gpkg}|layername={layer_name}"
        qml = self._saved_style_qml(gpkg, layer_name)
        if qml:
            layer = QgsVectorLayer(uri, layer_name, "ogr")
            if layer and layer.isValid():
                try:
                    from qgis.PyQt.QtXml import QDomDocument
                    doc = QDomDocument("qgis")
                    doc.setContent(qml)
                    layer.importNamedStyle(doc)
                except Exception as exc:
                    self._log(f"⚠ No se pudo aplicar la leyenda guardada de {layer_name}: {self._safe_text(exc)}")
                return layer
        try:
            target = os.path.normcase(os.path.abspath(gpkg))
            for lyr in QgsProject.instance().mapLayers().values():
                if lyr and lyr.isValid() and lyr.name() == layer_name:
                    src = self._safe_text(lyr.source()).split("|")[0]
                    if os.path.normcase(os.path.abspath(src)) == target:
                        return lyr
        except Exception:
            pass
        layer = QgsVectorLayer(uri, layer_name, "ogr")
        return layer if layer and layer.isValid() else None

    def _saved_style_qml(self, gpkg, layer_name):
        try:
            con = sqlite3.connect(gpkg)
            try:
                if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='layer_styles'").fetchone():
                    return None
                row = con.execute(
                    "SELECT styleQML FROM layer_styles WHERE lower(f_table_name)=lower(?) "
                    "ORDER BY useAsDefault DESC, rowid ASC LIMIT 1",
                    (layer_name,),
                ).fetchone()
                return row[0] if row and row[0] else None
            finally:
                con.close()
        except Exception:
            return None

    def _read_clave_map(self, gpkg):
        mapping = {}
        try:
            con = sqlite3.connect(gpkg)
            cur = con.cursor()
            for row in cur.execute('SELECT "key", "TIPO" FROM "CLAVE"'):
                k = self._safe_text(row[0]).strip()
                v = self._safe_text(row[1]).strip()
                if k:
                    mapping[k] = v
                    if k.endswith('.0'):
                        mapping[k[:-2]] = v
            con.close()
        except Exception:
            pass
        return mapping

    def _field_name(self, layer, candidates):
        names = [f.name() for f in layer.fields()]
        normalized = {self._normalize(n): n for n in names}
        for c in candidates:
            if c in names:
                return c
            nc = self._normalize(c)
            if nc in normalized:
                return normalized[nc]
        return None

    def _resolve_name(self, feature, layer):
        f_ambito_txt = self._field_name(layer, ["ambito_txt"])
        f_ambito = self._field_name(layer, ["Ámbito", "Ambito"])
        for field_name in [f_ambito_txt, f_ambito]:
            if field_name:
                value = self._safe_text(feature[field_name]).strip()
                if value:
                    return value
        return f"Elemento {feature.id()}"

    def _resolve_tipo(self, feature, layer, clave_map):
        f_tipo_txt = self._field_name(layer, ["tipo_txt"])
        if f_tipo_txt:
            value = self._safe_text(feature[f_tipo_txt]).strip()
            if value:
                return value
        f_tipo = self._field_name(layer, ["Tipo"])
        if f_tipo:
            raw = self._safe_text(feature[f_tipo]).strip()
            if raw in clave_map:
                return clave_map[raw]
            try:
                raw2 = str(float(raw))
                if raw2 in clave_map:
                    return clave_map[raw2]
                if raw2.endswith('.0') and raw2[:-2] in clave_map:
                    return clave_map[raw2[:-2]]
            except Exception:
                pass
            return raw
        return ""

    def _get_feature_ambito(self, feature):
        fields = [f.name() for f in feature.fields()]
        for candidate in ('ambito_txt', 'Ámbito', 'Ambito', 'ambito'):
            if candidate in fields:
                value = feature[candidate]
                return self._safe_text(value) if value not in (None, '') else 'Sin ámbito'
        return 'Sin ámbito'

    # ── V202: leyenda y estilos tomados de la simbología del GeoPackage ──
    @staticmethod
    def _enum_int(value):
        try:
            return int(value)
        except Exception:
            return getattr(value, "value", value)

    def _unit_px(self, value, unit):
        """Grosor de QGIS (mm, puntos, píxeles...) a píxeles para el KML."""
        try:
            v = float(value)
        except Exception:
            v = 0.26
        try:
            code = (QgsUnitTypes.encodeUnit(unit) or "").lower()
        except Exception:
            code = "mm"
        if code == "pixel":
            px = v
        elif code == "point":
            px = v * 96.0 / 72.0
        elif code == "inch":
            px = v * 96.0
        elif code == "mm":
            px = v * 96.0 / 25.4
        else:
            px = 2.0
        return max(1.0, round(px, 1))

    @staticmethod
    def _with_opacity(color, opacity):
        c = QColor(color)
        try:
            c.setAlpha(int(round(c.alpha() * float(opacity))))
        except Exception:
            pass
        return c

    def _layer_symbology(self, layer):
        """Prepara el renderizador de la capa (sea categorizado, graduado,
        por reglas o de símbolo único) y su leyenda en el mismo orden y con
        los mismos textos que en QGIS."""
        renderer = layer.renderer()
        if renderer is None:
            return None
        renderer = renderer.clone()
        ctx = QgsRenderContext()
        ectx = QgsExpressionContext()
        try:
            ectx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
        except Exception:
            pass
        ctx.setExpressionContext(ectx)
        items = []
        for it in renderer.legendSymbolItems():
            sym = it.symbol()
            if sym is None:
                continue
            label = self._safe_text(it.label()).strip()
            items.append({"key": it.ruleKey(), "label": label, "symbol": sym.clone()})
        if len(items) == 1 and not items[0]["label"]:
            items[0]["label"] = layer.name()
        try:
            renderer.startRender(ctx, layer.fields())
        except Exception:
            pass
        return {
            "renderer": renderer,
            "ctx": ctx,
            "items": items,
            "index": {d["key"]: i for i, d in enumerate(items)},
        }

    def _other_symbol(self, geom_type):
        try:
            from qgis.core import QgsSymbol
            sym = QgsSymbol.defaultSymbol(geom_type)
            if sym is None:
                return None
            if geom_type == QgsWkbTypes.PointGeometry:
                sym.setColor(QColor(230, 60, 60))
            elif geom_type == QgsWkbTypes.LineGeometry:
                sym.setColor(QColor(90, 90, 90))
            else:
                sym.setColor(QColor(200, 200, 200, 120))
            return sym
        except Exception:
            return None

    def _end_symbology(self, symbology):
        if symbology:
            try:
                symbology["renderer"].stopRender(symbology["ctx"])
            except Exception:
                pass

    def _feature_legend_index(self, symbology, feature):
        """Posición en la leyenda de la categoría con la que QGIS dibuja la
        entidad, o None si no corresponde a ninguna."""
        if not symbology or not symbology["items"]:
            return None
        ctx = symbology["ctx"]
        try:
            ctx.expressionContext().setFeature(feature)
        except Exception:
            pass
        try:
            keys = symbology["renderer"].legendKeysForFeature(feature, ctx)
        except Exception:
            keys = set()
        best = None
        for k in keys or ():
            i = symbology["index"].get(k)
            if i is not None and (best is None or i < best):
                best = i
        return best

    def _style_from_symbol(self, sym, geom_type):
        """Traduce un símbolo de QGIS al estilo KML más parecido."""
        if geom_type == QgsWkbTypes.PointGeometry:
            try:
                pix = QgsSymbolLayerUtils.symbolPreviewPixmap(sym, QSize(32, 32), 1)
                png_bytes = self._pixmap_to_png_bytes(pix)
                if png_bytes:
                    return {"kind": "point", "png_bytes": png_bytes}
            except Exception:
                pass
            return self._fallback_point_style()

        opacity = sym.opacity() if hasattr(sym, "opacity") else 1.0
        layers = [sym.symbolLayer(i) for i in range(sym.symbolLayerCount())]
        layers = [sl for sl in layers if sl is not None and getattr(sl, "enabled", lambda: True)()]

        if geom_type == QgsWkbTypes.LineGeometry:
            color, width = None, None
            for sl in layers:
                if not (hasattr(sl, "color") and hasattr(sl, "width")):
                    continue
                if hasattr(sl, "penStyle") and self._enum_int(sl.penStyle()) == 0:
                    continue
                w = self._unit_px(sl.width(), sl.widthUnit()) if hasattr(sl, "widthUnit") else 1.5
                color = QColor(sl.color())
                width = max(width or 0, w)
            if color is None:
                color = QColor(sym.color()) if hasattr(sym, "color") else QColor(0, 0, 0)
                width = 1.5
            return {"kind": "line", "color": self._with_opacity(color, opacity), "width": width}

        if geom_type == QgsWkbTypes.PolygonGeometry:
            fill, stroke, width = None, None, None
            for sl in layers:
                cls = sl.__class__.__name__
                if any(t in cls for t in ("Pattern", "Hatch", "Gradient", "Shapeburst", "RasterFill", "RandomMarker")):
                    # Rellenos que KML no puede dibujar: color semitransparente.
                    if fill is None and hasattr(sl, "color"):
                        c = QColor(sl.color())
                        c.setAlpha(min(c.alpha(), 110))
                        fill = c
                elif hasattr(sl, "brushStyle") and hasattr(sl, "fillColor"):
                    if self._enum_int(sl.brushStyle()) != 0:
                        fill = QColor(sl.fillColor())
                    if hasattr(sl, "strokeStyle") and self._enum_int(sl.strokeStyle()) != 0:
                        stroke = QColor(sl.strokeColor())
                        width = self._unit_px(sl.strokeWidth(), sl.strokeWidthUnit())
                elif hasattr(sl, "penStyle") and hasattr(sl, "width") and hasattr(sl, "color"):
                    # Contorno dibujado con una capa de línea.
                    if self._enum_int(sl.penStyle()) != 0:
                        stroke = QColor(sl.color())
                        width = self._unit_px(sl.width(), sl.widthUnit())
            return {
                "kind": "polygon",
                "fill": self._with_opacity(fill, opacity) if fill is not None else None,
                "stroke": self._with_opacity(stroke, opacity) if stroke is not None else None,
                "width": width or 1.0,
            }

        return {"kind": "generic"}

    def _pixmap_to_png_bytes(self, pixmap):
        image = pixmap.toImage()
        if image.size() != QSize(32, 32):
            image = image.scaled(32, 32, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        try:
            from qgis.PyQt.QtCore import QByteArray, QBuffer, QIODevice
            qba = QByteArray()
            buff = QBuffer(qba)
            buff.open(QIODevice.OpenModeFlag.WriteOnly)
            image.save(buff, "PNG")
            data = bytes(qba)
            buff.close()
            return data
        except Exception:
            return b""

    def _fallback_point_style(self):
        pix = QPixmap(32, 32)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix)
        p.setPen(QPen(QColor(20, 20, 20), 2))
        p.setBrush(QColor(230, 60, 60, 220))
        p.drawEllipse(6, 6, 20, 20)
        p.end()
        return {"kind": "point", "png_bytes": self._pixmap_to_png_bytes(pix)}

    def _build_style_xml(self, style_id, style_info, assets_dir):
        kind = style_info.get("kind")
        if kind == "point":
            icon_name = f"{style_id}.png"
            icon_path = os.path.join(assets_dir, icon_name)
            with open(icon_path, 'wb') as f:
                f.write(style_info.get('png_bytes', b''))
            return (
                f'<Style id="{escape(style_id)}"><IconStyle>'
                '<scale>1.0</scale>'
                f'<Icon><href>files/{escape(icon_name)}</href></Icon>'
                '<hotSpot x="0.5" y="0.5" xunits="fraction" yunits="fraction"/>'
                '</IconStyle></Style>'
            )

        if kind == "line":
            color = qcolor_to_kml(style_info.get("color"))
            width = style_info.get("width", 1.5)
            return f'<Style id="{escape(style_id)}"><LineStyle><color>{color}</color><width>{width}</width></LineStyle></Style>'

        if kind == "polygon":
            fill_c = style_info.get("fill")
            stroke_c = style_info.get("stroke")
            has_fill = 1 if fill_c is not None and fill_c.alpha() > 0 else 0
            has_outline = 1 if stroke_c is not None and stroke_c.alpha() > 0 else 0
            fill = qcolor_to_kml(fill_c if fill_c is not None else QColor(0, 0, 0, 0))
            stroke = qcolor_to_kml(stroke_c if stroke_c is not None else QColor(0, 0, 0, 0))
            width = style_info.get("width", 1.0)
            return (
                f'<Style id="{escape(style_id)}">'
                f'<LineStyle><color>{stroke}</color><width>{width}</width></LineStyle>'
                f'<PolyStyle><color>{fill}</color><fill>{has_fill}</fill><outline>{has_outline}</outline></PolyStyle>'
                '</Style>'
            )

        return f'<Style id="{escape(style_id)}"></Style>'

    def _build_extended_data(self, feature, layer, tipo, name):
        parts = ['<ExtendedData>']
        for fld in layer.fields():
            fname = fld.name()
            if self._normalize(fname) in ('geom', 'geometry'):
                continue
            val = feature[fname]
            if self._normalize(fname) == self._normalize('Tipo'):
                val = tipo
            if self._normalize(fname) in (self._normalize('Ámbito'), self._normalize('Ambito')):
                val = name
            parts.append(f'<Data name="{escape(fname)}"><value>{escape(self._safe_text(val))}</value></Data>')
        parts.append(f'<Data name="Name"><value>{escape(name)}</value></Data>')
        parts.append('</ExtendedData>')
        return ''.join(parts)

    def _coords(self, pt):
        return f"{pt.x():.8f},{pt.y():.8f},0"

    def _polygon_to_kml(self, poly):
        if not poly:
            return ""
        outer = poly[0]
        if not outer:
            return ""
        outer_coords = ' '.join(self._coords(p) for p in outer)
        inners = []
        for ring in poly[1:]:
            if not ring:
                continue
            ring_coords = ' '.join(self._coords(p) for p in ring)
            inners.append(f'<innerBoundaryIs><LinearRing><coordinates>{ring_coords}</coordinates></LinearRing></innerBoundaryIs>')
        return (
            '<Polygon><tessellate>1</tessellate>'
            f'<outerBoundaryIs><LinearRing><coordinates>{outer_coords}</coordinates></LinearRing></outerBoundaryIs>'
            f"{''.join(inners)}</Polygon>"
        )

    def _geometry_to_kml(self, geom):
        geom_type = QgsWkbTypes.geometryType(geom.wkbType())
        multi = QgsWkbTypes.isMultiType(geom.wkbType())

        if geom_type == QgsWkbTypes.PointGeometry:
            if multi:
                pts = geom.asMultiPoint()
                if not pts:
                    return ""
                if len(pts) == 1:
                    return f'<Point><coordinates>{self._coords(pts[0])}</coordinates></Point>'
                inner = ''.join(f'<Point><coordinates>{self._coords(p)}</coordinates></Point>' for p in pts)
                return f'<MultiGeometry>{inner}</MultiGeometry>'
            pt = geom.asPoint()
            return f'<Point><coordinates>{self._coords(pt)}</coordinates></Point>'

        if geom_type == QgsWkbTypes.LineGeometry:
            if multi:
                lines = geom.asMultiPolyline()
                inner = []
                for line in lines:
                    if line:
                        coords = ' '.join(self._coords(p) for p in line)
                        inner.append(f'<LineString><tessellate>1</tessellate><coordinates>{coords}</coordinates></LineString>')
                return f"<MultiGeometry>{''.join(inner)}</MultiGeometry>" if inner else ""
            line = geom.asPolyline()
            if not line:
                return ""
            coords = ' '.join(self._coords(p) for p in line)
            return f'<LineString><tessellate>1</tessellate><coordinates>{coords}</coordinates></LineString>'

        if geom_type == QgsWkbTypes.PolygonGeometry:
            if multi:
                polys = geom.asMultiPolygon()
                inner = [self._polygon_to_kml(poly) for poly in polys if poly]
                inner = [x for x in inner if x]
                return f"<MultiGeometry>{''.join(inner)}</MultiGeometry>" if inner else ""
            poly = geom.asPolygon()
            return self._polygon_to_kml(poly)

        return ""

    def _create_legend_png(self, sections, assets_dir):
        """V202: una sola imagen de leyenda para todo el KMZ, con un apartado
        por capa y, en cada uno, los símbolos y textos de la leyenda del
        GeoPackage en su mismo orden. sections = [(nombre_capa, [(símbolo, texto), ...]), ...]"""
        sections = [(name, rows) for name, rows in sections if rows]
        if not sections:
            return None
        title_font = QFont("Arial", 10, QFont.Weight.Bold)
        text_font = QFont("Arial", 9)
        fm_title = QFontMetrics(title_font)
        fm_text = QFontMetrics(text_font)
        icon = 20
        row_h = 24
        title_h = 26
        pad = 10
        text_w = 0
        for name, rows in sections:
            text_w = max(text_w, fm_title.horizontalAdvance(self._safe_text(name)) - icon - 8)
            for _, label in rows:
                text_w = max(text_w, fm_text.horizontalAdvance(self._safe_text(label)))
        width = int(min(720, max(240, pad * 2 + icon + 8 + text_w + 4)))
        height = pad * 2 + sum(title_h + row_h * len(rows) for _, rows in sections) + 6 * (len(sections) - 1)

        image = QImage(width, height, QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(QColor(255, 255, 255, 235))
        painter = QPainter(image)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        y = pad
        for name, rows in sections:
            painter.setPen(QPen(QColor(40, 40, 40)))
            painter.setFont(title_font)
            painter.drawText(QRect(pad, y, width - 2 * pad, title_h), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self._safe_text(name))
            y += title_h
            painter.setFont(text_font)
            for sym, label in rows:
                try:
                    pix = QgsSymbolLayerUtils.symbolPreviewPixmap(sym, QSize(icon, icon), 0)
                    painter.drawPixmap(pad, y + (row_h - icon) // 2, pix)
                except Exception:
                    pass
                painter.setPen(QPen(QColor(40, 40, 40)))
                painter.drawText(
                    QRect(pad + icon + 8, y, width - pad * 2 - icon - 8, row_h),
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                    fm_text.elidedText(self._safe_text(label), Qt.TextElideMode.ElideRight, width - pad * 2 - icon - 8),
                )
                y += row_h
            y += 6
        painter.end()

        path = os.path.join(assets_dir, 'leyenda.png')
        image.save(path, 'PNG')
        return path

    def _export_selected_layers_to_one_kmz(self, layers, gpkg, kmz_path, clave_map, full_legend=False):
        tmpdir = tempfile.mkdtemp(prefix='sdon_kmz_')
        try:
            assets_dir = os.path.join(tmpdir, 'files')
            os.makedirs(assets_dir, exist_ok=True)
            style_defs = {}
            all_folder_xml = []
            legend_sections = []

            for layer_idx, layer in enumerate(layers):
                if self._safe_text(layer.name()).strip().lower() == 'leyenda':
                    continue

                transform = None
                dest_crs = QgsCoordinateReferenceSystem('EPSG:4326')
                try:
                    if layer.crs().isValid() and layer.crs() != dest_crs:
                        transform = QgsCoordinateTransform(layer.crs(), dest_crs, QgsProject.instance())
                except Exception:
                    transform = None

                geom_type = QgsWkbTypes.geometryType(layer.wkbType())
                symbology = self._layer_symbology(layer)
                items = symbology["items"] if symbology else []
                used = set()
                fallback_used = False
                try:
                    by_ambito = {}
                    for feature in layer.getFeatures(QgsFeatureRequest()):
                        geom = feature.geometry()
                        if geom is None or geom.isEmpty():
                            continue
                        idx = self._feature_legend_index(symbology, feature)
                        if idx is not None:
                            style_id = f's{layer_idx}_{idx}'
                            if style_id not in style_defs:
                                style_info = self._style_from_symbol(items[idx]["symbol"], geom_type)
                                style_defs[style_id] = self._build_style_xml(style_id, style_info, assets_dir)
                            used.add(idx)
                        else:
                            # Entidad que no encaja en ninguna categoría de la
                            # leyenda: se exporta igualmente con un estilo neutro.
                            style_id = f's{layer_idx}_otros'
                            if style_id not in style_defs:
                                if geom_type == QgsWkbTypes.PointGeometry:
                                    style_info = self._fallback_point_style()
                                elif geom_type == QgsWkbTypes.LineGeometry:
                                    style_info = {"kind": "line", "color": QColor(90, 90, 90), "width": 1.5}
                                else:
                                    style_info = {"kind": "polygon", "fill": QColor(200, 200, 200, 120),
                                                  "stroke": QColor(90, 90, 90), "width": 1.0}
                                style_defs[style_id] = self._build_style_xml(style_id, style_info, assets_dir)
                            fallback_used = True

                        if transform:
                            try:
                                geom.transform(transform)
                            except Exception:
                                pass

                        name = self._resolve_name(feature, layer)
                        tipo = self._resolve_tipo(feature, layer, clave_map)
                        ambito = self._get_feature_ambito(feature) or name or 'Sin ámbito'

                        ext_data = self._build_extended_data(feature, layer, tipo, name)
                        geom_xml = self._geometry_to_kml(geom)
                        if not geom_xml:
                            continue

                        placemark = (
                            '<Placemark>'
                            f'<name>{escape(name)}</name>'
                            f'<styleUrl>#{escape(style_id)}</styleUrl>'
                            f'{ext_data}{geom_xml}'
                            '</Placemark>'
                        )
                        by_ambito.setdefault(ambito, []).append(placemark)
                finally:
                    self._end_symbology(symbology)

                rows = [
                    (it["symbol"], it["label"])
                    for i, it in enumerate(items)
                    if full_legend or i in used
                ]
                if fallback_used:
                    self._log(f'ℹ KMZ: {layer.name()} tiene elementos que no corresponden a ninguna categoría de su leyenda; se exportan con un estilo gris.')
                    other = self._other_symbol(geom_type)
                    if other is not None:
                        rows.append((other, 'Otros (sin categoría en la leyenda)'))
                legend_sections.append((layer.name(), rows))

                ambito_xml = []
                for ambito_name in sorted(by_ambito.keys()):
                    ambito_xml.append(f'<Folder><name>{escape(ambito_name)}</name>{"".join(by_ambito[ambito_name])}</Folder>')

                if ambito_xml:
                    all_folder_xml.append(
                        f'<Folder><name>{escape(layer.name())}</name>{"".join(ambito_xml)}</Folder>'
                    )

            overlay_block = ''
            legend_path = self._create_legend_png(legend_sections, assets_dir)
            if legend_path:
                overlay_block = (
                    '<ScreenOverlay>'
                    '<name>Leyenda</name>'
                    f'<Icon><href>files/{os.path.basename(legend_path)}</href></Icon>'
                    '<overlayXY x="0" y="1" xunits="fraction" yunits="fraction"/>'
                    '<screenXY x="0.02" y="0.98" xunits="fraction" yunits="fraction"/>'
                    '<rotationXY x="0" y="0" xunits="fraction" yunits="fraction"/>'
                    '<size x="0" y="0" xunits="pixels" yunits="pixels"/>'
                    '</ScreenOverlay>'
                )

            style_block = '\n'.join(style_defs.values())
            folder_block = '\n'.join(all_folder_xml)
            kml = (
                '<?xml version="1.0" encoding="UTF-8"?>\n'
                '<kml xmlns="http://www.opengis.net/kml/2.2">\n'
                '<Document>\n'
                f'<name>{escape(os.path.basename(kmz_path))}</name>\n'
                f'{style_block}\n'
                f'{overlay_block}\n'
                f'{folder_block}\n'
                '</Document>\n'
                '</kml>\n'
            )
            doc_kml = os.path.join(tmpdir, 'doc.kml')
            with open(doc_kml, 'w', encoding='utf-8') as f:
                f.write(kml)

            with zipfile.ZipFile(kmz_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                zf.write(doc_kml, 'doc.kml')
                for folder, _, files in os.walk(assets_dir):
                    for fn in files:
                        full = os.path.join(folder, fn)
                        rel = os.path.relpath(full, tmpdir)
                        zf.write(full, rel)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def _do_export(self):
        gpkg = self.gpkg_edit.text().strip()
        out_dir = self.out_edit.text().strip()
        selected_names = self._selected_layers()
        if not gpkg or not os.path.exists(gpkg):
            QMessageBox.warning(self, 'KMZ', 'Selecciona un GeoPackage válido.')
            return
        if not out_dir:
            QMessageBox.warning(self, 'KMZ', 'Selecciona un directorio de salida.')
            return
        if not selected_names:
            QMessageBox.warning(self, 'KMZ', 'Selecciona al menos una capa.')
            return

        try:
            os.makedirs(out_dir, exist_ok=True)
        except Exception as exc:
            QMessageBox.warning(self, 'KMZ', f'No se puede usar la carpeta de salida:\n{out_dir}\n\n{exc}')
            return
        self.settings.set('kmz/input_gpkg', gpkg)
        self.settings.set('kmz/output_dir', out_dir)
        full_legend = self.full_legend_chk.isChecked()
        self.settings.set('kmz/full_legend', full_legend)

        clave_map = self._read_clave_map(gpkg)
        layers = []
        for layer_name in selected_names:
            layer = self._resolve_layer(gpkg, layer_name)
            if layer is None or not layer.isValid():
                QMessageBox.warning(self, 'KMZ', f'No se pudo cargar la capa: {layer_name}')
                continue
            if self._safe_text(layer.name()).strip().lower() != 'leyenda':
                layers.append(layer)

        if not layers:
            QMessageBox.warning(self, 'KMZ', 'No se pudo cargar ninguna capa seleccionada.')
            return

        gpkg_base = re.sub(r'[^A-Za-z0-9._-]+', '_', os.path.splitext(os.path.basename(gpkg))[0]).strip('._-') or 'export'
        kmz_path = os.path.join(out_dir, f'{gpkg_base}_export.kmz')
        try:
            self._export_selected_layers_to_one_kmz(layers, gpkg, kmz_path, clave_map, full_legend=full_legend)
            self._log(f'✔ KMZ generado: {kmz_path}')
            QMessageBox.information(self, 'KMZ', f'Exportación completada.\nKMZ generado:\n{kmz_path}')
        except Exception as e:
            self._log(f'✖ Error exportando KMZ: {self._safe_text(e)}')
            QMessageBox.critical(self, 'Error', self._safe_text(e))

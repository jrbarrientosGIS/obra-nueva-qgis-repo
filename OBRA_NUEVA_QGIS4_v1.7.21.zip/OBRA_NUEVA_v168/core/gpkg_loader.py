# -*- coding: utf-8 -*-
import os

from qgis.core import (
    QgsEditorWidgetSetup, QgsProject, QgsVectorLayer, QgsWkbTypes,
)

from .gpkg_utils import GpkgIntrospector, normalize_text
from .ogr_layer_utils import project_layers_for_gpkg, split_ogr_source
from ..helpers.file_utils import normalize_base_name
from ..helpers.logging_utils import log_info, log_warning
from .legend_pruner import LegendPruner
from .form_customizer import IncidenciaFormCustomizer


# Propiedad que recuerda en cada capa si se cargó en modo "Visualización"
# (leyenda recortada) o "Edición" (leyenda completa), para respetarlo cuando
# la capa se refresca tras "Actualiza GPKG" sin volver a preguntar (V198).
PRUNED_LEGEND_PROP = 'obra_nueva/legend_pruned'


# V1.7.16: marca de las capas ocultas de apoyo (CLAVE, ASPECTOS) que carga
# el plugin para los desplegables.
SUPPORT_LAYER_PROP = 'obra_nueva/support_layer'

_CLEANUP_CONNECTED = []


def _truthy(value):
    return value in (True, 1, '1', 'true', 'True', 'TRUE')


def remove_orphan_support_layers():
    """Quita del proyecto las capas ocultas de apoyo cuyo GeoPackage ya no
    tiene ninguna otra capa cargada. Devuelve cuántas se han quitado."""
    project = QgsProject.instance()
    layers = list(project.mapLayers().values())
    support = [l for l in layers if _truthy(l.customProperty(SUPPORT_LAYER_PROP, False))]
    if not support:
        return 0
    in_use = set()
    for lyr in layers:
        if lyr in support:
            continue
        try:
            in_use.add(split_ogr_source(lyr.source())[0])
        except Exception:
            continue
    orphans = []
    for lyr in support:
        try:
            if split_ogr_source(lyr.source())[0] not in in_use:
                orphans.append(lyr.id())
        except Exception:
            continue
    if orphans:
        project.removeMapLayers(orphans)
    return len(orphans)


def _connect_support_cleanup():
    project = QgsProject.instance()
    if any(p is project for p in _CLEANUP_CONNECTED):
        return
    try:
        from qgis.PyQt.QtCore import QTimer
        project.layersRemoved.connect(lambda _ids: QTimer.singleShot(0, remove_orphan_support_layers))
        _CLEANUP_CONNECTED.append(project)
    except Exception as e:
        log_warning(f'No se pudo activar la limpieza de capas de apoyo: {e}')


class GpkgLoader:
    def __init__(self):
        self.legend_pruner = LegendPruner()
        self.form_customizer = IncidenciaFormCustomizer()

    def list_sublayers(self, gpkg_path):
        return GpkgIntrospector(gpkg_path).list_feature_tables()

    def load_grouped_gpkg(self, gpkg_path, load_mode='all', no_duplicates=True, skip_empty=False, prune_legend=True):
        selected = self.find_operational_layers_strict(gpkg_path)
        return self.load_selected_layers(
            gpkg_path,
            selected_layer_names=selected,
            no_duplicates=no_duplicates,
            skip_empty=skip_empty,
            prune_legend=prune_legend,
        )

    def load_selected_layers(self, gpkg_path, selected_layer_names, no_duplicates=True, skip_empty=False, prune_legend=True):
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        main_group = self._obra_group(root, gpkg_path)

        ordered_names = self._sort_operational_layers(selected_layer_names)

        # V200: las capas de este GeoPackage que se van a volver a cargar y
        # que YA están en el grupo de la obra se conservan (se refrescan
        # más abajo); solo se quita del grupo lo demás. Antes se eliminaban
        # todas del proyecto y se creaban de nuevo.
        reuse_ids = set()
        if no_duplicates:
            for name in ordered_names:
                for lyr in project_layers_for_gpkg(gpkg_path, name):
                    reuse_ids.add(lyr.id())
        self._clear_group_layers(main_group, keep_ids=reuse_ids, gpkg_path=gpkg_path)

        try:
            self.form_customizer.ensure_fields_for_gpkg(gpkg_path, ordered_names)
        except Exception as e:
            log_warning(f'No se pudieron preparar los campos de incidencias en {gpkg_path}: {e}')

        loaded_layers = []
        for layer_name in ordered_names:
            uri = f'{gpkg_path}|layername={layer_name}'
            existing_layers = (
                [l for l in project_layers_for_gpkg(gpkg_path, layer_name) if l.isValid()]
                if no_duplicates else []
            )
            if existing_layers:
                # La capa ya estaba cargada en el proyecto (p. ej. se acaba
                # de abrir un proyecto guardado que ya la traía, o se cargó
                # antes en esta misma sesión, o "Actualiza GPKG" acaba de
                # añadirle campos). V198: se localizan TODAS sus copias
                # comparando rutas normalizadas (antes se comparaba el
                # texto exacto de la ruta, y una copia con la ruta escrita
                # de otra forma -- "\\" frente a "/", mayúsculas -- no se
                # reconocía y se quedaba con el formulario viejo). Todas se
                # refrescan (estructura, estilo, formulario); la primera se
                # coloca en el grupo de la obra.
                existing = existing_layers[0]
                for lyr in existing_layers:
                    self._refresh_existing_layer(lyr, gpkg_path, layer_name, prune_legend)
                self._move_layer_to_group(existing, main_group)
                loaded_layers.append(existing)
                continue
            layer = QgsVectorLayer(uri, layer_name, 'ogr')
            if not layer.isValid():
                log_warning(f'No se pudo cargar la capa: {layer_name}')
                continue
            if skip_empty and layer.featureCount() == 0:
                continue
            layer.setName(layer_name)
            self._load_persisted_style(layer)
            # V1.7.16: primero el formulario (que puede crear el desplegable
            # de "Aspecto Ambiental") y después la reparación de desplegables;
            # al revés, el de Aspecto no funcionaba hasta recargar.
            self.form_customizer.apply_form(layer)
            self._repair_value_relation_layers(layer, gpkg_path)
            if prune_legend:
                self.legend_pruner.prune_layer_legend(layer)
            layer.setCustomProperty(PRUNED_LEGEND_PROP, bool(prune_legend))
            project.addMapLayer(layer, False)
            main_group.addLayer(layer)
            loaded_layers.append(layer)
        main_group.setExpanded(True)
        log_info(f'Cargadas {len(loaded_layers)} capas operativas desde {gpkg_path}')
        return loaded_layers

    def obra_group(self, gpkg_path, root=None):
        """Grupo de la obra en el panel de capas (lo usan Carga Obra, Nueva
        Obra y Actualiza GPKG).

        V201: si ya existe un grupo con ese nombre pero es de OTRA obra con
        el mismo nombre de fichero (p. ej. una copia archivada en otra
        carpeta), no se reutiliza: se crea uno propio con la carpeta entre
        paréntesis, para no mezclar ni borrar las capas de la otra obra.

        V1.7.16: solo cuenta como "de otra obra" un grupo con capas de un
        GeoPackage con el MISMO nombre de fichero y ninguna de este. Una
        capa base de otro GeoPackage que el usuario meta en el grupo ya no
        hace que la obra se mude a un grupo nuevo. Si "OBRA (carpeta)"
        también está ocupado, se numera ("OBRA (carpeta) 2"...) en vez de
        crear otro grupo con el mismo nombre en cada carga."""
        root = root or QgsProject.instance().layerTreeRoot()
        group_name = normalize_base_name(gpkg_path)
        target, _ = split_ogr_source(gpkg_path)
        candidates = [group_name]
        parent = os.path.basename(os.path.dirname(os.path.abspath(gpkg_path)))
        if parent:
            candidates.append(f'{group_name} ({parent})')
            candidates += [f'{group_name} ({parent}) {i}' for i in range(2, 50)]
        for name in candidates:
            group = root.findGroup(name)
            if group is None:
                return root.addGroup(name)
            if not self._group_is_other_obra(group, target, group_name):
                return group
        return root.addGroup(candidates[-1])

    def _obra_group(self, root, gpkg_path):
        return self.obra_group(gpkg_path, root)

    @staticmethod
    def _group_is_other_obra(group, target, group_name):
        mine = other = False
        for node in group.findLayers():
            lyr = node.layer()
            if lyr is None:
                continue
            path, _ = split_ogr_source(lyr.source())
            if not path.lower().endswith('.gpkg'):
                continue
            if path == target:
                mine = True
            elif normalize_base_name(path) == group_name:
                other = True
        return other and not mine

    def _move_layer_to_group(self, layer, group):
        """Coloca la capa en el grupo de la obra SIN sacarla del proyecto.

        V200 -- causa de que "Actualiza GPKG" / "Carga Obra" descargaran la
        capa del lienzo: antes se quitaba su nodo del árbol de capas con
        removeChildNode() y luego se añadía al grupo con addLayer(). Pero en
        QGIS, al quitar del árbol el ÚLTIMO nodo de una capa, el proyecto
        elimina la propia capa; addLayer() recibía entonces una capa ya
        borrada (la capa desaparecía, y en algunos casos QGIS podía
        cerrarse). Ahora se sigue el patrón recomendado por QGIS: primero se
        inserta en el grupo una copia del nodo y solo después se quita el
        nodo original, de modo que la capa nunca se queda sin nodo."""
        root = QgsProject.instance().layerTreeRoot()
        node = root.findLayer(layer.id())
        if node is None:
            group.addLayer(layer)
            return
        parent = node.parent()
        if parent is group:
            return
        group.addChildNode(node.clone())
        if parent is not None:
            parent.removeChildNode(node)

    def _refresh_existing_layer(self, layer, gpkg_path, table_name, prune_legend):
        """Pone al día una capa YA cargada en el proyecto: estructura
        (campos nuevos), estilo guardado en el GeoPackage, desplegables
        ValueRelation y formulario de la obra. V198: sin setDataSource()
        salvo como último recurso (ver _ensure_schema_current)."""
        self._ensure_schema_current(layer, gpkg_path, table_name)
        self._load_persisted_style(layer)
        self.form_customizer.apply_form(layer)
        self._repair_value_relation_layers(layer, gpkg_path)
        if prune_legend:
            self.legend_pruner.prune_layer_legend(layer)
        try:
            layer.setCustomProperty(PRUNED_LEGEND_PROP, bool(prune_legend))
            layer.triggerRepaint()
        except Exception:
            pass

    def _ensure_schema_current(self, layer, gpkg_path, table_name):
        """Comprueba si la capa ya "ve" todas las columnas que tiene ahora
        la tabla en el fichero. Desde V198 los campos se añaden por el propio
        proveedor OGR de QGIS, así que lo normal es que ya las vea y aquí no
        se haga nada. Si faltan (campos añadidos por otro programa o por una
        versión anterior del plugin), primero se intenta una recarga suave
        del proveedor y, solo si no basta, setDataSource() (V177), que
        reabre el origen de datos por completo."""
        try:
            intro = GpkgIntrospector(gpkg_path)
            file_cols = {normalize_text(c) for c in intro.table_columns(table_name)}
            # El nombre de tabla puede venir con otras mayúsculas que en
            # gpkg_geometry_columns (p. ej. desde el origen de la capa).
            geom_col = None
            for t in intro.list_geometry_tables():
                if t.lower() == (table_name or '').lower():
                    geom_col = intro.geometry_column_name(t)
                    break
            if geom_col:
                file_cols.discard(normalize_text(geom_col))
        except Exception as e:
            log_warning(f'No se pudo leer la estructura de "{table_name}" en {gpkg_path}: {e}')
            return

        def missing():
            return file_cols - {normalize_text(f.name()) for f in layer.fields()}

        if not missing():
            return
        try:
            layer.dataProvider().reloadData()
            layer.updateFields()
        except Exception as e:
            log_warning(f'No se pudieron recargar los campos de "{layer.name()}": {e}')
        if not missing():
            return
        try:
            layer.setDataSource(layer.source(), layer.name(), 'ogr', False)
        except Exception as e:
            log_warning(f'No se pudo reconectar la capa "{layer.name()}" al origen de datos actualizado: {e}')

    def _load_persisted_style(self, layer):
        """Carga sobre la capa el estilo guardado como predeterminado en el
        GeoPackage (tabla layer_styles, useAsDefault=1) -- exactamente el
        que sincroniza la pestaña "Actualiza GPKG": leyenda/simbología,
        anchos ValueMap/ValueRelation, formato de fecha, carpeta por defecto
        de los campos de documento, y el diseño de formulario (grupos,
        pestañas) diseñado en el modelo.

        QgsVectorLayer NO carga este estilo automáticamente: hay que pedirlo
        de forma explícita con loadDefaultStyle(), igual que ya hacen las
        pestañas "Nueva Obra" y "Consulta". Sin esta llamada, el formulario
        de edición nace con los valores por defecto de QGIS (sin listas
        desplegables, sin carpeta de documento, sin agrupaciones), aunque el
        GeoPackage tenga el estilo correcto guardado."""
        try:
            # loadDefaultStyle() no admite parámetros y devuelve (mensaje,
            # ok) -- no (ok) con un parámetro de salida por referencia. Con
            # la firma antigua, PyQGIS lanza TypeError ("too many
            # arguments") en las versiones de QGIS comprobadas.
            msg, ok = layer.loadDefaultStyle()
            if not ok and msg:
                log_warning(f'Aviso al cargar el estilo guardado de "{layer.name()}": {msg}')
        except Exception as e:
            log_warning(f'No se pudo cargar el estilo guardado de "{layer.name()}": {e}')

    # Tablas de apoyo (no espaciales) del GeoPackage cuyos ValueRelation
    # necesitan repararse igual que "CLAVE" (ver docstring de
    # _repair_value_relation_layers). V190 añade "ASPECTOS" (desplegable de
    # aspecto ambiental para Incidencias Ambientales, ver form_customizer.py)
    # sin tocar el comportamiento ya probado para "CLAVE".
    SUPPORT_TABLES = ('CLAVE', 'ASPECTOS')

    def _repair_value_relation_layers(self, layer, gpkg_path):
        """Repara los campos ValueRelation que apuntan a una tabla de apoyo
        del propio modelo -- "CLAVE" (p. ej. "Tipo", filtrado por Ámbito) o
        "ASPECTOS" (p. ej. "Aspecto Ambiental") -- ver SUPPORT_TABLES.

        El estilo persistido que se traslada tal cual desde el modelo (ver
        form_customizer.py V175) guarda, para esos campos, la ruta absoluta
        del GeoPackage donde el AUTOR del modelo tenía cargada su propia
        copia de esa tabla (p. ej. "E:/1_GPK/SDON_KKK.gpkg|layername=CLAVE")
        y el id interno que esa capa tenía en SU proyecto de QGIS. Ninguno
        de los dos existe en la máquina de quien abre otra obra: la ruta no
        suele existir en ese equipo, y aunque existiera, el id de capa no
        coincide con nada cargado en este proyecto. Sin poder resolver esa
        referencia, QGIS no encuentra la descripción del código
        seleccionado y el desplegable se ve, por ejemplo, "(8.1)" en vez de
        una descripción legible (comprobado con el propio SDON79).

        Todo GeoPackage de obra lleva su PROPIA copia de estas tablas (se
        sincronizan igual que el resto de tablas de referencia). Aquí se
        reapunta cada campo ValueRelation cuyo "LayerName" coincida con
        alguna de SUPPORT_TABLES a la tabla homónima de ESTE GeoPackage
        (cargada como capa oculta de apoyo, reutilizada si ya estaba
        cargada), conservando el resto de su configuración (columnas
        clave/valor, filtro, descripción...) tal cual la dejó el modelo --
        solo se corrige la referencia a la capa, no el diseño."""
        fields = layer.fields()
        tables_in_use = set()
        for i in range(fields.count()):
            setup = layer.editorWidgetSetup(i)
            if setup.type() != 'ValueRelation':
                continue
            config = setup.config() or {}
            layer_name_norm = normalize_text(str(config.get('LayerName') or ''))
            for table in self.SUPPORT_TABLES:
                if layer_name_norm == normalize_text(table):
                    tables_in_use.add(table)
        if not tables_in_use:
            return

        hidden_layers = {}
        for table in tables_in_use:
            hidden = self._get_hidden_support_layer(gpkg_path, table)
            if hidden is not None:
                hidden_layers[table] = hidden

        for i in range(fields.count()):
            setup = layer.editorWidgetSetup(i)
            if setup.type() != 'ValueRelation':
                continue
            config = dict(setup.config() or {})
            layer_name_norm = normalize_text(str(config.get('LayerName') or ''))
            matched_table = next(
                (t for t in self.SUPPORT_TABLES if normalize_text(t) == layer_name_norm),
                None,
            )
            if matched_table is None or matched_table not in hidden_layers:
                continue
            hidden = hidden_layers[matched_table]
            config['Layer'] = hidden.id()
            config['LayerName'] = matched_table
            config['LayerProviderName'] = 'ogr'
            config['LayerSource'] = f'{gpkg_path}|layername={matched_table}'
            layer.setEditorWidgetSetup(i, QgsEditorWidgetSetup('ValueRelation', config))

    def _get_hidden_support_layer(self, gpkg_path, table_name):
        """Carga (o reutiliza, si ya está cargada) una tabla de apoyo
        (CLAVE, ASPECTOS...) del GeoPackage indicado como capa oculta (no
        se añade a ningún grupo del panel de capas), para que los campos
        ValueRelation puedan resolverla por id de capa dentro de este
        proyecto de QGIS."""
        uri = f'{gpkg_path}|layername={table_name}'
        existing = [l for l in project_layers_for_gpkg(gpkg_path, table_name) if l.isValid()]
        if existing:
            return existing[0]
        layer = QgsVectorLayer(uri, table_name, 'ogr')
        if not layer.isValid():
            log_warning(f'No se pudo cargar la tabla "{table_name}" de {gpkg_path} para resolver los desplegables ValueRelation.')
            return None
        # V1.7.16: marcada como capa de apoyo para poder quitarla del proyecto
        # cuando ya no quede ninguna capa de su GeoPackage (si no, en Windows
        # mantenía el fichero abierto sin que se viera).
        layer.setCustomProperty(SUPPORT_LAYER_PROP, True)
        QgsProject.instance().addMapLayer(layer, False)
        _connect_support_cleanup()
        return layer

    def find_operational_layers_strict(self, gpkg_path):
        layer_names = self.list_sublayers(gpkg_path)
        targets = [
            ('Puntos', QgsWkbTypes.PointGeometry, ['_puntos', 'puntos']),
            ('Lineas', QgsWkbTypes.LineGeometry, ['_lineas', '_líneas', 'lineas', 'líneas']),
            ('Poligonos', QgsWkbTypes.PolygonGeometry, ['_poligonos', '_polígonos', 'poligonos', 'polígonos']),
        ]

        found = []
        for _, geom_type, suffixes in targets:
            match = self._find_layer_by_suffix_and_geom(
                gpkg_path=gpkg_path,
                layer_names=layer_names,
                suffixes=suffixes,
                target_geom_type=geom_type,
            )
            if match:
                found.append(match)
        return self._sort_operational_layers(found)

    def _find_layer_by_suffix_and_geom(self, gpkg_path, layer_names, suffixes, target_geom_type):
        suffixes = [self._normalize_text(s) for s in suffixes]
        candidates = []
        geometry_map = GpkgIntrospector(gpkg_path).geometry_type_by_table()

        excluded = {
            'pk',
            'estaciones',
            'estacion',
            'lineas_ffcc',
            'lineasffcc',
            'leyenda',
            'clave',
            'layer_groups',
            'metadata',
        }

        def geom_family(geometry_type_name):
            g = self._normalize_text(geometry_type_name)
            if 'point' in g:
                return QgsWkbTypes.PointGeometry
            # V1.7.16: polígonos antes que líneas ("CURVEPOLYGON" contiene
            # "curve" y se tomaba por una línea).
            if 'polygon' in g or 'surface' in g:
                return QgsWkbTypes.PolygonGeometry
            if 'line' in g or 'curve' in g:
                return QgsWkbTypes.LineGeometry
            return QgsWkbTypes.UnknownGeometry

        for layer_name in layer_names:
            lname = self._normalize_text(layer_name)
            if lname in excluded:
                continue
            if any(bad in lname for bad in ['leyenda', 'clave', 'group', 'metadata']):
                continue

            if geom_family(geometry_map.get(layer_name, '')) != target_geom_type:
                continue

            score = -1
            for suffix in suffixes:
                if lname == suffix:
                    score = max(score, 200)
                elif lname.endswith(suffix):
                    score = max(score, 150)
                elif suffix in lname:
                    score = max(score, 100)

            if score >= 0:
                candidates.append((score, layer_name))

        if not candidates:
            return None
        candidates.sort(key=lambda x: (-x[0], x[1]))
        return candidates[0][1]

    def _sort_operational_layers(self, layer_names):
        def rank(name):
            n = self._normalize_text(name)
            if 'puntos' in n:
                return (0, n)
            if 'lineas' in n:
                return (1, n)
            if 'poligonos' in n:
                return (2, n)
            return (99, n)
        return sorted(layer_names, key=rank)

    def _clear_group_layers(self, group, keep_ids=(), gpkg_path=None):
        """Quita del grupo de la obra las capas de ESTE GeoPackage que no se
        van a reutilizar (keep_ids se conservan en su sitio, ver
        _move_layer_to_group). V201: también dentro de subgrupos, y sin
        tocar capas de otros orígenes que el usuario haya metido en el
        grupo. Los subgrupos que quedan vacíos se eliminan. Antes se
        quitaban subgrupos enteros con removeChildNode(), y QGIS eliminaba
        con ellos del proyecto cualquier capa que contuvieran, incluidas
        las que se iban a reutilizar."""
        project = QgsProject.instance()
        keep_ids = set(keep_ids or ())
        target = split_ogr_source(gpkg_path)[0] if gpkg_path else None

        def belongs(layer):
            if target is None:
                return True
            try:
                return split_ogr_source(layer.source())[0] == target
            except Exception:
                return False

        def clean(g):
            for child in list(g.children()):
                if child.nodeType() == child.NodeLayer:
                    layer_id = child.layerId()
                    if layer_id in keep_ids:
                        continue
                    lyr = project.mapLayer(layer_id)
                    if lyr is None:
                        g.removeChildNode(child)
                    elif belongs(lyr):
                        project.removeMapLayer(layer_id)
                else:
                    clean(child)
                    if not child.children():
                        g.removeChildNode(child)

        clean(group)

    def detach_layers_for_path(self, gpkg_path):
        """Devuelve [(capa, origen), ...] de todas las capas del proyecto
        QGIS actual que provienen de gpkg_path, para refrescarlas con
        reattach_layers() cuando termine "Actualiza GPKG".

        V198: YA NO DESCONECTA NADA (se conserva el nombre para no tocar
        las llamadas de ui/tab_actualiza_gpkg.py). V194 desconectaba estas
        capas con setDataSource('') antes de escribir, para no tener dos
        conexiones abiertas sobre el mismo fichero; el usuario confirmó que
        QGIS 3 seguía cerrándose de golpe. La causa de fondo -- cambiar el
        esquema con ALTER TABLE desde una conexión sqlite3 propia, por
        debajo de GDAL -- se ha eliminado: los campos se añaden ahora por el
        proveedor OGR de QGIS (core/ogr_layer_utils.py), que es seguro con
        las capas conectadas. Desconectar una capa viva era además un riesgo
        en sí mismo (lienzo dibujándola, tabla o formulario abiertos,
        desplegables que la referencian)."""
        return [(layer, layer.source()) for layer in project_layers_for_gpkg(gpkg_path)]

    def reattach_layers(self, detached):
        """Tras "Actualiza GPKG" (modo un solo GeoPackage y modo carpeta),
        pone al día las capas de ese GeoPackage que ya estaban cargadas:
        campos nuevos, estilo sincronizado desde el modelo y formulario de
        la obra (grupos FICHAS-INFORMES/FOTOS/NC-INCIDENCIAS, ASPECTO-ZONA
        condicional, selectores de documento...). Antes (V194-V197) solo se
        reconectaba el origen de datos y el formulario se quedaba como
        estaba hasta volver a cargar la obra (posible origen del formulario
        "plano", sin grupos, visto en SDONO124). Respeta el modo de leyenda con el
        que se cargó cada capa (Edición/Visualización).

        El estilo y el formulario solo se reaplican a las capas operativas
        de la obra (con Ámbito, Tipo y Ficha); al resto (tablas de apoyo,
        capas base) solo se les refresca la estructura."""
        for layer, uri in detached:
            try:
                if not layer.isValid():
                    continue
                _, lname = split_ogr_source(uri or layer.source())
                gpkg_path = (uri or layer.source()).split('|')[0]
                table_name = lname or layer.name()
                if self._is_operational_layer(layer):
                    prune = _truthy(layer.customProperty(PRUNED_LEGEND_PROP, False))
                    self._refresh_existing_layer(layer, gpkg_path, table_name, prune)
                else:
                    self._ensure_schema_current(layer, gpkg_path, table_name)
            except Exception as e:
                try:
                    name = layer.name()
                except Exception:
                    name = '?'
                log_warning(f'No se pudo refrescar la capa "{name}" tras la actualización: {e}')

    def has_operational_layers(self, detached):
        """True si entre las capas devueltas por detach_layers_for_path()
        hay alguna capa operativa de la obra visible en el panel de capas
        (no cuentan las tablas de apoyo ocultas, como CLAVE)."""
        root = QgsProject.instance().layerTreeRoot()
        for layer, _ in detached or ():
            try:
                if (layer.isValid() and root.findLayer(layer.id()) is not None
                        and self._is_operational_layer(layer)):
                    return True
            except Exception:
                continue
        return False

    def _is_operational_layer(self, layer):
        names = {normalize_text(f.name()) for f in layer.fields()}
        return (
            ('ambito' in names)
            and ('tipo' in names)
            and ('ficha' in names)
        )

    def _normalize_text(self, text):
        return normalize_text(text).strip()

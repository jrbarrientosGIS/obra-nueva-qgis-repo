# -*- coding: utf-8 -*-
import os

from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QFileDialog, QCheckBox, QTextEdit, QMessageBox, QFrame,
    QRadioButton, QButtonGroup,
)

from ..core.settings_manager import SettingsManager
from ..core.gpkg_updater import GpkgStructureUpdater, scan_gpkg_files_recursive
from ..core.gpkg_loader import GpkgLoader
from ..core.gpkg_utils import primary_loaded_gpkg_path


class ActualizaGpkgTab(QWidget):
    """Pestaña 'Actualiza GPKG': sincroniza la estructura de un GeoPackage
    antiguo con la de un GeoPackage modelo (más reciente), añadiendo los
    campos y tablas nuevas sin perder ninguna entidad gráfica ni dato ya
    existente en el antiguo.

    Admite dos modos:
      * Un solo GeoPackage: como hasta ahora.
      * Carpeta completa: busca .gpkg de forma recursiva (subcarpetas
        incluidas) y los actualiza todos contra el mismo modelo.

    Al terminar una actualización individual, ofrece cargar el GeoPackage
    ya actualizado en el lienzo."""

    def __init__(self, iface, status_callback, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.status_callback = status_callback
        self.settings = SettingsManager()
        self.updater = GpkgStructureUpdater()
        self.loader = GpkgLoader()
        self._plan = None          # modo "un solo GeoPackage"
        self._batch_items = None   # modo "carpeta": [{'path','plan','error'}, ...]
        self._old_gpkg_user_chosen = False  # True en cuanto el usuario elige/escribe uno a mano
        self._build_ui()
        self._restore_state()

    # ── UI ───────────────────────────────────────────────────────────────
    def _build_ui(self):
        layout = QVBoxLayout(self)

        intro = QLabel(
            "Actualiza la estructura de un GeoPackage antiguo a partir de un GeoPackage modelo "
            "(la plantilla más reciente), añadiendo los campos y tablas que falten sin eliminar "
            "ni modificar ninguna entidad gráfica ni dato ya existente."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        model_row = QHBoxLayout()
        model_row.addWidget(QLabel("GPKG modelo (nuevo):"))
        self.model_edit = QLineEdit()
        self.model_edit.setPlaceholderText("Selecciona el GeoPackage plantilla / más reciente…")
        model_row.addWidget(self.model_edit)
        self.model_btn = QPushButton("…")
        self.model_btn.setFixedWidth(36)
        model_row.addWidget(self.model_btn)
        layout.addLayout(model_row)

        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Actualizar:"))
        self.mode_single_radio = QRadioButton("Un solo GeoPackage")
        self.mode_folder_radio = QRadioButton("Carpeta completa (busca .gpkg también en subcarpetas)")
        self.mode_single_radio.setChecked(True)
        self.mode_button_group = QButtonGroup(self)
        self.mode_button_group.addButton(self.mode_single_radio)
        self.mode_button_group.addButton(self.mode_folder_radio)
        mode_row.addWidget(self.mode_single_radio)
        mode_row.addWidget(self.mode_folder_radio)
        mode_row.addStretch(1)
        layout.addLayout(mode_row)

        old_row = QHBoxLayout()
        self.old_label = QLabel("GPKG a actualizar (antiguo):")
        old_row.addWidget(self.old_label)
        self.old_edit = QLineEdit()
        self.old_edit.setPlaceholderText("Selecciona el GeoPackage antiguo a actualizar…")
        old_row.addWidget(self.old_edit)
        self.old_btn = QPushButton("…")
        self.old_btn.setFixedWidth(36)
        old_row.addWidget(self.old_btn)
        layout.addLayout(old_row)

        opts_row = QHBoxLayout()
        self.backup_chk = QCheckBox("Crear copia de seguridad antes de actualizar")
        self.backup_chk.setChecked(True)
        self.create_tables_chk = QCheckBox("Crear también las tablas nuevas del modelo (vacías)")
        self.create_tables_chk.setChecked(True)
        self.sync_styles_chk = QCheckBox("Sincronizar leyenda y simbología con el modelo")
        self.sync_styles_chk.setChecked(True)
        opts_row.addWidget(self.backup_chk)
        opts_row.addWidget(self.create_tables_chk)
        opts_row.addWidget(self.sync_styles_chk)
        opts_row.addStretch(1)
        layout.addLayout(opts_row)

        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setFrameShadow(QFrame.Shadow.Plain)
        layout.addWidget(line)

        layout.addWidget(QLabel("Informe de diferencias:"))
        self.report_edit = QTextEdit()
        self.report_edit.setReadOnly(True)
        self.report_edit.setPlaceholderText("Pulsa «Analizar diferencias» para comparar ambos GeoPackage…")
        layout.addWidget(self.report_edit, 1)

        footer = QHBoxLayout()
        self.analyze_btn = QPushButton("1)  🔍  Analizar diferencias")
        self.update_btn = QPushButton("2)  ⬆  Actualizar GPKG")
        self.update_btn.setObjectName("run_btn")
        self.update_btn.setEnabled(False)
        self.reset_btn = QPushButton("Limpiar formulario")
        footer.addWidget(self.analyze_btn)
        footer.addStretch(1)
        footer.addWidget(self.update_btn)
        footer.addWidget(self.reset_btn)
        layout.addLayout(footer)

        self.model_btn.clicked.connect(self.choose_model)
        self.old_btn.clicked.connect(self.choose_old)
        self.model_edit.textChanged.connect(self._invalidate_plan)
        self.old_edit.textChanged.connect(self._invalidate_plan)
        self.old_edit.textEdited.connect(self._on_old_edit_user_edited)
        self.mode_single_radio.toggled.connect(self._on_mode_changed)
        self.analyze_btn.clicked.connect(self._do_analyze)
        self.update_btn.clicked.connect(self._do_update)
        self.reset_btn.clicked.connect(self._reset_form)

        self._on_mode_changed()

    # ── Utilidades ───────────────────────────────────────────────────────
    def _log(self, message):
        if self.status_callback:
            self.status_callback(message)

    def _safe_text(self, value):
        try:
            return str(value) if value is not None else ""
        except Exception:
            return ""

    def _is_folder_mode(self):
        return self.mode_folder_radio.isChecked()

    def _on_mode_changed(self):
        if self._is_folder_mode():
            self.old_label.setText("Carpeta a actualizar (recursivo):")
            self.old_edit.setPlaceholderText("Selecciona la carpeta que contiene los GeoPackage a actualizar…")
            key = 'actualiza/old_folder'
        else:
            self.old_label.setText("GPKG a actualizar (antiguo):")
            self.old_edit.setPlaceholderText("Selecciona el GeoPackage antiguo a actualizar…")
            key = 'actualiza/old_gpkg'
        # V1.7.16: el modo se recordaba al leer los ajustes pero nunca se guardaba.
        try:
            self.settings.set('actualiza/mode', 'folder' if self._is_folder_mode() else 'single')
        except Exception:
            pass
        self.old_edit.blockSignals(True)
        self.old_edit.setText(self.settings.get(key, '') or '')
        self.old_edit.blockSignals(False)
        self._invalidate_plan()
        self.refresh_project_default()

    def refresh_project_default(self):
        """Si hay algún GeoPackage cargado en el proyecto QGIS actual (modo
        "un solo GeoPackage"), lo propone por defecto en el campo del GPKG
        a actualizar -- tiene prioridad sobre el último GeoPackage
        recordado de una sesión anterior, para que el campo muestre
        siempre, de entrada, el que ya está abierto en el lienzo. Deja de
        aplicarse en cuanto el usuario elige o escribe una ruta a mano
        (hasta el siguiente «Limpiar formulario»)."""
        if self._is_folder_mode():
            return
        if self._old_gpkg_user_chosen:
            return
        default_path = primary_loaded_gpkg_path()
        if default_path:
            self.old_edit.blockSignals(True)
            self.old_edit.setText(default_path)
            self.old_edit.blockSignals(False)
            self._invalidate_plan()

    def _on_old_edit_user_edited(self, _text):
        self._old_gpkg_user_chosen = True

    def choose_model(self):
        last = self.settings.get('actualiza/model_gpkg', '') or ''
        path, _ = QFileDialog.getOpenFileName(self, "Seleccionar GeoPackage modelo", last, "GeoPackage (*.gpkg)")
        if path:
            self.model_edit.setText(path)
            self.settings.set('actualiza/model_gpkg', path)

    def choose_old(self):
        if self._is_folder_mode():
            last = self.settings.get('actualiza/old_folder', '') or ''
            path = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta a actualizar", last)
            if path:
                self.old_edit.setText(path)
                self.settings.set('actualiza/old_folder', path)
        else:
            last = self.settings.get('actualiza/old_gpkg', '') or ''
            path, _ = QFileDialog.getOpenFileName(self, "Seleccionar GeoPackage a actualizar", last, "GeoPackage (*.gpkg)")
            if path:
                self._old_gpkg_user_chosen = True
                self.old_edit.setText(path)
                self.settings.set('actualiza/old_gpkg', path)

    def _invalidate_plan(self):
        self._plan = None
        self._batch_items = None
        self.update_btn.setEnabled(False)

    def _reset_form(self):
        self.model_edit.clear()
        self.old_edit.clear()
        self.report_edit.clear()
        self._old_gpkg_user_chosen = False
        self._invalidate_plan()
        self.refresh_project_default()

    def _restore_state(self):
        self.model_edit.setText(self.settings.get('actualiza/model_gpkg', '') or '')
        saved_mode = self.settings.get('actualiza/mode', 'single')
        if str(saved_mode) == 'folder':
            self.mode_folder_radio.setChecked(True)
        else:
            self.mode_single_radio.setChecked(True)
        self._on_mode_changed()
        backup_val = self.settings.get('actualiza/backup', True)
        self.backup_chk.setChecked(str(backup_val).lower() not in ('false', '0'))
        create_val = self.settings.get('actualiza/create_tables', True)
        self.create_tables_chk.setChecked(str(create_val).lower() not in ('false', '0'))
        sync_styles_val = self.settings.get('actualiza/sync_styles', True)
        self.sync_styles_chk.setChecked(str(sync_styles_val).lower() not in ('false', '0'))

    def _pending_count(self, plan):
        sync_styles = self.sync_styles_chk.isChecked()
        create_missing = self.create_tables_chk.isChecked()
        n_fields = plan.total_new_fields()
        # V1.7.16: también las capas operativas que le faltan a la obra.
        n_tables = (len(plan.new_tables) + len(plan.missing_roles)) if create_missing else 0
        n_styles = plan.total_style_updates() if sync_styles else 0
        # V199: formularios de atributos a corregir (siempre, con o sin
        # sincronización de leyenda).
        n_forms = plan.total_form_fixes()
        # V1.7.16: códigos nuevos de CLAVE / ASPECTOS.
        n_rows = plan.total_support_rows()
        return n_fields, n_tables, n_styles, n_forms, n_rows

    @staticmethod
    def _pending_text(n_fields, n_tables, n_styles, n_forms, n_rows):
        partes = []
        if n_fields:
            partes.append(f"{n_fields} campo(s) nuevo(s)")
        if n_tables:
            partes.append(f"{n_tables} tabla(s) o capa(s) nueva(s)")
        if n_styles:
            partes.append(f"{n_styles} leyenda(s)/simbología(s)")
        if n_forms:
            partes.append(f"{n_forms} formulario(s) de atributos")
        if n_rows:
            partes.append(f"{n_rows} código(s) nuevo(s) de CLAVE/ASPECTOS")
        if not partes:
            return ''
        return partes[0] if len(partes) == 1 else ', '.join(partes[:-1]) + ' y ' + partes[-1]

    def _batch_totals(self, items):
        """(totales por tipo [5], ficheros con cambios, errores, no-obra)."""
        totals = [0, 0, 0, 0, 0]
        n_pending_files = n_errors = n_skipped = 0
        for item in items:
            if item.get('skipped'):
                n_skipped += 1
                continue
            if item['error']:
                n_errors += 1
                continue
            counts = self._pending_count(item['plan'])
            totals = [a + b for a, b in zip(totals, counts)]
            if any(counts):
                n_pending_files += 1
        return totals, n_pending_files, n_errors, n_skipped

    def _analyze_item(self, model_path, path):
        """V1.7.16: un GeoPackage que no es de obra se marca como "omitido",
        no como "error al analizar"."""
        try:
            return {'path': path, 'plan': self.updater.analyze(model_path, path), 'error': None}
        except ValueError as e:
            if 'No parece un GeoPackage de obra' in str(e):
                return {'path': path, 'plan': None, 'error': None, 'skipped': True}
            return {'path': path, 'plan': None, 'error': self._safe_text(e)}
        except Exception as e:
            return {'path': path, 'plan': None, 'error': self._safe_text(e)}

    # ── Informe de diferencias (un solo GeoPackage) ─────────────────────
    def _build_report(self, plan):
        sync_styles = self.sync_styles_chk.isChecked()
        lines = []
        lines.append(f"GPKG modelo:   {plan.model_path}")
        lines.append(f"GPKG antiguo:  {plan.old_path}")
        lines.append("")

        for diff in plan.pairs:
            label = f'"{diff.old_table}"' if diff.old_table == diff.model_table else f'"{diff.old_table}" ↔ modelo "{diff.model_table}"'
            role_tag = f"[{diff.role}] " if diff.role else ""
            header = f"{role_tag}{label}"

            style_pending = sync_styles and diff.needs_style_sync
            has_field_changes = diff.add_columns or diff.extra_in_old or diff.type_mismatch or diff.geom_mismatch

            form_pending = diff.needs_form_fix
            if not has_field_changes and not style_pending and not form_pending:
                note = ""
                if diff.style_status == 'different' and not sync_styles:
                    note = "  (leyenda distinta a la del modelo; sincronización desactivada)"
                form_ok = "  Formulario de atributos correcto." if diff.form_problems == [] else ""
                lines.append(f"✔ {header}: sin cambios, ya coincide con el modelo.{note}{form_ok}")
                continue

            lines.append(f"● {header}")
            for col in diff.add_columns:
                extra = "  (obligatorio en el modelo → se crea opcional)" if col.get('notnull') else ""
                lines.append(f'    ＋ añadir campo "{col["name"]}" ({col.get("type") or "TEXT"}){extra}')
            if diff.type_mismatch:
                for name, old_t, model_t in diff.type_mismatch:
                    lines.append(f'    ⚠ tipo distinto en "{name}": antiguo={old_t}  modelo={model_t}  (no se modifica)')
            if diff.geom_mismatch:
                old_g, model_g = diff.geom_mismatch
                lines.append(f'    ⚠ geometría distinta: antiguo={old_g}  modelo={model_g}  (no se modifica)')
            if diff.extra_in_old:
                lines.append(f'    ℹ campos propios del antiguo, no presentes en el modelo (se conservan): {", ".join(diff.extra_in_old)}')
            if diff.style_status == 'missing':
                accion = "se copiará la leyenda/simbología del modelo" if sync_styles else "sin leyenda propia (sincronización desactivada)"
                lines.append(f'    🎨 {accion}')
            elif diff.style_status == 'different':
                accion = "se actualizará la leyenda/simbología al modelo" if sync_styles else "leyenda distinta a la del modelo (sincronización desactivada)"
                lines.append(f'    🎨 {accion}')
            if form_pending:
                lines.append('    📝 formulario de atributos incompleto (se corregirá y se guardará en el GeoPackage):')
                for problem in diff.form_problems:
                    lines.append(f'        - {problem}')
            elif diff.form_problems == []:
                lines.append('    ✔ formulario de atributos correcto')
            lines.append("")

        if plan.missing_roles:
            accion = "se creará vacía" if self.create_tables_chk.isChecked() else "no se creará (opción desactivada)"
            for role, model_table, new_name in plan.missing_roles:
                lines.append(f'⚠ A la obra le falta la capa de {role}: "{new_name}" (modelo "{model_table}") — {accion}.')
            lines.append("")

        if plan.support_rows:
            for table, n in plan.support_rows.items():
                lines.append(f'＋ {table}: {n} código(s) del modelo que faltan en la obra (se añadirán; no se borra ninguno).')
            lines.append("")

        if plan.unmatched_old_roles:
            lines.append(f"⚠ Roles presentes en el antiguo sin equivalente en el modelo (se conservan sin cambios): {', '.join(plan.unmatched_old_roles)}")
            lines.append("")

        if plan.new_tables:
            lines.append("Tablas del modelo sin equivalente en el antiguo:")
            for t in plan.new_tables:
                accion = "se creará vacía" if self.create_tables_chk.isChecked() else "no se creará (opción desactivada)"
                lines.append(f'    ✚ "{t}" — {accion}')
            lines.append("")
        else:
            lines.append("✔ No hay tablas nuevas en el modelo pendientes de crear.")
            lines.append("")

        if plan.model_form_problems:
            for table, problems in plan.model_form_problems.items():
                lines.append(
                    f'⚠ El formulario del propio MODELO ("{table}") está incompleto: {"; ".join(problems)}. '
                    'En la obra se completará con el diseño estándar del plugin, pero conviene corregirlo en el modelo.'
                )
            lines.append("")

        pending_txt = self._pending_text(*self._pending_count(plan))
        lines.append("─" * 60)
        if pending_txt:
            lines.append(f"RESUMEN: {pending_txt} por aplicar.")
        else:
            lines.append("RESUMEN: el GeoPackage antiguo ya está actualizado a la estructura del modelo.")

        return "\n".join(lines)

    # ── Informe de diferencias (carpeta / actualización masiva) ─────────
    def _build_batch_report(self, items, folder_path):
        lines = []
        lines.append(f"GPKG modelo: {self.model_edit.text().strip()}")
        lines.append(f"Carpeta:     {folder_path}  (búsqueda recursiva en subcarpetas)")
        lines.append(f"GeoPackage encontrados: {len(items)}")
        lines.append("")

        for item in items:
            path = item['path']
            if item.get('skipped'):
                lines.append(f"– {path}: no es un GeoPackage de obra (se omite).")
                lines.append("")
                continue
            if item['error']:
                lines.append(f"✖ {path}")
                lines.append(f"    error al analizar: {item['error']}")
                lines.append("")
                continue

            pending_txt = self._pending_text(*self._pending_count(item['plan']))
            if not pending_txt:
                lines.append(f"✔ {path}: ya actualizado, sin cambios.")
            else:
                lines.append(f"● {path}")
                lines.append(f"    {pending_txt} pendiente(s).")
            lines.append("")

        totals, n_pending_files, n_errors, n_skipped = self._batch_totals(items)
        lines.append("─" * 60)
        total_txt = self._pending_text(*totals) or 'nada'
        lines.append(
            f"RESUMEN: {n_pending_files} de {len(items)} GeoPackage con cambios pendientes "
            f"({total_txt} en total)."
        )
        if n_skipped:
            lines.append(f"ℹ {n_skipped} archivo(s) no son GeoPackage de obra y se han omitido.")
        if n_errors:
            lines.append(f"⚠ {n_errors} archivo(s) no se pudieron analizar (ver detalle arriba).")

        return "\n".join(lines)

    # ── Analizar ─────────────────────────────────────────────────────────
    def _do_analyze(self):
        if self._is_folder_mode():
            self._do_analyze_batch()
        else:
            self._do_analyze_single()

    def _do_analyze_single(self):
        model_path = self.model_edit.text().strip()
        old_path = self.old_edit.text().strip()

        if not model_path or not os.path.exists(model_path):
            QMessageBox.warning(self, "Actualiza GPKG", "Selecciona un GeoPackage modelo válido.")
            return
        if not old_path or not os.path.exists(old_path):
            QMessageBox.warning(self, "Actualiza GPKG", "Selecciona un GeoPackage antiguo válido.")
            return
        if os.path.normcase(os.path.abspath(model_path)) == os.path.normcase(os.path.abspath(old_path)):
            QMessageBox.warning(self, "Actualiza GPKG", "El GPKG modelo y el GPKG antiguo no pueden ser el mismo archivo.")
            return

        self.settings.set('actualiza/model_gpkg', model_path)
        self.settings.set('actualiza/old_gpkg', old_path)

        try:
            plan = self.updater.analyze(model_path, old_path)
        except Exception as e:
            self._log(f'✖ Error analizando diferencias: {self._safe_text(e)}')
            QMessageBox.critical(self, "Error", self._safe_text(e))
            return

        self._plan = plan
        self._batch_items = None
        self.report_edit.setPlainText(self._build_report(plan))

        pending_txt = self._pending_text(*self._pending_count(plan))
        self.update_btn.setEnabled(bool(pending_txt))

        if pending_txt:
            self._log(f'🔍 Análisis completado: {pending_txt} pendiente(s).')
        else:
            self._log('✔ Análisis completado: el GeoPackage antiguo ya está actualizado a la estructura del modelo.')

    def _do_analyze_batch(self):
        model_path = self.model_edit.text().strip()
        folder_path = self.old_edit.text().strip()

        if not model_path or not os.path.exists(model_path):
            QMessageBox.warning(self, "Actualiza GPKG", "Selecciona un GeoPackage modelo válido.")
            return
        if not folder_path or not os.path.isdir(folder_path):
            QMessageBox.warning(self, "Actualiza GPKG", "Selecciona una carpeta válida.")
            return

        self.settings.set('actualiza/model_gpkg', model_path)
        self.settings.set('actualiza/old_folder', folder_path)

        try:
            gpkg_files = scan_gpkg_files_recursive(folder_path, exclude_paths=[model_path])
        except Exception as e:
            self._log(f'✖ Error buscando GeoPackage en la carpeta: {self._safe_text(e)}')
            QMessageBox.critical(self, "Error", self._safe_text(e))
            return

        if not gpkg_files:
            QMessageBox.information(
                self, "Actualiza GPKG",
                "No se ha encontrado ningún GeoPackage (.gpkg) en la carpeta seleccionada ni en sus subcarpetas."
            )
            self.report_edit.setPlainText(f"No se encontraron archivos .gpkg en:\n{folder_path}")
            self._plan = None
            self._batch_items = []
            self.update_btn.setEnabled(False)
            return

        self._log(f'🔍 Buscando GeoPackage en «{folder_path}» (recursivo): {len(gpkg_files)} encontrado(s). Analizando…')

        items = [self._analyze_item(model_path, path) for path in gpkg_files]

        self._plan = None
        self._batch_items = items
        self.report_edit.setPlainText(self._build_batch_report(items, folder_path))

        _totals, n_pending_files, n_errors, n_skipped = self._batch_totals(items)
        self.update_btn.setEnabled(bool(n_pending_files))

        self._log(
            f'🔍 Análisis masivo completado: {len(items)} GeoPackage revisados, '
            f'{n_pending_files} con cambios pendientes, {n_errors} con error, {n_skipped} omitidos (no son de obra).'
        )

    # ── Actualizar ───────────────────────────────────────────────────────
    def _do_update(self):
        if self._is_folder_mode():
            self._do_update_batch()
        else:
            self._do_update_single()

    def _do_update_single(self):
        if self._plan is None:
            QMessageBox.warning(self, "Actualiza GPKG", "Analiza primero las diferencias.")
            return

        create_missing = self.create_tables_chk.isChecked()
        do_backup = self.backup_chk.isChecked()
        sync_styles = self.sync_styles_chk.isChecked()
        self.settings.set('actualiza/backup', do_backup)
        self.settings.set('actualiza/create_tables', create_missing)
        self.settings.set('actualiza/sync_styles', sync_styles)

        n_fields, n_tables, n_styles, n_forms, n_rows = self._pending_count(self._plan)
        # V1.7.16: solo se nombra lo que de verdad se va a hacer (antes decía
        # "Se van a añadir 0 campos" cuando solo había formularios).
        acciones = []
        if n_fields:
            acciones.append(f"Se añadirán {n_fields} campo(s) nuevo(s).")
        if n_tables:
            acciones.append(f"Se crearán {n_tables} tabla(s) o capa(s) nueva(s) (vacías, con la leyenda del modelo).")
        if n_styles:
            acciones.append(f"Se sincronizará leyenda/simbología en {n_styles} tabla(s).")
        if n_forms:
            acciones.append(f"Se corregirá el formulario de atributos en {n_forms} capa(s).")
        if n_rows:
            acciones.append(f"Se añadirán {n_rows} código(s) nuevo(s) a CLAVE/ASPECTOS.")
        msg = (
            '\n\n'.join(acciones)
            + f'\n\nen:\n\n{self._plan.old_path}\n\n'
            "No se eliminará ni modificará ninguna entidad gráfica ni dato existente."
            + ("\n\nSe creará una copia de seguridad antes de aplicar los cambios." if do_backup else "\n\n⚠ La copia de seguridad está desactivada.")
            + "\n\n¿Continuar?"
        )
        reply = QMessageBox.question(
            self, "Confirmar actualización", msg,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        # V198: se anotan las capas de este GeoPackage ya cargadas en el
        # lienzo (caso habitual: esta misma pestaña lo propone por defecto,
        # ver refresh_project_default()) para ponerlas al día al terminar
        # (campos, estilo y formulario) con reattach_layers(). Ya NO se
        # desconectan: los campos se añaden por el proveedor OGR de QGIS
        # (core/ogr_layer_utils.py), sin una segunda conexión que cambie
        # el esquema por debajo de las capas -- causa de los cierres.
        detached = self.loader.detach_layers_for_path(self._plan.old_path)
        try:
            result = self.updater.apply(
                self._plan,
                backup=do_backup,
                create_missing_tables=create_missing,
                sync_styles=sync_styles,
                progress_cb=self._log,
            )
        except Exception as e:
            self.loader.reattach_layers(detached)
            self._log(f'✖ Error actualizando GPKG: {self._safe_text(e)}')
            QMessageBox.critical(self, "Error", self._safe_text(e))
            return
        self.loader.reattach_layers(detached)

        n_created = len(result["tables_created"]) + len(result.get("roles_created", []))
        self._log(
            f'✔ Actualización completada: {result["fields_added"]} campo(s) añadidos, '
            f'{n_created} tabla(s) creadas, {result["styles_synced"]} leyenda(s) sincronizadas, '
            f'{result.get("forms_fixed", 0)} formulario(s) corregidos, '
            f'{result.get("support_rows_added", 0)} código(s) nuevos.'
        )

        # Re-analizar para reflejar el nuevo estado del GPKG antiguo.
        try:
            self._plan = self.updater.analyze(self._plan.model_path, self._plan.old_path)
            self.report_edit.setPlainText(self._build_report(self._plan))
            self.update_btn.setEnabled(any(self._pending_count(self._plan)))
        except Exception as e:
            # V1.7.16: antes se ocultaba y el informe quedaba desfasado.
            self._log(f'⚠ No se pudo volver a analizar el GeoPackage tras actualizar: {self._safe_text(e)}')
            self.report_edit.appendPlainText('\n⚠ Informe desfasado: no se pudo volver a analizar tras actualizar.')

        summary = (
            f'Actualización completada.\n\n'
            f'Campos añadidos: {result["fields_added"]}\n'
            f'Tablas creadas: {n_created}\n'
            f'Leyendas/simbología sincronizadas: {result["styles_synced"]}\n'
            f'Formularios de atributos corregidos: {result.get("forms_fixed", 0)}\n'
            f'Códigos nuevos en CLAVE/ASPECTOS: {result.get("support_rows_added", 0)}'
        )
        if result.get("backup_path"):
            summary += f'\n\nCopia de seguridad:\n{result["backup_path"]}'
        QMessageBox.information(self, "Actualiza GPKG", summary)

        # V200: si el GeoPackage ya estaba cargado en el lienzo, sus capas
        # ya se han puesto al día en su sitio (reattach_layers): no se
        # vuelve a preguntar si cargarlo, porque volver a cargarlo solo
        # podía quitar y recrear esas mismas capas.
        if self.loader.has_operational_layers(detached):
            self._log('✔ Las capas de este GeoPackage que ya estaban en el lienzo se han actualizado en su sitio.')
        else:
            self._offer_load_in_canvas(self._plan.old_path if self._plan else None)

    def _do_update_batch(self):
        if not self._batch_items:
            QMessageBox.warning(self, "Actualiza GPKG", "Analiza primero las diferencias.")
            return

        create_missing = self.create_tables_chk.isChecked()
        do_backup = self.backup_chk.isChecked()
        sync_styles = self.sync_styles_chk.isChecked()
        self.settings.set('actualiza/backup', do_backup)
        self.settings.set('actualiza/create_tables', create_missing)
        self.settings.set('actualiza/sync_styles', sync_styles)

        pending_items = [
            it for it in self._batch_items
            if not it['error'] and not it.get('skipped') and any(self._pending_count(it['plan']))
        ]
        if not pending_items:
            QMessageBox.information(self, "Actualiza GPKG", "No hay ningún GeoPackage con cambios pendientes.")
            return

        totals, n_pending_files, n_errors, n_skipped = self._batch_totals(self._batch_items)
        msg = (
            f"Se va a actualizar {n_pending_files} GeoPackage de {len(self._batch_items)} encontrado(s) "
            f"({self._pending_text(*totals)} en total).\n\n"
            "No se eliminará ni modificará ninguna entidad gráfica ni dato existente en ninguno de ellos."
            + ("\n\nSe creará una copia de seguridad de cada archivo antes de aplicar sus cambios." if do_backup else "\n\n⚠ La copia de seguridad está desactivada.")
            + "\n\n¿Continuar?"
        )
        reply = QMessageBox.question(
            self, "Confirmar actualización masiva", msg,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        updated = 0
        errors = []
        agg_fields = agg_tables = agg_styles = agg_forms = 0
        for item in pending_items:
            path = item['path']
            self._log(f'▶ Actualizando «{path}»…')
            # Igual que en _do_update_single(): las capas de este GeoPackage
            # ya cargadas en el lienzo se ponen al día al terminar (campos,
            # estilo y formulario), también si falla (V198).
            detached = self.loader.detach_layers_for_path(path)
            try:
                result = self.updater.apply(
                    item['plan'],
                    backup=do_backup,
                    create_missing_tables=create_missing,
                    sync_styles=sync_styles,
                    progress_cb=self._log,
                )
                agg_fields += result['fields_added']
                agg_tables += len(result['tables_created']) + len(result.get('roles_created', []))
                agg_styles += result['styles_synced']
                agg_forms += result.get('forms_fixed', 0)
                updated += 1
            except Exception as e:
                err_text = self._safe_text(e)
                errors.append((path, err_text))
                self._log(f'✖ Error actualizando «{path}»: {err_text}')
            finally:
                self.loader.reattach_layers(detached)

        self._log(
            f'✔ Actualización masiva completada: {updated} de {len(pending_items)} GeoPackage actualizados '
            f'({agg_fields} campo(s), {agg_tables} tabla(s), {agg_styles} leyenda(s), {agg_forms} formulario(s)). '
            f'{len(errors)} error(es).'
        )

        # Re-analiza toda la carpeta para reflejar el nuevo estado.
        model_path = self.model_edit.text().strip()
        folder_path = self.old_edit.text().strip()
        try:
            new_items = [self._analyze_item(model_path, item['path']) for item in self._batch_items]
            self._batch_items = new_items
            self.report_edit.setPlainText(self._build_batch_report(new_items, folder_path))
            _totals, n_pending_files2, _e, _s = self._batch_totals(new_items)
            self.update_btn.setEnabled(bool(n_pending_files2))
        except Exception as e:
            self._log(f'⚠ No se pudo volver a analizar la carpeta tras actualizar: {self._safe_text(e)}')

        summary = (
            f'Actualización masiva completada.\n\n'
            f'GeoPackage actualizados: {updated} de {len(pending_items)}\n'
            f'Campos añadidos (total): {agg_fields}\n'
            f'Tablas creadas (total): {agg_tables}\n'
            f'Leyendas/simbología sincronizadas (total): {agg_styles}\n'
            f'Formularios de atributos corregidos (total): {agg_forms}'
        )
        if errors:
            detalle = '\n'.join(f'- {p}: {m}' for p, m in errors[:10])
            summary += f'\n\nErrores ({len(errors)}):\n{detalle}'
            if len(errors) > 10:
                summary += f'\n… y {len(errors) - 10} más (ver consola de estado).'
        QMessageBox.information(self, "Actualiza GPKG", summary)

    # ── Cargar en el lienzo (solo modo "un solo GeoPackage") ────────────
    def _offer_load_in_canvas(self, gpkg_path):
        if not gpkg_path or not os.path.exists(gpkg_path):
            return

        # Igual que "Carga Obra": preguntamos el modo de carga en el mismo
        # diálogo (en vez de un simple Sí/No) -- Edición carga la leyenda
        # completa del modelo (para poder seguir dando de alta elementos
        # con cualquier categoría), Visualización la recorta a las
        # categorías que ya tienen entidades en cada capa.
        box = QMessageBox(self)
        box.setWindowTitle("Actualiza GPKG")
        box.setIcon(QMessageBox.Icon.Question)
        box.setText(f'¿Quieres cargar el GeoPackage actualizado en el lienzo?\n\n{gpkg_path}')
        box.setInformativeText(
            'Edición: leyenda completa, permite añadir nuevos elementos a las capas.\n'
            'Visualización: leyenda filtrada a los elementos ya presentes en cada capa.'
        )
        edicion_btn = box.addButton('Edición', QMessageBox.ButtonRole.AcceptRole)
        visualizacion_btn = box.addButton('Visualización', QMessageBox.ButtonRole.AcceptRole)
        no_btn = box.addButton('No', QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(visualizacion_btn)
        box.exec()

        clicked = box.clickedButton()
        if clicked is None or clicked == no_btn:
            return
        prune_legend = clicked != edicion_btn

        try:
            # no_duplicates=True: si estas capas ya estaban cargadas en el
            # lienzo (p. ej. se abrió un proyecto guardado que ya las
            # traía) se REFRESCAN esas mismas capas -- campos nuevos,
            # estilo, formulario, el desplegable de "Tipo" -- en vez de
            # crear copias nuevas y dejar las viejas tal cual estaban.
            layers = self.loader.load_grouped_gpkg(gpkg_path, no_duplicates=True, skip_empty=False, prune_legend=prune_legend)
            modo_txt = 'Edición (leyenda completa)' if not prune_legend else 'Visualización (leyenda filtrada)'
            self._log(f'✔ {len(layers)} capa(s) cargada(s) en el lienzo desde {os.path.basename(gpkg_path)} [{modo_txt}].')
        except Exception as e:
            err_text = self._safe_text(e)
            self._log(f'✖ No se pudo cargar el GeoPackage en el lienzo: {err_text}')
            QMessageBox.critical(self, "Error", err_text)

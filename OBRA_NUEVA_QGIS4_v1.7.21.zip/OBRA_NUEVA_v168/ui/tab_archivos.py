# -*- coding: utf-8 -*-
"""Pestaña "Archivos" (V1.7.17): agrupa las herramientas de ficheros
(Exporta a KML/KMZ, Actualiza GPKG y Archivar GPKG). Cada fila abre el cuadro de
diálogo de su herramienta, que contiene la pestaña de siempre sin cambios."""
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QWidget,
    QTextEdit, QSizePolicy
)


class DialogoHerramienta(QDialog):
    """Cuadro de diálogo que aloja una herramienta de la pestaña Archivos."""

    def __init__(self, titulo, parent=None, con_consola=True):
        super().__init__(parent)
        self.setWindowTitle(titulo)
        self.resize(1100, 720)
        self.setMinimumSize(820, 560)
        self.setSizeGripEnabled(True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 8)
        lay.setSpacing(6)
        self._lay = lay
        self.consola = None
        if con_consola:
            self.consola = QTextEdit()
            self.consola.setObjectName("status_console")
            self.consola.setReadOnly(True)
            self.consola.setMaximumHeight(130)
            self.consola.setPlaceholderText("▶  Consola de estado...")

    def poner_contenido(self, widget):
        self._lay.addWidget(widget, 1)
        if self.consola is not None:
            self._lay.addWidget(self.consola)

    def anotar(self, mensaje):
        if self.consola is not None:
            self.consola.append(str(mensaje))


class ArchivosTab(QWidget):
    """Tres filas, una por herramienta. Al pulsar una se abre su cuadro de diálogo."""

    def __init__(self, herramientas, parent=None):
        """herramientas: lista de (icono_y_titulo, descripcion, dialogo, al_abrir)."""
        super().__init__(parent)
        self.herramientas = herramientas
        self.botones = []
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 20, 24, 20)
        lay.setSpacing(14)
        intro = QLabel("Herramientas de archivos. Elige una opción para abrir su cuadro de diálogo.")
        intro.setWordWrap(True)
        lay.addWidget(intro)
        for i, (titulo, descripcion, dialogo, al_abrir) in enumerate(herramientas, 1):
            fila = QHBoxLayout()
            fila.setSpacing(16)
            btn = QPushButton(f"{i})  {titulo}")
            btn.setObjectName("archivos_btn")
            btn.setMinimumHeight(64)
            btn.setMaximumHeight(96)
            btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            btn.setStyleSheet("text-align: left; padding-left: 18px; font-size: 11pt; font-weight: bold; min-height: 56px; max-height: 80px;")
            btn.clicked.connect(lambda _=False, d=dialogo, f=al_abrir: self.abrir(d, f))
            lbl = QLabel(descripcion)
            lbl.setWordWrap(True)
            lbl.setStyleSheet("color: #8A9BBE;")
            fila.addWidget(btn, 2)
            fila.addWidget(lbl, 3)
            lay.addLayout(fila)
            self.botones.append(btn)
        lay.addStretch(1)

    def abrir(self, dialogo, al_abrir=None):
        if al_abrir is not None:
            try:
                al_abrir()
            except Exception:
                pass
        dialogo.show()
        dialogo.raise_()
        dialogo.activateWindow()

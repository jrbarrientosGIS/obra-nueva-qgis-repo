# -*- coding: utf-8 -*-
import os
import csv
import sqlite3
from collections import defaultdict

from qgis.PyQt.QtCore import Qt, QDate, QDateTime
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QLineEdit, QPushButton,
    QFileDialog, QComboBox, QCheckBox, QMessageBox, QGroupBox, QTextEdit,
    QDialog, QListWidget, QListWidgetItem, QAbstractItemView, QProgressBar, QApplication
)
from qgis.core import (
    NULL, QgsVectorLayer, QgsFeature, QgsFields, QgsGeometry, QgsProject,
    QgsWkbTypes, QgsVectorFileWriter, QgsCoordinateTransform, QgsCoordinateTransformContext,
    QgsMapLayerStyle, QgsEditorWidgetSetup
)

from ..core.gpkg_updater import scan_gpkg_files_recursive
from ..core.gpkg_utils import (
    attachment_default_root, document_field_names, is_url, resolve_attachment_path, strip_accents,
)
from ..core.legend_pruner import LegendPruner
from ..core.ogr_layer_utils import simple_field

TARGET_LAYERS = ["SDON_Puntos", "SDON_Lineas", "SDON_Poligonos"]
CANONICAL_SUFFIXES = {
    "SDON_Puntos": ["_puntos", "puntos"],
    "SDON_Lineas": ["_lineas", "lineas"],
    "SDON_Poligonos": ["_poligonos", "poligonos"],
}
AMBITO_NAMES = ["AMBITO", "Ambito", "Ámbito", "ámbito", "ambito"]
TIPO_NAMES = ["TIPO", "Tipo", "tipo"]
PERIODO_NAMES = ["PERIODO", "Periodo", "periodo"]
ALL_VALUE = "(Todos)"
RESULT_NAMES = ["RESULT_PUNTOS", "RESULT_LINEAS", "RESULT_POLIGONOS"]
RESULT_GROUP = "RESULTADOS_MULTIObra"
# V1.7.16: marca de las capas resultado que crea esta pestaña.
RESULT_PROP = "obra_nueva/consulta_result"
# Nombre (sin extensión) de los ficheros que exporta esta pestaña; no se
# escanean como obras.
EXPORT_PREFIX = "consulta_multiobra"


def _text_field(name, length):
    """Campo de texto que funciona en QGIS 3 y QGIS 4 (V1.7.16, A7)."""
    f = simple_field(name, 'TEXT')
    f.setLength(length)
    return f


class GpkgSelectionDialog(QDialog):
    """Ventana emergente que aparece al terminar la búsqueda recursiva de
    GeoPackage en la carpeta elegida (y todas sus subcarpetas): muestra la
    lista completa encontrada, con casilla de verificación, para que el
    usuario decida sobre cuáles quiere realizar la consulta antes de que
    el plugin abra y analice cada uno (ese análisis, capa a capa y valor a
    valor, es lo costoso -- descartar aquí los que no interesan evita
    perder tiempo escaneándolos)."""

    def __init__(self, gpkg_files, base_folder, parent=None):
        super().__init__(parent)
        self.base_folder = base_folder
        self.accepted_selection = False
        self.setWindowTitle("Selecciona los GeoPackage a consultar")
        self.setModal(True)
        self.setMinimumSize(520, 420)

        layout = QVBoxLayout(self)

        info = QLabel(
            f"Se han encontrado {len(gpkg_files)} GeoPackage en esta carpeta "
            "y sus subcarpetas. Marca los que quieras incluir en la consulta:"
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        for full_path in gpkg_files:
            try:
                display = os.path.relpath(full_path, base_folder)
            except ValueError:
                display = full_path
            item = QListWidgetItem(display)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Checked)
            item.setData(Qt.ItemDataRole.UserRole, full_path)
            self.list_widget.addItem(item)
        layout.addWidget(self.list_widget, 1)

        sel_btns = QHBoxLayout()
        self.btn_select_all = QPushButton("Seleccionar todo")
        self.btn_select_none = QPushButton("Ninguno")
        sel_btns.addWidget(self.btn_select_all)
        sel_btns.addWidget(self.btn_select_none)
        sel_btns.addStretch()
        layout.addLayout(sel_btns)
        self.btn_select_all.clicked.connect(self._select_all)
        self.btn_select_none.clicked.connect(self._select_none)

        btns = QHBoxLayout()
        btns.addStretch()
        self.btn_ok = QPushButton("Aceptar")
        self.btn_ok.setObjectName("run_btn")
        self.btn_cancel = QPushButton("Cancelar")
        btns.addWidget(self.btn_ok)
        btns.addWidget(self.btn_cancel)
        layout.addLayout(btns)
        self.btn_ok.clicked.connect(self._on_accept)
        self.btn_cancel.clicked.connect(self.reject)

    def _on_accept(self):
        self.accepted_selection = True
        self.accept()

    def _select_all(self):
        for i in range(self.list_widget.count()):
            self.list_widget.item(i).setCheckState(Qt.CheckState.Checked)

    def _select_none(self):
        for i in range(self.list_widget.count()):
            self.list_widget.item(i).setCheckState(Qt.CheckState.Unchecked)

    def selected_files(self):
        result = []
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item.checkState() == Qt.CheckState.Checked:
                result.append(item.data(Qt.ItemDataRole.UserRole))
        return result


class ConsultaTab(QWidget):
    def __init__(self, iface, status_callback=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.status_callback = status_callback or (lambda text: None)
        self.folder_path = ""
        self.gpkg_files = []
        self.scan_info = {}
        self.tipo_key_by_display = {}
        self.obra_label = {}
        self._clave_cache = {}
        self._pruner = LegendPruner()
        self._missing_docs_log = set()
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        folder_group = QGroupBox("Carpeta de GeoPackage")
        fg = QGridLayout()

        self.folder_edit = QLineEdit()
        self.btn_browse = QPushButton("Seleccionar carpeta")
        self.btn_scan = QPushButton("1)  Escanear carpeta")

        fg.addWidget(QLabel("Carpeta:"), 0, 0)
        fg.addWidget(self.folder_edit, 0, 1)
        fg.addWidget(self.btn_browse, 0, 2)
        fg.addWidget(self.btn_scan, 1, 2)

        self.scan_progress = QProgressBar()
        self.scan_progress.setMinimum(0)
        self.scan_progress.setMaximum(1)
        self.scan_progress.setValue(0)
        self.scan_progress.setFormat("Escanear carpeta para empezar")
        fg.addWidget(QLabel("Progreso:"), 2, 0)
        fg.addWidget(self.scan_progress, 2, 1, 1, 2)

        folder_group.setLayout(fg)
        layout.addWidget(folder_group)

        filter_group = QGroupBox("Filtros")
        fl = QGridLayout()

        self.cmb_obra = QComboBox()
        self.cmb_ambito = QComboBox()
        self.cmb_tipo = QComboBox()
        self.cmb_periodo = QComboBox()
        for cmb in (self.cmb_obra, self.cmb_ambito, self.cmb_tipo, self.cmb_periodo):
            cmb.addItem(ALL_VALUE)

        fl.addWidget(QLabel("Obra:"), 0, 0)
        fl.addWidget(self.cmb_obra, 0, 1)
        fl.addWidget(QLabel("Ámbito:"), 1, 0)
        fl.addWidget(self.cmb_ambito, 1, 1)
        fl.addWidget(QLabel("Tipo:"), 2, 0)
        fl.addWidget(self.cmb_tipo, 2, 1)
        fl.addWidget(QLabel("Periodo:"), 3, 0)
        fl.addWidget(self.cmb_periodo, 3, 1)

        self.chk_points = QCheckBox("SDON_Puntos")
        self.chk_lines = QCheckBox("SDON_Lineas")
        self.chk_polygons = QCheckBox("SDON_Poligonos")
        self.chk_points.setChecked(True)
        self.chk_lines.setChecked(True)
        self.chk_polygons.setChecked(True)

        caps = QHBoxLayout()
        caps.addWidget(self.chk_points)
        caps.addWidget(self.chk_lines)
        caps.addWidget(self.chk_polygons)
        caps.addStretch()
        fl.addWidget(QLabel("Capas a consultar:"), 4, 0)
        fl.addLayout(caps, 4, 1)

        self.chk_zoom = QCheckBox("Zoom automático a resultados")
        self.chk_zoom.setChecked(True)
        fl.addWidget(self.chk_zoom, 5, 1)

        filter_group.setLayout(fl)
        layout.addWidget(filter_group)

        export_group = QGroupBox("Exportación")
        el = QGridLayout()
        self.export_folder_edit = QLineEdit()
        self.btn_export_folder = QPushButton("Carpeta de salida")
        self.btn_export_gpkg = QPushButton("3)  Exportar resultados a GeoPackage")
        self.btn_export_gpkg.setObjectName("run_btn")
        self.btn_export_csv = QPushButton("4)  Exportar resumen a CSV")
        el.addWidget(QLabel("Salida:"), 0, 0)
        el.addWidget(self.export_folder_edit, 0, 1)
        el.addWidget(self.btn_export_folder, 0, 2)
        el.addWidget(self.btn_export_gpkg, 1, 1)
        el.addWidget(self.btn_export_csv, 1, 2)
        export_group.setLayout(el)

        query_progress_row = QHBoxLayout()
        self.query_progress = QProgressBar()
        self.query_progress.setMinimum(0)
        self.query_progress.setMaximum(1)
        self.query_progress.setValue(0)
        self.query_progress.setFormat("Ejecutar consulta para empezar")
        query_progress_row.addWidget(QLabel("Progreso de consulta:"))
        query_progress_row.addWidget(self.query_progress, 1)
        layout.addLayout(query_progress_row)

        btns = QHBoxLayout()
        self.btn_query = QPushButton("2)  Ejecutar consulta")
        self.btn_query.setObjectName("run_btn")
        self.btn_close = QPushButton("Cerrar")
        btns.addStretch()
        btns.addWidget(self.btn_query)
        btns.addWidget(self.btn_close)
        layout.addLayout(btns)

        layout.addWidget(export_group)

        layout.addWidget(QLabel("Registro"))
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        layout.addWidget(self.log_box)

        self.btn_browse.clicked.connect(self.choose_folder)
        self.btn_scan.clicked.connect(self.scan_folder)
        self.btn_query.clicked.connect(self.run_query)
        self.btn_close.clicked.connect(self._close_parent_dialog)
        self.btn_export_folder.clicked.connect(self.choose_export_folder)
        self.btn_export_gpkg.clicked.connect(self.export_results_to_gpkg)
        self.btn_export_csv.clicked.connect(self.export_summary_to_csv)

    def _close_parent_dialog(self):
        parent = self.window()
        if parent is not None:
            parent.close()

    def log(self, text):
        self.log_box.append(text)
        try:
            self.status_callback(text)
        except Exception:
            pass

    def choose_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Selecciona la carpeta con los GeoPackage")
        if folder:
            self.folder_path = folder
            self.folder_edit.setText(folder)
            if not self.export_folder_edit.text().strip():
                self.export_folder_edit.setText(folder)

    def choose_export_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Selecciona la carpeta de salida")
        if folder:
            self.export_folder_edit.setText(folder)

    def selected_target_layers(self):
        layers = []
        if self.chk_points.isChecked():
            layers.append("SDON_Puntos")
        if self.chk_lines.isChecked():
            layers.append("SDON_Lineas")
        if self.chk_polygons.isChecked():
            layers.append("SDON_Poligonos")
        return layers

    def normalize_name(self, name):
        # V1.7.16: misma normalización que el resto del plugin (sin tildes,
        # también "À"/"Ü" y tildes escritas aparte), pero conservando los
        # espacios interiores.
        return strip_accents(str(name)).strip().lower()

    def find_existing_field(self, fields, candidates):
        names = [f.name() for f in fields]
        for c in candidates:
            if c in names:
                return c
        normalized = {self.normalize_name(n): n for n in names}
        for c in candidates:
            hit = normalized.get(self.normalize_name(c))
            if hit:
                return hit
        return None

    @staticmethod
    def _is_own_export(gpkg_path):
        """V1.7.16: los ficheros que exporta esta misma pestaña no son obras."""
        return os.path.basename(gpkg_path).lower().startswith(EXPORT_PREFIX)

    def _list_gpkg_feature_tables(self, gpkg_path):
        tables = []
        conn = None
        try:
            conn = sqlite3.connect(gpkg_path)
            cur = conn.cursor()
            cur.execute("SELECT table_name, data_type FROM gpkg_contents")
            for table_name, data_type in cur.fetchall():
                if str(data_type).lower() == "features":
                    tables.append(str(table_name))
        except Exception as e:
            # V1.7.16: antes se omitía sin dejar rastro.
            self.log(f"⚠ No se pudo leer {os.path.basename(gpkg_path)}: {e}")
        finally:
            if conn is not None:
                conn.close()
        return tables

    def _canonical_target_for_table(self, table_name):
        normalized = self.normalize_name(table_name)
        if normalized.startswith("result_"):
            return None   # V1.7.16: capas de resultado de una consulta anterior
        for canonical, suffixes in CANONICAL_SUFFIXES.items():
            canonical_norm = self.normalize_name(canonical)
            if normalized == canonical_norm:
                return canonical
            for suffix in suffixes:
                suffix_norm = self.normalize_name(suffix)
                if normalized.endswith(suffix_norm):
                    return canonical
        return None

    def _discover_target_layers(self, gpkg_path):
        discovered = {}
        for table_name in self._list_gpkg_feature_tables(gpkg_path):
            canonical = self._canonical_target_for_table(table_name)
            if canonical and canonical not in discovered:
                discovered[canonical] = table_name
        return discovered

    def _clave_map(self, gpkg_path):
        """{código: descripción} de la tabla CLAVE del GeoPackage (una sola
        lectura por fichero; V1.7.16: antes una conexión por cada valor)."""
        if gpkg_path in self._clave_cache:
            return self._clave_cache[gpkg_path]
        mapping = {}
        conn = None
        try:
            conn = sqlite3.connect(gpkg_path)
            cur = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
            table_names = [r[0] for r in cur.fetchall()]
            clave_table = next((t for t in table_names if self.normalize_name(t) == 'clave'), None)
            if clave_table:
                cur.execute(f'PRAGMA table_info("{clave_table}")')
                columns = [r[1] for r in cur.fetchall()]
                norm_to_real = {self.normalize_name(c): c for c in columns}
                key_candidates = ['key', 'clave', 'codigo', 'id', 'tipo_key', 'tipoid', 'tipo_id', 'tipo']
                desc_candidates = ['tipo', 'descripcion', 'description', 'desc', 'tipo_desc', 'nombre', 'label']
                key_field = next((norm_to_real[n] for n in key_candidates if n in norm_to_real), None)
                desc_field = next((norm_to_real[n] for n in desc_candidates
                                   if n in norm_to_real and norm_to_real[n] != key_field), None)
                if key_field and desc_field:
                    for k, d in cur.execute(f'SELECT "{key_field}", "{desc_field}" FROM "{clave_table}"'):
                        if k is not None and d not in (None, ''):
                            mapping[str(k).strip()] = str(d)
        except Exception as e:
            self.log(f"⚠ No se pudo leer la tabla CLAVE de {os.path.basename(gpkg_path)}: {e}")
        finally:
            if conn is not None:
                conn.close()
        self._clave_cache[gpkg_path] = mapping
        return mapping

    def _tipo_desc_for_gpkg(self, gpkg_path, key):
        """Descripción legible del TIPO según la tabla CLAVE de ESE GeoPackage
        (key -> TIPO). Si no puede resolverla, devuelve el código."""
        key = '' if key is None else str(key).strip()
        if not key:
            return key
        return self._clave_map(gpkg_path).get(key, key)

    @staticmethod
    def _value_text(value):
        """Texto de un valor para los filtros. V1.7.16: las fechas salen como
        2024-01-01 (antes "PyQt5.QtCore.QDate(2024, 1, 1)")."""
        if value is None or value == NULL:
            return ''
        if isinstance(value, QDateTime):
            return value.toString('yyyy-MM-dd HH:mm')
        if isinstance(value, QDate):
            return value.toString('yyyy-MM-dd')
        return str(value)

    def _set_busy(self, busy):
        """V1.7.16: botones bloqueados mientras escanea o consulta (un doble
        clic lanzaba dos consultas a la vez y duplicaba capas)."""
        for btn in (self.btn_scan, self.btn_query, self.btn_export_gpkg, self.btn_export_csv, self.btn_browse):
            try:
                btn.setEnabled(not busy)
            except Exception:
                pass

    def _reset_scan_progress(self, text="Escanear carpeta para empezar"):
        self.scan_progress.setMinimum(0)
        self.scan_progress.setMaximum(1)
        self.scan_progress.setValue(0)
        self.scan_progress.setFormat(text)

    def scan_folder(self):
        self._set_busy(True)
        try:
            self._scan_folder()
        finally:
            self._set_busy(False)

    def _obra_labels(self, gpkg_files):
        """Nombre de cada obra. V1.7.16: si dos obras tienen el mismo nombre
        de fichero en carpetas distintas, se añade la carpeta entre
        paréntesis para distinguirlas (antes se mezclaban)."""
        base = {g: os.path.splitext(os.path.basename(g))[0] for g in gpkg_files}
        repeated = {n for n in base.values() if list(base.values()).count(n) > 1}
        labels = {}
        for g, n in base.items():
            if n in repeated:
                parent = os.path.basename(os.path.dirname(os.path.abspath(g)))
                labels[g] = f"{n} ({parent})"
            else:
                labels[g] = n
        return labels

    def _scan_folder(self):
        folder = self.folder_edit.text().strip()
        if not folder or not os.path.isdir(folder):
            QMessageBox.warning(self, "Carpeta no válida", "Selecciona una carpeta válida.")
            return

        self.folder_path = folder
        self.log_box.clear()

        # Modo "ocupado": sin un total conocido de antemano (aún no hemos
        # recorrido la carpeta), la barra se anima en vez de mostrar un
        # porcentaje -- pero el texto SÍ se actualiza en cada subcarpeta
        # revisada, para que se note avance real mientras dura la
        # búsqueda en árboles de carpetas grandes.
        self.scan_progress.setMinimum(0)
        self.scan_progress.setMaximum(0)
        self.scan_progress.setValue(0)
        self.scan_progress.setFormat("Buscando GeoPackage...")

        self.log(f"Buscando GeoPackage en \"{folder}\" y todas sus subcarpetas...")

        def _on_walk_progress(current_dir, dirs_visited, found_count):
            self.scan_progress.setFormat(
                f"Buscando... {dirs_visited} carpeta(s) revisada(s), {found_count} GeoPackage encontrado(s)"
            )
            try:
                QApplication.processEvents()
            except Exception:
                pass

        found_files = scan_gpkg_files_recursive(folder, progress_cb=_on_walk_progress)
        own = [f for f in found_files if self._is_own_export(f)]
        if own:
            # V1.7.16 (A2): la exportación de una consulta anterior no es
            # una obra más (antes cada entidad salía dos veces).
            found_files = [f for f in found_files if not self._is_own_export(f)]
            self.log(f"Se omiten {len(own)} fichero(s) exportados por Consulta: "
                     + ", ".join(os.path.basename(f) for f in own))

        if not found_files:
            self._reset_scan_progress("Sin GeoPackage encontrados")
            QMessageBox.information(self, "Sin archivos", "No se encontraron archivos .gpkg en esa carpeta ni en sus subcarpetas.")
            return

        self._reset_scan_progress(f"{len(found_files)} GeoPackage encontrados -- elige cuáles escanear")

        dialog = GpkgSelectionDialog(found_files, folder, self)
        dialog.exec()
        if not dialog.accepted_selection:
            self._reset_scan_progress("Selección cancelada")
            self.log("Selección de GeoPackage cancelada por el usuario.")
            return

        selected_files = dialog.selected_files()
        if not selected_files:
            self._reset_scan_progress("Sin GeoPackage seleccionados")
            QMessageBox.information(self, "Sin selección", "No se ha marcado ningún GeoPackage para consultar.")
            return

        self.gpkg_files = sorted(selected_files, key=lambda p: os.path.normcase(p))
        self.obra_label = self._obra_labels(self.gpkg_files)
        self.scan_info = {}
        self.tipo_key_by_display = {}
        self._clave_cache = {}
        obras, ambitos, tipos, periodos = set(), set(), set(), set()

        for cmb in (self.cmb_obra, self.cmb_ambito, self.cmb_periodo):
            cmb.clear()
            cmb.addItem(ALL_VALUE)
        self.cmb_tipo.clear()
        self.cmb_tipo.addItem(ALL_VALUE, ALL_VALUE)

        self.log(f"Encontrados {len(found_files)} GeoPackage; {len(self.gpkg_files)} seleccionado(s) para escanear.")
        self.log(f"Escaneando {len(self.gpkg_files)} GeoPackage...")
        total_layers_found = 0

        total_to_scan = len(self.gpkg_files)
        self.scan_progress.setMinimum(0)
        self.scan_progress.setMaximum(total_to_scan)
        self.scan_progress.setValue(0)
        self.scan_progress.setFormat("Escaneando: %v / %m GeoPackage")

        for scan_index, gpkg in enumerate(self.gpkg_files, start=1):
            obra = self.obra_label[gpkg]
            per_file = {}
            discovered_layers = self._discover_target_layers(gpkg)
            for canonical_name in TARGET_LAYERS:
                real_layer_name = discovered_layers.get(canonical_name)
                if not real_layer_name:
                    continue

                uri = f"{gpkg}|layername={real_layer_name}"
                layer = QgsVectorLayer(uri, real_layer_name, "ogr")
                if not layer.isValid():
                    self.log(f"⚠ No se pudo abrir {real_layer_name} de {os.path.basename(gpkg)}; se omite.")
                    continue

                ambito_field = self.find_existing_field(layer.fields(), AMBITO_NAMES)
                tipo_field = self.find_existing_field(layer.fields(), TIPO_NAMES)
                periodo_field = self.find_existing_field(layer.fields(), PERIODO_NAMES)

                if not any([ambito_field, tipo_field, periodo_field]):
                    continue

                total_layers_found += 1
                per_file[canonical_name] = {
                    "real_layer_name": real_layer_name,
                    "ambito_field": ambito_field,
                    "tipo_field": tipo_field,
                    "periodo_field": periodo_field,
                    "crs_authid": layer.crs().authid() if layer.crs().isValid() else "EPSG:4326",
                    "wkb_type": int(layer.wkbType()),
                }

                obras.add(obra)
                if ambito_field:
                    idx = layer.fields().indexOf(ambito_field)
                    ambitos.update(str(v) for v in layer.uniqueValues(idx) if v not in (None, ""))
                if tipo_field:
                    idx = layer.fields().indexOf(tipo_field)
                    for v in layer.uniqueValues(idx):
                        if v in (None, ""):
                            continue
                        tipos.add(self._tipo_desc_for_gpkg(gpkg, v))
                if periodo_field:
                    idx = layer.fields().indexOf(periodo_field)
                    periodos.update(self._value_text(v) for v in layer.uniqueValues(idx) if v not in (None, ""))

            if per_file:
                self.scan_info[gpkg] = per_file
                visible = [f"{k}→{v.get('real_layer_name', k)}" for k, v in per_file.items()]
                self.log(f"OK {obra} -> {', '.join(visible)}")

            self.scan_progress.setValue(scan_index)
            try:
                QApplication.processEvents()
            except Exception:
                pass

        self.scan_progress.setFormat("Escaneo completado: %v / %m GeoPackage")

        for value in sorted(obras):
            self.cmb_obra.addItem(value)
        for value in sorted(ambitos):
            self.cmb_ambito.addItem(value)
        # V1.7.16 (A3): el desplegable Tipo filtra por DESCRIPCIÓN. El mismo
        # código puede significar cosas distintas en obras con tablas CLAVE
        # distintas (3 = "Arqueta" en una y "Poste" en otra).
        for desc in sorted(tipos, key=lambda x: (x.lower(), x)):
            self.tipo_key_by_display[desc] = desc
            self.cmb_tipo.addItem(desc, desc)
        for value in sorted(v for v in periodos if v):
            self.cmb_periodo.addItem(value)

        self.log("")
        self.log(f"GeoPackage válidos: {len(self.scan_info)}")
        self.log(f"Capas detectadas: {total_layers_found}")
        self.log(f"Obras: {len(obras)} | Ámbito: {len(ambitos)} | Tipo: {len(tipos)} | Periodo: {len(periodos)}")

        if not self.scan_info:
            QMessageBox.information(self, "Sin capas compatibles", "No se encontraron capas SDON_* con campos compatibles.")

    def _find_tipo_field_name(self, layer):
        return self.find_existing_field(layer.fields(), TIPO_NAMES)

    def _prune_result_legend(self, layer):
        """Ajusta la leyenda del resultado a las categorías realmente
        presentes. V1.7.16: con el mismo recorte que Carga Obra
        (core/legend_pruner.py), que conserva "resto de valores" cuando
        hace falta."""
        try:
            self._pruner.prune_layer_legend(layer)
        except Exception as e:
            self.log(f"Aviso al ajustar leyenda de {layer.name()}: {e}")

    @staticmethod
    def _extra_field_names(fields):
        """Nombres de los campos "obra" y "archivo_gpkg" del resultado que no
        chocan con campos de la obra. V1.7.16: la comparación no distingue
        mayúsculas (una obra con OBRA u Obra hacía fallar la exportación)."""
        lower = {f.name().lower() for f in fields}
        names = {}
        for base in ("obra", "archivo_gpkg"):
            name = base
            n = 2
            while name.lower() in lower:
                name = f"{base}_consulta" if n == 2 else f"{base}_consulta{n}"
                n += 1
            names[base] = name
        return names

    def make_result_layer(self, result_name, sample_layers, crs):
        """Capa resultado en memoria con la UNIÓN de los campos de todas las
        capas de origen (V1.7.16: antes solo los de la primera obra) y el
        sistema de coordenadas `crs`."""
        if not isinstance(sample_layers, (list, tuple)):
            sample_layers = [sample_layers]
        fields = QgsFields()
        existing = set()
        for src in sample_layers:
            for fld in src.fields():
                # V201: "fid" no se copia: cada obra repite 1, 2, 3... y al
                # exportar a GeoPackage chocaba con su clave primaria.
                if fld.name().lower() in ('fid', 'ogc_fid') or fld.name().lower() in existing:
                    continue
                fields.append(fld)
                existing.add(fld.name().lower())
        extra = self._extra_field_names(fields)
        fields.append(_text_field(extra["obra"], 120))
        fields.append(_text_field(extra["archivo_gpkg"], 255))

        wkb = QgsWkbTypes.multiType(sample_layers[0].wkbType())
        geometry_str = QgsWkbTypes.displayString(wkb)
        crs_authid = crs.authid() if crs is not None and crs.isValid() else "EPSG:4326"
        uri = f"{geometry_str}?crs={crs_authid}"
        mem = QgsVectorLayer(uri, result_name, "memory")
        pr = mem.dataProvider()
        pr.addAttributes(fields)
        mem.updateFields()
        mem.setCustomProperty(RESULT_PROP, True)
        mem.setCustomProperty(RESULT_PROP + "/obra_field", extra["obra"])
        mem.setCustomProperty(RESULT_PROP + "/archivo_field", extra["archivo_gpkg"])
        return mem

    def apply_source_style(self, source_layer, target_layer):
        keep = {k: target_layer.customProperty(k) for k in
                (RESULT_PROP, RESULT_PROP + "/obra_field", RESULT_PROP + "/archivo_field")}
        try:
            source_layer.loadDefaultStyle()
        except Exception:
            pass

        try:
            if source_layer.renderer():
                target_layer.setRenderer(source_layer.renderer().clone())
        except Exception as e:
            self.log(f"Aviso al clonar renderizador de {source_layer.name()}: {e}")

        try:
            target_layer.setLabelsEnabled(source_layer.labelsEnabled())
            if source_layer.labelsEnabled() and source_layer.labeling():
                target_layer.setLabeling(source_layer.labeling().clone())
        except Exception:
            pass

        try:
            target_layer.setOpacity(source_layer.opacity())
        except Exception:
            pass

        for prop in [
            "legend/label-0",
            "embeddedWidgets/count",
            "embeddedWidgets/0/id",
            "embeddedWidgets/0/config",
            "labeling",
            "labeling/enabled",
            "labeling/fontFamily",
            "labeling/fontSize",
            "labeling/fieldName",
            "MapTip",
        ]:
            try:
                val = source_layer.customProperty(prop, None)
                if val is not None:
                    target_layer.setCustomProperty(prop, val)
            except Exception:
                pass

        try:
            style = QgsMapLayerStyle()
            style.readFromLayer(source_layer)
            style.writeToLayer(target_layer)
        except Exception:
            pass
        # writeToLayer() copia también propiedades de la capa: se restaura la
        # marca de "capa resultado" y los nombres de sus campos extra.
        for k, v in keep.items():
            if v is not None:
                target_layer.setCustomProperty(k, v)

        try:
            target_layer.triggerRepaint()
        except Exception:
            pass

    def _document_field_names(self, layer):
        """Nombres de los campos de documento/foto de la capa (widget
        "ExternalResource"; sin estilo guardado, por su nombre: Ficha,
        Foto 1-4, Doc_Apertura, Doc_Cierre)."""
        return document_field_names(layer, include_known=True)

    def _apply_document_widgets(self, src_layer, target_layer, document_fields):
        """Traslada a la capa resultado el widget "ExternalResource" de
        cada campo de documento/foto detectado en la capa origen, pero
        forzando `RelativeStorage` a Absoluto: como build_feature_out ya
        resuelve cada ruta a una ruta absoluta real (ver
        core.gpkg_utils.resolve_attachment_path), el widget de la capa
        resultado debe interpretar el valor guardado tal cual, sin
        intentar resolverlo de nuevo contra una carpeta relativa que ya no
        tiene sentido en una capa que mezcla varios GeoPackage de origen."""
        if not document_fields:
            return
        target_fields = target_layer.fields()
        for name in document_fields:
            src_idx = src_layer.fields().indexOf(name)
            tgt_idx = target_fields.indexOf(name)
            if src_idx < 0 or tgt_idx < 0:
                continue
            try:
                setup = src_layer.editorWidgetSetup(src_idx)
                src_config = dict(setup.config() or {}) if setup.type() == 'ExternalResource' else {}
            except Exception:
                src_config = {}
            src_config['RelativeStorage'] = 0  # Absoluto.
            src_config['DefaultRoot'] = ''
            try:
                target_layer.setEditorWidgetSetup(tgt_idx, QgsEditorWidgetSetup('ExternalResource', src_config))
            except Exception as e:
                self.log(f"Aviso al configurar el campo de documento \"{name}\" en el resultado: {e}")

    def build_feature_out(self, feat_in, result_layer, obra, archivo_gpkg, document_fields=None, gpkg_path=None,
                          transform=None, roots=None):
        document_fields = document_fields or set()
        roots = roots or {}
        obra_field = result_layer.customProperty(RESULT_PROP + "/obra_field", "obra")
        archivo_field = result_layer.customProperty(RESULT_PROP + "/archivo_field", "archivo_gpkg")
        out = QgsFeature(result_layer.fields())
        geom = QgsGeometry(feat_in.geometry())
        if transform is not None and not geom.isNull():
            try:
                geom.transform(transform)
            except Exception as e:
                self.log(f"⚠ No se pudo transformar una entidad de {obra}: {e}")
        if not geom.isNull():
            geom.convertToMultiType()
        out.setGeometry(geom)
        input_names = feat_in.fields().names()
        input_by_lower = {n.lower(): n for n in input_names}
        attrs = []
        for f in result_layer.fields():
            n = f.name()
            if n == obra_field:
                attrs.append(obra)
            elif n == archivo_field:
                attrs.append(archivo_gpkg)
            elif n.lower() in input_by_lower:
                src_name = input_by_lower[n.lower()]
                value = feat_in[src_name]
                if src_name in document_fields and value not in (None, "") and gpkg_path:
                    if not is_url(value):
                        resolved, found = resolve_attachment_path(value, gpkg_path, roots.get(src_name))
                        if resolved:
                            value = resolved
                            if not found:
                                self._missing_docs_log.add((n, resolved))
                attrs.append(value)
            else:
                attrs.append(None)
        out.setAttributes(attrs)
        return out

    def feature_matches(self, feat, info, obra_value, ambito_value, tipo_value, periodo_value, gpkg_path=None):
        ambito_field = info.get("ambito_field")
        tipo_field = info.get("tipo_field")
        periodo_field = info.get("periodo_field")

        if ambito_value != ALL_VALUE:
            if not ambito_field or str(feat[ambito_field]) != ambito_value:
                return False
        if tipo_value != ALL_VALUE:
            if not tipo_field:
                return False
            value = feat[tipo_field]
            if value in (None, ""):
                return False
            # V1.7.16 (A3): se compara la descripción según la CLAVE de la
            # propia obra, no el código.
            desc = self._tipo_desc_for_gpkg(gpkg_path, value) if gpkg_path else str(value)
            if desc != tipo_value:
                return False
        if periodo_value != ALL_VALUE:
            if not periodo_field or self._value_text(feat[periodo_field]) != periodo_value:
                return False
        return True

    def remove_existing_result_layers(self):
        """Quita las capas resultado de la consulta anterior. V1.7.16: solo
        las creadas por esta pestaña (no cualquier capa llamada RESULT_*), y
        el grupo solo si queda vacío: una capa del usuario metida en el
        grupo ya no desaparece del proyecto."""
        project = QgsProject.instance()
        ids = [l.id() for l in project.mapLayers().values()
               if l.name() in RESULT_NAMES and l.customProperty(RESULT_PROP, False) in (True, 'true', '1', 1)]
        if ids:
            project.removeMapLayers(ids)
        group = project.layerTreeRoot().findGroup(RESULT_GROUP)
        if group is not None and not group.findLayers():
            project.layerTreeRoot().removeChildNode(group)

    def _reset_query_progress(self, text="Ejecutar consulta para empezar"):
        self.query_progress.setMinimum(0)
        self.query_progress.setMaximum(1)
        self.query_progress.setValue(0)
        self.query_progress.setFormat(text)

    def run_query(self):
        self._set_busy(True)
        try:
            self._run_query()
        finally:
            self._set_busy(False)

    def _run_query(self):
        if not self.scan_info:
            self._reset_query_progress("Primero escanea la carpeta")
            QMessageBox.warning(self, "Primero escanea", "Primero debes escanear la carpeta.")
            return

        selected_layers = self.selected_target_layers()
        if not selected_layers:
            self._reset_query_progress("Selecciona al menos una capa")
            QMessageBox.warning(self, "Sin capas", "Selecciona al menos una capa.")
            return

        obra_value = self.cmb_obra.currentText()
        ambito_value = self.cmb_ambito.currentText()
        tipo_value = self.cmb_tipo.currentData() if self.cmb_tipo.currentIndex() >= 0 else self.cmb_tipo.currentText()
        periodo_value = self.cmb_periodo.currentText()

        self.remove_existing_result_layers()

        self._missing_docs_log = set()
        counts = {name: 0 for name in RESULT_NAMES}
        lost = {name: 0 for name in RESULT_NAMES}
        result_name_map = {
            "SDON_Puntos": "RESULT_PUNTOS",
            "SDON_Lineas": "RESULT_LINEAS",
            "SDON_Poligonos": "RESULT_POLIGONOS",
        }

        self.log("")
        self.log("Ejecutando consulta...")
        self.log(f"Obra={obra_value} | Ámbito={ambito_value} | Tipo={tipo_value} | Periodo={periodo_value}")

        # 1) Capas de origen que entran en la consulta.
        units = []   # (gpkg, obra, layer_name, info, src)
        for gpkg, per_file in self.scan_info.items():
            obra = self.obra_label.get(gpkg) or os.path.splitext(os.path.basename(gpkg))[0]
            if obra_value != ALL_VALUE and obra != obra_value:
                continue
            for layer_name in selected_layers:
                if layer_name not in per_file:
                    continue
                info = per_file[layer_name]
                real_layer_name = info.get("real_layer_name", layer_name)
                src = QgsVectorLayer(f"{gpkg}|layername={real_layer_name}", real_layer_name, "ogr")
                if not src.isValid():
                    self.log(f"⚠ No se pudo abrir {real_layer_name} de {obra}; se omite.")
                    continue
                # Estilo persistido de ESTA capa origen (formulario/widgets
                # de campo) antes de leer su editorWidgetSetup.
                try:
                    src.loadDefaultStyle()
                except Exception:
                    pass
                units.append((gpkg, obra, layer_name, info, src))

        # 2) V1.7.16: una capa resultado por tipo con la unión de campos de
        # todas las obras y un único sistema de coordenadas (el del
        # proyecto si lo tiene; si no, el de la primera obra). Cada obra se
        # transforma a ese sistema.
        project = QgsProject.instance()
        created_layers = {}
        for result_name in RESULT_NAMES:
            sources = [u[4] for u in units if result_name_map[u[2]] == result_name]
            if not sources:
                continue
            crs = project.crs() if project.crs().isValid() else sources[0].crs()
            created_layers[result_name] = self.make_result_layer(result_name, sources, crs)
            self.apply_source_style(sources[0], created_layers[result_name])

        self.query_progress.setMinimum(0)
        self.query_progress.setMaximum(max(len(units), 1))
        self.query_progress.setValue(0)
        self.query_progress.setFormat("Consultando: %v / %m capas")

        for n_unit, (gpkg, obra, layer_name, info, src) in enumerate(units, start=1):
            self.query_progress.setValue(n_unit)
            try:
                QApplication.processEvents()
            except Exception:
                pass

            result_name = result_name_map[layer_name]
            out_layer = created_layers[result_name]
            document_fields = self._document_field_names(src)
            roots = {name: attachment_default_root(src, src.fields().indexOf(name)) for name in document_fields}
            self._apply_document_widgets(src, out_layer, document_fields)

            transform = None
            if src.crs().isValid() and out_layer.crs().isValid() and src.crs() != out_layer.crs():
                transform = QgsCoordinateTransform(src.crs(), out_layer.crs(), project)
            elif not src.crs().isValid():
                self.log(f"⚠ {obra}: la capa {src.name()} no tiene sistema de coordenadas; se copia sin transformar.")

            archivo = os.path.basename(gpkg)
            feats_to_add = []
            for feat in src.getFeatures():
                if self.feature_matches(feat, info, obra_value, ambito_value, tipo_value, periodo_value, gpkg):
                    feats_to_add.append(self.build_feature_out(
                        feat, out_layer, obra, archivo, document_fields, gpkg, transform, roots))

            if feats_to_add:
                ok, added = out_layer.dataProvider().addFeatures(feats_to_add)
                n_ok = len(added) if ok else 0
                # V1.7.16: si el proveedor rechaza entidades se avisa (antes
                # se perdían sin aviso y el contador las sumaba igual).
                if not ok or n_ok < len(feats_to_add):
                    lost[result_name] += len(feats_to_add) - n_ok
                out_layer.updateExtents()
                counts[result_name] += n_ok

        self.query_progress.setFormat("Consulta completada: %v / %m capas")

        if self._missing_docs_log:
            self.log("")
            self.log(f"⚠ {len(self._missing_docs_log)} documento(s)/foto(s) no se encontraron en disco (se guarda la mejor ruta estimada, revisa la carpeta):")
            for field_name, path in sorted(self._missing_docs_log):
                self.log(f"  {field_name}: {path}")
        for result_name, n in lost.items():
            if n:
                self.log(f"⚠ {result_name}: {n} entidad(es) no se pudieron añadir al resultado.")

        if not created_layers:
            QMessageBox.information(self, "Sin resultados", "No se generó ninguna capa resultado.")
            return

        root = project.layerTreeRoot()
        result_group = root.findGroup(RESULT_GROUP) or root.addGroup(RESULT_GROUP)

        added = []
        for result_name in ["RESULT_POLIGONOS", "RESULT_LINEAS", "RESULT_PUNTOS"]:
            layer = created_layers.get(result_name)
            if layer and layer.featureCount() > 0:
                self._prune_result_legend(layer)
                project.addMapLayer(layer, False)
                result_group.addLayer(layer)
                added.append(layer)
                self.log(f"{result_name}: {counts[result_name]} entidades")
            elif layer:
                self.log(f"{result_name}: 0 entidades")

        if not added:
            if not result_group.findLayers():
                root.removeChildNode(result_group)
            QMessageBox.information(self, "Sin resultados", "No hay entidades que cumplan el filtro.")
            return

        if self.chk_zoom.isChecked():
            self._zoom_to(added)

        try:
            self.iface.messageBar().pushMessage(
                "MultiObra Query Pro",
                "Consulta finalizada. Revisa el grupo RESULTADOS_MULTIObra.",
                level=0,
                duration=5
            )
        except Exception:
            pass
        QMessageBox.information(self, "Consulta finalizada", "Consulta completada correctamente.")

    def _zoom_to(self, layers):
        """V1.7.16: la extensión se pasa al sistema de coordenadas del lienzo."""
        try:
            canvas = self.iface.mapCanvas()
            dest = canvas.mapSettings().destinationCrs()
        except Exception:
            return
        extent = None
        for lyr in layers:
            ext = lyr.extent()
            if dest.isValid() and lyr.crs().isValid() and lyr.crs() != dest:
                try:
                    ext = QgsCoordinateTransform(lyr.crs(), dest, QgsProject.instance()).transformBoundingBox(ext)
                except Exception:
                    pass
            if extent is None:
                extent = ext
            else:
                extent.combineExtentWith(ext)
        if extent and not extent.isEmpty():
            canvas.setExtent(extent)
            canvas.refresh()

    def current_result_layers(self):
        project = QgsProject.instance()
        result = []
        for name in RESULT_NAMES:
            result.extend(project.mapLayersByName(name))
        return result

    def export_results_to_gpkg(self):
        layers = self.current_result_layers()
        if not layers:
            QMessageBox.warning(self, "Sin resultados", "Primero ejecuta una consulta.")
            return

        out_dir = self.export_folder_edit.text().strip()
        if not out_dir or not os.path.isdir(out_dir):
            QMessageBox.warning(self, "Salida no válida", "Selecciona una carpeta de salida válida.")
            return

        out_path = os.path.join(out_dir, EXPORT_PREFIX + ".gpkg")
        if os.path.exists(out_path):
            try:
                os.remove(out_path)
            except Exception as e:
                QMessageBox.warning(self, "No se puede sobrescribir", str(e))
                return

        first = True
        for lyr in layers:
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "GPKG"
            options.layerName = lyr.name()
            options.fileEncoding = "UTF-8"
            options.actionOnExistingFile = (QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteFile if first
                                            else QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer)

            res = QgsVectorFileWriter.writeAsVectorFormatV3(
                lyr, out_path, QgsCoordinateTransformContext(), options
            )
            err = res[0] if isinstance(res, tuple) else res
            msg = res[1] if isinstance(res, tuple) and len(res) > 1 else ""
            if err != QgsVectorFileWriter.WriterError.NoError:
                QMessageBox.warning(self, "Error exportando", str(msg))
                return
            first = False
            # V1.7.16: la exportación lleva la leyenda y los widgets (las
            # fotos se abren como adjunto al cargar el GeoPackage exportado).
            try:
                written = QgsVectorLayer(f"{out_path}|layername={lyr.name()}", lyr.name(), "ogr")
                style = QgsMapLayerStyle()
                style.readFromLayer(lyr)
                style.writeToLayer(written)
                written.saveStyleToDatabase(lyr.name(), "Consulta multiobra", True, "")
                del written
            except Exception as e:
                self.log(f"Aviso: no se pudo guardar el estilo de {lyr.name()} en la exportación: {e}")

        QMessageBox.information(self, "Exportación completada", f"GeoPackage generado:\n{out_path}")

    def export_summary_to_csv(self):
        layers = self.current_result_layers()
        if not layers:
            QMessageBox.warning(self, "Sin resultados", "Primero ejecuta una consulta.")
            return

        out_dir = self.export_folder_edit.text().strip()
        if not out_dir or not os.path.isdir(out_dir):
            QMessageBox.warning(self, "Salida no válida", "Selecciona una carpeta de salida válida.")
            return

        out_path = os.path.join(out_dir, EXPORT_PREFIX + "_resumen.csv")
        rows = []
        for lyr in layers:
            obra_field = lyr.customProperty(RESULT_PROP + "/obra_field", "obra")
            idx_obra = lyr.fields().indexOf(obra_field)
            tipo_field = self.find_existing_field(lyr.fields(), TIPO_NAMES)   # V1.7.16: también "tipo"
            idx_tipo = lyr.fields().indexOf(tipo_field) if tipo_field else -1
            counts = defaultdict(int)
            for feat in lyr.getFeatures():
                obra = str(feat[idx_obra]) if idx_obra != -1 else ""
                tipo = self._value_text(feat[idx_tipo]) if idx_tipo != -1 else ""
                counts[(lyr.name(), obra, tipo)] += 1
            for (layer_name, obra, tipo), total in counts.items():
                rows.append([layer_name, obra, tipo, total])

        try:
            with open(out_path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f, delimiter=";")
                writer.writerow(["capa", "obra", "tipo", "total"])
                for row in sorted(rows):
                    writer.writerow(row)
        except OSError as e:
            # V1.7.16: típico con el CSV abierto en Excel.
            QMessageBox.warning(self, "No se puede escribir el CSV",
                                f"No se pudo guardar {out_path}.\n¿Está abierto en Excel?\n\n{e}")
            return

        QMessageBox.information(self, "Exportación completada", f"Resumen CSV generado:\n{out_path}")

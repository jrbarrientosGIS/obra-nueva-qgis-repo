# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTabWidget, QTextEdit, QScrollArea, QSizePolicy, QWidget, QFrame
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QFont

from ..core.settings_manager import SettingsManager
from .tab_nueva_obra import NuevaObraTab
from .tab_carga_obra import CargaObraTab
from .tab_kmz import KmzTab
from .tab_consulta import ConsultaTab
from .tab_fotos import FotosTab
from .tab_actualiza_gpkg import ActualizaGpkgTab
from .tab_archivar_gpkg import ArchivarGpkgTab
from .tab_archivos import ArchivosTab, DialogoHerramienta
from .help_dialog import HelpDialog
from .styles import get_stylesheet



def _plugin_version():
    """Versión leída de metadata.txt (V1.7.16: antes la cabecera decía v1.7.3)."""
    import configparser
    import os
    meta = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'metadata.txt')
    try:
        cp = configparser.ConfigParser(interpolation=None)
        cp.read(meta, encoding='utf-8')
        return cp.get('general', 'version').split('-')[0]
    except Exception:
        return '?'

class ObraNuevaMainDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.settings = SettingsManager()
        self.setWindowTitle('OBRA_NUEVA')
        self.resize(1220, 790)
        self.setMinimumSize(900, 650)
        self.setSizeGripEnabled(True)
        self.setStyleSheet(get_stylesheet())
        self.setup_ui()
        self.restore_state()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Cabecera ──────────────────────────────────────────────────────────
        header_widget = QWidget()
        header_widget.setObjectName("header_widget")
        header_widget.setFixedHeight(52)
        header_layout = QHBoxLayout(header_widget)
        header_layout.setContentsMargins(16, 0, 12, 0)
        header_layout.setSpacing(8)

        # Punto de color decorativo
        dot = QLabel("●")
        dot.setStyleSheet("color: #4A90D9; font-size: 14pt; background: transparent;")
        dot.setFixedWidth(20)

        title = QLabel("OBRA_NUEVA")
        title.setObjectName("main_title")
        title.setProperty("class", "title")
        font_title = QFont()
        font_title.setBold(True)
        font_title.setPointSize(11)
        title.setFont(font_title)
        title.setStyleSheet("color: #E8EDF5; background: transparent; font-size: 11pt; font-weight: bold;")

        sep = QLabel("·")
        sep.setStyleSheet("color: #374461; font-size: 11pt; background: transparent;")

        subtitle = QLabel("Plataforma GeoPackage / KMZ / Multiobra")
        subtitle.setProperty("class", "subtitle")
        subtitle.setStyleSheet("color: #8A9BBE; background: transparent; font-size: 9pt;")

        self.btn_help = QPushButton("⚙  Ayuda")
        self.btn_help.setObjectName("btn_help")
        self.btn_help.setFixedHeight(28)
        self.btn_help.clicked.connect(self.open_help)

        header_layout.addWidget(dot)
        header_layout.addWidget(title)
        header_layout.addWidget(sep)
        header_layout.addWidget(subtitle)
        header_layout.addStretch()
        header_layout.addWidget(self.btn_help)

        layout.addWidget(header_widget)

        # ── Separador ────────────────────────────────────────────────────────
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setFrameShadow(QFrame.Shadow.Plain)
        line.setStyleSheet("color: #4A90D9; background-color: #4A90D9; max-height: 1px;")
        layout.addWidget(line)

        # ── Área de contenido con márgenes ───────────────────────────────────
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(10, 8, 10, 0)
        content_layout.setSpacing(6)

        # ── Pestañas ─────────────────────────────────────────────────────────
        self.tabs = QTabWidget()
        self.tabs.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        content_layout.addWidget(self.tabs, 1)

        # ── Consola de estado ────────────────────────────────────────────────
        self.status_console = QTextEdit()
        self.status_console.setObjectName("status_console")
        self.status_console.setReadOnly(True)
        self.status_console.setMaximumHeight(130)
        self.status_console.setPlaceholderText("▶  Consola de estado...")
        content_layout.addWidget(self.status_console)

        layout.addWidget(content_widget, 1)

        # ── Barra de estado inferior ─────────────────────────────────────────
        footer = QWidget()
        footer.setFixedHeight(22)
        footer.setStyleSheet(
            "background-color: #131926; border-top: 1px solid #374461;"
        )
        footer_layout = QHBoxLayout(footer)
        footer_layout.setContentsMargins(12, 0, 12, 0)
        footer_lbl = QLabel(f"GIS-OMICRON  ·  v{_plugin_version()}")
        footer_lbl.setStyleSheet("color: #4A5568; font-size: 8pt; background: transparent;")
        footer_layout.addStretch()
        footer_layout.addWidget(footer_lbl)
        layout.addWidget(footer)

        # ── Instanciar pestañas ───────────────────────────────────────────────
        # V1.7.17: pestañas principales Nueva Obra, Carga Obra, Fotos y Consulta;
        # KMZ, Actualiza GPKG y Archivar GPKG pasan a la pestaña "Archivos" y
        # cada una se abre en su propio cuadro de diálogo.
        self.tab_nueva = NuevaObraTab(self.iface, self.append_status)
        self.tab_carga = CargaObraTab(self.iface, self.append_status)
        self.tab_consulta = ConsultaTab(self.iface, self.append_status)
        self.tab_fotos = FotosTab(self.iface, self.append_status)

        self.tab_fotos_scroll = QScrollArea()
        self.tab_fotos_scroll.setWidgetResizable(True)
        self.tab_fotos_scroll.setWidget(self.tab_fotos)

        def _herramienta(titulo, clase, con_consola=True):
            dlg = DialogoHerramienta(titulo, self, con_consola=con_consola)

            def _estado(mensaje, _d=dlg):
                _d.anotar(mensaje)
                self.append_status(mensaje)
            tab = clase(self.iface, _estado)
            dlg.poner_contenido(tab)
            return dlg, tab

        self.dlg_kmz, self.tab_kmz = _herramienta("OBRA_NUEVA · Exporta a KML/KMZ", KmzTab)
        self.dlg_actualiza_gpkg, self.tab_actualiza_gpkg = _herramienta(
            "OBRA_NUEVA · Actualiza GPKG", ActualizaGpkgTab)
        self.dlg_archivar_gpkg, self.tab_archivar_gpkg = _herramienta(
            "OBRA_NUEVA · Archivar GPKG", ArchivarGpkgTab, con_consola=False)

        self.tab_archivos = ArchivosTab([
            ("🗺  Exporta a KML/KMZ",
             "Exporta capas del GeoPackage a KMZ con la leyenda del GeoPackage.",
             self.dlg_kmz, None),
            ("🔄  Actualiza GPKG",
             "Pone al día la estructura, los estilos y los formularios de una obra con el modelo.",
             self.dlg_actualiza_gpkg, self.tab_actualiza_gpkg.refresh_project_default),
            ("🗄  Archivar GPKG",
             "Copia una obra terminada a otra carpeta dejando sus adjuntos accesibles.",
             self.dlg_archivar_gpkg, self.tab_archivar_gpkg.refresh_project_default),
        ])

        # Orden de las pestañas
        self.tabs.addTab(self.tab_nueva,        "🗂  Nueva Obra")
        self.tabs.addTab(self.tab_carga,        "📂  Carga Obra")
        self.tabs.addTab(self.tab_fotos_scroll, "📷  Fotos")
        self.tabs.addTab(self.tab_consulta,     "🔍  Consulta")
        self.tabs.addTab(self.tab_archivos,     "📁  Archivos")

        self.tabs.currentChanged.connect(self._on_tab_changed)
        self._on_tab_changed(self.tabs.currentIndex())

    def _on_tab_changed(self, index):
        widget = self.tabs.widget(index)
        # Consulta y Archivos no usan la consola de estado de la ventana principal.
        self.status_console.setVisible(widget not in (self.tab_consulta, self.tab_archivos))

    def open_help(self):
        plugin_dir = getattr(self.iface, 'plugin_dir', '')
        if not plugin_dir:
            plugin_dir = os.path.dirname(os.path.dirname(__file__))
        dlg = HelpDialog(plugin_dir, self)
        dlg.exec()

    def append_status(self, message):
        if hasattr(self, 'status_console') and self.status_console is not None:
            self.status_console.append(str(message))

    def closeEvent(self, event):
        self.settings.set('last_tab_1717', self.tabs.currentIndex())
        super().closeEvent(event)

    def restore_state(self):
        idx = int(self.settings.get('last_tab_1717', 0) or 0)
        self.tabs.setCurrentIndex(idx if 0 <= idx < self.tabs.count() else 0)

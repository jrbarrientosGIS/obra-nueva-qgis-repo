# -*- coding: utf-8 -*-
from qgis.core import QgsMessageLog, Qgis


PLUGIN_TAG = 'OBRA_NUEVA'


def log_info(message):
    QgsMessageLog.logMessage(str(message), PLUGIN_TAG, Qgis.MessageLevel.Info)


def log_warning(message):
    QgsMessageLog.logMessage(str(message), PLUGIN_TAG, Qgis.MessageLevel.Warning)


def log_error(message):
    QgsMessageLog.logMessage(str(message), PLUGIN_TAG, Qgis.MessageLevel.Critical)


def log_message(message, level=Qgis.MessageLevel.Info):
    """Única forma de escribir en el registro de QGIS (pestaña OBRA_NUEVA).
    V1.7.16: antes cada pestaña llamaba a QgsMessageLog por su cuenta."""
    QgsMessageLog.logMessage(str(message), PLUGIN_TAG, level)

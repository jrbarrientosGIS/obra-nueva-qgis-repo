OBRA_NUEVA 1.7.21 - Fotos, bloque 2: fotos que no son JPG
=========================================================

- Si la foto elegida no es JPG (p. ej. PNG o TIF), el fichero original NO se
  modifica. Se crea un JPG con el mismo nombre en la misma carpeta; si ya
  existe un JPG con ese nombre, se crea nombre_georref.jpg (nunca se pisa
  nada). Ese JPG recibe las coordenadas (EXIF GPS) y, si se pidió, la fecha
  estampada; la fecha (estampada o detectada) también queda como fecha EXIF.
- El JPG nuevo conserva la fecha de modificación del fichero original.
- Si no se puede crear el JPG (carpeta de solo lectura, imagen dañada), se
  avisa en la consola de estado y la foto no se georreferencia.
- La 1.7.20 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.20.zip y
  OBRA_NUEVA_QGIS4_v1.7.20.zip.

V201 - REVISIÓN GENERAL DEL CÓDIGO (1.7.14)
===========================================

Revisión completa del código de la 1.7.13, por áreas: Fotos, Consulta y
Archivar, Nueva Obra / Carga Obra / formulario, Actualiza GPKG, KMZ y
coherencia entre las versiones QGIS 3 y QGIS 4. Cada hallazgo se comprobó
leyendo el código antes de corregirlo. Se corrigen los que podían cerrar
QGIS, perder datos o dejar una función sin funcionar. Los demás quedan
anotados al final.

CORREGIDO
---------
Cierres de QGIS / memoria
  - core/form_customizer.py: al quitar del formulario campos repetidos
    (Apertura, Doc_Apertura, Doc_Cierre, Zona...), se leían los nombres de
    elementos que acababan de destruirse en C++ (memoria ya liberada). Es
    un posible origen de cierres de QGIS durante "Actualiza GPKG" y al
    cargar la obra con el modo Edición/Visualización.
  - ui/tab_fotos.py: las ventanas de vista previa de foto no se liberaban
    nunca y guardaban cada imagen a tamaño completo (unos 48 MB por foto).
    Al recorrer una carpeta de fotos la memoria crecía sin parar. Ahora se
    liberan al cerrarlas.
  - ui/tab_fotos.py: "Georref fotos ámbitos" y la carpeta de las capas de
    fotos usaban la lista de capas guardada al abrir la pestaña, que podía
    contener capas ya eliminadas tras recargar la obra (error o cierre).
    Ahora se relee el proyecto en cada uso.

Pérdida de datos
  - ui/tab_fotos.py: si puntos_informe (u otra capa de fotos) no estaba
    cargada en el proyecto pero ya existía su GeoPackage junto a la obra,
    se creaba una capa vacía en memoria y, al guardar la primera foto,
    sustituía a la existente: se perdían los puntos de días anteriores.
    Ahora se carga la existente, y además nunca se sobrescribe una capa de
    fotos que ya esté en el fichero.
  - ui/tab_nueva_obra.py: con "Sobrescribir" marcado y la misma carpeta y
    nombre que el modelo, se borraba el propio GeoPackage modelo. Ahora se
    impide.
  - core/gpkg_loader.py: al cargar una obra, si ya había en el panel un
    grupo con el mismo nombre pero de OTRO GeoPackage (p. ej. una copia
    archivada en otra carpeta), se eliminaban las capas de esa otra obra.
    Ahora cada GeoPackage usa su propio grupo, del grupo de la obra solo
    se quitan capas de ese mismo GeoPackage, y no se pierden capas que
    estén dentro de subgrupos.
  - core/gpkg_archiver.py: sobrescribir una copia archivada que estaba
    cargada en QGIS, o que tenía ficheros -wal/-shm antiguos, podía dejar
    la copia corrupta. Ahora se avisa si está cargada y se borran los
    -wal/-shm antiguos antes de copiar.

Funciones que no funcionaban
  - ui/tab_fotos.py: "Insertar por coordenadas EXIF" nunca encontraba las
    coordenadas, y la fecha de la foto salía de la fecha de modificación
    en vez de la de captura. Con las versiones de Pillow que trae QGIS, el
    bloque GPS y la fecha de captura (DateTimeOriginal) hay que leerlos con
    get_ifd(). Comprobado con Pillow 12.2.
  - ui/tab_fotos.py: la renumeración de IF ya no confirma ni descarta
    cambios sin guardar que el usuario tuviera en la capa.
  - ui/tab_consulta.py: exportar los resultados de la consulta a GeoPackage
    fallaba con varias obras ("UNIQUE constraint failed ... fid"), porque
    se copiaba el campo fid de cada obra. Ya no se copia.
  - ui/tab_kmz.py: las líneas y polígonos clasificados por Tipo salían sin
    color en Google Earth. Ahora toman el color de su categoría. Cada capa
    tiene su propia imagen de leyenda (antes todas usaban la de la última
    capa). Las fechas salen como dd/mm/aaaa en vez de
    "PyQt5.QtCore.QDate(...)" y los valores vacíos ya no salen como "NULL".
    Si la carpeta de salida no existe (USB o unidad de red desconectada),
    se avisa en vez de mostrar un error de Python.
  - ui/tab_kmz.py (solo QGIS 4): los iconos de punto salían vacíos por un
    enum de Qt5 (QBuffer.WriteOnly). Corregido con
    QIODevice.OpenModeFlag.WriteOnly.
  - core/gpkg_updater.py: "Actualiza GPKG" en modo carpeta ya no modifica
    GeoPackages que no son de obra (sin capas Puntos/Líneas/Polígonos). La
    tabla layer_styles ya no se crea como una tabla más. Las tablas nuevas
    se crean antes de copiar los estilos. El estilo guardado se localiza
    aunque su fila tenga un f_geometry_column antiguo. Si no se puede
    rehacer el formulario, se informa en vez de marcarlo como corregido.

Empaquetado
  - El icono de la versión QGIS 3 era un marcador provisional. Ahora es el
    mismo que el de QGIS 4.
  - plugins.xml: la versión mínima de QGIS 3 pasa a 3.44, la que exige el
    plugin. Antes anunciaba 3.28.

PENDIENTE (no corregido en esta versión)
----------------------------------------
  - Plegado automático de los grupos del formulario: QGIS 3.44 no expone
    setCollapsedExpression en Python, así que los grupos quedan siempre
    plegados.
  - Modo Visualización: oculta las entidades con Tipo vacío o que solo se
    dibujaban con la categoría "resto de valores".
  - Nueva Obra no copia la tabla ASPECTOS (el desplegable de Aspecto
    Ambiental sale vacío hasta pasar "Actualiza GPKG").
  - Fotos:
      · el OCR de fechas puede bloquear la interfaz con muchas fotos sin
        fecha;
      · estampar la fecha borra el EXIF de la copia (incluida la
        orientación);
      · los planos de situación mezclan sistemas de coordenadas si capa y
        proyecto no coinciden;
      · capas MultiPoint.
  - Consulta:
      · el esquema y el SRC del resultado salen de la primera obra;
      · no se comprueba si addFeatures falla;
      · el zoom no transforma coordenadas;
      · los botones siguen activos durante el escaneo.
  - KMZ: identificadores de estilo de punto compartidos entre capas, y
    valores con caracteres no válidos en nombres de fichero.
  - core/kmz_exporter.py y core/multiobra_engine.py: código que no se usa.

CÓMO SE COMPROBÓ
----------------
py_compile y pyflakes en ambas copias. Las pruebas de lógica con
simulación de QGIS (carga, actualización, formulario, grupos y subgrupos,
grupo con el mismo nombre de otra obra) siguen pasando. La lectura de EXIF
se probó con una imagen real y Pillow 12.2. La paridad QGIS 3 / QGIS 4 se
comprobó con diff: solo cambia la sintaxis de Qt y la corrección de
QBuffer. No verificado con QGIS real.

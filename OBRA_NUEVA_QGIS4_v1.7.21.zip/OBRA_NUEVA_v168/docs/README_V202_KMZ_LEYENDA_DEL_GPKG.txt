V202 - EL KMZ MANTIENE LA LEYENDA DEL GEOPACKAGE (1.7.15)
=========================================================

PETICIÓN
--------
"Quiero que se mantenga la leyenda del gpkg" en la exportación KMZ.

CÓMO ERA
--------
  - La simbología salía de la capa del lienzo si estaba cargada (con la
    simbología que tuviera en ese momento, p. ej. recortada en modo
    Visualización) y, si no, del GeoPackage.
  - Solo se entendían los renderizadores categorizados. Los colores eran
    aproximados:
      · líneas siempre de 1,5 px;
      · polígonos siempre rellenos, con borde gris fijo (un polígono solo
        con contorno salía relleno);
      · puntos de símbolo único con un círculo rojo genérico.
  - La leyenda usaba el texto de la tabla CLAVE de cada elemento, no el de
    la leyenda, en un orden cualquiera. Había una imagen por capa y todas
    se superponían en la misma esquina de la pantalla.

CÓMO ES AHORA (ui/tab_kmz.py)
-----------------------------
  - Simbología: se usa el estilo guardado en el propio GeoPackage (tabla
    layer_styles), es decir, su leyenda, aunque la capa esté cargada en el
    lienzo con otra. Solo si el GeoPackage no guarda estilo para esa
    tabla se usa la del lienzo.
  - Asignación de símbolo: cada elemento recibe el mismo símbolo con el
    que lo dibuja QGIS (legendKeysForFeature). Funciona con cualquier tipo
    de leyenda: categorizada, graduada, por reglas o de símbolo único.
  - Puntos: icono generado con el propio símbolo de QGIS.
  - Líneas: color y grosor reales (mm, pt o px convertidos a píxeles) y
    transparencia del símbolo.
  - Polígonos:
      · color y transparencia del relleno, y color y grosor del contorno;
      · sin relleno o sin contorno si el símbolo no los tiene;
      · los rellenos que KML no puede dibujar (tramas, degradados) salen
        como color semitransparente.
  - Leyenda: una sola imagen para todo el KMZ, con un apartado por capa.
    Cada apartado lleva los mismos iconos, textos y orden que la leyenda
    del GeoPackage en QGIS.
  - Nueva casilla "Leyenda completa del GeoPackage (incluir también
    categorías sin elementos)": desmarcada, la leyenda solo incluye las
    categorías que tienen elementos en lo exportado; marcada, incluye
    todas.
  - Elementos sin categoría: los que no corresponden a ninguna categoría
    de la leyenda (QGIS no los dibuja) se exportan igualmente en gris, con
    la fila "Otros (sin categoría en la leyenda)" y un aviso en el
    registro.
  - Identificadores: los estilos usan identificadores por capa y
    categoría. Ya no se mezclan iconos entre capas ni se rompe la
    exportación por caracteres raros en los valores.

CÓMO SE COMPROBÓ
----------------
Con QGIS 3.34 real (bibliotecas de Python, sin interfaz) se creó un
GeoPackage de prueba con:
  - polígonos: una categoría solo con contorno rojo de 0,8 mm, otra con
    relleno azul semitransparente, una categoría sin elementos y un
    elemento sin categoría;
  - líneas: una continua de 1,2 mm y otra discontinua de 0,4 mm;
  - puntos: triángulo y cuadrado.
Además se cargó en el lienzo la misma capa de polígonos con otra
simbología.

Resultados:
  - el KMZ usa la del GeoPackage;
  - el polígono de contorno sale sin relleno;
  - los grosores salen a 3,0 / 4,5 / 1,5 px;
  - la leyenda, revisada visualmente, coincide con la de QGIS en ambos
    modos.

La copia QGIS 4 se genera con la misma conversión Qt5 -> Qt6 de siempre,
que se comprobó reproduciendo exactamente el fichero QGIS 4 anterior.
Pendiente de prueba con QGIS 3.44 y QGIS 4 en Windows.

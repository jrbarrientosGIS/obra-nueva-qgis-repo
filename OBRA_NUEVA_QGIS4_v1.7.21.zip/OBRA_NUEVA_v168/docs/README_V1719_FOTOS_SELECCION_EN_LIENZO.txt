OBRA_NUEVA 1.7.19 - Fotos: selección sobre el lienzo
====================================================

1. Bloque 2, "1. Seleccionar en el Lienzo": activa una herramienta de clic.
   No hace falta tener la entidad seleccionada antes. Se pincha sobre el
   lienzo la entidad cuya foto se quiere colocar (de cualquier capa visible;
   si hay varias cerca, la más próxima al clic). Se abre la vista previa de
   la foto, se pincha el punto definitivo y la foto queda en fotos_georref.
2. Las coordenadas del punto elegido (WGS84) se graban como EXIF GPS en la
   foto original. La fecha de modificación del fichero no cambia, así que la
   fecha mostrada en fotos sin fecha EXIF no se altera. Si la foto es de solo
   lectura, no es JPG o está abierta en otro programa, se avisa en el registro.
   Con piexif instalado la grabación no recomprime la imagen; sin él se usa
   Pillow conservando la calidad de compresión.
3. La selección se repite para la foto siguiente hasta cancelar (ESC o botón
   Cancelar). Las fotos elegidas con "Seleccionar Fichero" o "Seleccionar
   Carpeta" no se modifican.
4. Bloque 3: la primera opción del botón "Seleccionar Fotos" se llama ahora
   "1. Preseleccionadas en el lienzo" (importa las fotos de las entidades que
   ya estén seleccionadas, de una o varias capas).
5. La 1.7.18 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.18.zip y
   OBRA_NUEVA_QGIS4_v1.7.18.zip.

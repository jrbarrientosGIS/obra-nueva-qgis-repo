OBRA_NUEVA
==========

Instalación
-----------
Recomendado: Complementos > Administrar e instalar complementos > Instalar a
partir de ZIP, y elegir OBRA_NUEVA_QGIS3.zip (QGIS 3.44 o superior) u
OBRA_NUEVA_QGIS4.zip (QGIS 4).

Instalación manual:
1. Copiar la carpeta OBRA_NUEVA_v168 (con ese nombre exacto) dentro de:
   %APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\
   Si ya existe, borrarla antes por completo.
2. Reiniciar QGIS.
3. Activar el complemento desde el administrador de complementos.

La carpeta se llama siempre OBRA_NUEVA_v168, sea cual sea la versión. Una
carpeta con otro nombre (p. ej. OBRA_NUEVA) dejaría el plugin duplicado.

Pestañas
--------
- Nueva Obra: crea una obra a partir del GeoPackage modelo y la carga agrupada.
- Carga Obra: carga una obra existente en modo Edición o Visualización.
- KMZ: exporta las capas a un KMZ con la leyenda del GeoPackage.
- Consulta: consulta varias obras a la vez y exporta el resultado.
- Fotos: fotos georreferenciadas y anejo fotográfico (DOCX).
- Actualiza GPKG: pone una obra (o una carpeta de obras) al día con el modelo.
- Archivar GPKG: copia una obra terminada con sus adjuntos accesibles.

Pruebas
-------
El paquete obra_nueva_tests (aparte del plugin) comprueba con QGIS real los
flujos principales. Ver su README.

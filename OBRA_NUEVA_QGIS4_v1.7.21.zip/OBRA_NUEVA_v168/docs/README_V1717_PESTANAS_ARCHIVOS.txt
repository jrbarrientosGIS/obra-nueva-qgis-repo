OBRA_NUEVA 1.7.17 - Reorganización de pestañas
==============================================

1. Orden de las pestañas: Nueva Obra, Carga Obra, Fotos, Consulta y Archivos.
2. Archivos: tres opciones, una por fila: Exporta a KML/KMZ, Actualiza GPKG y
   Archivar GPKG. Al pulsar una se abre su cuadro de diálogo (el contenido de
   las antiguas pestañas KMZ, Actualiza GPKG y Archivar GPKG, sin cambios).
   Cada cuadro de diálogo lleva su consola de estado (Archivar GPKG, como
   antes, no la usa); los mensajes también llegan a la consola principal.
3. Fotos: los tres bloques reparten el alto por igual.
4. La pestaña con la que se abre la ventana se recuerda con una clave nueva
   (last_tab_1717): los ajustes antiguos no apuntan a la pestaña equivocada.
5. Versión 1.7.17 en metadata.txt; la cabecera inferior de la ventana la lee
   de ahí. La 1.7.16 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.16.zip y
   OBRA_NUEVA_QGIS4_v1.7.16.zip.

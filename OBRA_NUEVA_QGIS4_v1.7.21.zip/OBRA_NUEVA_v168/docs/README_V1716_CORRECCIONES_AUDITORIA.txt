OBRA_NUEVA 1.7.16 - Correcciones de la auditoría de la 1.7.15
=============================================================

Versión correctiva que aplica las recomendaciones de la auditoría
(28/10/2026). Resumen por pestaña (detalle en el registro de cambios del
gestor de complementos y en la ayuda, sección 14):

- Formulario de atributos: el modo "arrastrar y soltar" se fija antes de
  modificar el formulario, así que el grupo ASPECTO-ZONA, la limpieza de
  campos repetidos y el plegado se guardan de verdad (A1).
- Consulta: no escanea sus propias exportaciones (A2), filtra Tipo por
  descripción (A3), unión de campos y SRC común, zoom transformado,
  botones bloqueados mientras trabaja, CSV abierto en Excel.
- Archivar GPKG: compara carpetas con os.path.samefile y nunca toca el
  origen (A4); carpeta por defecto de los adjuntos, enlaces web, sin copias
  a medias.
- KMZ: XML siempre válido (A5), categorías desmarcadas, colores por campo,
  líneas con borde, rellenos con trama, SRC ausente, leyenda en columnas.
- Fotos: OCR limitado (A6), clic en el SRC de la capa, Nº sin repetir, EXIF
  conservado al estampar, multipuntos, manifiesto acumulado.
- Nueva Obra: mismo cargador que Carga Obra, sobrescribir con la obra
  cargada, ASPECTOS, columna de geometría del estilo, validación del nombre.
- Actualiza GPKG: capas operativas que faltan, códigos de CLAVE/ASPECTOS,
  estilos alternativos del usuario, layer_styles sin id, mensajes correctos.
- Carga Obra: desplegable de Aspecto en la primera carga, grupos con capas de
  otros GeoPackage, capas de apoyo ocultas, "resto de valores" en
  Visualización, campos con la capa en edición, polígonos curvos.
- QGIS 4: tipos de campo con QMetaType (A7), enums de QgsVectorFileWriter con
  su nombre completo, supportsQt6=True.
- Código: una sola normalización de nombres, siete módulos sin uso
  eliminados, registro de mensajes unificado, ayuda y README al día,
  historial en "changelog".

Pendiente: probar la build de QGIS 4 en un QGIS 4 real. Conocido sin
corregir: los grupos del formulario solo se buscan en el primer nivel.

Pruebas: paquete obra_nueva_tests (92 pruebas con QGIS real).

OBRA_NUEVA 1.7.18 - Pestaña Fotos: botón "Seleccionar Fotos"
=============================================================

1. Bloques 2 y 3: las órdenes de selección se agrupan en un botón
   "1)  Seleccionar Fotos" que despliega tres opciones:
     1. Seleccionar en el Lienzo
     2. Seleccionar Fichero (antes "Seleccionar foto individual")
     3. Seleccionar Carpeta
2. Bloque 3, "Seleccionar en el Lienzo": admite selección múltiple, de varias
   entidades y de varias capas a la vez. Si hay selección en más de una capa,
   se pide confirmación antes de importar. No repite una misma foto en el
   mismo punto.
3. Bloque 2, "Seleccionar en el Lienzo": añade a la cola las fotos de las
   entidades seleccionadas en la capa activa; después se colocan una a una
   con "2) Iniciar / continuar colocación", como las de una carpeta.
4. Botones reordenados de arriba abajo y de izquierda a derecha según su
   número de paso; textos de ayuda y estados en gris, más discretos.
5. La 1.7.17 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.17.zip y
   OBRA_NUEVA_QGIS4_v1.7.17.zip.

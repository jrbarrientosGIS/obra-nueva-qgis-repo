OBRA_NUEVA 1.7.20 - Fotos, bloque 2: solo ubicación y fecha
===========================================================

1. El bloque 2 se desliga del bloque 3 y se ciñe a ubicación y fecha:
   - Las coordenadas del punto pinchado se graban (EXIF GPS, WGS84) en la
     foto ORIGINAL, tanto si se elige en el lienzo como si es un fichero o una
     carpeta.
   - Si se decide estampar una fecha, se imprime en la foto original y se
     guarda también como fecha EXIF (así no se vuelve a pedir ni se estampa dos
     veces). La fecha de modificación del fichero no cambia.
2. Desaparecen en este bloque: la casilla "Seleccionar para informe final",
   la descripción, el botón "3) Exportar imágenes georref", los estados de
   fotos_georref y puntos_informes_pre y la creación de la capa fotos_georref.
3. Una vez por sesión se pide confirmación antes de modificar originales.
4. Botones: 1) Seleccionar Fotos (lienzo / fichero / carpeta), Eliminar
   seleccionadas de la cola, Cancelar y 2) Iniciar / continuar colocación.
5. La 1.7.19 se conserva en el repositorio como OBRA_NUEVA_QGIS3_v1.7.19.zip y
   OBRA_NUEVA_QGIS4_v1.7.19.zip.
